-- Gun Game Mod By Blazzingxx
-- author: Blazzingxx
-- version: 1.1 (Beta)
-- release date: 2009/09/30

-- Dofiles
gg_dir = 'sys/lua/gungame/gg_'
ut_dir = 'fun/'
snd_dir = 'gungame/gg_'
dofile(gg_dir..'config.cfg')
dofile(gg_dir..'settings.cfg')
dofile(gg_dir..'values.lua')
dofile(gg_dir..'func_up.lua')
dofile(gg_dir..'console.lua')
dofile(gg_dir..'filter.lua')
dofile(gg_dir..'func_m.lua')
dofile(gg_dir..'func.lua')

addhook("team","gg_team")
addhook("join","gg_join")
addhook("leave","gg_leave")
addhook("parse","gg_parse")
addhook("spawn","gg_spawn")
addhook("minute","gg_min")
addhook("startround","gg_startround")
addhook("menu","gg_menu")
addhook("serveraction","gg_bind")
addhook("walkover","gg_walk")
addhook("die","gg_die")
addhook("drop","gg_drop")
addhook("buy","gg_buy")
addhook("say","gg_say")
if (gg_warmup > 0) then
	addhook("second","gg_sec")
else
	addhook("kill","gg_kill")
	addhook("hit","gg_hit")
	addhook("attack","gg_attack")
end