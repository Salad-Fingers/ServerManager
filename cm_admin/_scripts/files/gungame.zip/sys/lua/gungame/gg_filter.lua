-- Gun Game Cmd Filter

if (gg_p_health < 1 or gg_p_health > 250) then 
	gg_p_health = 100
	gg_print(4,'Incorect gg_p_health Configuration! (Set As Default)')
end
if (gg_p_armor < 0 or gg_p_armor > 200) then 
	gg_p_armor = 25
	gg_print(4,'Incorect gg_p_armor Configuration! (Set As Default)')
end
if (gg_warmup_time < 5 or gg_warmup_time > 120) then 
	gg_warmup_time = 35
	gg_print(4,'Incorect gg_warmup_time Configuration! (Set As Default)')
end
if (gg_warmup_wpn < 1 or gg_warmup_wpn > 255) then 
	gg_warmup_wpn = 51
	gg_print(4,'Incorect gg_warmup_wpn Configuration! (Set As Default)')
end
if (gg_rank_count < 10 or gg_rank_count > 150) then 
	gg_rank_count = 15
	gg_print(4,'Incorect gg_rank_count Configuration! (Set As Default)')
end
if (gg_rank_update < 1 or gg_rank_update > 5) then 
	gg_rank_update = 1
	gg_print(4,'Incorect gg_rank_update Configuration! (Set As Default)')
end
if (gg_wpn_need < 1 or gg_wpn_need > 15) then 
	gg_wpn_need = 3
	gg_print(4,'Incorect gg_wpn_need Configuration! (Set As Default)')
end
if (gg_points < 1 or gg_points > 100) then 
	gg_points = 1
	gg_print(4,'Incorect gg_points Configuration! (Set As Default)')
end
if (gg_points_winner < 1 or gg_points_winner > 200) then 
	gg_points_winner = 15
	gg_print(4,'Incorect gg_points_winner Configuration! (Set As Default)')
end
if (gg_vote_rounds < 1 or gg_vote_rounds > 5) then 
	gg_vote_rounds = 3
	gg_print(4,'Incorect gg_vote_rounds Configuration! (Set As Default)')
end
if (gg_vote_time < 1 or gg_vote_time > 60) then 
	gg_vote_time = 30
	gg_print(4,'Incorect gg_vote_time Configuration! (Set As Default)')
end
if (gg_vote_wpn < 1 or gg_vote_wpn > 255) then 
	gg_vote_wpn = 51
	gg_print(4,'Incorect gg_vote_wpn Configuration! (Set As Default)')
end
if (gg_team_game > 0) then gg_print(2,'Team-Mode Activated!') end