-- Gun Game Functions Update

function gg_print(c,t)
	print(color[c]..'[GG] '..t)
end

function gg_txt2(p,s,c,t,x,y,a)
	parse('hudtxt2 '..p..' '..s..' "'..color[c]..''..t..'" '..x..' '..y..' '..a..'')
end

function gg_txt(s,c,t,x,y,a)
	parse('hudtxt '..s..' "'..color[c]..''..t..'" '..x..' '..y..' '..a..'')
end

function gg_msg2(p,c,t)
	msg2(p,color[c]..''..t)
end

function gg_msg(c,t)
	msg(color[c]..''..t)
end

function gg_player_set(p)
	parse('setmaxhealth '..p..' '..gg_p_health)
	parse('setarmor '..p..' '..gg_p_armor)
end

function gg_equip(p)
	parse('equip '..p..' '..gg_wpn[set_p_val(p,2)])
end

function gg_equip2(p,n)
	parse('equip '..p..' '..n)
	parse('setweapon '..p..' '..n)
end

function gg_equip3(p)
	parse('equip '..p..' '..gg_wpn[set_p_val(p,2)])
	parse('setweapon '..p..' '..gg_wpn[set_p_val(p,2)])
	if (set_p_val(p,2) > 1 and set_p_val(p,2) <= #gg_wpn) then parse('strip '..p..' '..gg_wpn[set_p_val(p,2)- 1]) end
end

function gg_equip4(p)
	local t = player(p,"team")
	parse('equip '..p..' '..gg_team_wpn[team_lvl[t]])
	parse('setweapon '..p..' '..gg_team_wpn[team_lvl[t]])
	if (team_lvl[t] > 1 and team_lvl[t] <= #gg_team_wpn) then parse('strip '..p..' '..gg_team_wpn[team_lvl[t]- 1]) end
end

function ut_snd(s)
	if (gg_ut_sound > 0) then
		parse('sv_sound '..ut_dir..''..gg_ut_snd[s]..'.wav')
	end
end

function gg_snd(s)
	if (gg_sound > 0) then
		parse('sv_sound '..snd_dir..''..gg_adv_snd[s]..'.ogg')
	end
end

function gg_snd2(p,s)
	if (gg_sound > 0) then
		parse('sv_sound2 '..p..'  '..snd_dir..''..gg_adv_snd[s]..'.ogg')
	end
end