-- Gun Game Functions

if (gg_rank > 0) then
	gg_rank_ld()
	gg_rank_sv()
	if (gg_rank_diplay > 0) then gg_server_inf_ld() end
end

function gg_sec()
	gg_warmup_func()
end

function gg_startround()
	if (gg_team_game < 1) then
		gg_start_game()
	else
		gg_start_team()
	end
end

function gg_team(p,t)
	gg_lvl_check(p)
	if (p_load[p] < 1) then
		if (gg_basic_join_sound > 0) then gg_snd2(p,1) end
		gg_p_ld(p)
		p_load[p] = 1
		if (warmup_rnd < 1 and lead_id > 0) then
			if (set_p_val(lead_id,2) > 5) then
				set_p_stata(p,2,set_p_val(lead_id,2) - 4)
				gg_msg2(p,2,'Your Level Set! ('..(set_p_val(lead_id,2) - 4)..')@C')
			end
		end
		if (gg_team_game < 1) then
			gg_hud_update(p)
		else
			gg_hud_team(p,t)
		end
		if (gg_vote_sec > 0 and gg_vote_rnd < 1) then gg_vote_menu(p) end
	end
	if (gg_team_game > 0) then
		gg_hud_team(p,t)
	end
end

function gg_join(p)
	if (gg_basic_join_msg > 0) then gg_msg2(p,6,'Welcome To Gun Game (v1.1) Server!@C') end
	p_load[p] = 0
	gg_res_normal(p)
end

function gg_leave(p)
	if (gg_team_game < 1) then
		if (p == lead_id) then
			gg_msg(4,'[GG] Gun Game Leader Left The Game!')
			lead_pt = 0
			local i
			for i = 1,p_cnt do
				if (player(i,"exists") and i ~= p) then gg_leader(i) end
			end
		end
	end
	for i = 1,7 do set_gg_stata(p,i,0) end
end

function gg_spawn(p)
	if (warmup_rnd < 1) then 
		gg_ut_lvl[p] = 0
		gg_player_set(p)
		if (gg_team_game < 1) then
			return gg_wpn[set_p_val(p,2)]
		else
			return gg_team_wpn[team_lvl[player(p,"team")]]
		end
	else
		return gg_warmup_wpn
	end
end

function gg_kill(p,v,w)
	ut_blood(p)
	if (player(p,"team") ~= player(v,"team")) then
		set_gg_statb(p,2,1)
		if (gg_team_game < 1) then
			if (w == 50 and set_p_val(p,2) < 23 and set_p_val(v,2) < 23) then
				gg_knife_norm(p,v,w)
			else
				gg_kill_norm(p,w)
				gg_levelup_norm(p)
			end
			if (set_p_val(p,2) <= #gg_wpn) then gg_leader(p) end
		else
			if (w == 50 and team_lvl[player(p,"team")] < 15) then gg_knife_team(p,v) end
			gg_kill_team(p,w)
			gg_levelup_team(p)
			if (team_lvl[player(p,"team")] <= #gg_team_wpn) then gg_leader_team(p) end
		end
		if (gg_rank > 0 and player(p,"usgn") > 0 and set_gg_val(p,4) > gg_rank_score[gg_rank_count]) then gg_rank_check(p) end
		gg_p_sv(p)
	end	
end

function gg_hit(p,k,w)
	if (w ~= 50) then set_gg_statb(k,7,1) end
end

function gg_menu(p,m,s)
	if (m == 'Map Voting!') then
		if (s > 0) then
			if (p_vote[p] < 1 and gg_vote_rnd < 1) then
				gg_vote_votes = gg_vote_votes + 1
				map_vote[s] = map_vote[s] + 1
				p_vote[p] = 1
				local i
				local ratio = 0
				gg_txt(3,3,'Map Voting:',6,180,0)
				for i = 1,#gg_vote_maps do
					if (gg_vote_votes > 0) then
						ratio = math.ceil(100 * (map_vote[i] / gg_vote_votes)) 
					else
						ratio = 0
					end
					gg_txt(i + 3,1,gg_vote_maps[i]..' ('..map_vote[i]..' - '..ratio..'%)',6,180 + (i * 15),0)
				end
				gg_msg2(p,6,'Your Vote: '..gg_vote_maps[s]..'@C')
				if (gg_vote_msg > 0) then gg_msg(6,'[GG] '..player(p,"name").. ' vote '..gg_vote_maps[s]) end
			else
				gg_msg2(p,4,'You Already Voted!@C')
			end
		end
	end
	if (m == 'Gun Game 1.1 Menu') then
		if (s == 1) then gg_main_say(p) end
		if (s == 2) then gg_script_cfg(p) end
		if (s == 3) then gg_script_inf(p) end
	end
	if (m == 'Say Commands') then
		if (s >= 1 and s <= #gg_say_cmd) then gg_say_action(p,s) end
	end
end

function gg_bind(p,a)
	if (a == 1) then gg_main_menu(p) end
	if (a == 2) then gg_main_say(p) end
end

function gg_say(p,t)
	if (t == gg_say_cmd[1]) then gg_say_action(p,1) end
	if (t == gg_say_cmd[2]) then gg_say_action(p,2) end
	if (t == gg_say_cmd[3]) then gg_say_action(p,3) end
	if (t == gg_say_cmd[4]) then gg_say_action(p,4) end
end

function gg_min()
	gg_minutes = gg_minutes + 1
	if (gg_rank > 0) then
		gg_rank_minutes = gg_rank_minutes + 1
		if (gg_rank_minutes >= gg_rank_update) then
			gg_rank_sv()
			gg_server_inf_sv()
			gg_rank_minutes = 0
		end
	end
	if (gg_minutes == 1) then
		gg_msg(6,'===== Gun Game =====')
		gg_msg(3,'Author: Blazzingxx')
		gg_msg(3,'Version: 1.1 Beta')
		gg_msg(3,'Release: 2009/09/30')
	end
	if (gg_minutes > 2) then
		gg_msg(6,'[GG] Press F2 to show the game menu')
		gg_msg(6,'[GG] Press F3 to see all say commands')
		gg_minutes = 0
	end
end

function gg_attack(p)
	if (player(p,"weapontype") ~= 50) then set_gg_statb(p,6,1) end
end

function gg_die(p,k,w)
	if (warmup_rnd < 1) then set_gg_statb(p,3,1) end
	if (w < 51 or w > 71) then return 1 end
end

function gg_drop(p,k,w)
	if (w < 53 or w > 71) then return 1 end
end

function gg_buy(p)
	return 1
end

function gg_walk(p,k,w)
	if (w < 51 or w > 71) then return 1 end
end