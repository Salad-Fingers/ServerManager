-- Gun Game Console

-- Console Function
function gg_parse(cmd)
	if (string.sub(cmd, 1, 13) == 'sv_maxplayers') then
		gg_print(4,'You cant change max players in the game!')
		gg_print(4,'Change it before starting server!')
		return 2
	end
	if (string.sub(cmd, 1, 13) == 'sv_restart') then
		gg_rnd_start = 0
		gg_msg(2,'Admin Restarted Round!@C')
		if (gg_warmup > 0) then
			warmup_sec = gg_warmup_time
			warmup_rnd = gg_warmup
			if (gg_vote_rnd > 0) then
				addhook("second","gg_sec")	
			end
			freehook("kill","gg_kill")
			freehook("hit","gg_hit")
			freehook("attack","gg_attack")
		else
			if (gg_vote_rnd < 1) then
				warmup_rnd = gg_warmup
				freehook("kill","gg_kill")
				freehook("hit","gg_hit")
				freehook("attack","gg_attack")
			end
		end
		if (gg_vote_rnd < 1) then addhook("second","gg_vote_func") end
		parse('restart')
		return 2
	end
	return 0
end