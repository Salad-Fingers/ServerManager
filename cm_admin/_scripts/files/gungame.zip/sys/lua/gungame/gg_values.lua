-- Gun Game Valuables

function array(m)
	local array = {}
	for i = 1, m do
		array[i] = 0
	end
	return array
end

function arrays(m,n)
	local arrays = {}
	for i = 1, m do
		arrays[i] = n
	end
	return arrays
end

function set_gg_val(p,n)
	local set_val = {}
	set_val = gg_p_stats[7 * (p - 1) + n]
	return set_val
end

function set_gg_stata(p,n,m)
	gg_p_stats[7 * (p - 1) + n] =  m
end

function set_gg_statb(p,n,m)
	gg_p_stats[7 * (p - 1) + n] = gg_p_stats[7 * (p - 1) + n] + m
end

function set_p_val(p,n)
	local set_p_val = {}
	set_p_val = p_stats[3 * (p - 1) + n]
	return set_p_val
end

function set_p_stata(p,n,m)
	p_stats[3 * (p - 1) + n] = m
end

function set_p_statb(p,n,m)
	p_stats[3 * (p - 1) + n] = p_stats[3 * (p - 1) + n] + m
end

p_cnt = game('sv_maxplayers')
gg_mode = game('sv_gamemode')
p_load = array(p_cnt)
p_stats = array(p_cnt * 3)
gg_p_state_name = {'Knife Kills','Kills','Deaths','Points','Wins','Shots','Hits'}
gg_p_stats = array(p_cnt * 7)
gg_cfg_info = {'Off','On'}
gg_say_cmd = {'!help','!commands','!stats','!toplist'}
gg_say_info = {'Gun Game Main Menu','All Say Commands','Your Stats','Watch Top 10'}
gg_adv_snd = {'game','gong','kill','levelup','down','lead','lost','tied','power','knifelvl'}
gg_ut_snd = {'Doublekill','Multikill','Ultrakill','Monsterkill','Killingspree','Rampage','Unstoppable',Godlike,'Prepare','Firstblood','Humiliation'}
gg_ut_fblood = 0
gg_ut_lvl = array(p_cnt)
gg_rnd_start = 0
gg_minutes = 0
lead_id = 0
lead_pt = 0
lead_tie = ''
tm_wpn = {2,1,3}
if (gg_team_game > 0) then
	team_name = {'Terrorists','Counter-Terrorists'}
	team_pt =  array(2)
	team_lvl =  arrays(2,1)
end
if (gg_rank > 0) then
	gg_rank_name = arrays(gg_rank_count,'(None)')
	gg_rank_usgn = array(gg_rank_count,0)
	gg_rank_wins = array(gg_rank_count)
	gg_rank_score = array(gg_rank_count)
	gg_rank_state = {'USGN','Score','Wins','Name'}
	gg_rank_work = 0
	gg_info_line = {}
	gg_rank_minutes = 0
end
if (gg_vote > 0) then
	gg_vote_rnd = gg_vote_rounds
else
	gg_vote_rnd = 1
end
p_vote = array(p_cnt)
map_vote = array(#gg_vote_maps)
gg_vote_votes = 0
gg_vote_sec = gg_vote_time
warmup_sec = gg_warmup_time
warmup_rnd = gg_warmup
color = {'�255200000','�000255000','�160160255','�255000000','�240000240','�255128064','�255255255','�100255100'}