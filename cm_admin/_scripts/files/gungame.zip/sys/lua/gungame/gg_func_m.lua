-- Gun Game Mini Functions

function gg_warmup_func()
	if (warmup_rnd > 0 and warmup_sec > 0) then
		if (warmup_sec == gg_warmup_time) then
			gg_msg(8,'[GG] Warmup round - ('..itemtype(gg_warmup_wpn,"name")..') ONLY')
			gg_msg(5,'Warmup Round!@C')
			gg_msg(3,'Weapon: '..itemtype(gg_warmup_wpn,"name")..'@C')
			parse('sv_gamemode 2')
		end
		local i
		for i = 1,p_cnt do gg_equip2(i,gg_warmup_wpn) end 
		warmup_sec = warmup_sec - 1
		gg_txt(2,5,'Warmup round: '..warmup_sec..' seconds left',320,440,1)
		if (warmup_sec == 0) then
			warmup_rnd = 0
			gg_msg(5,'Warmup End!@C')
			parse('restart')
			freehook("second","gg_sec")
			addhook("kill","gg_kill")
			addhook("hit","gg_hit")
			addhook("attack","gg_attack")
		end
	end
end

function gg_vote_func()
	if (gg_vote_sec > 0 and gg_vote_rnd < 1) then
		if (gg_vote_sec == gg_vote_time) then
			local s
			for s = 1,3 do gg_txt(s,1,'',0,0,0) end
			gg_msg(5,'Vote Map Round!@C')
			gg_msg(3,'Weapon: '..itemtype(gg_warmup_wpn,"name")..'@C')
			parse('sv_gamemode 2')
			gg_vote_menu(0)
			gg_txt(3,3,'Map Voting:',6,180,0)
			for i = 1,#gg_vote_maps do
				gg_txt(i + 3,1,gg_vote_maps[i]..' (0 - 0%)',6,180 + (i * 15),0)
			end
		end
		local i
		for i = 1,p_cnt do gg_equip2(i,gg_vote_wpn) end 
		gg_vote_sec = gg_vote_sec - 1
		gg_txt(2,6,'Vote map round: '..gg_vote_sec..' seconds left',320,440,1)
	else
		local vote_select = 1
		local vote_win = 0
		local vote_cnt = 1
		local vote_tie = {}
		local vote_rand
		local i
		for i = 1,#gg_vote_maps do
			if (map_vote[i] > vote_win) then
				vote_tie = array(vote_cnt)
				vote_win = map_vote[i]
				vote_select = i
				vote_cnt = 1
				vote_tie[vote_cnt] = i
			elseif (map_vote[i] == vote_win) then
				vote_cnt = vote_cnt + 1
				vote_tie[vote_cnt] = i
			end
		end
		if (vote_cnt > 1) then
			print('Random select!')
			vote_rand = math.random(1,vote_cnt)
			vote_select = vote_tie[vote_rand]
			print('Voted ID: '..vote_rand..' Voted Name: '..gg_vote_maps[vote_select])
		end
		if (gg_vote_maps[vote_select] ~= map("name")) then
			parse('changemap '..gg_vote_maps[vote_select])
		else
			gg_msg(5,'Map Continue! ('..map("name")..')@C')
			gg_vote_sec = gg_vote_time
			gg_vote_rnd = gg_vote_rounds
			warmup_rnd = 0
			gg_rnd_start = 0
			addhook("kill","gg_kill")
			addhook("hit","gg_hit")
			addhook("attack","gg_attack")
			parse('restart')
		end
		freehook("second","gg_vote_func")
		for i = 1,#gg_vote_maps do gg_txt(i + 3,1,'',0,0,0) end
	end
end

function gg_start_game()
	gg_ut_fblood = 0
	if (warmup_rnd < 1 and gg_rnd_start < 1) then
		gg_snd(2)
		ut_snd(9)
		gg_msg(7,'Prepare To Fight!!!@C')
		parse('sv_gamemode '..gg_mode)
		lead_id = 0
		lead_pt = 0
		gg_rnd_start = 1
		gg_vote_votes = 0
		map_vote = array(#gg_vote_maps)
		local i
		for i = 1,p_cnt do
			gg_res_normal(i)
			p_vote[i] = 0
			if (player(i,"exists")) then
				gg_equip(i)
				gg_hud_update(i)
				if (player(i,"team") > 0) then
					if (tm_wpn[player(i,"team")] ~= gg_wpn[1]) then
						parse('strip '..i..' '..tm_wpn[player(i,"team")])
					end
				end
			end
		end
	else
		if (warmup_rnd > 0) then
			for i = 1,3 do gg_txt(i,1,'',0,0,0) end
		end
	end
end

function gg_start_team()
	gg_ut_fblood = 0
	if (warmup_rnd < 1 and gg_rnd_start < 1) then
		gg_snd(2)
		ut_snd(9)
		gg_msg(7,'Prepare To Fight!!!@C')
		parse('sv_gamemode '..gg_mode)
		lead_id = 0
		lead_pt = 0
		gg_rnd_start = 1
		gg_vote_votes = 0
		map_vote = array(#gg_vote_maps)
		local i
		for i = 1,2 do
			team_pt[i] = 0
			team_lvl[i] = 1
		end
		for i = 1,p_cnt do
			p_vote[i] = 0
			if (player(i,"exists") and player(i,"team") > 0) then
				gg_equip4(i)
				gg_hud_team(i,player(i,"team"))
				if (player(i,"team") > 0) then
					if (tm_wpn[player(i,"team")] ~= gg_team_wpn[1]) then
						parse('strip '..i..' '..tm_wpn[player(i,"team")])
					end
				end
			end
		end
	else
		if (warmup_rnd > 0) then
			for i = 1,3 do gg_txt(i,1,'',0,0,0) end
		else
			if (gg_team_objective > 0) then
				local win
				local finish = 0
				if game("winrow_ct") > 0 then win = 2; end
				if game("winrow_t") > 0 then win = 1; end
				team_lvl[win] = team_lvl[win] + 1
				team_pt[win] = 0
				if (win == lead_id and team_lvl[win] <= #gg_team_wpn) then gg_msg(8,'[GG] '..team_name[win]..' is leading on lvl '..team_lvl[win].. ' (Round Winners)') end
				for i = 1,p_cnt do
					if (player(i,"team") == win) then
						if ( team_lvl[win] <= #gg_team_wpn) then
							gg_msg2(i,2,'Level Up!@C')
							gg_snd2(i,4)
							gg_txt2(i,2,1,'Required Kills: '..team_pt[win]..'/'..gg_team_k_need,322,410,1)
							gg_txt2(i,3,1,'Team Level: '..team_lvl[win]..' ('..itemtype(gg_team_wpn[team_lvl[win]],"name")..')',322,430,1)
						end
						if (finish < 1) then
							gg_win_check_team(i,1)
							finish = 1
						end
					end
				end
			end
		end
	end
end

function gg_hud_update(p)
	gg_txt2(p,0,2,'Gun Game Mod (v 1.1)',322,13,1)
	if (warmup_rnd < 1) then
		if (lead_id > 0) then
			gg_txt2(p,1,3,'Leader: '..player(lead_id,"name")..' ('..set_p_val(lead_id,2)..' - '..itemtype(gg_wpn[set_p_val(lead_id,2)],"name")..')',322,26,1)
		else
			gg_txt2(p,1,3,'Leader: '..player(p,"name")..' ('..set_p_val(p,2)..' - '..itemtype(gg_wpn[set_p_val(p,2)],"name")..')',322,26,1)
		end
		gg_txt2(p,2,1,'Need To Kill: '..set_p_val(p,1)..'/'..gg_wpn_need,322,410,1)
		gg_txt2(p,3,1,'Your Level: '..set_p_val(p,2)..' ('..itemtype(gg_wpn[set_p_val(p,2)],"name")..')',322,430,1)
	end
end

function gg_hud_team(p,t)
	gg_txt2(p,0,2,'Gun Game Mod (v 1.1)',322,13,1)
	if (warmup_rnd < 1 and t > 0) then
		if (lead_id > 0) then
			gg_txt2(p,1,3,'Leader: '..team_name[lead_id]..' ('..team_lvl[lead_id]..' - '..itemtype(gg_team_wpn[team_lvl[lead_id]],"name")..')',322,26,1)
		else
			gg_txt2(p,1,3,'Leader: '..team_name[t]..' ('..team_lvl[t]..' - '..itemtype(gg_team_wpn[team_lvl[t]],"name")..')',322,26,1)
		end
		gg_txt2(p,2,1,'Required Kills: '..team_pt[t]..'/'..gg_team_k_need,322,410,1)
		gg_txt2(p,3,1,'Team Level: '..team_lvl[t]..' ('..itemtype(gg_team_wpn[team_lvl[t]],"name")..')',322,430,1)
	end
end

function ut_blood(p)
	if (gg_ut_first_blood > 0) then
		if (gg_ut_fblood < 1) then
			ut_snd(10)
			gg_msg(7,player(p,"name")..' Sheds First Blood!!!@C')
			gg_ut_fblood = 1
		end
	end
	gg_ut_lvl[p] = gg_ut_lvl[p] + 1
	if (gg_ut_lvl[p] > 8) then
		gg_ut_lvl[p] = 8
	end
	if (gg_ut_lvl[p] > 1) then
		if (gg_ut_sound > 0) then gg_msg(3,player(p,"name")..': '..gg_ut_snd[gg_ut_lvl[p] - 1]..'!') end
		ut_snd(gg_ut_lvl[p] - 1)
	end
end

function gg_p_sv(p)
	if (player(p,"usgn") > 0) then
		f = assert(io.open(gg_dir..'data/'..player(p,"usgn")..'.txt','w'))
		f:write(set_gg_val(p,1)..'\n'..set_gg_val(p,2)..'\n'..set_gg_val(p,3)..'\n'..set_gg_val(p,4)..'\n'..set_gg_val(p,5)..'\n'..set_gg_val(p,6)..'\n'..set_gg_val(p,7))
		f:close()
	end
end

function gg_p_ld(p)
	local usgn = player(p,"usgn")
	if (usgn > 0) then
		gg_msg2(p,3,'Your U.S.G.N. ID: '..usgn..'@C')
		f = io.open(gg_dir..'data/'..usgn..'.txt','r')
		if (f ~= nil) then
			gg_msg2(p,2,'Your Save File Found!@C')
			local i = 0
			for line in f:lines() do
				i = i + 1
				if (i < 8) then set_gg_stata(p,i,tonumber(line)) end
			end
			f:close()
		else
			gg_msg2(p,4,'Failed To Load Save!@C')
		end
	else
		gg_msg2(p,4,'Please check your U.S.G.N. account settings!@C')
	end
	if (set_gg_val(p,2) < 1 or usgn < 1) then
		for i = 1,7 do set_gg_stata(p,i,0) end
	end
end


function gg_knife_team(p,v)
	local t = player(p,"team")
	team_pt[t] = team_pt[t] + 2
	if (set_gg_val(v,4) > 1) then set_gg_statb(v,4,- 2) end
	set_gg_statb(p,1,1)
	set_gg_statb(p,4,2)
	gg_msg(8,'[GG] '..player(p,"name")..' stole 2 points from '..player(v,"name"))
	if (gg_ut_knife > 0) then
		ut_snd(11)
		gg_msg(5,player(p,"name")..' Knifed '..player(v,"name")..'@C')
	end
	gg_snd2(p,9)
	gg_snd2(v,5)
	local i
	for i = 1, p_cnt do
		if (t == player(i,"team")) then
			gg_txt2(i,2,1,'Required Kills: '..team_pt[t]..'/'..gg_team_k_need,322,410,1)
		end
	end
end

function gg_kill_norm(p,w)
	if (gg_wpn[set_p_val(p,2)] == w) then
		gg_snd2(p,3)
		set_p_statb(p,1,1)
		set_p_statb(p,3,gg_points)
		set_gg_statb(p,4,gg_points)
		gg_win_check(p)
	else
		gg_win_check(p)
	end
	gg_txt2(p,2,1,'Need To Kill: '..set_p_val(p,1)..'/'..gg_wpn_need,322,410,1) 
end

function gg_knife_norm(p,v)
	gg_msg2(p,2,'Level Up!@C')
	set_p_statb(p,2,1)
	set_p_statb(v,2,-1)
	set_gg_statb(p,1,1)
	gg_lvl_check(v)
	set_p_statb(p,3,gg_points * gg_wpn_need)
	set_gg_statb(p,4,gg_points * gg_wpn_need)
	gg_msg(8,'[GG] '..player(p,"name")..' stole a level from '..player(v,"name"))
	if (gg_ut_knife > 0) then
		ut_snd(11)
		gg_msg(5,player(p,"name")..' Knifed '..player(v,"name")..'@C')
	end
	gg_snd2(p,9)
	gg_snd2(v,5)
	gg_win_check(p)
	if (v == lead_id) then
		lead_pt =  set_p_val(v,1) + gg_wpn_need * ((set_p_val(v,2) - 1))
		gg_txt(1,3,'Leader: '..lead_tie..' ('..set_p_val(v,2)..' - '..itemtype(gg_wpn[set_p_val(v,2)],"name")..')',322,26,1)
	end
	gg_txt2(p,3,1,'Your Level: '..set_p_val(p,2)..' ('..itemtype(gg_wpn[set_p_val(p,2)],"name")..')',322,430,1)
	gg_txt2(v,3,1,'Your Level: '..set_p_val(v,2)..' ('..itemtype(gg_wpn[set_p_val(v,2)],"name")..')',322,430,1)
	if (gg_wpn[set_p_val(p,2)] == 50) then gg_snd(10); gg_msg(5,player(p,"name")..' Reached Knife Level!@C') end
end

function gg_levelup_norm(p)
	local t = player(p,"team")
	if (set_p_val(p,1) >= gg_wpn_need) then
		set_p_stata(p,1,0)
		set_p_statb(p,2,1)
		gg_msg2(p,2,'Level Up!@C')
		set_gg_statb(p,6,1)
		gg_snd2(p,4)
		gg_win_check(p)
		gg_txt2(p,2,1,'Need To Kill: '..set_p_val(p,1)..'/'..gg_wpn_need,322,410,1)  
		if (set_p_val(p,2) <= #gg_wpn) then
			gg_txt2(p,3,1,'Your Level: '..set_p_val(p,2)..' ('..itemtype(gg_wpn[set_p_val(p,2)],"name")..')',322,430,1)
			if (p == lead_id) then gg_msg(8,'[GG] '..player(p,"name")..' is leading on lvl '..set_p_val(p,2)) end
			if (gg_wpn[set_p_val(p,2)] == 50) then gg_snd(10); gg_msg(5,player(p,"name")..' Reached Knife Level!@C') end
		end
	end
end

function gg_kill_team(p,w)
	local t = player(p,"team")
	if (gg_team_wpn[team_lvl[t]] == w) then
		gg_snd2(p,3)
		team_pt[t] = team_pt[t] + 1
		set_p_statb(p,3,gg_points)
		set_gg_statb(p,4,gg_points)
		if (team_pt[t] + 1 < gg_team_k_need) then gg_win_check_team(p,2) end
		local i
		for i = 1, p_cnt do
			if (t == player(i,"team")) then
				gg_txt2(i,2,1,'Required Kills: '..team_pt[t]..'/'..gg_team_k_need,322,410,1)
			end
		end
	else
		gg_win_check_team(p,2)
	end
end

function gg_leader_team(p)
	local t = player(p,"team")
	local t_pt = team_pt[t] + gg_team_k_need * (team_lvl[t] - 1)
	if (t_pt > lead_pt) then
		if (t ~= lead_id) then
			gg_msg(8,'[GG] '..team_name[t]..' took lead on lvl '..team_lvl[t])
			local i
			for i = 1, p_cnt do
				if player(i,"exists") then
					if (t == player(i,"team")) then
						gg_snd2(i,6)
					elseif (t ~= player(i,"team") and player(i,"team") > 0) then
						gg_snd2(i,7)
					end
				end
			end
		end
		lead_pt = t_pt
		lead_id = t
		lead_tie = ''
		gg_txt(1,3,'Leader: '..team_name[t]..' ('..team_lvl[t]..' - '..itemtype(gg_team_wpn[team_lvl[t]],"name")..')',322,26,1)
	elseif  (t_pt == lead_pt and t ~= lead_id) then
		gg_msg(8,'[GG] '..team_name[t]..' has tied the leader!')
		gg_txt(1,3,'Leader: '..team_name[1]..' + '..team_name[2]..' ('..team_lvl[t]..' - '..itemtype(gg_team_wpn[team_lvl[t]],"name")..')',322,26,1)
		local i
		for i = 1, p_cnt do
			if player(i,"exists") then
				if (t == player(i,"team")) then
					gg_snd2(i,8)
				elseif (t ~= player(i,"team") and player(i,"team") > 0) then
					gg_snd2(i,8)
				end
			end
		end
	end
end

function gg_levelup_team(p)
	local t = player(p,"team")
	if (team_pt[t] >= gg_team_k_need) then
		set_gg_statb(p,6,1)
		team_lvl[t] = team_lvl[t] + 1
		team_pt[t] = 0
		gg_win_check_team(p,1)
		if (team_lvl[t] <= #gg_team_wpn) then
			local i
			for i = 1, p_cnt do
				if player(i,"exists") then
					if (t == player(i,"team")) then
 						gg_msg2(i,2,'Level Up!@C')
						gg_snd2(i,4)
						gg_txt2(i,2,1,'Required Kills: '..team_pt[t]..'/'..gg_team_k_need,322,410,1)
						gg_txt2(i,3,1,'Team Level: '..team_lvl[t]..' ('..itemtype(gg_team_wpn[team_lvl[t]],"name")..')',322,430,1)
					end
				end
			end
			if (t == lead_id) then gg_msg(8,'[GG] '..team_name[t]..' is leading on lvl '..team_lvl[t]) end
			if (gg_team_wpn[team_lvl[t]] == 50) then gg_snd(10); gg_msg(5,team_name[t]..' Reached Knife Level!@C') end
		end
	end
end

function gg_win_check_team(p,m)
	local t = player(p,"team")
	local i
	if (team_lvl[t] > #gg_team_wpn) then
		if (gg_vote > 0) then gg_vote_rnd = gg_vote_rnd - 1 end
		for i = 1,p_cnt do
			if player(i,"exists") then
				if (t == player(i,"team")) then
					set_gg_statb(i,4,gg_points_winner * 3)
					set_p_statb(i,3,gg_points_winner * 3)
					set_gg_statb(i,5,1)
				end
			end
			if player(i,"exists") then gg_msg2(i,2,'[GG] This Round You Have Gained '..set_p_val(i,3)..' Points') end
		end
		gg_msg(2,'=== Winner ===@C')
		gg_msg(2,team_name[t]..'@C')
		gg_msg(2,'============@C')
		gg_msg(2,'=== Winner ===')
		gg_msg(2,team_name[t]..' (+ '..(3 * gg_points_winner)..' points)')
		for i = 1,2 do
			team_pt[i] = 0
			team_lvl[i] = 1
		end
		if (gg_warmup > 0) then
			warmup_sec = gg_warmup_time
			warmup_rnd = gg_warmup
			if (gg_vote_rnd > 0) then
				addhook("second","gg_sec")	
			end
			freehook("kill","gg_kill")
			freehook("hit","gg_hit")
			freehook("attack","gg_attack")
		else
			if (gg_vote_rnd < 1) then
				warmup_rnd = gg_warmup
				freehook("kill","gg_kill")
				freehook("hit","gg_hit")
				freehook("attack","gg_attack")
			end
		end
		if (gg_vote_rnd < 1) then addhook("second","gg_vote_func") end
		gg_rnd_start = 0
		parse('restart')
	else
		if (m == 1) then
			for i = 1,p_cnt do
				if (t == player(i,"team")) then
					gg_equip4(i)
				end
			end
		elseif (m == 2) then
			gg_equip4(p)
		end
	end
end

function gg_win_check(p)
	if (set_p_val(p,2) > #gg_wpn) then
		if (gg_vote > 0) then gg_vote_rnd = gg_vote_rnd - 1 end
		local winer_n = {'(None)','(None)'}
		local winer_p = {0,0}
		local winer_id = {0,0}
		local i
		local n
		for i = 1,p_cnt do
			if (player(i,"exists") and i ~=p and set_p_val(i,1) + gg_wpn_need * (set_p_val(i,2) - 1) > winer_p[2]) then
				for n = 1,2 do
					if (winer_p[3 - n] < set_p_val(i,1) + gg_wpn_need * (set_p_val(i,2) - 1)) then
						winer_n[4 - n] = winer_n[3 - n]
						winer_p[4 - n] = winer_p[3 - n]
						winer_id[4 - n] = winer_id[3 - n]
						winer_p[3 - n] = set_p_val(i,1) + gg_wpn_need * (set_p_val(i,2) - 1)
						winer_n[3 - n] = player(i,"name")
						winer_id[3 - n] = i
					end
				end
			end
		end
		set_p_statb(p,3,gg_points_winner * 3)
		set_gg_statb(p,5,1)
		set_gg_statb(p,4,gg_points_winner * 3)
		for i = 1,2 do
			if (player(i,"exists") and winer_id[i] > 0) then set_p_statb(winer_id[i],3,(gg_points_winner * 3) - (i * gg_points_winner)) end
		end
		for i = 1,p_cnt do
			if player(i,"exists") then gg_msg2(i,2,'[GG] This Round You Have Gained '..set_p_val(i,3)..' Points') end
			gg_res_normal(i)
		end
		gg_msg(2,'=== Winner ===@C')
		gg_msg(2,player(p,"name")..'@C')
		gg_msg(2,'============@C')
		gg_msg(2,'=== Winners ===')
		gg_msg(2,'1. '..player(p,"name")..' (+ '..(3 * gg_points_winner)..' points)')
		gg_msg(2,'2. '..winer_n[1]..' (+ '..(2 * gg_points_winner)..' points)')
		gg_msg(2,'3. '..winer_n[2]..' (+ '..gg_points_winner..' points)')
		if (gg_warmup > 0) then
			warmup_sec = gg_warmup_time
			warmup_rnd = gg_warmup
			if (gg_vote_rnd > 0) then
				addhook("second","gg_sec")	
			end
			freehook("kill","gg_kill")
			freehook("hit","gg_hit")
			freehook("attack","gg_attack")
		else
			if (gg_vote_rnd < 1) then
				warmup_rnd = gg_warmup
				freehook("kill","gg_kill")
				freehook("hit","gg_hit")
				freehook("attack","gg_attack")
			end
		end
		if (gg_vote_rnd < 1) then addhook("second","gg_vote_func") end
		gg_rnd_start = 0
		parse('restart')
	else
		gg_equip3(p)
	end
end

function gg_lvl_check(p)
	if (set_p_val(p,2) < 1) then set_p_stata(p,2,1) end
end

function gg_leader(p)
	local pl_pt = set_p_val(p,1) + gg_wpn_need * (set_p_val(p,2) - 1)
	if (pl_pt > lead_pt) then
		if (p ~= lead_id) then
			gg_snd2(p,6)
			gg_snd2(lead_id,7)
			gg_msg(8,'[GG] '..player(p,"name")..' took lead on lvl '..set_p_val(p,2))
		end
		lead_pt = pl_pt
		lead_id = p
		lead_tie = player(lead_id,"name")
		gg_txt(1,3,'Leader: '..player(p,"name")..' ('..set_p_val(p,2)..' - '..itemtype(gg_wpn[set_p_val(p,2)],"name")..')',322,26,1)
	elseif  (pl_pt == lead_pt and p ~= lead_id) then
		lead_tie = lead_tie..' + '..player(p,"name")
		gg_msg(8,'[GG] '..player(p,"name")..' has tied the leader!')
		gg_txt(1,3,'Leader: '..lead_tie..' ('..set_p_val(p,2)..' - '..itemtype(gg_wpn[set_p_val(p,2)],"name")..')',322,26,1)
		gg_snd2(p,8)
		gg_snd2(lead_id,8)
	end
end

function gg_res_normal(p)
	set_p_stata(p,1,0)
	set_p_stata(p,2,1)
	set_p_stata(p,3,0)
end

function gg_rank_sv()
	local i
	local m
	for m = 1,3 do
		f = assert(io.open(gg_dir..'rank/'..gg_rank_state[m]..'.txt','w'))
		gg_print(3,'Gun Game Rank File Updated! ('..gg_rank_state[m]..')')
		for i = 1,gg_rank_count do
			if (m == 1) then
				f:write(gg_rank_usgn[i]..'\n')
			elseif (m == 2) then
				f:write(gg_rank_score[i]..'\n')
			elseif (m == 3) then
				f:write(gg_rank_wins[i]..'\n')
			end
		end
		f:close()
	end
	f = assert(io.open(gg_dir..'rank/Names.txt','w'))
	for i = 1,gg_rank_count do
		f:write(gg_rank_name[i]..'\n')
	end
	f:close()
end

function gg_rank_ld()
	local m
	for m = 1,3 do
		f = io.open(gg_dir..'rank/'..gg_rank_state[m]..'.txt','r')
		if (f ~= nil) then
			gg_print(3,'Gun Game Rank File Found! ('..gg_rank_state[m]..')')
			local i = 0
			for line in f:lines() do
				i = i + 1
				if (m == 1) then
					gg_rank_usgn[i] = tonumber(line)
				elseif (m == 2) then
					gg_rank_score[i] = tonumber(line)
				elseif (m == 3) then
					gg_rank_wins[i] = tonumber(line)
				end
			end
			f:close()
		else
			gg_print(4,'One Of Gun Game Rank Files Not Found!')
		end
	end
	f = io.open(gg_dir..'rank/names.txt','r')
	if (f ~= nil) then
		gg_print(3,'Gun Game Rank File Found! (Names)')
		local i = 0
		for line in f:lines() do
			i = i + 1
			gg_rank_name[i] = line
		end
		f:close()
	else
		gg_print(4,'One Of Gun Game Rank Files Not Found!')
	end
end

function gg_rank_check(p)
	local m = gg_rank_count
	local i
	for i = 0, gg_rank_count do
		if (player(p,"usgn") == gg_rank_usgn[gg_rank_count - i]) then
			m = gg_rank_count - i
		end
	end
	for  i = gg_rank_count - m - 1, gg_rank_count -  2 do
		local n = gg_rank_count - i - 1
		if (gg_rank_score[n] < set_gg_val(p,4)) then
			if (gg_rank_usgn[n] ~= player(p,"usgn")) then
				gg_rank_usgn[n + 1] = gg_rank_usgn[n]
				gg_rank_name[n + 1] = gg_rank_name[n]
				gg_rank_wins[n + 1] = gg_rank_wins[n]
				gg_rank_score[n + 1] = gg_rank_score[n]
			end
			gg_rank_usgn[n] = player(p,"usgn")
			gg_rank_name[n] = player(p,"name")
			gg_rank_wins[n] = set_gg_val(p,5)
			gg_rank_score[n] = set_gg_val(p,4)
		end
	end
end

function gg_vote_menu(p)
	local v_maps = ''
	local i
	for i = 1,#gg_vote_maps do
		v_maps = v_maps..''..gg_vote_maps[i]..','
	end
	menu(p,'Map Voting!,'..v_maps)	
end

function gg_server_inf_ld()
	f = io.open(gg_dir..'serverinfo.txt','r')
	if (f ~= nil) then
		gg_print(3,'Gun Game Server Info File Found!')
		local i = 0
		for line in f:lines() do
			i = i + 1
			gg_info_line[i] = line
		end
		f:close()
	else
		gg_print(4,'Gun Game Server Info File Not Found!')
	end
end

function gg_server_inf_sv()
	local i
	f = assert(io.open('sys/serverinfo.txt','w'))
	gg_print(3,'Gun Game Server Info File Updated!')
	for i = 1,#gg_info_line do
		f:write(gg_info_line[i]..'\n')
	end
	local inf_clr
	if (145 / gg_rank_count > 1) then
		inf_clr = math.ceil(145 / gg_rank_count) - 1
	else
		inf_clr = 0
	end	
	f:write('\n�255128064======== Gun Game Top '..gg_rank_count..' List ========\n')
	for i = 1,gg_rank_count do
		f:write('�'..(255 - (i * inf_clr))..''..(255 - (i * inf_clr))..''..(255 - (i * inf_clr))..''..i..'. '..gg_rank_name[i]..' - Points: '..gg_rank_score[i]..' - Wins: '..gg_rank_wins[i]..'\n')
	end
	f:write('�064064064Gun Game Rank Generating By Blazzingxx')
	f:close()
end

function gg_main_menu(p)
	menu(p,'Gun Game 1.1 Menu,Say Commands|(Client),Watch Script Config|(Client),Script Info|(Client)')	
end

function gg_main_say(p)
	local cmd = ''
	local i
	for i = 1,#gg_say_cmd do
		cmd = cmd..''..gg_say_cmd[i]..'|'..gg_say_info[i]..','
	end
	menu(p,'Say Commands,'..cmd)	
end

function gg_script_inf(p)
	menu(p,'Script Info,Author|Blazzingxx,Version|1.1 beta,Release|2009/09/30,Programming Language|Lua')	
end

function gg_script_cfg(p)
	if (gg_info_client > 0) then
		menu(p,'Server Config,Warmup Round|'..gg_cfg_info[gg_warmup + 1]..',Warmup Weapon|'..itemtype(gg_warmup_wpn,"name")..',Team Mode|'..gg_cfg_info[gg_team_game +1 ]..',Team Mode Objectives|'..gg_cfg_info[gg_team_objective +1 ]..',Rank Feature|'..gg_cfg_info[gg_rank + 1]..',Server Info Top List|'..gg_cfg_info[gg_rank_diplay + 1]..',Gun Game Sounds|'..gg_cfg_info[gg_sound + 1]..',UT Sounds|'..gg_cfg_info[gg_ut_sound + 1]..',Map Vote Round|'..gg_cfg_info[gg_vote + 1])
	else
		gg_msg2(4,'This Feature Disabled By Admin')
	end
end

function gg_say_action(p,a)
	if (a == 1) then gg_main_menu(p) end
	if (a == 2) then gg_main_say(p) end
	if (a == 3) then
		if (player(p,"usgn") > 0) then
			gg_msg2(p,1,'===== Your Stats =====')
			local i
			local acc
			local k_d
			for i = 2,7 do
				if (i > 2) then
					gg_msg2(p,1,gg_p_state_name[i]..': '..set_gg_val(p,i))
					if (i == 3) then
						if (set_gg_val(p,3) > 0) then
							k_d = tonumber(tostring(set_gg_val(p,2) / set_gg_val(p,3)):sub(1, 4)) 
						else
							k_d = 1.00
						end
						gg_msg2(p,1,'Kills/Deaths: '..k_d)
					end
				elseif (i == 2) then
					gg_msg2(p,1,gg_p_state_name[2]..': '..set_gg_val(p,2)..' (Knife: '..set_gg_val(p,1)..')')
				end
			end
			if (set_gg_val(p,6) > 0) then
				acc = tonumber(tostring(100 * (set_gg_val(p,7) / set_gg_val(p,6))):sub(1, 4)) 
			else
				acc = 0
			end
			gg_msg2(p,1,'Accuracy: '..acc..'%')
		else
			gg_msg2(p,4,'[GG] No U.S.G.N. Login!')
		end
	end
	if (a ==4) then
		if (gg_rank > 0) then
			gg_msg2(p,1,'===== Gun Game Top 10 =====')
			local i
			for i = 1,10 do gg_msg2(p,1,i..'. '..gg_rank_name[i]..' - Score: '..gg_rank_score[i]..' - Wins: '..gg_rank_wins[i]) end
		else
			gg_msg2(p,4,'[GG] This Feature Disabled By Admin!')
		end
	end
end