function Array(size,value) 
if not value then value=0 end
    local array = {}
    for i = 1, size do
        array[i]=value
    end
    return array
end

VERSION = "4.0.2" -- The Admin Script's Updated Version

DATA={}
BanList = {}
RESETSCORE=false
UTSFX=false
SHOWDAMAGE=false
FASTRELOAD=false
TIME=0
name=Array(32,"")
hatimg=Array(32,nil)
antispam=Array(32,false)
tag=Array(32,false)
admnokill=Array(32)
info=Array(32)
userlevel=Array(32)
mute=Array(32)
wallhack=Array(32)
bteam=Array(32,4)
cx=Array(32)
cy=Array(32)
secilmis=Array(32)
grab=Array(32)
shat=Array(32)
ctype=Array(32,LANG["none"])
mutetimer=Array(32)
namecolor=Array(32)
txtcolor=Array(32)
teamnames={LANG["terorists"],LANG["counterterorists"]}
teamnames[0]=LANG["spectator"]
teamcolor={"255000000","000128255"}
teamcolor[0]="255255000"
vsTAB={vid_1=0,vid_2=0,live=false,score_1=0,score_2=0}
hatspagenumber=math.ceil(#HATS/7)
mapspagenumber=math.ceil(#maps/7)
ccode=string.char(169)

parse('sv_maxplayers 16')
parse('sv_fow 0')
parse('sv_friendlyfire 0')
parse('mp_deathdrop 0')
