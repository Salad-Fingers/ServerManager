-- #Hat's Name			#Hat's image path
-- You can add hats with this way (unlimited)

#Devil Hat 			#gfx/The Admin/devil.png
#Angel Hat	 		#gfx/The Admin/angel.png
#Gandalf Hat		#gfx/The Admin/gandalf.png
#Marine Hat 		#gfx/The Admin/marine_hat.png
#Metal Helm 		#gfx/The Admin/metalhelm.png
#Pirate Hat 		#gfx/The Admin/pirate.png
#Santa Hat 			#gfx/The Admin/santa_hat.png
#Smile 				#gfx/The Admin/smile.png
#Spear				#gfx/The Admin/spear.png
