-------------------------------------------------------------------
--   GetUSGNName - Fetch UnrealSoftware login names of players   --
--    See README.txt for more info on usage and configuration    --
--                 24/03/11 - http://www.cs2d.nl                 --
-------------------------------------------------------------------


-- Usage is simple and needs not really be changed: player(id, "usgnname")
-- Info and some additional functions are added for those who want to edit


---------------------------------------------------------------------------
--   Some basic configuration here, nothing has to be changed, really.   --
---------------------------------------------------------------------------
local DIR = "sys/lua/usgnname"     -- Directory where all files are located.
local NO_NAME = "unknown"          -- The value that functions return when they cannot find a name. Use a string when the returned value is output directly, but you can also change this to a number, a boolean or whatnot when processing the value is needed.
local ERROR_REPORTING = true       -- Do errors have to be logged?
local MAX_AGE = 31                 -- Maximum time (in days) USGN names may be saved. MAX_AGE <= 0 means always preserve.
local NET_DELAY = 1500             -- The delay before trying to open the file containing the USGN name (in ms). Can easily be decreased on fast networks.
local USGN_NAMES = {}              -- An empty table which will be filled with U.S.G.N. names.



-- What we do here is adding an extra option to the player() function.
-- We first make a local copy of the function (called _player).
-- Then we create our own function, where we can add extra values for the second parameter, usgnname in this case.
-- For any other value of the second parameter, the function simply returns the 'real' player function.

local _player = player
function player(id, t)
	if t == "usgnname" then return USGN_NAMES[id]
	else return _player(id, t) end
end



---------------------------------------------------------------------------
--  Just to make there is a trailing backslash (damned Windows paths...) --
---------------------------------------------------------------------------
DIR = DIR:gsub("/", "\\")
if DIR:sub(-2) ~= "\\" then DIR = DIR .. "\\" end



---------------------------
--    ERROR REPORTING    --
---------------------------
local function _e (m) if ERROR_REPORTING and m then if type(m) == "string" then print("# GetUSGNName ERROR: " .. m) end end end



---------------------------
--     OUTPUT PIPING     --
---------------------------
local function pipe(cmd)
	local f = assert(io.popen(cmd, "r"))
	local s = assert(f:read("*a"))
	f:close()
	if #s == 0 then _e("could not access " .. cmd .. " (in function pipe; while calling " .. cmd .. ")") return false end
	s = s:gsub("\n", "")
	return s
end


-------------------------------------------------------------------------------------
-- GET USGN NAME BY PLAYER ID
-- NOTE: USING THIS FUNCTION WILL FREEZE THE SERVER FOR UP TO SEVERAL SECONDS!
-- USING THE (SLOWER) FUNCTION SaveUNameById IS ADVISORY!
-------------------------------------------------------------------------------------
function GetUNameByID(id)
	if not id then _e("no player ID stated (in function GetUNameById)") return NO_NAME end
	if id <= 0 or id > 32 then _e("invalid player ID stated (in function GetUNameById)") return NO_NAME end
	
	local u = player(id, "usgn")
	if u == 0 then return NO_NAME end
	
	local name = pipe(DIR .. "GetUSGNName " .. u)
	if not name then return NO_NAME end
	if name:sub(1, 7) == "%ERROR%" then _e(name:sub(8) .. " (in function pipe; while calling GetUSGNName.py)") return NO_NAME end
	return name
end


-------------------------------------------------------------------------------------
-- GET USGN NAME BY U.S.G.N. ID #
-- NOTE: USING THIS FUNCTION WILL FREEZE THE SERVER FOR UP TO SEVERAL SECONDS!
-- USING THE (SLOWER) FUNCTION SaveUNameById IS ADVISORY!
-------------------------------------------------------------------------------------
function GetUNameByUSGN(usgn)
	if not usgn then _e("no U.S.G.N. ID # stated (in function GetUNameByUSGN)") return NO_NAME end
	if usgn <= 0 then _e("invalid U.S.G.N. ID # stated (in function GetUNameByUSGN)") return NO_NAME end	
	
	local name = pipe(DIR .. "GetUSGNName " .. usgn)
	if not name then return NO_NAME end
	if name:sub(1, 7) == "%ERROR%" then _e(name:sub(8) .. " (in function pipe; while calling GetUSGNName.py)") return NO_NAME end
	return name
end


-------------------------------------------------------------------------------------
-- SAVE USGN NAME TO A FILE BY U.S.G.N. ID #
-- RETURNS THE VALUE OF NO_NAME ON FAILURE, TRUE ON SUCCESS
-- THIS FUNCTION IS OF NU USE ON ITS OWN, USE USGNName INSTEAD
-------------------------------------------------------------------------------------
local function SaveUNameById(id)
	if not id then _e("no player ID stated (in function SaveUNameById)") return NO_NAME end
	if id <= 0 or id > 32 then _e("invalid player ID stated (in function SaveUNameById)") return NO_NAME end
	
	local u = player(id, "usgn")
	if u == 0 then return NO_NAME end
	
	if not os.execute("start /min cmd /c " .. DIR .. "GetUSGNName " .. u .. " SAVE > nul") then _e("could not open process (in function SaveUNameById; while calling GetUSGNName.exe)") return false end
	return true
end





---------------------------------------------------------------------------
--           LOAD THE USGN NAME WHEN A PLAYER JOINS THE SERVER           --
---------------------------------------------------------------------------
addhook("join", "SaveUSGNName")
addhook("leave", "ClearUSGNName")

function SaveUSGNName(id)
	local u = player(id, "usgn")
	if not u then USGN_NAMES[id] = NO_NAME return 0 end
	
	local f = io.open(DIR .. "USGNNames/" .. u, "r")
	if f == nil then
		USGN_NAMES[id] = NO_NAME
		if SaveUNameById(id) == true then timer(NET_DELAY, "ReadUSGNName", u.."|"..id) end
	else
		local c = f:read("*all")
		local t = tonumber(c:sub(1, 10))
		f:close()
		if MAX_AGE > 0 and os.difftime(os.time(), t) >= MAX_AGE * 24 * 60 * 60 then
			os.remove(DIR .. "USGNNames/" .. u)
			USGN_NAMES[id] = NO_NAME
			if SaveUNameById(id) == true then timer(NET_DELAY, "ReadUSGNName", u.."|"..id) end
		else
			USGN_NAMES[id] = c:sub(11)
		end
	end
end


function ReadUSGNName(t)
	local u, id = t:sub(1,t:find("|")-1), tonumber(t:sub(t:find("|")+1))
	local f = io.open(DIR .. "USGNNames/" .. u, "r")
	if f ~= nil then
		local c = f:read("*all")
		USGN_NAMES[id] = c:sub(11)
		f:close()
	end
end


---------------------------------------------------------------------------
--           CLEAR THE USGN NAME WHEN PLAYER LEAVES THE SERVER           --
---------------------------------------------------------------------------
function ClearUSGNName(id)
	USGN_NAMES[id] = nil
end


---------------------------------------------------------------------------
--    LOAD THE USGN NAMES OF PLAYERS INITIALLY PRESENT IN THE SERVER     --
---------------------------------------------------------------------------
for _, v in pairs(player(0, "table")) do SaveUSGNName(v) end