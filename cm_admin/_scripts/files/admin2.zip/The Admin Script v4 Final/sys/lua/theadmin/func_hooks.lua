function theAdmin.die(id)
if grab[id]>0 then
parse('speedmod '..grab[id]..' 0')
grab[id]=0
end
if wallhack[id]~=0 then
wallhack[id]=0
end
end

function theAdmin.hit(id,s)
if admnokill[id]==1 then
return 1
end
if (s>0 and s<33) and player(id,"exists") and grab[id]==s then
return 1
end
end

function theAdmin.team(id,team)
	if vsTAB.live then
		if vsTAB.half then
			return 0
		end
		return 1
	end
end

function theAdmin.say(id,txt)
if antispam[id]==true then return 1 end
antispam[id]=true
timer(1000,"parse","lua antispam["..id.."]=false")
if string.lower(txt)=="!credits" or string.lower(txt)=="!info" or string.lower(txt)=="!scriptinfo" then -- Please don't remove it
if info[id]==0 then
parse('hudtxt2 '..id..' 27 "'..ccode..'000255000The Admin Script v'..VERSION..' Final" 250 185')
parse('hudtxt2 '..id..' 28 "'..ccode..'255255000Script By Apple # ���z�����" 250 200')
parse('hudtxt2 '..id..' 37 "'..ccode..'000255255Thanks For Playing!" 250 220')
parse('hudtxt2 '..id..' 26 "'..ccode..'255128000Server Name: '..game("sv_name")..'" 250 240')
parse('hudtxt2 '..id..' 29 "'..ccode..'255000000Say `!info� for close this text!" 250 255')
info[id]=1
return 1
elseif info[id]==1 then
parse('hudtxt2 '..id..' 26 " " 250 185')
parse('hudtxt2 '..id..' 27 " " 250 185')
parse('hudtxt2 '..id..' 28 " " 250 200')
parse('hudtxt2 '..id..' 37 " " 250 220')
parse('hudtxt2 '..id..' 29 " " 250 250')
info[id]=0
return 1
end
end
if RESETSCORE==true then
if string.lower(txt)=="!rs" or string.lower(txt)=="!resetscore" then
parse('setscore '..id..' 0')
parse('setdeaths '..id..' 0')
msg2(id,""..ccode.."255255255�"..LANG["scorereset"].."�")
return 1
end
end
if (mute[id]==1) then
	msg2(id,""..ccode.."255000000"..string.format(LANG["youmuted"],math.floor(mutetimer[id]/60),((string.len(mutetimer[id]%60)==2 and mutetimer[id]%60) or "0"..mutetimer[id]%60)))
return 1
end
if userlevel[id]>0 then
if string.lower(txt)~="rank" then
txt=txt.." "
	msg(""..ccode..""..namecolor[id]..""..player(id,"name").." "..((tag[id] and ""..string.char(169)..""..string.char(169).."200200200�"..levelnames[userlevel[id]].."�") or "")..": "..ccode..""..ccode..""..txtcolor[id]..""..txt)
return 1
end
end
end

function theAdmin.kill(id,v)
	if vsTAB.live then
		if id==v then return end
		if id==vsTAB.vid_1 then
			vsTAB.score_1=vsTAB.score_1+1
		elseif id==vsTAB.vid_2 then
			vsTAB.score_2=vsTAB.score_2+1
		end
		if vsTAB.score_1==5 or vsTAB.score_2==5 then
			vsTAB.half=true
			timer(2000,'parse','maket '..vsTAB.vid_2)
			timer(2000,'parse','makect '..vsTAB.vid_1)
			timer(2000,'parse','lua vsTAB.half=false')
			msg(""..ccode.."255255255"..LANG["halftime"].."!@C")
		end
		VShuds()
		if vsTAB.score_1==10 or vsTAB.score_2==10 then
			finishversus()
		end
	end
end

function theAdmin.join(id)
	if (player(id,"usgn")>0) then
		loadplayerdata(id)
	end
	if admin(id) then
		userlevel[id]=1
	end
if mutetimer[id]>0 then
mute[id]=1
else
mute[id]=0
end
tag[id]=false
name[id]=player(id,"name")
namecolor[id]="255255255"
txtcolor[id]="255255000"
bteam[id]=4
end

function theAdmin.leave(id)
     if player(id,"usgn")>0 then
		saveplayerdata(id)
     end
name[id]=""
userlevel[id]=0
wallhack[id]=0
shat[id]=0
if grab[id]>0 then
parse('speedmod '..grab[id]..' 0')
grab[id]=0
end
mutetimer[id]=0
admnokill[id]=0
mute[id]=0
info[id]=0
end

function theAdmin.spawn(id)
if userlevel[id]>0 and userlevel[id]<4 then
changetype(id,ctype[id])
end
end

function theAdmin.minute()
TIME=TIME+1
if TIME%5==0 then
savedata()
end
local sname=""
local z,gn=1,game("sv_name")
	for k=1, string.len(gn) do
		if gn:sub(k,k)==" " then
			sname=sname..""..ccode..""..crandom()..""..crandom()..""..crandom()..""..gn:sub(z,k)
			z=k+1
		end
		if k==string.len(gn) then
			sname=sname..""..ccode..""..crandom()..""..crandom()..""..crandom()..""..gn:sub(z,k)
		end
	end
	msg(sname)
	msg(""..ccode.."000255000"..LANG["minutemsg"])
end

function theAdmin.reload(id,mode)
	if FASTRELOAD then
	wp = player(id,"weapontype")
		if mode==1 then
			parse("equip "..id.." "..wp)
			parse("setweapon "..id.." "..wp)
		end
	end
end

function theAdmin.attack(id)
if grab[id]~=0 then
parse('speedmod '..grab[id]..' 0')
grab[id]=0
end
end

function theAdmin.second()
for _, id in ipairs(player(0,"table")) do
parse('hudtxtcolorfade '..id..' 40 1000 '..math.random(0,255)..' '..math.random(0,255)..' '..math.random(0,255))
if mutetimer[id]>0 then
mutetimer[id]=mutetimer[id]-1
if mutetimer[id]==0 then
unmute(id)
end
end
end
end

function theAdmin.sayteam(id,txt)
if (mute[id]==1) then
	msg2(id,""..ccode.."255000000"..string.format(LANG["youmuted"],math.floor(mutetimer[id]/60),((string.len(mutetimer[id]%60)==2 and mutetimer[id]%60) or "0"..mutetimer[id]%60)))
return 1
end
if antispam[id]==true then return 1 end
antispam[id]=true
timer(1000,"parse","lua antispam["..id.."]=false")
if userlevel[id]>0 then
txt=txt.." "
	teamsay(id,""..ccode..""..namecolor[id]..""..player(id,"name")..""..((tag[id] and ""..ccode..""..ccode.."200200200 �"..levelnames[userlevel[id]].."�") or "").." "..ccode..""..ccode.."255255000(Team): "..ccode..""..ccode..""..txtcolor[id]..""..txt)
return 1
end
end

function theAdmin.startround()
parse('hudtxt 41 "'..ccode..'000255000The Admin Script v'..VERSION..' Final" 240 5')
parse('hudtxt 40 "'..ccode..'255128000'..game("sv_name")..'" 325 20 1')
for _, id in ipairs(player(0,"tableliving")) do
wearhat(id,shat[id])
end
end

function theAdmin.clientdata(id,mode,x,y)
if mode == 2 then
cx[id] = x
cy[id] = y
end
end

function theAdmin.serveraction(id,act)
if userlevel[id]>0 then
if act==1 then
adminmainpage(id)
end
if userlevel[id]<4 and act==3 then
createobject(id,ctype[id])
end
end
if userlevel[id]==1 then
if act==2 then
if wallhack[id]==1 then
wallhack[id]=0
elseif wallhack[id]==0 then
wallhack[id]=1
wallhackfunction(id)
end
end
end
end

function theAdmin.menu(id,title,buton)
loadnames()
if title==LANG["adminmenu"] then
if buton==1 then
menu(id,LANG["serversettings"].." - "..LANG["page"].." 1,"..LANG["autoteambalance"].."|"..set[tonumber(game("mp_autoteambalance"))]..","..LANG["friendlyfire"].."|"..set[tonumber(game("sv_friendlyfire"))]..","..LANG["fogofwar"].."|"..set[tonumber(game("sv_fow"))]..","..LANG["infammo"].."|"..set[tonumber(game("mp_infammo"))]..","..LANG["antispeeder"].."|"..set[tonumber(game("mp_antispeeder"))]..","..LANG["deathdrop"].."|"..ddrop[tonumber(game("mp_deathdrop"))]..","..LANG["dropgrenades"].."|"..set[tonumber(game("mp_dropgrenades"))]..","..LANG["flashlight"].."|"..set[tonumber(game("mp_flashlight"))]..","..LANG["next"].."")
elseif buton==2 then
local t={LANG["red"],LANG["blue"],LANG["white"],LANG["yourteam"]}
t[0]=LANG["yellow"]
menu(id,LANG["spawnmenu"]..","..LANG["spawncreature"]..","..LANG["spawnobject"]..","..LANG["spawnitem"]..","..LANG["spawnprojectile"]..",,"..LANG["buildingteam"].."|"..t[bteam[id]]..",,,"..LANG["back"].."")
elseif buton==3 then
secilmis[id]="manage"
menu(id,""..LANG["players"].." 1/5,"..name[1].."|"..levelname(1)..","..name[2].."|"..levelname(2)..","..name[3].."|"..levelname(3)..","..name[4].."|"..levelname(4)..","..name[5].."|"..levelname(5)..","..name[6].."|"..levelname(6)..","..name[7].."|"..levelname(7)..","..LANG["next"]..","..LANG["back"].."")
elseif buton==4 then
secilmis[id]="punish"
menu(id,""..LANG["players"].." 1/5,"..name[1]..","..name[2]..","..name[3]..","..name[4]..","..name[5]..","..name[6]..","..name[7]..","..LANG["next"]..","..LANG["back"].."")
elseif buton==5 then
secilmis[id]="give"
menu(id,""..LANG["players"].." 1/5,"..name[1]..","..name[2]..","..name[3]..","..name[4]..","..name[5]..","..name[6]..","..name[7]..",,"..LANG["next"].."")
elseif buton==6 then
parse('restart')
msg(""..ccode.."000255000"..string.format(LANG["restarted"],player(id,"name")))
elseif buton==7 then
menu(id,LANG["saysettings"]..","..LANG["changenamecolor"]..","..LANG["changetextcolor"]..",".. ((tag[id] and LANG["dontusetag"]) or LANG["usetag"]) ..",,,,,,"..LANG["back"].."")
elseif buton==8 then
menu(id,LANG["scriptsettings"]..","..LANG["resetscore"].." (!rs)|"..((RESETSCORE and LANG["on"]) or LANG["off"])..","..LANG["showdamage"].." (By Fasttt)|"..((SHOWDAMAGE and LANG["on"]) or LANG["off"])..","..LANG["fastreload"].."|"..((FASTRELOAD and LANG["on"]) or LANG["off"])..",UTSFX|"..((UTSFX and LANG["on"]) or LANG["off"])..",,"..LANG["godmode"].."|"..((admnokill[id]==1 and LANG["on"]) or LANG["off"])..",,,"..LANG["back"].."")
elseif buton==9 then
adminsecondpage(id)
end
elseif title==LANG["vipmenu"] then
if buton==1 then
menu(id,LANG["saysettings"]..","..LANG["changenamecolor"]..","..LANG["changetextcolor"]..",".. ((tag[id] and LANG["dontusetag"]) or LANG["usetag"]) ..",,,,,,"..LANG["back"].."")
elseif buton==2 then
hatsmenu(id,1)
elseif buton==3 then
secilmis[id]="usgnname"
menu(id,""..LANG["players"].." 1/5,"..nameusgn(1)..","..nameusgn(2)..","..nameusgn(3)..","..nameusgn(4)..","..nameusgn(5)..","..nameusgn(6)..","..nameusgn(7)..","..LANG["next"]..","..LANG["back"].."")
end
elseif title==LANG["modmenu"] then
if buton==1 then
secilmis[id]="punish"
menu(id,""..LANG["players"].." 1/5,"..name[1]..","..name[2]..","..name[3]..","..name[4]..","..name[5]..","..name[6]..","..name[7]..","..LANG["next"]..","..LANG["back"].."")
elseif buton==2 then
secilmis[id]="give"
menu(id,""..LANG["players"].." 1/5,"..name[1]..","..name[2]..","..name[3]..","..name[4]..","..name[5]..","..name[6]..","..name[7]..",,"..LANG["next"].."")
elseif buton==3 then
menu(id,LANG["saysettings"]..","..LANG["changenamecolor"]..","..LANG["changetextcolor"]..",".. ((tag[id] and LANG["dontusetag"]) or LANG["usetag"]) ..",,,,,,"..LANG["back"].."")
elseif buton==4 then
hatsmenu(id,1)
elseif buton==5 then
parse('restart')
msg(""..ccode.."000255000"..string.format(LANG["restarted"],player(id,"name")))
elseif buton==6 then
menu(id,LANG["tpmenu"]..","..LANG["bring"]..","..LANG["teleport"])
elseif buton==7 then
secilmis[id]="usgnname"
menu(id,""..LANG["players"].." 1/5,"..nameusgn(1)..","..nameusgn(2)..","..nameusgn(3)..","..nameusgn(4)..","..nameusgn(5)..","..nameusgn(6)..","..nameusgn(7)..","..LANG["next"]..","..LANG["back"].."")
end
elseif title==LANG["smodmenu"] then
if buton==1 then
local t={LANG["red"],LANG["blue"],LANG["white"],LANG["yourteam"]}
t[0]=LANG["yellow"]
menu(id,LANG["spawnmenu"]..","..LANG["spawncreature"]..","..LANG["spawnobject"]..","..LANG["spawnitem"]..","..LANG["spawnprojectile"]..",,"..LANG["buildingteam"].."|"..t[bteam[id]]..",,,"..LANG["back"].."")
elseif buton==2 then
secilmis[id]="manage"
menu(id,""..LANG["players"].." 1/5,"..name[1].."|"..levelname(1)..","..name[2].."|"..levelname(2)..","..name[3].."|"..levelname(3)..","..name[4].."|"..levelname(4)..","..name[5].."|"..levelname(5)..","..name[6].."|"..levelname(6)..","..name[7].."|"..levelname(7)..","..LANG["next"]..","..LANG["back"].."")
elseif buton==3 then
secilmis[id]="punish"
menu(id,""..LANG["players"].." 1/5,"..name[1]..","..name[2]..","..name[3]..","..name[4]..","..name[5]..","..name[6]..","..name[7]..","..LANG["next"]..","..LANG["back"].."")
elseif buton==4 then
secilmis[id]="give"
menu(id,""..LANG["players"].." 1/5,"..name[1]..","..name[2]..","..name[3]..","..name[4]..","..name[5]..","..name[6]..","..name[7]..",,"..LANG["next"].."")
elseif buton==5 then
menu(id,LANG["saysettings"]..","..LANG["changenamecolor"]..","..LANG["changetextcolor"]..",".. ((tag[id] and LANG["dontusetag"]) or LANG["usetag"]) ..",,,,,,"..LANG["back"].."")
elseif buton==6 then
parse('restart')
msg(""..ccode.."000255000"..string.format(LANG["restarted"],player(id,"name")))
elseif buton==7 then
secilmis[id]="mapvote"
mapsmenu(id,1)
elseif buton==8 then
hatsmenu(id,1)
elseif buton==9 then
adminsecondpage(id)
end
elseif title==LANG["smodmenu"].." 2" then
if buton==1 then
menu(id,LANG["tpmenu"]..","..LANG["bring"]..","..LANG["teleport"])
elseif buton==2 then
botmenu(id)
elseif buton==3 then
secilmis[id]="usgnname"
menu(id,""..LANG["players"].." 1/5,"..nameusgn(1)..","..nameusgn(2)..","..nameusgn(3)..","..nameusgn(4)..","..nameusgn(5)..","..nameusgn(6)..","..nameusgn(7)..","..LANG["next"]..","..LANG["back"].."")
elseif buton==4 then
if vsTAB.live then
closeversus()
else
secilmis[id]="versus1"
menu(id,""..LANG["players"].." 1/5,"..name[1]..","..name[2]..","..name[3]..","..name[4]..","..name[5]..","..name[6]..","..name[7]..","..LANG["next"]..","..LANG["back"].."")
end
elseif buton==5 then
banlist(id)
elseif buton==9 then
adminmainpage(id)
end
end
if title==LANG["adminmenu"].." 2" then
if buton==1 then
secilmis[id]="mapvote"
mapsmenu(id,1)
elseif buton==2 then
hatsmenu(id,1)
elseif buton==3 then
menu(id,LANG["tpmenu"]..","..LANG["bring"]..","..LANG["teleport"])
elseif buton==4 then
botmenu(id)
elseif buton==5 then
secilmis[id]="usgnname"
menu(id,""..LANG["players"].." 1/5,"..nameusgn(1)..","..nameusgn(2)..","..nameusgn(3)..","..nameusgn(4)..","..nameusgn(5)..","..nameusgn(6)..","..nameusgn(7)..","..LANG["next"]..","..LANG["back"].."")
elseif buton==6 then
if vsTAB.live then
closeversus()
else
secilmis[id]="versus1"
menu(id,""..LANG["players"].." 1/5,"..name[1]..","..name[2]..","..name[3]..","..name[4]..","..name[5]..","..name[6]..","..name[7]..","..LANG["next"]..","..LANG["back"].."")
end
elseif buton==7 then
banlist(id)
elseif buton==8 then
adminmainpage(id)
end
end
if title:sub(1,8)==LANG["mapvote"] then
if MAPVOTERATE and MAPVOTERATE.live==true then
if buton==1 then
MAPVOTERATE.yes=MAPVOTERATE.yes+1
parse('hudtxt 9 "'..ccode..'000255000'..LANG["yes"]..': '..MAPVOTERATE.yes..'" 10 180')
elseif buton==2 then
MAPVOTERATE.no=MAPVOTERATE.no+1
parse('hudtxt 10 "'..ccode..'255000000'..LANG["no"]..': '..MAPVOTERATE.no..'" 10 195')
end
end
end
if title==LANG["tpmenu"] then
if buton==1 then
secilmis[id]="bring"
menu(id,""..LANG["players"].." 1/5,"..name[1]..","..name[2]..","..name[3]..","..name[4]..","..name[5]..","..name[6]..","..name[7]..","..LANG["next"]..","..LANG["back"].."")
elseif buton==2 then
secilmis[id]="teleport"
menu(id,""..LANG["players"].." 1/5,"..name[1]..","..name[2]..","..name[3]..","..name[4]..","..name[5]..","..name[6]..","..name[7]..","..LANG["next"]..","..LANG["back"].."")
end
end
if title==LANG["scriptsettings"] then
if buton==1 then
if RESETSCORE==true then
RESETSCORE=false
msg(""..ccode.."000255000"..LANG["resetscore"].." "..ccode..""..ccode.."255000000"..LANG["disabled"])
else
RESETSCORE=true
msg(""..ccode.."000255000Reset Score ENABLED. Say !rs for reset score")
end
elseif buton==2 then
if SHOWDAMAGE==true then
freehook('ms100','sd.check')
freehook('hit','sd.hit')
SHOWDAMAGE=false
msg(""..ccode.."000255000"..LANG["showdamage"].." "..ccode..""..ccode.."255000000"..LANG["disabled"])
else
addhook('ms100','sd.check')
addhook('hit','sd.hit')
SHOWDAMAGE=true
msg(""..ccode.."000255000"..LANG["showdamage"].." "..LANG["enabled"])
end
elseif buton==3 then
if FASTRELOAD==true then
FASTRELOAD=false
msg(""..ccode.."000255000"..LANG["fastreload"].." "..ccode..""..ccode.."255000000"..LANG["disabled"])
else
FASTRELOAD=true
msg(""..ccode.."000255000"..LANG["fastreload"].." "..LANG["enabled"])
end
elseif buton==4 then
if UTSFX==false then
addhook("kill","sskill")
addhook("die","ssdie")
addhook("startround","ssstartround")
msg(""..ccode.."000255000UTSFX "..LANG["enabled"])
UTSFX=true
else
freehook("kill","sskill")
freehook("die","ssdie")
freehook("startround","ssstartround")
UTSFX=false
msg(""..ccode.."000255000UTSFX "..ccode..""..ccode.."255000000"..LANG["disabled"])
end
elseif buton==6 then
if admnokill[id]==1 then
admnokill[id]=0
msg2(id,""..ccode.."000255000"..LANG["godmode"].." "..ccode..""..ccode.."255000000"..LANG["disabled"])
else
admnokill[id]=1
msg2(id,""..ccode.."000255000"..LANG["godmode"].." "..LANG["enabled"])
end
elseif buton==9 then
adminmainpage(id)
end
end
if title==LANG["spawnmenu"] then
if buton==1 then
menu(id,LANG["spawncreature"]..","..LANG["zombie"]..","..LANG["headcrab"]..","..LANG["snark"]..","..LANG["vortigaunt"]..","..LANG["soldier"])
elseif buton==2 then
menu(id,LANG["spawnobject"].." - "..LANG["page"].." 1/3,"..LANG["barricade"]..","..LANG["barbedwire"]..","..LANG["wall1"]..","..LANG["wall2"]..","..LANG["wall3"]..","..LANG["gatefield"]..","..LANG["dispenser"]..","..LANG["next"].."")
elseif buton==3 then
menu(id,LANG["spawnitem"]..","..LANG["pistols"]..","..LANG["shotguns"]..","..LANG["smgs"]..","..LANG["rifles"]..","..LANG["machinegun"]..","..LANG["armors"]..","..LANG["grenades"]..","..LANG["others"]..","..LANG["back"].."")
elseif buton==4 then
menu(id,LANG["spawnprojectile"]..","..LANG["hegrenade"]..","..LANG["flashbang"]..","..LANG["smokegrenade"]..","..LANG["gasgrenade"]..","..LANG["molotov"]..","..LANG["airstrike"]..","..LANG["snowball"]..","..LANG["flare"]..","..LANG["next"].."")
elseif buton==6 then
menu(id,LANG["buildingteam"]..","..LANG["yellow"].."|"..LANG["nuetral"]..","..LANG["red"].."|"..LANG["terorists"]..","..LANG["blue"].."|"..LANG["counterterorists"]..","..LANG["white"].."|"..LANG["nofunc"]..","..LANG["yourteam"].."|"..LANG["yourteamcolor"].."")
elseif buton==9 then
adminmainpage(id)
end
end
local t,b=title,buton
if t==LANG["buildingteam"] then
if b==1 then
bteam[id]=0
elseif b==2 then
bteam[id]=1
elseif b==3 then
bteam[id]=2
elseif b==4 then
bteam[id]=3
elseif b==5 then
bteam[id]=4
end
if b>0 and b<6 then
local t={LANG["red"],LANG["blue"],LANG["white"],LANG["yourteam"]}
t[0]=LANG["yellow"]
menu(id,LANG["spawnmenu"]..","..LANG["spawncreature"]..","..LANG["spawnobject"]..","..LANG["spawnitem"]..","..LANG["spawnprojectile"]..",,"..LANG["buildingteam"].."|"..t[bteam[id]]..",,,"..LANG["back"].."")
msg2(id,string.char(169).."000255000"..LANG["bcolorchanged"])
end
end
if t==LANG["spawnprojectile"] then
if b==1 then
changetype(id,LANG["throwable"].." "..LANG["hegrenade"])
elseif b==2 then
changetype(id,LANG["throwable"].." "..LANG["flashbang"])
elseif b==3 then
changetype(id,LANG["throwable"].." "..LANG["smokegrenade"])
elseif b==4 then
changetype(id,LANG["throwable"].." "..LANG["gasgrenade"])
elseif b==5 then
changetype(id,LANG["throwable"].." "..LANG["molotov"])
elseif b==6 then
changetype(id,LANG["throwable"].." "..LANG["airstrike"])
elseif b==7 then
changetype(id,LANG["throwable"].." "..LANG["snowball"])
elseif b==8 then
changetype(id,LANG["throwable"].." "..LANG["flare"])
elseif b==9 then
menu(id,LANG["spawnprojectile"].." 2,"..LANG["gutbomb"]..","..LANG["scharge"]..","..LANG["rpgrocket"]..","..LANG["normrocket"]..","..LANG["glgrenade"]..",,,,"..LANG["back"].."")
end
end
if t==LANG["spawnprojectile"].." 2" then
if b==1 then
changetype(id,LANG["throwable"].." "..LANG["gutbomb"])
elseif b==2 then
changetype(id,LANG["throwable"].." "..LANG["scharge"])
elseif b==3 then
changetype(id,LANG["throwable"].." "..LANG["rpgrocket"])
elseif b==4 then
changetype(id,LANG["throwable"].." "..LANG["normrocket"])
elseif b==5 then
changetype(id,LANG["throwable"].." "..LANG["glgrenade"])
elseif b==9 then
menu(id,LANG["spawnprojectile"]..","..LANG["hegrenade"]..","..LANG["flashbang"]..","..LANG["smokegrenade"]..","..LANG["gasgrenade"]..","..LANG["molotov"]..","..LANG["airstrike"]..","..LANG["snowball"]..","..LANG["flare"]..","..LANG["next"].."")
end
end
if title==LANG["spawncreature"] then
if buton==1 then
changetype(id,LANG["zombie"])
elseif buton==2 then
changetype(id,LANG["headcrab"])
elseif buton==3 then
changetype(id,LANG["snark"])
elseif buton==4 then
changetype(id,LANG["vortigaunt"])
elseif buton==5 then
changetype(id,LANG["soldier"])
end
end
if title==LANG["serversettings"].." - "..LANG["page"].." 1" then
if buton==1 then
if tonumber(game("mp_autoteambalance"))==1 then
parse('mp_autoteambalance 0')
else
parse('mp_autoteambalance 1')
end
elseif buton==2 then
if tonumber(game("sv_friendlyfire"))==1 then
parse('sv_friendlyfire 0')
else
parse('sv_friendlyfire 1')
end
elseif buton==3 then
if tonumber(game("sv_fow"))==1 then
parse('sv_fow 0')
else
parse('sv_fow 1')
end
elseif buton==4 then
if tonumber(game("mp_infammo"))==1 then
parse('mp_infammo 0')
else
parse('mp_infammo 1')
end
elseif buton==5 then
if tonumber(game("mp_antispeeder"))==1 then
parse('mp_antispeeder 0')
else
parse('mp_antispeeder 1')
end
elseif buton==6 then
if tonumber(game("mp_deathdrop"))==0 then
parse('mp_deathdrop 4')
else
parse('mp_deathdrop 0')
end
elseif buton==7 then
if tonumber(game("mp_dropgrenades"))==1 then
parse('mp_dropgrenades 0')
else
parse('mp_dropgrenades 1')
end
elseif buton==8 then
if tonumber(game("mp_flashlight"))==1 then
parse('mp_flashlight 0')
else
parse('mp_flashlight 1')
end
elseif buton==9 then
menu(id,LANG["serversettings"].." - "..LANG["page"].." 2,"..LANG["killinfo"].."|"..set[tonumber(game("mp_killinfo"))]..","..LANG["hudoptions"].."|"..(hudd[tonumber(game("mp_hud"))] or hudd[-1])..","..LANG["floodprot"].."|"..set[tonumber(game("mp_floodprot"))]..","..LANG["changegmode"].."|"..gmode[tonumber(game("sv_gamemode"))]..","..LANG["smokeblock"].."|"..set[tonumber(game("mp_smokeblock"))]..","..LANG["idleaction"].."|"..iact[tonumber(game("mp_idleaction"))]..","..LANG["radar"].."|"..set[tonumber(game("mp_radar"))]..","..LANG["changemap"].."|"..game("sv_map")..","..LANG["back"])
end
if buton>0 and buton<9 then
menu(id,LANG["serversettings"].." - "..LANG["page"].." 1,"..LANG["autoteambalance"].."|"..set[tonumber(game("mp_autoteambalance"))]..","..LANG["friendlyfire"].."|"..set[tonumber(game("sv_friendlyfire"))]..","..LANG["fogofwar"].."|"..set[tonumber(game("sv_fow"))]..","..LANG["infammo"].."|"..set[tonumber(game("mp_infammo"))]..","..LANG["antispeeder"].."|"..set[tonumber(game("mp_antispeeder"))]..","..LANG["deathdrop"].."|"..ddrop[tonumber(game("mp_deathdrop"))]..","..LANG["dropgrenades"].."|"..set[tonumber(game("mp_dropgrenades"))]..","..LANG["flashlight"].."|"..set[tonumber(game("mp_flashlight"))]..","..LANG["next"].."")
end
end
if title==LANG["serversettings"].." - "..LANG["page"].." 2" then
if buton==1 then
if tonumber(game("mp_killinfo"))==1 then
parse('mp_killinfo 0')
else
parse('mp_killinfo 1')
end
menu(id,LANG["serversettings"].." - "..LANG["page"].." 2,"..LANG["killinfo"].."|"..set[tonumber(game("mp_killinfo"))]..","..LANG["hudoptions"].."|"..(hudd[tonumber(game("mp_hud"))] or hudd[-1])..","..LANG["floodprot"].."|"..set[tonumber(game("mp_floodprot"))]..","..LANG["changegmode"].."|"..gmode[tonumber(game("sv_gamemode"))]..","..LANG["smokeblock"].."|"..set[tonumber(game("mp_smokeblock"))]..","..LANG["idleaction"].."|"..iact[tonumber(game("mp_idleaction"))]..","..LANG["radar"].."|"..set[tonumber(game("mp_radar"))]..","..LANG["changemap"].."|"..game("sv_map")..","..LANG["back"])
elseif buton==2 then
menu(id,LANG["hudoptions"]..","..hudd[0]..","..hudd[1]..","..hudd[2]..","..hudd[3]..","..hudd[4]..","..hudd[5]..","..hudd[6]..","..hudd[6]..","..hudd[-1])
elseif buton==3 then
if tonumber(game("mp_floodprot"))==1 then
parse('mp_floodprot 0')
else
parse('mp_floodprot 1')
end
menu(id,LANG["serversettings"].." - "..LANG["page"].." 2,"..LANG["killinfo"].."|"..set[tonumber(game("mp_killinfo"))]..","..LANG["hudoptions"].."|"..(hudd[tonumber(game("mp_hud"))] or hudd[-1])..","..LANG["floodprot"].."|"..set[tonumber(game("mp_floodprot"))]..","..LANG["changegmode"].."|"..gmode[tonumber(game("sv_gamemode"))]..","..LANG["smokeblock"].."|"..set[tonumber(game("mp_smokeblock"))]..","..LANG["idleaction"].."|"..iact[tonumber(game("mp_idleaction"))]..","..LANG["radar"].."|"..set[tonumber(game("mp_radar"))]..","..LANG["changemap"].."|"..game("sv_map")..","..LANG["back"])
elseif buton==4 then
menu(id,LANG["changegmode"]..","..gmode[0]..","..gmode[1]..","..gmode[2]..","..gmode[3]..","..gmode[4].."")
elseif buton==5 then
if tonumber(game("mp_smokeblock"))==1 then
parse('mp_smokeblock 0')
else
parse('mp_smokeblock 1')
end
menu(id,LANG["serversettings"].." - "..LANG["page"].." 2,"..LANG["killinfo"].."|"..set[tonumber(game("mp_killinfo"))]..","..LANG["hudoptions"].."|"..(hudd[tonumber(game("mp_hud"))] or hudd[-1])..","..LANG["floodprot"].."|"..set[tonumber(game("mp_floodprot"))]..","..LANG["changegmode"].."|"..gmode[tonumber(game("sv_gamemode"))]..","..LANG["smokeblock"].."|"..set[tonumber(game("mp_smokeblock"))]..","..LANG["idleaction"].."|"..iact[tonumber(game("mp_idleaction"))]..","..LANG["radar"].."|"..set[tonumber(game("mp_radar"))]..","..LANG["changemap"].."|"..game("sv_map")..","..LANG["back"])
elseif buton==6 then
menu(id,LANG["idleaction"]..","..iact[0]..","..iact[1]..","..iact[2]..","..iact[3]..","..iact[4])
elseif buton==7 then
if tonumber(game("mp_radar"))==1 then
parse('mp_radar 0')
else
parse('mp_radar 1')
end
menu(id,LANG["serversettings"].." - "..LANG["page"].." 2,"..LANG["killinfo"].."|"..set[tonumber(game("mp_killinfo"))]..","..LANG["hudoptions"].."|"..(hudd[tonumber(game("mp_hud"))] or hudd[-1])..","..LANG["floodprot"].."|"..set[tonumber(game("mp_floodprot"))]..","..LANG["changegmode"].."|"..gmode[tonumber(game("sv_gamemode"))]..","..LANG["smokeblock"].."|"..set[tonumber(game("mp_smokeblock"))]..","..LANG["idleaction"].."|"..iact[tonumber(game("mp_idleaction"))]..","..LANG["radar"].."|"..set[tonumber(game("mp_radar"))]..","..LANG["changemap"].."|"..game("sv_map")..","..LANG["back"])
elseif buton==8 then
secilmis[id]="mapchange"
mapsmenu(id,1)
elseif buton==9 then
menu(id,LANG["serversettings"].." - "..LANG["page"].." 1,"..LANG["autoteambalance"].."|"..set[tonumber(game("mp_autoteambalance"))]..","..LANG["friendlyfire"].."|"..set[tonumber(game("sv_friendlyfire"))]..","..LANG["fogofwar"].."|"..set[tonumber(game("sv_fow"))]..","..LANG["infammo"].."|"..set[tonumber(game("mp_infammo"))]..","..LANG["antispeeder"].."|"..set[tonumber(game("mp_antispeeder"))]..","..LANG["deathdrop"].."|"..ddrop[tonumber(game("mp_deathdrop"))]..","..LANG["dropgrenades"].."|"..set[tonumber(game("mp_dropgrenades"))]..","..LANG["flashlight"].."|"..set[tonumber(game("mp_flashlight"))]..","..LANG["next"].."")
end
end
if title:sub(1,9) == LANG["mapsmenu"] then
local p = tonumber(title:sub(18))
if buton>0 and buton<8 then
local selected=((p-1)*7)+buton
if maps[selected] then
if secilmis[id]=="changemap" then
parse('sv_map '..maps[selected])
elseif secilmis[id]=="mapvote" then
startmapvote(maps[selected])
end
end
else
if buton==8 then
mapsmenu(id,p+1)
elseif buton==9 then
mapsmenu(id,p-1)
end
end
end
if title==LANG["changegmode"] then
if buton==1 then
parse('sv_gamemode 0')
elseif buton==2 then
parse('sv_gamemode 2')
elseif buton==3 then
parse('sv_gamemode 1')
elseif buton==4 then
parse('sv_gamemode 3')
elseif buton==5 then
parse('sv_gamemode 4')
end
end
if title==LANG["idleaction"] then
if buton==1 then
parse('mp_idleaction 0')
elseif buton==2 then
parse('mp_idleaction 1')
elseif buton==3 then
parse('mp_idleaction 2')
elseif buton==4 then
parse('mp_idleaction 3')
elseif buton==5 then
parse('mp_idleaction 4')
end
if buton>0 and buton<7 then
menu(id,LANG["serversettings"].." - "..LANG["page"].." 2,"..LANG["killinfo"].."|"..set[tonumber(game("mp_killinfo"))]..","..LANG["hudoptions"].."|"..(hudd[tonumber(game("mp_hud"))] or hudd[-1])..","..LANG["floodprot"].."|"..set[tonumber(game("mp_floodprot"))]..","..LANG["changegmode"].."|"..gmode[tonumber(game("sv_gamemode"))]..","..LANG["smokeblock"].."|"..set[tonumber(game("mp_smokeblock"))]..","..LANG["idleaction"].."|"..iact[tonumber(game("mp_idleaction"))]..","..LANG["radar"].."|"..set[tonumber(game("mp_radar"))]..","..LANG["changemap"].."|"..game("sv_map")..","..LANG["back"])
end
end
if title==LANG["spawnobject"].." - "..LANG["page"].." 1/3" then
if buton==1 then
changetype(id,LANG["barricade"])
elseif buton==2 then
changetype(id,LANG["barbedwire"])
elseif buton==3 then
changetype(id,LANG["wall1"])
elseif buton==4 then
changetype(id,LANG["wall2"])
elseif buton==5 then
changetype(id,LANG["wall3"])
elseif buton==6 then
changetype(id,LANG["gatefield"])
elseif buton==7 then
changetype(id,LANG["dispenser"])
elseif buton==8 then
menu(id,LANG["spawnobject"].." - "..LANG["page"].." 2/3,"..LANG["supply"]..","..LANG["turret"]..","..LANG["dualturret"]..","..LANG["tripleturret"]..","..LANG["supersupply"]..","..LANG["tpenter"]..","..LANG["tpexit"]..","..LANG["next"]..","..LANG["back"].."")
end
end
if title==LANG["spawnobject"].." - "..LANG["page"].." 2/3" then
if buton==1 then
changetype(id,LANG["supply"])
elseif buton==2 then
changetype(id,LANG["turret"])
elseif buton==3 then
changetype(id,LANG["dualturret"])
elseif buton==4 then
changetype(id,LANG["tripleturret"])
elseif buton==5 then
changetype(id,LANG["supersupply"])
elseif buton==6 then
changetype(id,LANG["tpenter"])
elseif buton==7 then
changetype(id,LANG["tpexit"])
elseif buton==8 then
menu(id,"Spawn Object - "..LANG["page"].." 3/3,"..LANG["consite"]..","..LANG["mine"]..","..LANG["orangeportal"]..","..LANG["blueportal"]..","..LANG["back"].."")
elseif buton==9 then
menu(id,LANG["spawnobject"].." - "..LANG["page"].." 1/3,"..LANG["barricade"]..","..LANG["barbedwire"]..","..LANG["wall1"]..","..LANG["wall2"]..","..LANG["wall3"]..","..LANG["gatefield"]..","..LANG["dispenser"]..","..LANG["next"].."")
end
end
if title==LANG["spawnobject"].." - "..LANG["page"].." 3/3" then
if buton==1 then
changetype(id,LANG["consite"])
elseif buton==2 then
changetype(id,LANG["mine"])
elseif buton==3 then
changetype(id,LANG["orangeportal"])
elseif buton==4 then
changetype(id,LANG["blueportal"])
elseif buton==5 then
menu(id,LANG["spawnobject"].." - "..LANG["page"].." 2/3,"..LANG["supply"]..","..LANG["turret"]..","..LANG["dualturret"]..","..LANG["tripleturret"]..","..LANG["supersupply"]..","..LANG["tpenter"]..","..LANG["tpexit"]..","..LANG["next"]..","..LANG["back"].."")
end
end
if title==LANG["spawnitem"] then
if buton==1 then
menu(id,LANG["pistols"]..",Glock,USP,Deagle,P228,Elite,Five-Seven,"..LANG["back"].."")
elseif buton==2 then
menu(id,LANG["shotguns"]..",M3,XM1014,"..LANG["back"].."")
elseif buton==3 then
menu(id,LANG["smgs"]..",Mac10,TMP,UMP45,MP5,P90,"..LANG["back"].."")
elseif buton==4 then
menu(id,LANG["rifles"].." - "..LANG["page"].." 1/2,Ak-47,M4A1,Famas,Galil,SG552,Steyr Aug,Scout,"..LANG["next"]..","..LANG["back"].."")
elseif buton==5 then
changetype(id,"M249")
elseif buton==6 then
menu(id,LANG["armors"]..","..LANG["kevlar"]..","..LANG["kevlarhelm"]..","..LANG["lightarmor"]..","..LANG["mediumarmor"]..","..LANG["heavyarmor"]..","..LANG["medicarmor"]..","..LANG["shealthsuit"]..","..LANG["superarmor"]..","..LANG["back"].."")
elseif buton==7 then
menu(id,LANG["grenades"]..","..LANG["hegrenade"]..","..LANG["flashbang"]..","..LANG["smokegrenade"]..","..LANG["flare"]..","..LANG["molotov"]..","..LANG["gasgrenade"]..","..LANG["airstrike"]..","..LANG["gutbomb"]..","..LANG["scharge"].."")
elseif buton==8 then
menu(id,LANG["others"].." - "..LANG["page"].." 1/3,"..LANG["laser"]..","..LANG["rpglauncher"]..","..LANG["flamethrower"]..","..LANG["grenadelauncher"]..","..LANG["rocketlauncher"]..","..LANG["portalgun"]..","..LANG["mine"]..","..LANG["next"]..","..LANG["back"].."")
end
end
if title==LANG["pistols"] then
if buton==1 then
changetype(id,"Glock")
elseif buton==2 then
changetype(id,"USP")
elseif buton==3 then
changetype(id,"Deagle")
elseif buton==4 then
changetype(id,"P228")
elseif buton==5 then
changetype(id,"Elite")
elseif buton==6 then
changetype(id,"Five-Seven")
elseif buton==7 then
menu(id,LANG["spawnitem"]..","..LANG["pistols"]..","..LANG["shotguns"]..","..LANG["smgs"]..","..LANG["rifles"]..","..LANG["machinegun"]..","..LANG["armors"]..","..LANG["grenades"]..","..LANG["others"]..","..LANG["back"].."")
end
end
if title==LANG["shotguns"] then
if buton==1 then
changetype(id,"M3")
elseif buton==2 then
changetype(id,"XM1014")
elseif buton==3 then
menu(id,LANG["spawnitem"]..","..LANG["pistols"]..","..LANG["shotguns"]..","..LANG["smgs"]..","..LANG["rifles"]..","..LANG["machinegun"]..","..LANG["armors"]..","..LANG["grenades"]..","..LANG["others"]..","..LANG["back"].."")
end
end
if title==LANG["smgs"] then
if buton==1 then
changetype(id,"Mac10")
elseif buton==2 then
changetype(id,"TMP")
elseif buton==3 then
changetype(id,"UMP45")
elseif buton==4 then
changetype(id,"MP5")
elseif buton==5 then
changetype(id,"P90")
elseif buton==6 then
menu(id,LANG["spawnitem"]..","..LANG["pistols"]..","..LANG["shotguns"]..","..LANG["smgs"]..","..LANG["rifles"]..","..LANG["machinegun"]..","..LANG["armors"]..","..LANG["grenades"]..","..LANG["others"]..","..LANG["back"].."")
end
end
if title==LANG["rifles"].." - "..LANG["page"].." 1/2" then
if buton==1 then
changetype(id,"AK-47")
elseif buton==2 then
changetype(id,"M4A1")
elseif buton==3 then
changetype(id,"Famas")
elseif buton==4 then
changetype(id,"Galil")
elseif buton==5 then
changetype(id,"SG552")
elseif buton==6 then
changetype(id,"Aug")
elseif buton==7 then
changetype(id,"Scout")
elseif buton==8 then
menu(id,"Rifles - "..LANG["page"].." 2/2,AWP,SG550,G3SG1,FN F2000,M134,"..LANG["back"].."")
elseif buton==9 then
menu(id,LANG["spawnitem"]..","..LANG["pistols"]..","..LANG["shotguns"]..","..LANG["smgs"]..","..LANG["rifles"]..","..LANG["machinegun"]..","..LANG["armors"]..","..LANG["grenades"]..","..LANG["others"]..","..LANG["back"].."")
end
end
if title==LANG["rifles"].." - "..LANG["page"].." 2/2" then
if buton==1 then
changetype(id,"AWP")
elseif buton==2 then
changetype(id,"SG550")
elseif buton==3 then
changetype(id,"G3SG1")
elseif buton==4 then
changetype(id,"FNF2000")
elseif buton==5 then
changetype(id,"M134")
elseif buton==6 then
menu(id,"Rifles - "..LANG["page"].." 1/2,Ak-47,M4A1,Famas,Galil,SG552,Steyr Aug,Scout,"..LANG["next"]..","..LANG["back"].."")
end
end
if title==LANG["armors"] then
if buton==1 then
changetype(id,LANG["kevlar"])
elseif buton==2 then
changetype(id,LANG["kevlarhelm"])
elseif buton==3 then
changetype(id,LANG["lightarmor"])
elseif buton==4 then
changetype(id,LANG["mediumarmor"])
elseif buton==5 then
changetype(id,LANG["heavyarmor"])
elseif buton==6 then
changetype(id,LANG["medicarmor"])
elseif buton==7 then
changetype(id,LANG["shealthsuit"])
elseif buton==8 then
changetype(id,LANG["superarmor"])
elseif buton==9 then
menu(id,LANG["spawnitem"]..","..LANG["pistols"]..","..LANG["shotguns"]..","..LANG["smgs"]..","..LANG["rifles"]..","..LANG["machinegun"]..","..LANG["armors"]..","..LANG["grenades"]..","..LANG["others"]..","..LANG["back"].."")
end
end
if title==LANG["grenades"] then
if buton==1 then
changetype(id,LANG["hegrenade"])
elseif buton==2 then
changetype(id,LANG["flashbang"])
elseif buton==3 then
changetype(id,LANG["smokegrenade"])
elseif buton==4 then
changetype(id,LANG["flare"])
elseif buton==5 then
changetype(id,LANG["molotov"])
elseif buton==6 then
changetype(id,LANG["gasgrenade"])
elseif buton==7 then
changetype(id,LANG["airstrike"])
elseif buton==8 then
changetype(id,LANG["gutbomb"])
elseif buton==9 then
changetype(id,LANG["scharge"])
end
end
if title==LANG["others"].." - "..LANG["page"].." 1/3" then
if buton==1 then
changetype(id,LANG["laser"])
elseif buton==2 then
changetype(id,LANG["rpglauncher"])
elseif buton==3 then
changetype(id,LANG["flamethrower"])
elseif buton==4 then
changetype(id,LANG["grenadelauncher"])
elseif buton==5 then
changetype(id,LANG["rocketlauncher"])
elseif buton==6 then
changetype(id,LANG["portalgun"])
elseif buton==7 then
changetype(id,LANG["trapmine"])
elseif buton==8 then
menu(id,LANG["others"].." - "..LANG["page"].." 2/3,"..LANG["lasermine"]..","..LANG["tshield"]..","..LANG["snowball"]..","..LANG["wrench"]..","..LANG["chainsaw"]..","..LANG["knife"]..","..LANG["machete"]..","..LANG["next"]..","..LANG["back"].."")
elseif buton==9 then
menu(id,LANG["spawnitem"]..","..LANG["pistols"]..","..LANG["shotguns"]..","..LANG["smgs"]..","..LANG["rifles"]..","..LANG["machinegun"]..","..LANG["armors"]..","..LANG["grenades"]..","..LANG["others"]..","..LANG["back"].."")
end
end
if title==LANG["others"].." - "..LANG["page"].." 2/3" then
if buton==1 then
changetype(id,LANG["lasermine"])
elseif buton==2 then
changetype(id,LANG["tshield"])
elseif buton==3 then
changetype(id,LANG["snowball"])
elseif buton==4 then
changetype(id,LANG["wrench"])
elseif buton==5 then
changetype(id,LANG["chainsaw"])
elseif buton==6 then
changetype(id,LANG["knife"])
elseif buton==7 then
changetype(id,LANG["machete"])
elseif buton==8 then
menu(id,LANG["others"].." - "..LANG["page"].." 3/3,"..LANG["claw"]..","..LANG["bomb"]..","..LANG["redflag"]..","..LANG["blueflag"]..","..LANG["defusekit"]..","..LANG["nightvision"]..","..LANG["medikit"]..","..LANG["gold"]..","..LANG["back"].."")
elseif buton==9 then
menu(id,LANG["others"].." - "..LANG["page"].." 1/3,"..LANG["laser"]..","..LANG["rpglauncher"]..","..LANG["flamethrower"]..","..LANG["grenadelauncher"]..","..LANG["rocketlauncher"]..","..LANG["portalgun"]..","..LANG["mine"]..","..LANG["next"]..","..LANG["back"].."")
end
end
if title==LANG["others"].." - "..LANG["page"].." 3/3" then
if buton==1 then
changetype(id,LANG["claw"])
elseif buton==2 then
changetype(id,LANG["bomb"])
elseif buton==3 then
changetype(id,LANG["redflag"])
elseif buton==4 then
changetype(id,LANG["blueflag"])
elseif buton==5 then
changetype(id,LANG["defusekit"])
elseif buton==6 then
changetype(id,LANG["nightvision"])
elseif buton==7 then
changetype(id,LANG["medikit"])
elseif buton==8 then
changetype(id,LANG["gold"])
elseif buton==9 then
menu(id,LANG["others"].." - "..LANG["page"].." 2/3,"..LANG["lasermine"]..","..LANG["tshield"]..","..LANG["snowball"]..","..LANG["wrench"]..","..LANG["chainsaw"]..","..LANG["knife"]..","..LANG["machete"]..","..LANG["next"]..","..LANG["back"].."")
end
end
if title==LANG["botmenu"] then
if buton==1 then
parse('bot_add_t')
elseif buton==2 then
parse('bot_add_ct')
elseif buton==3 then
parse('bot_remove_t')
elseif buton==4 then
parse('bot_remove_ct')
elseif buton==5 then
parse('bot_remove_all')
elseif buton==6 then
parse('bot_kill')
elseif buton==7 then
adminsecondpage(id)
end
if buton>0 and buton<7 then
botmenu(id)
end
end
if title==LANG["hudoptions"] then
if buton>0 and buton<9 then
parse('mp_hud '.. buton-1)
end
if buton==9 then
parse('mp_hud -1')
end
if buton>0 then
msg(""..ccode.."000255000"..LANG["hudchange"])
menu(id,LANG["serversettings"].." - "..LANG["page"].." 2,"..LANG["killinfo"].."|"..set[tonumber(game("mp_killinfo"))]..","..LANG["hudoptions"].."|"..(hudd[tonumber(game("mp_hud"))] or hudd[-1])..","..LANG["floodprot"].."|"..set[tonumber(game("mp_floodprot"))]..","..LANG["changegmode"].."|"..gmode[tonumber(game("sv_gamemode"))]..","..LANG["smokeblock"].."|"..set[tonumber(game("mp_smokeblock"))]..","..LANG["idleaction"].."|"..iact[tonumber(game("mp_idleaction"))]..","..LANG["radar"].."|"..set[tonumber(game("mp_radar"))]..","..LANG["changemap"].."|"..game("sv_map")..","..LANG["back"])
end
end
if title:sub(1,-5)==LANG["players"] then
local p = tonumber(title:sub(-3,-3))
local i = ((p-1)*7)+buton
if buton>0 and buton<8 then
if player(i,"exists") then
if secilmis[id]=="give" then
menu(id,LANG["giveitem"].." --> "..player(i,"name")..","..LANG["sethealth"]..","..LANG["setarmor"]..","..LANG["setmoney"]..","..LANG["setspeed"]..","..LANG["changeteam"]..","..LANG["addscore"]..","..LANG["adddeaths"])
elseif secilmis[id]=="punish" then
if i==id then
msg2(id,ccode.."255000000"..LANG["cantpunish"].."@C")
return
end
menu(id,LANG["punish"].." --> "..player(i,"name")..","..LANG["ban"]..","..LANG["kick"]..","..LANG["slap"]..","..LANG["kill"]..","..LANG["freeze"]..","..LANG["grab"]..","..LANG["mute"])
elseif secilmis[id]=="bring" then
if i==id then
msg2(id,ccode.."255000000"..LANG["cantbring"].."@C")
return
end
parse('setpos '..i..' '..player(id,"x")..' '..player(id,"y"))
parse('effect "colorsmoke" '..player(i,"x")..' '..player(i,"y")..' 25 25 255 255 255')
elseif secilmis[id]=="teleport" then
if i==id then
msg2(id,ccode.."255000000"..LANG["cantteleport"].."@C")
return
end
parse('setpos '..id..' '..player(i,"x")..' '..player(i,"y"))
parse('effect "colorsmoke" '..player(id,"x")..' '..player(id,"y")..' 25 25 255 255 255')
elseif secilmis[id]=="versus1" then
vsTAB.vid_1=i
secilmis[id]="versus2"
menu(id,""..LANG["players"].." 1/5,"..name[1]..","..name[2]..","..name[3]..","..name[4]..","..name[5]..","..name[6]..","..name[7]..","..LANG["next"]..","..LANG["back"].."")
elseif secilmis[id]=="versus2" then
if i~=vsTAB.vid_1 then
vsTAB.vid_2=i
startversus()
else
menu(id,""..LANG["players"].." 1/5,"..name[1]..","..name[2]..","..name[3]..","..name[4]..","..name[5]..","..name[6]..","..name[7]..","..LANG["next"]..","..LANG["back"].."")
end
elseif secilmis[id]=="usgnname" then
if player(i,"exists") and player(i,"usgn")>0 then
local n = player(i,"usgnname")
if string.lower(n)=="unknown" then
msg2(id,""..ccode.."000255000"..string.format(LANG["loadrelog"],player(i,"name")))
else
msg2(id,""..ccode.."000255000"..string.format(LANG["usgninf"],player(i,"name"),player(i,"usgnname"),player(i,"usgn")))
end
end
elseif secilmis[id]=="manage" then
if player(i,"usgn")==0 then
msg2(id,""..ccode.."255000000"..string.format(LANG["donthaveusgn"],player(i,"name")).."@C")
return
end
if i==id then
msg2(id,""..ccode.."255000000"..LANG["cantmanage"].."@C")
return
end
local l = userlevel[i]
local a1,a2,a3,a4,a5 = LANG["admin2"],LANG["smod2"],LANG["mod2"],LANG["vip"],LANG["user"]
if l==1 or userlevel[id]==2 then a1="("..a1..")" end
if l==2 then a2="("..a2..")" end
if l==3 then a3="("..a3..")" end
if l==4 then a4="("..a4..")" end
if l==0 then a5="("..a5..")" end
menu(id,""..LANG["manage"].." --> "..player(i,"name")..","..a1..","..a2..","..a3..","..a4..","..a5)
end
if secilmis[id]~="versus2" then
secilmis[id]=i
end
end
else
local names
if buton==8 then
if p==5 then
names=thenaames(5,id)
menu(id,""..LANG["players"].." ".. p .."/5"..names..","..LANG["next"]..","..LANG["back"].."")
else
names=thenaames(p+1,id)
menu(id,""..LANG["players"].." ".. p+1 .."/5"..names..","..LANG["next"]..","..LANG["back"].."")
end
elseif buton==9 then
if p==1 then
names=thenaames(1,id)
menu(id,""..LANG["players"].." ".. p .."/5"..names..","..LANG["next"]..","..LANG["back"].."")
else
names=thenaames(p-1,id)
menu(id,""..LANG["players"].." ".. p-1 .."/5"..names..","..LANG["next"]..","..LANG["back"].."")
end
end
end
return
end
if title:sub(1,string.len(LANG["manage"]))==LANG["manage"] then
local t,i = {1,2,3,4},secilmis[id]
t[5]=0
if id==i then
msg2(id,""..ccode.."255000000"..LANG["cantrank"].."@C")
return
end
userlevel[i]=t[buton]
if userlevel[i]~=1 and wallhack[i]~=0 then
wallhack[i]=0
end
msg(""..ccode.."000255000"..string.format(LANG["rankedmsg"],player(i,"name"),levelname(i)).."!")
end
if title:sub(1,string.len(LANG["punish"]))==LANG["punish"] then
local i,b = secilmis[id], buton
if b == 1 then
menu(id,LANG["ban"].." --> "..player(i,"name")..","..((player(id,"ip")=="0.0.0.0" and "("..LANG["ipban"]..")") or LANG["ipban"].."|"..player(i,"ip"))..","..LANG["nameban"].."s|"..player(i,"name")..","..((player(i,"usgn")>0 and LANG["usgnban"].."|"..player(i,"usgn")) or "("..LANG["usgnban"]..")|#"..LANG["notlogged"]).."")
elseif b==2 then
msg(""..ccode.."000255000"..string.format(LANG["haskicked"],player(id,"name"),player(i,"name")))
parse('kick '..i)
elseif b==3 then
parse('slap '..i)
msg(""..ccode.."000255000"..string.format(LANG["hasslapped"],player(id,"name"),player(i,"name")))
elseif b==4 then
parse('killplayer '..i)
msg(""..ccode.."000255000"..string.format(LANG["haskilled"],player(id,"name"),player(i,"name")))
elseif b==5 then
parse('speedmod '..i..' -100')
msg(""..ccode.."000255000"..string.format(LANG["hasfreezed"],player(id,"name"),player(i,"name")))
elseif b==6 then
if secilmis[id]==id then msg2(id,""..ccode.."255000000"..LANG["cantgrab"].."@C") return end
grab[id]=i
if wallhack[i]==1 then
wallhack[i]=0
end
grb(id)
parse('speedmod '..grab[id]..' -100')
msg(""..ccode.."000255000"..string.format(LANG["hasgrabbed"],player(id,"name"),player(i,"name")))
elseif b==7 then
local s, m = LANG["seconds"], LANG["minutes"]
menu(id,LANG["mute"].." --> "..player(id,"name")..",30 "..s..",1 "..m..",2 "..m..",3 "..m..",5 "..m..",6 "..m..",10 "..m..",12 "..m..",15 "..m)
end
end
if title:sub(1,string.len(LANG["ban"])) == LANG["ban"] then
local i,b = secilmis[id], buton
if b==1 then
if not player(i,"bot") then
table.insert(BanList,{tostring(player(i,"ip")),tostring(player(i,"name"))})
msg(""..ccode.."000255000"..string.format(LANG["hasbanned"],player(id,"name"),player(i,"name")))
parse('banip '..player(i,"ip"))
else
msg2(id,""..ccode.."255000000"..LANG["cantrank"].."@C")
end
elseif b==2 then
table.insert(BanList,{tostring(player(i,"name")),tostring(player(i,"name"))})
msg(""..ccode.."000255000"..string.format(LANG["hasbanned"],player(id,"name"),player(i,"name")))
parse('banname '..player(i,"name"))
elseif b==3 then
if player(i,"usgn")>0 then
table.insert(BanList,{tostring(player(i,"usgn")),tostring(player(i,"name"))})
msg(""..ccode.."000255000"..string.format(LANG["hasbanned"],player(id,"name"),player(i,"name")))
parse('banusgn '..player(i,"usgn"))
end
end
if b>0 and b<4 then
savebanlist()
end
end
if title:sub(1,string.len(LANG["unban"])) == LANG["unban"] then
local i = secilmis[id]
local p = tonumber(title:sub(13))
	if b>0 and b<8 then
	local k = ((p-1)*7)+b
		if BanList[k] and BanList[k][1] and BanList[k][2] then
			msg(""..ccode.."255255255"..string.format(LANG["unbanned"],BanList[k][2]))
			parse('unban '..BanList[k][1])
			table.remove(BanList,k)
			savebanlist()
		end
	end
	if b==8 then
		banlist(id,p+1)
	elseif b==9 then
		banlist(id,p-1)
	end
end
if title:sub(1,string.len(LANG["mute"])) == LANG["mute"] then
local i = secilmis[id]
local m = 0
if player(i,"exists") then
if b==1 then
m=30
elseif b==2 then
m=60
elseif b==3 then
m=120
elseif b==4 then
m=180
elseif b==5 then
m=300
elseif b==6 then
m=360
elseif b==7 then
m=600
elseif b==8 then
m=720
elseif b==9 then
m=900
end
if m>0 then
muted(i,m)
end
end
end
if title:sub(1,string.len(LANG["giveitem"])) == LANG["giveitem"] then
local i=secilmis[id]
if buton==1 then
local hp = LANG["hp"]
menu(id,LANG["sethealth"]..",1 "..hp..",10 "..hp..",50 "..hp..",75 "..hp..",100 "..hp..",150 "..hp..",200 "..hp..",250 "..hp)
elseif buton==2 then
menu(id,LANG["setarmor"]..","..LANG["noarmor"]..","..LANG["kevlarhelm"]..",200 "..LANG["kevlar"]..","..LANG["lightarmor"]..","..LANG["mediumarmor"]..","..LANG["heavyarmor"]..","..LANG["medicarmor"]..","..LANG["superarmor"]..","..LANG["shealthsuit"])
elseif buton==3 then
menu(id,LANG["setarmor"]..",$0,$1000,$2500,$5000,$7500,$10000,$12500,$15000,$16000")
elseif buton==4 then
local s = LANG["speed"]
menu(id,LANG["setspeed"]..",-100 "..s..",-20 "..s..",-10 "..s..",0 "..s..",10 "..s..",20 "..s..",50 "..s..",100 "..s)
elseif buton==5 then
menu(id,LANG["changeteam"]..","..((player(i,"team")==1 and "("..LANG["terorists"]..")") or LANG["terorists"])..","..((player(i,"team")==2 and "("..LANG["counterterorists"]..")") or LANG["counterterorists"])..","..((player(i,"team")==0 and "("..LANG["spectator"]..")") or LANG["spectator"]))
elseif buton==6 then
menu(id,LANG["addscore"]..",-50,-20,-10,10,20,50,100")
elseif buton==7 then
menu(id,LANG["adddeaths"]..",10,20,50,100,250,500,1000")
end
end
if title==LANG["setmoney"] then
local b,i=buton,secilmis[id]
local o = player(i,"score")
if b==0 then return end
if b==1 then
parse('setmoney '..i..' 0')
elseif b==2 then
parse('setmoney '..i..' 1000')
elseif b==3 then
parse('setmoney '..i..' 2500')
elseif b==4 then
parse('setmoney '..i..' 5000')
elseif b==5 then
parse('setmoney '..i..' 7500')
elseif b==6 then
parse('setmoney '..i..' 10000')
elseif b==7 then
parse('setmoney '..i..' 12500')
elseif b==8 then
parse('setmoney '..i..' 15000')
elseif b==9 then
parse('setmoney '..i..' 16000')
end
msg(""..ccode.."000255000"..string.format(LANG["setsmoney"],player(id,"name"),player(i,"name"),player(i,"money")))
end
if title==LANG["addscore"] then
local b,i=buton,secilmis[id]
local o = player(i,"score")
if b==0 or b==9 then return end
if b==1 then
parse('setscore '..i..' '..player(i,"score")-50)
elseif b==2 then
parse('setscore '..i..' '..player(i,"score")-20)
elseif b==3 then
parse('setscore '..i..' '..player(i,"score")-10)
elseif b==4 then
parse('setscore '..i..' '..player(i,"score")+10)
elseif b==5 then
parse('setscore '..i..' '..player(i,"score")+20)
elseif b==6 then
parse('setscore '..i..' '..player(i,"score")+50)
elseif b==7 then
parse('setscore '..i..' '..player(i,"score")+100)
end
msg(""..ccode.."000255000"..string.format(LANG["setsscore"],player(id,"name"),player(i,"score")-o,player(i,"name")))
end
if title==LANG["adddeaths"] then
local b,i=buton,secilmis[id]
local o = player(i,"deaths")
if b==0 or b==9 then return end
if b==1 then
parse('setdeaths '..i..' '..player(i,"deaths")+10)
elseif b==2 then
parse('setdeaths '..i..' '..player(i,"deaths")+20)
elseif b==3 then
parse('setdeaths '..i..' '..player(i,"deaths")+50)
elseif b==4 then
parse('setdeaths '..i..' '..player(i,"deaths")+100)
elseif b==5 then
parse('setdeaths '..i..' '..player(i,"deaths")+250)
elseif b==6 then
parse('setdeaths '..i..' '..player(i,"deaths")+500)
elseif b==7 then
parse('setdeaths '..i..' '..player(i,"deaths")+1000)
end
msg(""..ccode.."000255000"..string.format(LANG["setsdeaths"],player(id,"name"),player(i,"deaths")-o,player(i,"name")))
end
if title==LANG["changeteam"] then
local b,i=buton,secilmis[id]
if b==0 or b==9 then return end
if b==1 then
parse('maket '..i)
elseif b==2 then
parse('makect '..i)
elseif b==3 then
parse('makespec '..i)
end
msg(""..ccode.."000255000"..string.format(LANG["setsteam"],player(id,"name"),player(i,"name"),teamnames[player(i,"team")]))
end
if title==LANG["sethealth"] then
local b,i=buton,secilmis[id]
if b==1 then
parse('sethealth '..i..' 1')
elseif b==2 then
parse('sethealth '..i..' 10')
elseif b==3 then
parse('sethealth '..i..' 50')
elseif b==4 then
parse('sethealth '..i..' 75')
elseif b==5 then
parse('setmaxhealth '..i..' 100')
elseif b==6 then
parse('setmaxhealth '..i..' 150')
elseif b==7 then
parse('setmaxhealth '..i..' 200')
elseif b==8 then
parse('setmaxhealth '..i..' 250')
end
if b==0 or b==9 then return end
msg(""..ccode.."000255000"..string.format(LANG["setshealth"],player(id,"name"),player(i,"name"),player(i,"health")))
end
if title==LANG["setarmor"] then
local b,i=buton,secilmis[id]
if b==0 or b==9 then return end
if b==1 then
msg(""..ccode.."000255000"..string.format(LANG["setsarmor"],player(id,"name"),player(i,"name"),LANG["noarmor"]))
parse('setarmor '..i..' 0')
elseif b==2 then
msg(""..ccode.."000255000"..string.format(LANG["setsarmor"],player(id,"name"),player(i,"name"),LANG["kevlarhelm"]))
parse('setarmor '..i..' 100')
elseif b==3 then
msg(""..ccode.."000255000"..string.format(LANG["setsarmor"],player(id,"name"),player(i,"name"),"200 "..LANG["kevlar"]))
parse('setarmor '..i..' 200')
elseif b==4 then
msg(""..ccode.."000255000"..string.format(LANG["setsarmor"],player(id,"name"),player(i,"name"),LANG["lightarmor"]))
parse('equip '..i..' 79')
elseif b==5 then
msg(""..ccode.."000255000"..string.format(LANG["setsarmor"],player(id,"name"),player(i,"name"),LANG["mediumarmor"]))
parse('equip '..i..' 80')
elseif b==6 then
msg(""..ccode.."000255000"..string.format(LANG["setsarmor"],player(id,"name"),player(i,"name"),LANG["heavyarmor"]))
parse('equip '..i..' 81')
elseif b==7 then
msg(""..ccode.."000255000"..string.format(LANG["setsarmor"],player(id,"name"),player(i,"name"),LANG["medicarmor"]))
parse('equip '..i..' 82')
elseif b==8 then
msg(""..ccode.."000255000"..string.format(LANG["setsarmor"],player(id,"name"),player(i,"name"),LANG["superarmor"]))
parse('equip '..i..' 83')
elseif b==9 then
msg(""..ccode.."000255000"..string.format(LANG["setsarmor"],player(id,"name"),player(i,"name"),LANG["shealthsuit"]))
parse('equip '..i..' 84')
end
end
if title==LANG["setspeed"] then
local b,i=buton,secilmis[id]
if b==0 or b==9 then return end
if b==1 then
parse('speedmod '..i..' -100')
elseif b==2 then
parse('speedmod '..i..' -20')
elseif b==3 then
parse('speedmod '..i..' -10')
elseif b==4 then
parse('speedmod '..i..' 0')
elseif b==5 then
parse('speedmod '..i..' 10')
elseif b==6 then
parse('speedmod '..i..' 20')
elseif b==7 then
parse('speedmod '..i..' 50')
elseif b==8 then
parse('speedmod '..i..' 100')
end
msg(""..ccode.."000255000"..string.format(LANG["setsspeed"],player(id,"name"),player(i,"name"),player(i,"setspeed")))
end
if title==LANG["saysettings"] then
if buton==1 then
menu(id,LANG["changenamecolor"].." - "..LANG["page"].." 1,"..LANG["red"]..","..LANG["green"]..","..LANG["blue"]..","..LANG["yellow"]..","..LANG["white"]..","..LANG["grey"]..","..LANG["orange"]..","..LANG["cyan"]..","..LANG["next"].."")
elseif buton==2 then
menu(id,LANG["changetextcolor"].." - "..LANG["page"].." 1,"..LANG["red"]..","..LANG["green"]..","..LANG["blue"]..","..LANG["yellow"]..","..LANG["white"]..","..LANG["grey"]..","..LANG["orange"]..","..LANG["cyan"]..","..LANG["next"].."")
elseif buton==3 then
if tag[id]==false then
tag[id]=true
msg2(id,""..ccode.."000255000"..LANG["saytagon"])
else
tag[id]=false
msg2(id,""..ccode.."255000000"..LANG["saytagdis"])
end
elseif buton==9 then
adminmainpage(id)
end
end
if title==LANG["changetextcolor"].." - "..LANG["page"].." 1" then
local firstcolor = txtcolor[id] -- before change
if buton==1 then
txtcolor[id]="255000000"
elseif buton==2 then
txtcolor[id]="000255000"
elseif buton==3 then
txtcolor[id]="000000255"
elseif buton==4 then
txtcolor[id]="255255000"
elseif buton==5 then
txtcolor[id]="255255255"
elseif buton==6 then
txtcolor[id]="128128128"
elseif buton==7 then
txtcolor[id]="255128000"
elseif buton==8 then
txtcolor[id]="000255255"
elseif buton==9 then
menu(id,LANG["changetextcolor"].." - "..LANG["page"].." 2,"..LANG["pink"]..","..LANG["brown"]..","..LANG["purple"]..","..LANG["darkblue"]..","..LANG["turquoise"]..","..LANG["chocolate"]..","..LANG["silver"]..","..LANG["darkcyan"]..","..LANG["back"].."")
end
if buton>0 and buton<9 and firstcolor~=txtcolor[id] then
msg2(id,ccode..""..txtcolor[id]..""..LANG["textcolorchanged"])
end
end
if title==LANG["changetextcolor"].." - "..LANG["page"].." 2" then
local firstcolor = txtcolor[id]
if buton==1 then
txtcolor[id]="255000255"
elseif buton==2 then
txtcolor[id]="164042042"
elseif buton==3 then
txtcolor[id]="128000128"
elseif buton==4 then
txtcolor[id]="000000139"
elseif buton==5 then
txtcolor[id]="175238238"
elseif buton==6 then
txtcolor[id]="210105030"
elseif buton==7 then
txtcolor[id]="192192192"
elseif buton==8 then
txtcolor[id]="000139139"
elseif buton==9 then
menu(id,LANG["changetextcolor"].." - "..LANG["page"].." 1,"..LANG["red"]..","..LANG["green"]..","..LANG["blue"]..","..LANG["yellow"]..","..LANG["white"]..","..LANG["grey"]..","..LANG["orange"]..","..LANG["cyan"]..","..LANG["next"].."")
end
if buton>0 and buton<9 and firstcolor~=txtcolor[id] then
msg2(id,ccode..""..txtcolor[id]..""..LANG["textcolorchanged"])
end
end
if title==LANG["changenamecolor"].." - "..LANG["page"].." 1" then
local firstcolor = namecolor[id]
if buton==1 then
namecolor[id]="255000000"
elseif buton==2 then
namecolor[id]="000255000"
elseif buton==3 then
namecolor[id]="000000255"
elseif buton==4 then
namecolor[id]="255255000"
elseif buton==5 then
namecolor[id]="255255255"
elseif buton==6 then
namecolor[id]="128128128"
elseif buton==7 then
namecolor[id]="255128000"
elseif buton==8 then
namecolor[id]="000255255"
elseif buton==9 then
menu(id,LANG["changenamecolor"].." - "..LANG["page"].." 2,"..LANG["pink"]..","..LANG["brown"]..","..LANG["purple"]..","..LANG["darkblue"]..","..LANG["turquoise"]..","..LANG["chocolate"]..","..LANG["silver"]..","..LANG["darkcyan"]..","..LANG["back"].."")
end
if buton>0 and buton<9 and firstcolor~=namecolor[id] then
msg2(id,ccode..""..namecolor[id]..""..LANG["namecolorchanged"])
end
end
if title==LANG["changenamecolor"].." - "..LANG["page"].." 2" then
local firstcolor = namecolor[id]
if buton==1 then
namecolor[id]="255000255"
elseif buton==2 then
namecolor[id]="164042042"
elseif buton==3 then
namecolor[id]="128000128"
elseif buton==4 then
namecolor[id]="000000139"
elseif buton==5 then
namecolor[id]="175238238"
elseif buton==6 then
namecolor[id]="210105030"
elseif buton==7 then
namecolor[id]="192192192"
elseif buton==8 then
namecolor[id]="000139139"
elseif buton==9 then
menu(id,LANG["changenamecolor"].." - "..LANG["page"].." 1,"..LANG["red"]..","..LANG["green"]..","..LANG["blue"]..","..LANG["yellow"]..","..LANG["white"]..","..LANG["grey"]..","..LANG["orange"]..","..LANG["cyan"]..","..LANG["next"].."")
end
if buton>0 and buton<9 and firstcolor~=namecolor[id] then
msg2(id,ccode..""..namecolor[id]..""..LANG["namecolorchanged"])
end
end
if title:sub(1,9) == LANG["hatsmenu"] then
local p = tonumber(title:sub(18))
if buton>0 and buton<8 then
local selected=((p-1)*7)+buton
if HATS[selected] then
shat[id]=selected
wearhat(id,selected)
hatsmenu(id,p)
end
else
if buton==8 then
hatsmenu(id,p+1)
elseif buton==9 then
hatsmenu(id,p-1)
end
end
end
end