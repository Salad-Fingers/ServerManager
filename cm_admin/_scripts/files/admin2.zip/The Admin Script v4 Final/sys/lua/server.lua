-----------------------------------
-- The Admin Script v4.0.2 Final --
-- Lua �y ���z�����              --
-- FIXED BUGS !                  --
-- Thanks For Download!          --
-----------------------------------
local xxxxx="xxxxx" -- If you're made admin yourself, remove this line.

Adminlist = {xxxxx}
--
-- Please Write Your USGN here --> xxxxx ! (Usgn nizi xxxxx yazan yeri silip yaz�n!)
-- If you are a server, you dont need write usgn!
-- If you want write 2 or more USGN write --> xxxxx,xxxxx,xxxxx (E�er birden fazla ki�i eklemek isterseniz aralar�na virg�l koyup yaz�n!)

-- END
theAdmin={}
dir = "sys/lua/theadmin/"

LANG={}
HATS={}

dofile(dir .. "language.lua")
dofile(dir .. "func_hooks.lua")
dofile(dir .. "usgnname/GetUSGNName.lua") -- Thanks to Banaan
maps = {}
-- Reading maps
local dosya = io.open(dir .. "maps.lua","r")
if dosya then
	dosya:read()
	for k in dosya:lines() do
		table.insert(maps,k)
	end
	dosya:close()
end
dosya=nil
-- Reading hats
local f = io.open(dir .. "hats.lua","r")
if f then
	f:read()
	for k in f:lines() do
		local b = 0
		if k:sub(1,1)=="#" then
			for m = 2,string.len(k) do
				if k:sub(m,m)=="#" then
					b=m
				end
			end
			table.insert(HATS,{k:sub(2,b-1),k:sub(b+1)})
		end
	end
	f=nil
end
		
dofile(dir .. "values.lua")
local d = io.open(dir .. "banlist.txt")
if d then
	dofile(dir .. "banlist.txt")
	d:close()
	d=nil
end
local d2 = io.open(dir .. "data/savedata.lua")
if d2 then
	dofile(dir .. "data/savedata.lua")
	d2:close()
	d2=nil
end

-- Hooks
addhook("die","theAdmin.die")
addhook("hit","theAdmin.hit")
addhook("say","theAdmin.say")
addhook("kill","theAdmin.kill")
addhook("join","theAdmin.join")
addhook("menu","theAdmin.menu")
addhook("team","theAdmin.team")
addhook("leave","theAdmin.leave")
addhook("spawn","theAdmin.spawn")
addhook("minute","theAdmin.minute")
addhook("reload","theAdmin.reload")
addhook("attack","theAdmin.attack")
addhook("second","theAdmin.second")
addhook("sayteam","theAdmin.sayteam")
addhook("startround","theAdmin.startround")
addhook("clientdata","theAdmin.clientdata")
addhook("serveraction","theAdmin.serveraction")
timer(20,"req","",0)

--END of Hooks
print(""..ccode.."000255000The Admin Script v"..VERSION.." Final")
print(""..ccode.."255000000�y ���z�����") -- Please don't edit here.
print(""..ccode.."255255255Thanks for use!")
-- Functions

function string.split(text,b)
local cmd = {}
if b then
b = b
else
b = "%s"
end
b = "[^"..b.."]+"
for o in string.gmatch(text,b) do
table.insert(cmd,o)
end
return cmd
end

function totable(t,match)
     local cmd = {}
     if not match then match = "[^%s]+" end
     for word in string.gmatch(t, match) do
          table.insert(cmd, word)
     end
     return cmd
end

function req()
	reqcld(0,2)
end

function dist(fromx,fromy,tox,toy)
return math.sqrt((fromx-tox)^2+(fromy-toy)^2)
end

function admin(id)
	for _, n in ipairs(Adminlist) do -- U.S.G.N Admin
		if player(id,"usgn")==n then
			return true
		end
	end
	if player(id,"ip")=="0.0.0.0" then -- Server Admin (by New game)
		return true
	end
return false
end

function teamsay(id,txt)
	for _, i in ipairs(player(0,"table")) do
		if tonumber(player(i,"team"))==tonumber(player(id,"team")) then
			msg2(i,txt)
		end
	end
end

function startmapvote(Map)
if not MAPVOTERATE then
MAPVOTERATE={
map=Map,
yes=0,
no=0,
live=true,
}
else
MAPVOTERATE.yes=0
MAPVOTERATE.no=0
MAPVOTERATE.live=true
MAPVOTERATE.map=Map
end
parse('hudtxt 7 "'..ccode..'255255255== '..string.upper(LANG["mapvote"])..' ==" 10 150')
parse('hudtxt 8 "'..ccode..'255255255'..LANG["map"]..': '..Map..'" 10 165')
parse('hudtxt 9 "'..ccode..'000255000'..LANG["yes"]..': '..MAPVOTERATE.yes..'" 10 180')
parse('hudtxt 10 "'..ccode..'255000000'..LANG["no"]..': '..MAPVOTERATE.no..'" 10 195')
parse('hudtxt 11 "'..ccode..'255255255'..LANG["timeremaining"]..': 15 sec" 10 210')
for t=1,15 do
timer(1000*t,'parse','hudtxt 11 "'..ccode..'255255255'..LANG["timeremaining"]..': '..(15-t)..' sec" 10 210',1)
end
timer(15000,'finishthemapvote','')
	for _, id in ipairs(player(0,"table")) do
		menu(id,LANG["mapvote"].." ("..Map.."),"..LANG["yes"]..","..LANG["no"].."")
	end
end

function startversus()
if not vsTAB then return end
if vsTAB.vid_1==0 or vsTAB.vid_2==0 then return end
parse('endround')
for _, i in ipairs(player(0,"table")) do
if player(i,"team")>0 and i~=vsTAB.vid_1 and i~=vsTAB.vid_2 then
parse('makespec '..i)
end
end
parse('maket '..vsTAB.vid_1)
parse('makect '..vsTAB.vid_2)
vsTAB.live=true
vsTAB.score_1=0
vsTAB.score_2=0
msg(ccode..'255000000'..player(vsTAB.vid_1,"name")..' '..ccode..''..ccode..'000255000vs '..ccode..''..ccode..'000000255'..player(vsTAB.vid_2,"name")..'@C')
parse('hudtxt 13 "'..ccode..''..teamcolor[player(vsTAB.vid_1,"team")]..''..player(vsTAB.vid_1,"name")..'" 300 430 2')
parse('hudtxt 14 "'..ccode..''..teamcolor[player(vsTAB.vid_2,"team")]..''..player(vsTAB.vid_2,"name")..'" 360 430 0')
parse('hudtxt 15 "'..ccode..'000255000('..vsTAB.score_1..'-'..vsTAB.score_2..')" 330 430 1')
end

function VShuds()
	if vsTAB.live then
		parse('hudtxt 13 "'..ccode..''..teamcolor[player(vsTAB.vid_1,"team")]..''..player(vsTAB.vid_1,"name")..'" 300 430 2')
		parse('hudtxt 14 "'..ccode..''..teamcolor[player(vsTAB.vid_2,"team")]..''..player(vsTAB.vid_2,"name")..'" 360 430 0')
		parse('hudtxt 15 "'..ccode..'000255000('..vsTAB.score_1..'-'..vsTAB.score_2..')" 330 430 1')
	end
end

function finishversus()
	if vsTAB.live then
		if vsTAB.score_1==10 then
			msg(""..ccode.."000255000"..LANG["winner"]..": "..ccode..""..ccode.."000000255"..player(vsTAB.vid_1,"name").."!@C")
		elseif vsTAB.score_2==10 then
			msg(""..ccode.."000255000"..LANG["winner"]..": "..ccode..""..ccode.."255000000"..player(vsTAB.vid_2,"name").."!@C")
		end
		closeversus()
	end
end

function closeversus()
	if vsTAB and vsTAB.live then
		vsTAB.live=false
		msg(""..ccode.."255255255"..LANG["versusclosed"])
		parse('restart 3')
		for _, i in ipairs(player(0,"table")) do
			if player(i,"team")==0 then
				if math.random(1,2)==1 then
					parse('maket '..i)
				else
					parse('makect '..i)
				end
			end
		end
		parse('hudtxt 13 "" 0 0')
		parse('hudtxt 14 "" 0 0')
		parse('hudtxt 15 "" 0 0')
	end
end

function finishthemapvote()
MAPVOTERATE.live=false
local yes,no=MAPVOTERATE.yes,MAPVOTERATE.no
for k=7,11 do
parse('hudtxt '..k..' "" 0 0')
end
if yes>no then
msg(""..ccode.."000255000"..LANG["mapvotesuccess"])
timer(10000,"parse","sv_map "..MAPVOTERATE.map)
elseif yes==no then
msg(""..ccode.."255000000"..LANG["mapvoteequal"])
else
msg(""..ccode.."255000000"..LANG["mapvotefail"])
end
end

function thenaames(p,id)
local names=""
for pl = ((p-1)*7)+1,p*7 do
if player(pl,"exists") then
if secilmis[id]=="manage" then
names=names..", "..player(pl,"name").." |"..levelname(pl)
else
names=names..", "..player(pl,"name").." "
end
else
names=names..","
end
end
return names
end

function mapsmenu(id,p)
if p<1 then p=1 end
if p>mapspagenumber then p=mapspagenumber end
local names=""
for k = (((p-1)*7)+1), p*7 do
if maps[k] then
names=names..","..maps[k]
else
names=names..","
end
end
local next,back=""..LANG["next"].."",""..LANG["back"]..""
if p==1 then back="("..LANG["back"]..")" end
if p==mapspagenumber then next="("..LANG["next"]..")" end
menu(id,LANG["mapsmenu"].." - "..LANG["page"].." "..p..""..names..","..next..","..back)
end

function hatsmenu(id,p)
if p<1 then adminmainpage(id) return end
if p>hatspagenumber then p=hatspagenumber end
local names=""
for k = (((p-1)*7)+1), p*7 do
if HATS[k] then
names=names..","..HATS[k][1]
else
names=names..","
end
end
local next,back=""..LANG["next"].."",""..LANG["back"]..""
if p==1 then back="("..LANG["back"]..")" end
if p==hatspagenumber then next="("..LANG["next"]..")" end
menu(id,LANG["hatsmenu"].." - "..LANG["page"].." "..p..""..names..","..next..","..back)
end

function changetype(id,type)
ctype[id]=type
parse('hudtxt2 '..id..' 12 "'..ccode..'255255255'..LANG["ctype"]..': '..ctype[id]..'" 10 430')
end

function createobject(id,t)
if t=="None" then return end
local b
if bteam[id]==4 then
b=player(id,"team")
else
b=bteam[id]
end
parse('hudtxt2 '..id..' 12 "'..ccode..'050050050'..LANG["ctype"]..': '..ctype[id]..'" 10 430')
parse('hudtxtcolorfade '..id..' 12 250 255 255 255')
local d=dist(cx[id],cy[id],player(id,"x"),player(id,"y"))
if t==LANG["throwable"].." "..LANG["hegrenade"] then
parse('spawnprojectile '..id..' 51 '..player(id,"x")..' '..player(id,"y")..' '..d..' '..player(id,"rot"))
elseif t==LANG["throwable"].." "..LANG["flashbang"] then
parse('spawnprojectile '..id..' 52 '..player(id,"x")..' '..player(id,"y")..' '..d..' '..player(id,"rot"))
elseif t==LANG["throwable"].." "..LANG["smokegrenade"] then
parse('spawnprojectile '..id..' 53 '..player(id,"x")..' '..player(id,"y")..' '..d..' '..player(id,"rot"))
elseif t==LANG["throwable"].." "..LANG["flare"] then
parse('spawnprojectile '..id..' 54 '..player(id,"x")..' '..player(id,"y")..' '..d..' '..player(id,"rot"))
elseif t==LANG["throwable"].." "..LANG["gasgrenade"] then
parse('spawnprojectile '..id..' 72 '..player(id,"x")..' '..player(id,"y")..' '..d..' '..player(id,"rot"))
elseif t==LANG["throwable"].." "..LANG["molotov"] then
parse('spawnprojectile '..id..' 73 '..player(id,"x")..' '..player(id,"y")..' '..d..' '..player(id,"rot"))
elseif t==LANG["throwable"].." "..LANG["snowball"] then
parse('spawnprojectile '..id..' 75 '..player(id,"x")..' '..player(id,"y")..' '..d..' '..player(id,"rot"))
elseif t==LANG["throwable"].." "..LANG["airstrike"] then
parse('spawnprojectile '..id..' 76 '..player(id,"x")..' '..player(id,"y")..' '..d..' '..player(id,"rot"))
elseif t==LANG["throwable"].." "..LANG["gutbomb"] then
parse('spawnprojectile '..id..' 86 '..player(id,"x")..' '..player(id,"y")..' '..d..' '..player(id,"rot"))
elseif t==LANG["throwable"].." "..LANG["scharge"] then
parse('spawnprojectile '..id..' 89 '..player(id,"x")..' '..player(id,"y")..' '..d..' '..player(id,"rot"))
elseif t==LANG["throwable"].." "..LANG["rpgrocket"] then
parse('spawnprojectile '..id..' 47 '..player(id,"x")..' '..player(id,"y")..' '..d..' '..player(id,"rot"))
elseif t==LANG["throwable"].." "..LANG["normrocket"] then
parse('spawnprojectile '..id..' 48 '..player(id,"x")..' '..player(id,"y")..' '..d..' '..player(id,"rot"))
elseif t==LANG["throwable"].." "..LANG["glgrenade"] then
parse('spawnprojectile '..id..' 49 '..player(id,"x")..' '..player(id,"y")..' '..d..' '..player(id,"rot"))
else
if tile(math.floor(cx[id]/32),math.floor(cy[id]/32),"walkable") then
if t==LANG["zombie"] then
parse('spawnnpc 1 '.. cx[id]/32 ..' '.. cy[id]/32)
elseif t==LANG["headcrab"] then
parse('spawnnpc 2 '.. cx[id]/32 ..' '.. cy[id]/32)
elseif t==LANG["snark"] then
parse('spawnnpc 3 '.. cx[id]/32 ..' '.. cy[id]/32)
elseif t==LANG["vortigaunt"] then
parse('spawnnpc 4 '.. cx[id]/32 ..' '.. cy[id]/32)
elseif t==LANG["soldier"] then
parse('spawnnpc 5 '.. cx[id]/32 ..' '.. cy[id]/32)
elseif t==LANG["barricade"] then
parse('spawnobject 1 '..(cx[id]/32)..' '..(cy[id]/32)..' 1 1 '..b..' '..id)
elseif t==LANG["barbedwire"] then
parse('spawnobject 2 '..(cx[id]/32)..' '..(cy[id]/32)..' 1 1 '..b..' '..id)
elseif t==LANG["wall1"] then
parse('spawnobject 3 '..(cx[id]/32)..' '..(cy[id]/32)..' 1 1 '..b..' '..id)
elseif t==LANG["wall2"] then
parse('spawnobject 4 '..(cx[id]/32)..' '..(cy[id]/32)..' 1 1 '..b..' '..id)
elseif t==LANG["wall3"] then
parse('spawnobject 5 '..(cx[id]/32)..' '..(cy[id]/32)..' 1 1 '..b..' '..id)
elseif t==LANG["gatefield"] then
parse('spawnobject 6 '..(cx[id]/32)..' '..(cy[id]/32)..' 1 1 '..b..' '..id)
elseif t==LANG["dispenser"] then
parse('spawnobject 7 '..(cx[id]/32)..' '..(cy[id]/32)..' 1 1 '..b..' '..id)
elseif t==LANG["supply"] then
parse('spawnobject 9 '..(cx[id]/32)..' '..(cy[id]/32)..' 1 1 '..b..' '..id)
elseif t==LANG["turret"] then
parse('spawnobject 8 '..(cx[id]/32)..' '..(cy[id]/32)..' 1 1 '..b..' '..id)
elseif t==LANG["dualturret"] then
parse('spawnobject 11 '..(cx[id]/32)..' '..(cy[id]/32)..' 1 1 '..b..' '..id)
elseif t==LANG["tripleturret"] then
parse('spawnobject 12 '..(cx[id]/32)..' '..(cy[id]/32)..' 1 1 '..b..' '..id)
elseif t==LANG["supersupply"] then
parse('spawnobject 15 '..(cx[id]/32)..' '..(cy[id]/32)..' 1 1 '..b..' '..id)
elseif t==LANG["tpenter"] then
parse('spawnobject 13 '..(cx[id]/32)..' '..(cy[id]/32)..' 1 1 '..b..' '..id)
elseif t==LANG["tpexit"] then
parse('spawnobject 14 '..(cx[id]/32)..' '..(cy[id]/32)..' 1 1 '..b..' '..id)
elseif t==LANG["consite"] then
parse('spawnobject 10 '..(cx[id]/32)..' '..(cy[id]/32)..' 1 1 '..b..' '..id)
elseif t==LANG["mine"] then
parse('spawnobject 20 '..(cx[id]/32)..' '..(cy[id]/32)..' 1 1 '..b..' '..id)
elseif t==LANG["orangeportal"] then
parse('spawnobject 22 '..(cx[id]/32)..' '..(cy[id]/32)..' 1 1 '..b..' '..id)
elseif t==LANG["blueportal"] then
parse('spawnobject 23 '..(cx[id]/32)..' '..(cy[id]/32)..' 1 1 '..b..' '..id)
elseif t=="Glock" then
parse('spawnitem 2 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t=="USP" then
parse('spawnitem 1 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t=="Deagle" then
parse('spawnitem 3 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t=="P228" then
parse('spawnitem 4 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t=="Elite" then
parse('spawnitem 5 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t=="Five-Seven" then
parse('spawnitem 6 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t=="M249" then
parse('spawnitem 40 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t=="M3" then
parse('spawnitem 10 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t=="XM1014" then
parse('spawnitem 11 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t=="Mac10" then
parse('spawnitem 23 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t=="TMP" then
parse('spawnitem 21 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t=="UMP45" then
parse('spawnitem 24 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t=="MP5" then
parse('spawnitem 20 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t=="P90" then
parse('spawnitem 22 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t=="AK-47" then
parse('spawnitem 30 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t=="M4A1" then
parse('spawnitem 32 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t=="Famas" then
parse('spawnitem 39 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t=="Galil" then
parse('spawnitem 38 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t=="SG552" then
parse('spawnitem 31 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t=="Aug" then
parse('spawnitem 33 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t=="Scout" then
parse('spawnitem 34 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t=="AWP" then
parse('spawnitem 35 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t=="SG550" then
parse('spawnitem 37 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t=="G4SG1" then
parse('spawnitem 36 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t=="FNF2000" then
parse('spawnitem 91 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t=="M134" then
parse('spawnitem 90 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["kevlar"] then
parse('spawnitem 57 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["kevlarhelm"] then
parse('spawnitem 58 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["lightarmor"] then
parse('spawnitem 79 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["mediumarmor"] then
parse('spawnitem 80 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["heavyarmor"] then
parse('spawnitem 81 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["medicarmor"] then
parse('spawnitem 82 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["superarmor"] then
parse('spawnitem 83 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["shealthsuit"] then
parse('spawnitem 84 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["hegrenade"] then
parse('spawnitem 51 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["flashbang"] then
parse('spawnitem 52 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["smokegrenade"] then
parse('spawnitem 53 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["flare"] then
parse('spawnitem 54 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["molotov"] then
parse('spawnitem 73 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["gasgrenade"] then
parse('spawnitem 72 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["airstrike"] then
parse('spawnitem 76 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["gutbomb"] then
parse('spawnitem 86 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["scharge"] then
parse('spawnitem 89 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["laser"] then
parse('spawnitem 45 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["rpglauncher"] then
parse('spawnitem 47 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["flamethrower"] then
parse('spawnitem 46 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["rocketlauncher"] then
parse('spawnitem 48 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["grenadelauncher"] then
parse('spawnitem 49 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["mine"] then
parse('spawnitem 77 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["lasermine"] then
parse('spawnitem 87 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["tshield"] then
parse('spawnitem 41 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["snowball"] then
parse('spawnitem 75 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["wrench"] then
parse('spawnitem 74 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["chainsaw"] then
parse('spawnitem 85 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["knife"] then
parse('spawnitem 50 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["machete"] then
parse('spawnitem 69 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["claw"] then
parse('spawnitem 78 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["bomb"] then
parse('spawnitem 55 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["redflag"] then
parse('spawnitem 70 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["blueflag"] then
parse('spawnitem 71 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["defusekit"] then
parse('spawnitem 56 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["nightvision"] then
parse('spawnitem 59 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["medikit"] then
parse('spawnitem 64 '..(cx[id]/32)..' '..(cy[id]/32))
elseif t==LANG["gold"] then
parse('spawnitem 68 '..(cx[id]/32)..' '..(cy[id]/32))
end
local img=image("gfx/sprites/flare2.bmp",math.floor(cx[id]/32)*32+16,math.floor(cy[id]/32)*32+16,1)
imagescale(img,0.1,0.1)
imageblend(img,1)
imagecolor(img,255,255,0)
tween_scale(img,400,0.7,0.7)
tween_alpha(img,400,0)
timer(400,"freeimage",img)
end
end
end

function banlist(id,p)
if not p then p = 1 end
		if p<1 then p=1 end
		if p>math.ceil(#BanList/7) then p=math.ceil(#BanList/7) end
		local bans=""
		for k = (((p-1)*7)+1), p*7 do
			if BanList[k] and BanList[k][1] and BanList[k][2] then
				bans=bans..", "..BanList[k][1].." |"..BanList[k][2]
			else
				bans=bans..","
			end
		end
		local next,back=""..LANG["next"].."",""..LANG["back"]..""
		if p==1 then back="("..LANG["back"]..")" end
		if p==math.ceil(#BanList/7) then next="("..LANG["next"]..")" end
	menu(id,LANG["unban"].." - "..LANG["page"].." "..p.."@b"..bans..","..next..","..back)
end

function savebanlist()
	local d = io.open(dir .. "banlist.txt","w")
	if d then
		for k, m in ipairs(BanList) do
			if BanList[k] and m[1] and m[2] then
				d:write('BanList['..k..'] = {"'..m[1]..'", "'..m[2]..'"}\n')
			end
		end
		d:close()
	end
end
		

function grb(id)
id=tonumber(id)
local x,y = cx[id],cy[id]
if grab[id]~=0 then
if x>0 and y>0 and x<map("xsize")*32 and y<map("ysize")*32 then
	parse('setpos '..grab[id]..' '..cx[id]..' '..cy[id])
end
timer(20,"grb",id)
end	
end

function muted(id,t)
if not t then t=300 end
if mute[id]==0 then
mute[id]=1
mutetimer[id]=t
msg2(id,""..ccode.."255000000You got muted for "..math.floor(mutetimer[id]/60).." min ".. ((string.len(mutetimer[id]%60)==2 and mutetimer[id]%60) or "0"..mutetimer[id]%60) .." sec!@C")
msg(""..ccode.."255000000"..player(id,"name").." got muted for "..math.floor(mutetimer[id]/60).." min ".. ((string.len(mutetimer[id]%60)==2 and mutetimer[id]%60) or "0"..mutetimer[id]%60) .." sec!")
end
end
function unmute(id)
if mute[id]==1 then
mute[id]=0
mutetimer[id]=0
msg2(id,""..ccode.."000255000"..LANG["unmuted"].."!@C")
end
end

function loadnames()
for i = 1,32 do
if player(i,"exists") then
name[i]=" "..player(i,"name").." "
end
end
end

parse('hudtxt 41 "'..ccode..'000255000The Admin Script v'..VERSION..' Final" 240 5')
parse('hudtxt 40 "'..ccode..'255128000'..game("sv_name")..'" 325 20 1')

function wearhat(id,s)
if player(id,"bot")==false and s>0 then
if hatimg[id] then
freeimage(hatimg[id])
end
hatimg[id]=image(HATS[s][2],1,1,200+id)
end
end

function loadplayerdata(id)
	if DATA[player(id,"usgn")] then
		userlevel[id]=DATA[player(id,"usgn")][1]
		mutetimer[id]=DATA[player(id,"usgn")][2]
	end
end

function saveplayerdata(id)
	local a=false
	if not DATA[player(id,"usgn")] then
		DATA[player(id,"usgn")]={userlevel[id],mutetimer[id]}
	else
		DATA[player(id,"usgn")][1]=userlevel[id]
		DATA[player(id,"usgn")][2]=mutetimer[id]
	end
end

DATANUM={}

function loadsavetab(num)
for k, m in ipairs(DATANUM) do
if m==num then
return
end
end
DATANUM[#DATANUM+1]=num
end

function savedata()
	for _, id in ipairs(player(0,"table")) do
		if player(id,"usgn")>0 then
			saveplayerdata(id)
		end
	end
	local f = io.open(dir .. "data/savedata.lua","w+")
	table.foreach(DATA,loadsavetab)
	if f then
		for k, m in ipairs(DATANUM) do
			local n = tonumber(DATANUM[k])
			local tab = DATA[n]
			local text="DATA["..n.."] = {"..tab[1]..","..tab[2].."}\n"
			f:write(text)
		end
		f:close()
		for k, m in ipairs(DATANUM) do
			table.remove(DATANUM,k)
		end
		print(LANG["datasaved"])
	end
end

function table.iceren(tbl,e)
	for k, m in ipairs(tbl) do
		if m==e then
			return true
		end
	end
	return false
end

function botmenu(id)
local b1,b2 = 0,0
for _, i in ipairs(player(0,"team1")) do
if player(i,"bot") then
b1=b1+1
end
end
for _, i in ipairs(player(0,"team2")) do
if player(i,"bot") then
b2=b2+1
end
end
menu(id,""..LANG["botmenu"]..","..LANG["addt"].."|"..LANG["bots"]..": "..b1..","..LANG["addct"].."|"..LANG["bots"]..": "..b2..","..LANG["removet"].."|"..LANG["bots"]..": "..b1..","..LANG["removect"].."|"..LANG["bots"]..": "..b2..","..LANG["removebots"]..","..LANG["killbots"]..","..LANG["back"].."")
end

levelnames = {
[0]=LANG["user"],
[1]=LANG["admin"],
[2]=LANG["smod"],
[3]=LANG["mod"],
[4]=LANG["vip"],
	}
	
function levelname(id)
if player(id,"exists") then
return levelnames[userlevel[id]]
end
return ""
end

function crandom()
local t=math.random(50,255)
if string.len(t)==2 then
return "0"..t
end
return t
end

function wallhackfunction(i)
i=tonumber(i)
if wallhack[i] == 1 then
timer(1,"wallhackfunction",i)
local rot = player(i,[[rot]])
if rot < -90 then rot = rot + 360 end
local angle = math.rad(math.abs( rot + 90 )) - math.pi
local x = player(i,[[x]]) + math.cos(angle) * 6
local y = player(i,[[y]]) + math.sin(angle) * 6
if x > 0 and y > 0 and x < map([[xsize]]) * 32 and y < map([[ysize]]) * 32 then
parse([[setpos ]]..i..[[ ]]..x..[[ ]]..y)
end
end
end

function adminmainpage(id)
secilmis[id]=""
if userlevel[id]==1 then
menu(id,LANG["adminmenu"]..","..LANG["serversettings"]..","..LANG["spawnmenu"]..","..LANG["administrate"]..","..LANG["punish"]..","..LANG["giveitem"]..","..LANG["restart"]..","..LANG["saysettings"]..","..LANG["scriptsettings"]..","..LANG["next"].."")
elseif userlevel[id]==2 then
menu(id,LANG["smodmenu"]..","..LANG["spawnmenu"]..","..LANG["administrate"]..","..LANG["punish"]..","..LANG["giveitem"]..","..LANG["saysettings"]..","..LANG["restart"]..","..LANG["startmapvote"]..","..LANG["hats"]..","..LANG["next"].."")
elseif userlevel[id]==3 then
menu(id,LANG["modmenu"]..","..LANG["punish"]..","..LANG["giveitem"]..","..LANG["saysettings"]..","..LANG["hats"]..","..LANG["restart"]..","..LANG["tpmenu"]..","..LANG["usgnnames"])
elseif userlevel[id]==4 then
menu(id,LANG["vipmenu"]..","..LANG["saysettings"]..","..LANG["hats"]..","..LANG["usgnnames"])
end
end

function adminsecondpage(id)
secilmis[id]=""
if userlevel[id]==1 then
menu(id,LANG["adminmenu"].." 2,"..LANG["startmapvote"]..","..LANG["hats"]..","..LANG["tpmenu"]..","..LANG["botmenu"]..","..LANG["usgnnames"]..",".. ((vsTAB.live and LANG["stopversus"]) or LANG["versus"]) ..","..LANG["unban"]..","..LANG["back"].."")
elseif userlevel[id]==2 then
menu(id,LANG["smodmenu"].." 2,"..LANG["tpmenu"]..","..LANG["botmenu"]..","..LANG["usgnnames"]..",".. ((vsTAB.live and LANG["stopversus"]) or LANG["versus"]) ..","..LANG["unban"]..",,,,"..LANG["back"].."")
end
end

function nameusgn(id)
	if player(id,"exists") then
		if player(id,"usgn")>0 then
			return player(id,"name")
		end
		return "("..player(id,"name")..")"
	end
	return ""
end

set = {
[0]=LANG["on"],
[1]=LANG["off"],
}
ddrop = {
[0]=LANG["on"],
[4]=LANG["off"],
}
hudd = {
[-1]=LANG["everything"],
[0]=LANG["nohud"],
[1]=LANG["onlyhealth"], 
[2]=LANG["onlyarmor"],
[3]=LANG["hpandarm"],
[4]=LANG["onlyclock"],
[5]=LANG["hpandclock"],
[6]=LANG["armandclock"],
[7]=LANG["hparmandclock"],
}
gmode = {
[0]=LANG["standard"],
[1]=LANG["deathmatch"],
[2]=LANG["tdeathmatch"],
[3]=LANG["construction"],
[4]=LANG["zombies"],
}
iact = {
[0]=LANG["kick"],
[1]=LANG["makespec"],
[2]=LANG["slap"],
[3]=LANG["kill"],
[4]=LANG["showmessage"],
}

--------------------------------------------------
-- UT+Quake Sounds Script by Unreal Software    --
-- 22.02.2009 - www.UnrealSoftware.de           --
-- Adds UT and Quake Sounds to your Server      --
--------------------------------------------------

if sample==nil then sample={} end
sample.ut={}

sample.ut.level=Array(32)				-- current kill level (killstreak), for each player
sample.ut.fblood=0							-- first blood already shed? 0=no/1=yes

-----------------------
-- PREPARE TO FIGHT! --
-----------------------
function ssstartround()
if UTSFX==true then
	parse("sv_sound \"fun/prepare.wav\"")
	sample.ut.fblood=0
end
end

function ssdie(id)
if UTSFX==true then
sample.ut.level[id]=0
end
end


-----------------------
-- KILL SOUNDS+MSGS  --
-----------------------
function sskill(killer,victim,weapon)
	if UTSFX==true then
		sample.ut.level[killer]=sample.ut.level[killer]+1
		level = sample.ut.level[killer]
		-- FIRST BLOOD?
		if (sample.ut.fblood==0) then
			sample.ut.fblood=1
			parse("sv_sound \"fun/firstblood.wav\"");
			msg (player(killer,"name").." sheds FIRST BLOOD by killing "..player(victim,"name").."!")
		end
		-- HUMILIATION? (KNIFEKILL)
		if (weapon==50) then
			-- HUMILIATION!
			parse("sv_sound \"fun/humiliation.wav\""); 
			msg (player(killer,"name").." humiliated "..player(victim,"name").."!")
		else
			-- REGULAR KILL
			if (level==1) then
				-- 1: Single Kill! Nothing Special!
			elseif (level==2) then
				-- 2: Doublekill
				parse("sv_sound \"fun/doublekill.wav\"");
				msg (player(killer,"name").." made a Doublekill!")
			elseif (level==3) then
				-- 3: Multikill
				parse("sv_sound \"fun/multikill.wav\"")
				msg (player(killer,"name").." made a Multikill!")
			elseif (level==4) then
				-- 4: Ultrakill
				parse("sv_sound \"fun/ultrakill.wav\"")
				msg (player(killer,"name").." made an ULTRAKILL!")
			elseif (level==5) then
				-- 5: Monsterkill
				parse("sv_sound \"fun/monsterkill.wav\"")
				msg (player(killer,"name").." made a MO-O-O-O-ONSTERKILL-ILL-ILL!")
			else
				-- >5: Unstoppable
				parse("sv_sound \"fun/unstoppable.wav\"")
				msg (player(killer,"name").." is UNSTOPPABLE! "..level.." KILLS!")
			end
		end
	end
end

--------------------------------------------
-- Show Damage Script by FastLine Advance
--------------------------------------------

sd = {}

sd.damage = Array(32)
sd.showtimer = Array(32)

function sd.hit(id,src,wpn,hp)
	if hp > 0 and src > 0 and src < 33 then -- if the source is player (part of fix)
		sd.damage[src] = sd.damage[src] + hp
		sd.show(src)
		sd.showtimer[src] = 10
	end
end

function sd.show(id)
parse('hudtxt2 '..id..' 0 "'..ccode..'255255255-'..sd.damage[id]..' HP" 300 200 -1')
end

function sd.check()
	for i = 1,32 do
		if player(i,'exists') then
			if sd.showtimer[i] > 0 then
				sd.showtimer[i] = sd.showtimer[i] - 1
			else
				sd.damage[i] = 0
				parse('hudtxt2 '..i..' 0 "" 320 240 0')
			end
		end
	end
end
