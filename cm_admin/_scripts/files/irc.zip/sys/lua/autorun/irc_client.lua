require("socket")

function game_version()
	local f = io.open("sys/core/version.cfg", "r")
	local ver = f:read("*a")
	f:close()

	ver = string.sub(ver,1,string.len(ver)-1)
	ver = string.gsub(ver, " ", "")
	ver = string.gsub(ver, "%p", "")
	return ver
end

IRC = {}

--[[ Modifiable data ]]--
IRC.Nick = game("sv_name"):gsub("%W", "") -- Nick in chat
IRC.Server = "irc.quakenet.org" -- IRC server IP
IRC.Chan = "#cs2d" -- IRC server channel
IRC.Ports = {6667} -- IRC server ports

--[[ DO NOT MODIFY ]]--
IRC.InChan = false
IRC.InChat = false
IRC.Disconnected = false

function Color(r,g,b)
	r,g,b = tostring(r),tostring(g),tostring(b)
	while string.len(r) < 3 do
		r = "0"..r
	end
	while string.len(g) < 3 do
		g = "0"..g
	end
	while string.len(b) < 3 do
		b = "0"..b
	end
	if string.len(r) == 3 and string.len(g) == 3 and string.len(b) == 3 then
		return "�"..r..g..b
	end
	return "�000000000"
end

function string.split(txt,d)
	if not d then d = " " end
	local split = {}
	local lastPos = 1
	for i = 1, string.len(txt)+1 do
		if string.sub(txt,i,i+string.len(d)-1) == d or i == string.len(txt)+1 then
			local newSplit = string.sub(txt,lastPos,i-1)
			table.insert(split,newSplit)
			lastPos = i + string.len(d)
		end
	end
	return split
end

function IRC.Connect()
	IRC.Disconnect()

	local Socket
	for i, Port in pairs(IRC.Ports) do
		Socket = socket.tcp()
		if not Socket then
			return 0
		end

		Socket:settimeout(5000, "t")
		local Success = Socket:connect(IRC.Server, Port)
		if Success and Success == 1 then
			Socket:settimeout(0, "b")
			msg(Color(0, 255, 0).."Connected to "..IRC.Server..":"..Port)
			break
		else
			msg(Color(255, 0, 0).."Failed to connect to "..IRC.Server..":"..Port)
		end

		Socket:close()
		Socket = nil
	end

	if Socket then
		IRC.InChan = false
		IRC.InChat = false
		IRC.Stream = Socket
		IRC.Send("USER "..game_version().." 127.0.0.1 "..IRC.Server.." :Counter-Strike 2D")
		IRC.Send("NICK "..IRC.Nick)
		IRC.Send("PONG ")
		return 1
	end
	return 0
end

addhook("mapchange", "IRC.Disconnect")
function IRC.Disconnect()
	if IRC.Stream then
		IRC.Stream:close()
		IRC.Stream = nil
	end
end

function Mid(str,l1,l2)
	l2 = l2 or -1
	if l2 < 0 then
		return string.sub(str,l1,string.len(str)-l2+1)
	else
		return string.sub(str,l1,l1+l2)
	end
end

function Instr(str,txt)
	return string.find(str,txt) or 0
end

function Left(str,dist)
	return string.sub(str,1,dist)
end

function IRC.Send(Message)
	if not IRC.Stream then
		return 0
	end
	return IRC.Stream:send(Message.."\n") and 1 or 0
end

addhook("always","IRC.Update")
function IRC.Update()
	if not IRC.Stream then
		return nil
	end
	while true do
		local fullResp, Error = IRC.Stream:receive("*l")
		if not fullResp then
			if Error == "closed" then
				IRC.Disconnect()
				msg(Color(255,0,0).."Disconnected")
			end
			break
		end

		local resp = fullResp
		local s = resp:split()
		if s[1] == "PING" then
			IRC.Send("PONG "..string.sub(s[2],2))
			return nil
		end

		local br = {}

		if string.sub(resp,1,1) == ":" then resp = string.sub(resp,2) end
		br[1] = Instr(resp,":")
		local cmsg; if br[1] == 0 then cmsg = resp else cmsg = Mid(resp,br[1]+1,-2) end

		-- Analyze
		local irca_def = Mid(resp,1,br[1]-1)

		-- First string
		br[2] = Instr(irca_def," ")
		local irca_fstring = Mid(irca_def,1,br[2]-1)

		-- Nick
		br[3] = Instr(irca_def,"!")
		local irca_nick = ""
		if br[3] > 0 then
			irca_nick = irca_def
			while br[3] > 0 do
				irca_nick = string.sub(irca_nick,1,br[3]-1); br[3] = Instr(irca_nick,"!")
			end
		end

		-- Command
		br[4] = Instr(resp," ",br[2]+1)
		local irca_com
		if br[4] == 0 then irca_com = "" else irca_com = Mid(resp,br[2]+1,-1) end

		-- Command Parameter
		br[5] = Instr(irca_com," ")
		local irca_comp
		if br[5] == 0 then irca_comp = "" else
			irca_comp = Mid(irca_com,br[5]+1,-1)
			if Left(irca_comp,1) == ":" then irca_comp = Mid(irca_comp,2,-1) end
		end

		-- Normal chat
		if Instr(irca_def,"PRIVMSG") > 0 then
			if Left(cmsg, 7) == "ACTION" then
				cmsg = Mid(cmsg, 9, -1)

				if cmsg:sub(1, 4) == "[SV]" then
					cmsg = cmsg:sub(cmsg:find(":") + 2)
				end
				msg(Color(255, 255, 255)..irca_nick..": "..Color(255, 255, 0)..cmsg)
			else
				if cmsg:sub(1, 4) == "[SV]" then
					cmsg = cmsg:sub(cmsg:find(":") + 2)
				end
				msg(Color(255, 255, 255)..irca_nick.." "..Color(0, 255, 0).."[IRC]: "..Color(255, 255, 0)..cmsg)
			end
			return nil
		elseif Instr(irca_def, "NOTICE") > 0 then
			msg(Color(255, 255, 255).."* "..Color(255, 255, 255)..irca_nick.." "..Color(0, 255, 0).."Notice: "..Color(255, 255, 0)..cmsg)
			return nil
		elseif string.upper(Left(irca_comp,string.len(IRC.Nick)+string.len(IRC.Chan)+3)) == string.upper(IRC.Nick.." = "..IRC.Chan) or string.upper(Left(irca_comp,string.len(IRC.Nick)+string.len(IRC.Chan)+3)) == string.upper(IRC.Nick.." @ "..IRC.Chan) then
			local tstr = irca_comp
			local tbr = Instr(tstr,":")
			if tbr then
				tstr = Mid(tstr,tbr+1,-1)
				while true do
					tbr = Instr(tstr," ")
					tn = Mid(tstr,1,tbr-1)
					if tbr > 0 then
						tstr = Mid(tstr,tbr+1,-1)
					else
						tstr = ""
					end

					if string.len(tstr) == 0 then
						break
					end
				end
			end
			return nil
		elseif Left(irca_com, 4) == "JOIN" then
			msg(Color(255, 255, 255)..irca_nick.." has joined IRC channel")
			return nil
		elseif Left(irca_com, 4) == "PART" then
			msg(Color(255, 255, 255)..irca_nick.." "..Color(255, 255, 0).."has left IRC channel")
			return nil
		elseif Left(irca_com, 4) == "QUIT" then
			msg(Color(255, 255, 255)..irca_nick.." "..Color(255, 255, 0).."has left IRC channel")
			return nil
		elseif Left(irca_com, 4) == "MODE" then
			msg(Color(255, 255, 255)..irca_nick.." "..Color(255, 255, 0).."sets mode: "..Color(0, 255, 0) .. irca_comp)
			return nil
		elseif cmsg == "End of /MOTD command." then
			IRC.InChat = true
			IRC.Send("JOIN "..IRC.Chan)
		end
	end
end

function PlayerIRC(id,txt)
	IRC.Send("PRIVMSG "..IRC.Chan.." :[SV]"..player(id,"name")..": "..txt)
end

addhook("say","IRC.Say")
addhook("sayteam","IRC.Say")
function IRC.Say(id,txt)
	local s = txt:split()
	if s[1] == "!irc" then
		if IRC.Stream then
			if IRC.InChat then
				local irc_msg = string.sub(txt, 6)
				PlayerIRC(id, irc_msg)

				if player(id,"team") == 1 or player(id, "team") == 3 then
					msg(Color(255, 0, 0) .. player(id,"name").." "..Color(255, 0, 255).."-> IRC: "..Color(255,255,0)..irc_msg)
				elseif player(id,"team") == 2 then
					msg(Color(0, 0, 255) .. player(id,"name").." "..Color(255, 0, 255).."-> IRC: "..Color(255,255,0)..irc_msg)
				elseif player(id,"team") == 0 then
					msg(Color(255, 255, 0) .. player(id,"name").." "..Color(255, 0, 255).."-> IRC: "..Color(255,255,0)..irc_msg)
				end
			else
				msg2(id, Color(255, 0, 0).."Not connected to channel")
			end
		else
			msg2(id, Color(255, 0, 0).."IRC is offline")
		end
		return 1
	elseif s[1] == "!ircconnect" then
		if player(id, "rcon") or player(id, "ip") == "0.0.0.0" then
			if IRC.Stream then
				msg2(id, Color(255, 0, 0).."IRC is already connected")
			else
				msg2(id, Color(0, 255, 0).."Attempting to connect")
				IRC.Connect()
			end
		else
			msg2(id, Color(255, 0, 0).."Only server administrator(s) are allowed to run this command")
		end
		return 1
	elseif s[1] == "!ircdisconnect" then
		if player(id, "rcon") or player(id, "ip") == "0.0.0.0" then
			if IRC.Stream then
				IRC.Disconnect()
				msg2(id, Color(0, 255, 0).."Disconnected successfully")
			else
				msg2(id, Color(255, 0, 0).."IRC is already disconnected")
			end
		else
			msg2(id, Color(255, 0, 0).."Only server administrator(s) are allowed to run this command")
		end
		return 1
	end
end

addhook("log","onlog")
function onlog(txt)
	if txt == "Server Shutdown" then
		IRC.Disconnect()
	end
end
IRC.Connect()
