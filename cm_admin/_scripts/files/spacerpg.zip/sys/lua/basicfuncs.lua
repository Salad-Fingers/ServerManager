function initArray2(f,v)
	local cmd={}
	for c=1,f do
		cmd[c]=v
	end
	return cmd
end

function doublearray(m,n,k)
    local a, x, y = {}
    for x = 0, m do a[x] = {}
        for y = 0, n do
            a[x][y] = k
        end
    end
    return a
end

function contains(table, element)
    for _, value in ipairs(table) do
        if value == element then
            return true
        end
    end
    return false
end

function table.find(table, element)
    for key, value in ipairs(table) do
        if value == element then
            return key
        end
    end
    return nil
end

function hudtxt2(id,idt,color,text,x,y)
	local toprint=("�"..color.." "..text)
	parse('hudtxt2 '..id..' '..idt..' "'..toprint..'" '..x.." "..y)
end

function sound3(tilex,tiley,rangex,rangey,sound)
    -- Ranges are tiles!
    for pl=1,32 do
        if (player(pl,"exists")) then
            if (player(pl,"tilex")>=tilex-rangex and player(pl,"tiley")>=tiley-rangey and player(pl,"tilex")<=tilex+rangex and player(pl,"tiley")<=tiley+rangey) then
                parse("sv_sound2 "..pl.." \""..sound.."\"")
            end
        end
    end
end

function inRange(x,y,rx1,ry1,rx2,ry2)
	if (x>=rx1 and x<=rx2 and y>=ry1 and y<=ry2) then
		return true
	end
	return false
end

function csconvert(rot,x,y,factor)
	if rot<-90 then rot=rot+360 end
	local angle=math.rad(math.abs(rot+90))-math.pi
	local cx=x+(math.cos(angle)*factor)
	local cy=y+(math.sin(angle)*factor)
	return cx,cy
end
