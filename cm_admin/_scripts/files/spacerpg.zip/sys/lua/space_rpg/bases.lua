shieldp=initArray2(32,0)
armorp=initArray2(32,0)
energyp=initArray2(32,0)
fuelp=initArray2(32,0)
statsp=initArray2(32,0)
factj=initArray2(32,0)
factp=initArray2(32,0)

function inZone(id,x1,x2,y1,y2)
    if (player(id,"tilex")>=x1 and player(id,"tilex")<=x2 and player(id,"tiley")>=y1 and player(id,"tiley")<=y2) then
        return true
    end
end

function test(id)
    for zz=1,#zones do
        if (inZone(id,zones[zz].xs,zones[zz].xe,zones[zz].ys,zones[zz].ye)) then
			if (not zones[zz].type or zones[zz].type~="planet") then
				hudtxt2(id,27,"000255000","You are in "..zones[zz].name.." sector, "..factions[zones[zz].faction].name.." space",120,20)
				break
			else
				hudtxt2(id,27,"000255000","You are on the surface of "..planets[zones[zz].planet].name..", owned by "..factions[zones[zz].faction].name,120,20)
				break
			end
        else
            hudtxt2(id,27,"000255000","You are in open space",120,20)
        end
    end
end

function test2(id)
	for zz=1,#zones do
		if (zones[zz].comm and inZone(id,zones[zz].comm.x1,zones[zz].comm.x2,zones[zz].comm.y1,zones[zz].comm.y2)) then
			hudtxt2(id,28,"000255000","=== TRADING ZONE ===",120,35)
			break
		else
			hudtxt2(id,28,"000255000","",120,40)
		end
	end
end

function test3(id)
	for zz=1,#zones do
		if (zones[zz].bar and inZone(id,zones[zz].bar.x1,zones[zz].bar.x2,zones[zz].bar.y1,zones[zz].bar.y2)) then
			hudtxt2(id,29,"000255000","=== SOCIAL HUB ===",120,35)
			break
		else
			hudtxt2(id,29,"000255000","",120,40)
		end
	end
end

addhook("movetile","zonemove")
function zonemove(id,x,y)
    test(id)
    test2(id)
    test3(id)
end

function getComm(b,n,id)
    if (basedata[b]~=nil and basedata[b].commtr[n]~=nil) then
	 if (reputation[id][zones[b].faction]~=0) then
        	return comms[basedata[b].commtr[n].type].name.."|"..basedata[b].commtr[n].price-elib.percent(basedata[b].commtr[n].price,(0.5*reputation[id][zones[b].faction]))
	 else
		return comms[basedata[b].commtr[n].type].name.."|"..basedata[b].commtr[n].price
	 end
    else
        return ""
    end
end

function getBComm(b,n,id)
    if (basedata[b]~=nil and basedata[b].commb[n]~=nil) then
	 if (reputation[id][zones[b].faction]~=0) then
        	return comms[basedata[b].commb[n].type].name.."|"..basedata[b].commb[n].price-elib.percent(basedata[b].commb[n].price,(0.5*reputation[id][zones[b].faction]))
	 else
		return comms[basedata[b].commb[n].type].name.."|"..basedata[b].commb[n].price
	 end
    else
        return ""
    end
end

function getEq(b,n,id)
    if (basedata[b] and basedata[b].eqtr[n]) then
	 if (reputation[id][zones[b].faction]~=0) then
        	return equipment[basedata[b].eqtr[n].type].name.."|"..basedata[b].eqtr[n].price-elib.percent(basedata[b].eqtr[n].price,(0.5*reputation[id][zones[b].faction]))
	 else
		return equipment[basedata[b].eqtr[n].type].name.."|"..basedata[b].eqtr[n].price
	 end
    else
        return ""
    end
end

function getShip(b,n,id)
    if (basedata[b] and basedata[b].shtr[n]) then
	 if (reputation[id][zones[b].faction]~=0) then
        	return ships[basedata[b].shtr[n].type].name.."|"..basedata[b].shtr[n].price-elib.percent(basedata[b].shtr[n].price,(0.5*reputation[id][zones[b].faction]))
	 else
		return ships[basedata[b].shtr[n].type].name.."|"..basedata[b].shtr[n].price
	 end
    else
        return ""
    end
end

function trademenu(id,z,p)
	p=p or 1
	local pages=math.ceil(#basedata[z].commtr/6)
	if (pages>1) then
		if (pages>2) then
			if (p==1) then
				menu(id,"Commodity Trader "..p.." - "..zones[z].name..","..getComm(z,1,id)..","..getComm(z,2,id)..","..getComm(z,3,id)..","..getComm(z,4,id)..","..getComm(z,5,id)..","..getComm(z,6,id)..",Next,,Sell")
			elseif (p>1 and p<pages) then
				menu(id,"Commodity Trader "..p.." - "..zones[z].name..","..getComm(z,1+(6*(p-1)),id)..","..getComm(z,2+(6*(p-1)),id)..","..getComm(z,3+(6*(p-1)),id)..","..getComm(z,4+(6*(p-1)),id)..","..getComm(z,5+(6*(p-1)),id)..","..getComm(z,6+(6*(p-1)),id)..",Next,Prev,Sell")
			else
				menu(id,"Commodity Trader "..p.." - "..zones[z].name..","..getComm(z,1+(6*(pages-1)),id)..","..getComm(z,2+(6*(pages-1)),id)..","..getComm(z,3+(6*(pages-1)),id)..","..getComm(z,4+(6*(pages-1)),id)..","..getComm(z,5+(6*(pages-1)),id)..","..getComm(z,6+(6*(pages-1)),id)..",,Prev,Sell")
			end
		elseif (pages==2) then
			if (p==1) then
				menu(id,"Commodity Trader "..p.." - "..zones[z].name..","..getComm(z,1,id)..","..getComm(z,2,id)..","..getComm(z,3,id)..","..getComm(z,4,id)..","..getComm(z,5,id)..","..getComm(z,6,id)..",Next,,Sell")
			elseif (p>1 and p<pages) then
				menu(id,"Commodity Trader "..p.." - "..zones[z].name..","..getComm(z,7,id)..","..getComm(z,8,id)..","..getComm(z,9,id)..","..getComm(z,10,id)..","..getComm(z,11,id)..","..getComm(z,12,id)..",,Prev,Sell")
			end
		end
	elseif (pages==1) then
		menu(id,"Commodity Trader "..p.." - "..zones[z].name..","..getComm(z,1,id)..","..getComm(z,2,id)..","..getComm(z,3,id)..","..getComm(z,4,id)..","..getComm(z,5,id)..","..getComm(z,6,id)..",,,Sell")
	end
end

function trsellmenu(id,z,p)
	p=p or 1
	local pages=math.ceil(#basedata[z].commb/6)
	if (pages>1) then
		if (pages>2) then
			if (p==1) then
				menu(id,"Commodity Trader (Sell) "..p.." - "..zones[z].name..","..getBComm(z,1,id)..","..getBComm(z,2,id)..","..getBComm(z,3,id)..","..getBComm(z,4,id)..","..getBComm(z,5,id)..","..getBComm(z,6,id)..",Next,,Buy")
			elseif (p>1 and p<pages) then
				menu(id,"Commodity Trader "..p.." - "..zones[z].name..","..getBComm(z,1+(6*(p-1)),id)..","..getBComm(z,2+(6*(p-1)),id)..","..getBComm(z,3+(6*(p-1)),id)..","..getBComm(z,4+(6*(p-1)),id)..","..getBComm(z,5+(6*(p-1)),id)..","..getBComm(z,6+(6*(p-1)),id)..",Next,Prev,Buy")
			else
				menu(id,"Commodity Trader "..p.." - "..zones[z].name..","..getBComm(z,1+(6*(pages-1)),id)..","..getBComm(z,2+(6*(pages-1)),id)..","..getBComm(z,3+(6*(pages-1)),id)..","..getBComm(z,4+(6*(pages-1)),id)..","..getBComm(z,5+(6*(pages-1)),id)..","..getBComm(z,6+(6*(pages-1)),id)..",,Prev,Buy")
			end
		elseif (pages==2) then
			if (p==1) then
				menu(id,"Commodity Trader (Sell) "..p.." - "..zones[z].name..","..getBComm(z,1,id)..","..getBComm(z,2,id)..","..getBComm(z,3,id)..","..getBComm(z,4,id)..","..getBComm(z,5,id)..","..getBComm(z,6,id)..",Next,,Buy")
			elseif (p>1 and p<pages) then
				menu(id,"Commodity Trader (Sell) "..p.." - "..zones[z].name..","..getBComm(z,7,id)..","..getBComm(z,8,id)..","..getBComm(z,9,id)..","..getBComm(z,10,id)..","..getBComm(z,11,id)..","..getBComm(z,12,id)..",,Prev,Buy")
			end
		end
	elseif (pages==1) then
		menu(id,"Commodity Trader (Sell) "..p.." - "..zones[z].name..","..getBComm(z,1,id)..","..getBComm(z,2,id)..","..getBComm(z,3,id)..","..getBComm(z,4,id)..","..getBComm(z,5,id)..","..getBComm(z,6,id)..",,,Buy")
	end
end

function eqmenu(id,z,p)
	p=p or 1
	local pages=math.ceil(#basedata[z].eqtr/6)
	if (pages>1) then
		if (pages>2) then
			if (p==1) then
				menu(id,"Equipment Trader "..p.." - "..zones[z].name..","..getEq(z,1,id)..","..getEq(z,2,id)..","..getEq(z,3,id)..","..getEq(z,4,id)..","..getEq(z,5,id)..","..getEq(z,6,id)..",Next,")
			elseif (p>1 and p<pages) then
				menu(id,"Equipment Trader "..p.." - "..zones[z].name..","..getEq(z,1+(6*(p-1)),id)..","..getEq(z,2+(6*(p-1)),id)..","..getEq(z,3+(6*(p-1)),id)..","..getEq(z,4+(6*(p-1)),id)..","..getEq(z,5+(6*(p-1)),id)..","..getEq(z,6+(6*(p-1)),id)..",Next,Prev")
			else
				menu(id,"Equipment Trader "..p.." - "..zones[z].name..","..getEq(z,1+(6*(pages-1)),id)..","..getEq(z,2+(6*(pages-1)),id)..","..getEq(z,3+(6*(pages-1)),id)..","..getEq(z,4+(6*(pages-1)),id)..","..getEq(z,5+(6*(pages-1)),id)..","..getEq(z,6+(6*(pages-1)),id)..",,Prev")
			end
		elseif (pages==2) then
			if (p==1) then
				menu(id,"Equipment Trader "..p.." - "..zones[z].name..","..getEq(z,1,id)..","..getEq(z,2,id)..","..getEq(z,3,id)..","..getEq(z,4,id)..","..getEq(z,5,id)..","..getEq(z,6,id)..",Next")
			elseif (p>1 and p<pages) then
				menu(id,"Equipment Trader "..p.." - "..zones[z].name..","..getEq(z,7,id)..","..getEq(z,8,id)..","..getEq(z,9,id)..","..getEq(z,10,id)..","..getEq(z,11,id)..","..getEq(z,12,id)..",,Prev")
			end
		end
	elseif (pages==1) then
		menu(id,"Equipment Trader "..p.." - "..zones[z].name..","..getEq(z,1,id)..","..getEq(z,2,id)..","..getEq(z,3,id)..","..getEq(z,4,id)..","..getEq(z,5,id)..","..getEq(z,6,id))
	end
end

function shmenu(id,z,p)
	p=p or 1
	local pages=math.ceil(#basedata[z].shtr/6)
	if (pages>1) then
		if (pages>2) then
			if (p==1) then
				menu(id,"Equipment Trader "..p.." - "..zones[z].name..","..getShip(z,1,id)..","..getShip(z,2,id)..","..getShip(z,3,id)..","..getShip(z,4,id)..","..getShip(z,5,id)..","..getShip(z,6,id)..",Next,,Sell")
			elseif (p>1 and p<pages) then
				menu(id,"Spaceship Trader "..p.." - "..zones[z].name..","..getShip(z,1+(6*(p-1)),id)..","..getShip(z,2+(6*(p-1)),id)..","..getShip(z,3+(6*(p-1)),id)..","..getShip(z,4+(6*(p-1)),id)..","..getShip(z,5+(6*(p-1)),id)..","..getShip(z,6+(6*(p-1)),id)..",Next,Prev")
			else
				menu(id,"Spaceship Trader "..p.." - "..zones[z].name..","..getShip(z,1+(6*(pages-1)),id)..","..getShip(z,2+(6*(pages-1)),id)..","..getShip(z,3+(6*(pages-1)),id)..","..getShip(z,4+(6*(pages-1)),id)..","..getShip(z,5+(6*(pages-1)),id)..","..getShip(z,6+(6*(pages-1)),id)..",,Prev")
			end
		elseif (pages==2) then
			if (p==1) then
				menu(id,"Spaceship Trader "..p.." - "..zones[z].name..","..getShip(z,1,id)..","..getShip(z,2,id)..","..getShip(z,3,id)..","..getShip(z,4,id)..","..getShip(z,5,id)..","..getShip(z,6,id)..",Next")
			elseif (p>1 and p<pages) then
				menu(id,"Spaceship Trader "..p.." - "..zones[z].name..","..getShip(z,7,id)..","..getShip(z,8,id)..","..getShip(z,9,id)..","..getShip(z,10,id)..","..getShip(z,11,id)..","..getShip(z,12,id)..",,Prev")
			end
		end
	elseif (pages==1) then
		menu(id,"Spaceship Trader "..p.." - "..zones[z].name..","..getShip(z,1,id)..","..getShip(z,2,id)..","..getShip(z,3,id)..","..getShip(z,4,id)..","..getShip(z,5,id)..","..getShip(z,6,id)..",,")
	end
end

function findByName(name)
    for z=1,#zones do
        if (zones[z].name==name) then
            return z
        else
            return nil
        end
    end
end

function getTraders(z,m)
	if (m==1) then
		if (basedata[z] and basedata[z].commtr) then
			return "Commodities"
		end
	elseif (m==2) then
		if (basedata[z] and basedata[z].commb) then
			return "Commodities (Sell)"
		end
	elseif (m==3) then
		if (basedata[z] and basedata[z].eqtr) then
			return "Equipment"
		end
	elseif (m==4) then
		if (basedata[z] and basedata[z].shtr) then
			return "Ships"
		end
	end
	return ""
end

--[[function msgParse(id,t,color,x,y)
	local brs,bre=t:find("\n")
	if t and brs and bre then
		msg2(id,t:sub(1,brs-1))
		msg2(id,msgParse(id,t:sub(bre+1)))
	else
		msg2(id,t)
	end
end]]

function getBribe(z,i,id)
	if (z and basedata[z] and basedata[z].bribes and basedata[z].bribes[i]) then
		if (reputation[id][basedata[z].bribes[i].faction]>=factions[basedata[z].bribes[i].faction].initrep-basedata[z].bribes[i].factor and reputation[id][basedata[z].bribes[i].faction]<factions[basedata[z].bribes[i].faction].initrep+basedata[z].bribes[i].factor) then
			if (credits[id]>=basedata[z].bribes[i].price) then
				return factions[basedata[z].bribes[i].faction].name.."|"..basedata[z].bribes[i].price
			else
				return "("..factions[basedata[z].bribes[i].faction].name..")|"..basedata[z].bribes[i].price
			end
		end
	end
	return ""
end

function baseBribes(id,z)
	menu(id,"Bribes - "..zones[z].name.."@b,"..getBribe(z,1,id)..","..getBribe(z,2,id)..","..getBribe(z,3,id)..","..getBribe(z,4,id)..","..getBribe(z,5,id)..","..getBribe(z,6,id)..","..getBribe(z,7,id)..","..getBribe(z,8,id)..","..getBribe(z,9,id))
end

function repStats(id)
	shieldp[id]=(ships[shipt[id]].shield-shield[id])*0.5
	armorp[id]=(ships[shipt[id]].armor-armor[id])*2
	energyp[id]=(ships[shipt[id]].energy-energy[id])*2
	fuelp[id]=(ships[shipt[id]].fuel-fuel[id])*3
	statsp[id]=shieldp[id]+armorp[id]+energyp[id]+fuelp[id]
	menu(id,"Replenish Stats,Shield|"..shieldp[id]..",Armor|"..armorp[id]..",Energy|"..energyp[id]..",Fuel|"..fuelp[id]..",Replenish All|"..statsp[id])
end

function getAl(id,b)
	if (basedata[b] and basedata[b].factc) then
		if (credits[id]>=basedata[b].factc and faction[id]~=zones[b].faction) then
			return "Gain Allegiance|"..basedata[b].factc
		else
			return "(Gain Allegiance)|"..basedata[b].factc
		end
	end
	return ""
end

function promptAl(id,f,p)
	menu(id,"FACTION JOIN CONFIRMATION@b,(You are about to join "..factions[f].name.." - are you sure?,Yes,No")
	factj[id]=f
	factp[id]=p
end

addhook("use","traders")
function traders(id)
    for z=1,#zones do
        if (zones[z]~=nil and zones[z].comm~=nil and player(id,"tilex")>=zones[z].comm.x1 and player(id,"tilex")<=zones[z].comm.x2 and player(id,"tiley")>=zones[z].comm.y1 and player(id,"tiley")<=zones[z].comm.y2) then
            menu(id,"SERVICES - "..zones[z].name..","..getTraders(z,1)..","..getTraders(z,2)..","..getTraders(z,3)..","..getTraders(z,4)..",,,,"..getAl(id,z)..",Replenish Stats")
        end
        if (zones[z]~=nil and zones[z].bar~=nil and player(id,"tilex")>=zones[z].bar.x1 and player(id,"tilex")<=zones[z].bar.x2 and player(id,"tiley")>=zones[z].bar.y1 and player(id,"tiley")<=zones[z].bar.y2) then
            menu(id,"SOCIAL HUB - "..zones[z].name..",(Missions|Not available yet),Bribes")
        end
    end
end

addhook("menu","buymenus")
function buymenus(id,menu,sel)
    for z=1,#zones do
		if (menu=="SERVICES - "..zones[z].name) then
			if (sel==1) then
				trademenu(id,z)
			end
			if (sel==2) then
				trsellmenu(id,z)
			end
			if (sel==3) then
				eqmenu(id,z)
			end
			if (sel==4) then
				shmenu(id,z)
			end
			if (sel==8) then
				if (faction[id]~=zones[z].faction and credits[id]>=basedata[z].factc) then
					promptAl(id,zones[z].faction,basedata[z].factc)
				end
			end
			if (sel==9) then
				repStats(id)
			end
		end
		if (menu=="SOCIAL HUB - "..zones[z].name) then
			if (sel==2) then
				baseBribes(id,z)
			end
		end
		if (z and basedata[z] and basedata[z].commtr) then
			for i=1,#basedata[z].commtr do
				if (menu=="Commodity Trader "..i.." - "..zones[z].name) then
					local name=menu:sub(21)
					local page=tonumber(menu:sub(17,19))
					if (sel>=1 and sel<=6 and credits[id]>=basedata[z].commtr[(sel+(6*(page-1)))].price) then
						if (checkFree(id)) then
							insertInBackpack(id,basedata[z].commtr[(sel+(6*(page-1)))].type,1)
							if (reputation[id][zones[z].faction]~=0) then
								credits[id]=credits[id]-(basedata[z].commtr[(sel+(6*(page-1)))].price-elib.percent(basedata[z].commtr[(sel+(6*(page-1)))].price,(0.5*reputation[id][zones[z].faction])))
							else
								credits[id]=credits[id]-basedata[z].commtr[(sel+(6*(page-1)))].price
							end
							trademenu(id,z)
						end
					end
					if (sel==7) then
						trademenu(id,findByName(name),page+1)
					end
					if (sel==8) then
						trademenu(id,findByName(name),page-1)
					end
					if (sel==9) then
						trsellmenu(id,findByName(name))
					end
				end
			end
		end
		if (z and basedata[z] and basedata[z].commb) then
			for i=1,#basedata[z].commb do
				if (menu=="Commodity Trader (Sell) "..i.." - "..zones[z].name) then
					local name=menu:sub(30)
					local page=tonumber(menu:sub(25,26))
					if (sel>=1 and sel<=6 and findInBackpack(id,basedata[z].commb[(sel+(6*(page-1)))].type)) then
						removeFromBackpack(id,findInBackpack(id,basedata[z].commb[(sel+(6*(page-1)))].type))
						if (reputation[id][zones[z].faction]~=0) then
							credits[id]=credits[id]+(basedata[z].commb[(sel+(6*(page-1)))].price+elib.percent(basedata[z].commb[(sel+(6*(page-1)))].price,(0.5*reputation[id][zones[z].faction])))
						else
							credits[id]=credits[id]+basedata[z].commb[(sel+(6*(page-1)))].price
						end
						trsellmenu(id,z,page)
					end
					if (sel==7) then
						trsellmenu(id,findByName(name),page+1)
					end
					if (sel==8) then
						trsellmenu(id,findByName(name),page-1)
					end
					if (sel==9) then
						trademenu(id,findByName(name))
					end
				end
			end
		end
		if (z and basedata[z] and basedata[z].eqtr) then
			for i=1,#basedata[z].eqtr do
				if (menu=="Equipment Trader "..i.." - "..zones[z].name) then
					local name=menu:sub(21)
					local page=tonumber(menu:sub(17,19))
					if (sel>=1 and sel<=6 and credits[id]>=basedata[z].eqtr[(sel+(6*(page-1)))].price-elib.percent(basedata[z].eqtr[(sel+(6*(page-1)))].price,(0.5*reputation[id][zones[z].faction]))) then
						if (checkFree(id)) then
							insertInBackpack(id,basedata[z].eqtr[(sel+(6*(page-1)))].type+100,1)
							if (reputation[id][zones[z].faction]~=0) then
								credits[id]=credits[id]-(basedata[z].eqtr[(sel+(6*(page-1)))].price-elib.percent(basedata[z].eqtr[(sel+(6*(page-1)))].price,(0.5*reputation[id][zones[z].faction])))
							else
								credits[id]=credits[id]-basedata[z].eqtr[(sel+(6*(page-1)))].price
							end
							eqmenu(id,z)
						end
					end
					if (sel==7) then
						eqmenu(id,findByName(name),page+1)
					end
					if (sel==8) then
						eqmenu(id,findByName(name),page-1)
					end
				end
			end
		end
		if (z and basedata[z] and basedata[z].shtr) then
			for i=1,#basedata[z].shtr do
				if (menu=="Spaceship Trader "..i.." - "..zones[z].name) then
					local name=menu:sub(21)
					local page=tonumber(menu:sub(17,19))
					if (sel>=1 and sel<=6 and credits[id]>=basedata[z].shtr[(sel+(6*(page-1)))].price-elib.percent(basedata[z].shtr[(sel+(6*(page-1)))].price,(0.5*reputation[id][zones[z].faction]))) then
						shipt[id]=basedata[z].shtr[(sel+(6*(page-1)))].type
						if (reputation[id][zones[z].faction]~=0) then
							credits[id]=credits[id]-(basedata[z].shtr[(sel+(6*(page-1)))].price-elib.percent(basedata[z].shtr[(sel+(6*(page-1)))].price,(0.5*reputation[id][zones[z].faction])))
						else
							credits[id]=credits[id]-basedata[z].shtr[(sel+(6*(page-1)))].price
						end
						initHardware(id)
					end
					if (sel==7) then
						shmenu(id,findByName(name),page+1)
					end
					if (sel==8) then
						shmenu(id,findByName(name),page-1)
					end
				end
			end
		end
		if (menu=="Replenish Stats") then
			if (sel==1) then
				if (credits[id]>=shieldp[id]) then
					shield[id]=ships[shipt[id]].shield
					credits[id]=credits[id]-shieldp[id]
				end
			end
			if (sel==2) then
				if (credits[id]>=armordp[id]) then
					armor[id]=ships[shipt[id]].armor
					credits[id]=credits[id]-armorp[id]
				end
			end
			if (sel==3) then
				if (credits[id]>=energyp[id]) then
					energy[id]=ships[shipt[id]].energy
					credits[id]=credits[id]-energyp[id]
				end
			end
			if (sel==4) then
				if (credits[id]>=fuelp[id]) then
					fuel[id]=ships[shipt[id]].fuel
					credits[id]=credits[id]-fuelp[id]
				end
			end
			if (sel==5) then
				if (credits[id]>=statsp[id]) then
					initHardware(id)
					credits[id]=credits[id]-statsp[id]
				end
			end
		end
		if (menu=="Bribes - "..zones[z].name) then
			if (sel~=0) then
				if (credits[id]>=basedata[z].bribes[sel].price) then
					changeRep(id,basedata[z].bribes[sel].faction,basedata[z].bribes[sel].factor)
					credits[id]=credits[id]-basedata[z].bribes[sel].price
				else
					msg2(id,"You don't have enough money")
				end
			end
		end
    end
	if (menu=="FACTION JOIN CONFIRMATION") then
		credits[id]=credits[id]-factp[id]
		joinFaction(id,factj[id])
		factj[id]=0
	end
end
