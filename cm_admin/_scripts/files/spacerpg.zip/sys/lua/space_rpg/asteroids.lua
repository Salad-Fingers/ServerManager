astimg=initArray2(1024,0)
astoc=initArray2(1024,0)
astocc=initArray2(32,0)
astoci=initArray2(1024,0)
astype=initArray2(1024,0)
asthealth=initArray2(1024,0)
astcomm=initArray2(1024,0)
astpos=doublearray(1024,2,0)
astold=initArray2(1024,{})
asts={}

function checkEmpty2(v)
    for i = 1, #asts do
        if asts[i] == 0 then
            asts[i] = v
            return i
        end
    end
    asts[#asts + 1] = v
	return #asts
end

function createAsteroid(id,x,y,type,mineral)
	astimg[id]=image("gfx/space/asteroid_0"..type..".png",x*32+16,y*32+16,1)
	imagepos(astimg[id],x*32+16,y*32+16,math.random(0,360))
	astype[id]=type
	asthealth[id]=type*10
	astcomm[id]=mineral
	astpos[id][1]=x
	astpos[id][2]=y
	checkEmpty2(id)
end

function hitAsteroid(id,ply,dmg)
	asthealth[id]=asthealth[id]-dmg
	if (asthealth[id]<=0) then
		killAsteroid(id,ply)
	end
end

function deocAsteroid(ply)
	if (astocc[ply]~=0) then
		freeimage(astoci[astocc[ply]])
		astoc[astocc[ply]]=0
		astoci[astocc[ply]]=0
		astocc[ply]=0
	end
end

function killAsteroid(id,ply)
	if (astcomm[id]~=0) then
		insertInBackpack(ply,astcomm[id],astype[id])
	end
	removeAsteroid(id)
end

function removeAsteroid(id)
	astold[id].pos={astpos[id][1],astpos[id][2]}
	astold[id].type=astype[id]
	astold[id].comm=astcomm[id]
	timer(60000,"parse","lua createAsteroid("..id..","..astold[id].pos[1]..","..astold[id].pos[2]..","..astold[id].type..","..astold[id].comm..")")
	freeimage(astimg[id])
	freeimage(astoci[id])
	astoci[id]=0
	astimg[id]=0
	astoc[id]=0
	asthealth[id]=0
	astcomm[id]=0
	astype[id]=0
	astpos[id][1]=0
	astpos[id][2]=0
	asts[id]=0
end

function createAsteroidField(density,mineral,x1,y1,x2,y2)
	local area=(x2-x1)*(y2-y1)
	if (area>=9) then
		if (density==1) then
			for ast=(#asts+1),(math.floor(area/5))+(#asts) do
				local function createast(x1,y1,x2,y2,mineral,id)
					local xx=math.random(x1,x2)
					local yy=math.random(y1,y2)
					createAsteroid(id,xx,yy,(math.random(1,5)),mineral)
				end
				createast(x1,y1,x2,y2,mineral,ast)
			end
		elseif (density==2) then
			for ast=(#asts+1),(math.floor(area/2))+(#asts) do
				local function createast(x1,y1,x2,y2,mineral,id)
					local xx=math.random(x1,x2)
					local yy=math.random(y1,y2)
					createAsteroid(id,xx,yy,(math.random(1,5)),mineral)
				end
				createast(x1,y1,x2,y2,mineral,ast)
			end
		elseif (density==3) then
			for ast=(#asts+1),(math.floor(area/1.5))+(#asts) do
				local function createast(x1,y1,x2,y2,mineral,id)
					local xx=math.random(x1,x2)
					local yy=math.random(y1,y2)
					createAsteroid(id,xx,yy,(math.random(1,5)),mineral)
				end
				createast(x1,y1,x2,y2,mineral,ast)
			end
		end
	end
end

addhook("minute","refreshAsts")
function refreshAsts()
	--[[for k,_ in pairs(projectiles) do
		removeProjectile(k)
	end]]
	--[[for _,id in ipairs(player(0,'table')) do
		datasave(id)
	end]]
	--[[for _,a in ipairs(asts) do
		if (a~=0 and a) then
			removeAsteroid(a)
		end
	end
	astFields()]]
end

function astFields()
	for a=1,#astfields do
		createAsteroidField(astfields[a].density,astfields[a].comm,astfields[a].xs,astfields[a].ys,astfields[a].xe,astfields[a].ye)
	end
end

astFields()