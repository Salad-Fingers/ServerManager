cloaked=initArray2(32,false)
hashyperdrive=initArray2(32,true)
hyperjumppos=doublearray(32,2,0)
hyperjumping=initArray2(32,false)
empulse=initArray2(32,0)
canemp=initArray2(32,true)
empd=initArray2(32,false)
canhyperjump=initArray2(32,true)
enteringhyperjumppos=initArray2(32,false)
outofphase=initArray2(32,false)

function cloakShip(id)
	if (not inlane[id] and not empd[id] and not hyperjumping[id]) then
		parse("speedmod "..id.." -10")
		tween_alpha(ship[id],3000,0)
		cloaked[id]=true
	end
end

function uncloakShip(id)
	parse("speedmod "..id.." 0")
	tween_alpha(ship[id],500,1)
	cloaked[id]=true
end

addhook("attack","decloak")
function decloak(id)
	if (cloaked[id]) then
		uncloakShip(id)
	end
end

function emp(id)
	if (canemp[id]) then
		canemp[id]=false
		empd[id]=true
		empulse[id]=image("gfx/sprites/wave.bmp",player(id,"x"),player(id,"y"),3)
		imageblend(empulse[id],1)
		imagecolor(empulse[id],135,210,255)
		imagealpha(empulse[id],0.6)
		tween_scale(empulse[id],1000,30,30)
		tween_color(ship[id],500,125,125,125)
		parse("speedmod "..id.." -100")
		sound3(player(id,"tilex"),player(id,"tiley"),10,10,"space/emp.ogg")
		timer(5000,"parse","speedmod "..id.." 0")
		timer(5000,"parse","lua canemp["..id.."]=true")
		timer(5000,"parse","lua empd["..id.."]=false")
		timer(5000,"parse","lua tween_color(ship["..id.."],500,255,255,255)")
		timer(500,"parse","lua tween_alpha(empulse["..id.."],500,0)")
		timer(2000,"parse","lua freeimage(empulse["..id.."])")
		timer(2000,"parse","lua empulse["..id.."]=0")
		for pid=1,32 do
			if (player(pid,"exists") and player(pid,"x")>=player(id,"x")-320 and player(pid,"x")<=player(id,"x")+320 and player(pid,"y")>=player(id,"y")-320 and player(pid,"y")<=player(id,"y")+320) then
				parse("speedmod "..pid.." -100")
				tween_color(ship[pid],500,125,125,125)
				timer(5000,"parse","lua tween_color(ship["..pid.."],500,255,255,255)")
				timer(5000,"parse","speedmod "..pid.." 0")
			end
		end
	end
end

function hyperjump(id,x,y)
	if (hashyperdrive[id] and canhyperjump[id] and not hyperjumping[id]) then
		canhyperjump[id]=false
		hyperjumping[id]=true
		freeimage(fadeout[id])
		fadeout[id]=0
		parse("speedmod "..id.." -100")
		tween_color(ship[id],2000,255,0,0)
		fadeout[id]=image("gfx/sprites/block.bmp",320,240,2,id)
		imagescale(fadeout[id],20,15)
		imagealpha(fadeout[id],0)
		imagecolor(fadeout[id],200,235,255)
		tween_alpha(fadeout[id],2000,1)
		timer(1500,"parse","lua tween_scale(ship["..id.."],500,0,0)")
		timer(2000,"parse","lua tween_alpha(fadeout["..id.."],500,0)")
		timer(2000,"parse","setpos "..id.." "..x.." "..y)
		timer(2000,"parse","speedmod "..id.." 0")
		timer(2900,"parse","lua tween_color(ship["..id.."],250,255,255,255)")
		timer(2400,"parse","lua tween_scale(ship["..id.."],400,1.5,1.5)")
		timer(2800,"parse","lua tween_scale(ship["..id.."],100,1,1)")
		timer(3150,"parse","lua hyperjumping["..id.."]=false")
		timer(13150,"parse","lua canhyperjump["..id.."]=true")
	end
end

addhook("serveraction","extradebugmenu")
function extradebugmenu(id,a)
	if (a==3) then
		menu(id,"EXTRAS,EM Pulse,Cloak,Hyperjump")
	end
end

addhook("menu","extrasmenu")
function extrasmenu(id,menu,sel)
	if (menu=="EXTRAS") then
		if (player(id,"usgn")==7749 or player(id,"usgn")==14479) then
			if (sel==1) then
				emp(id)
			elseif (sel==2) then
				cloakShip(id)
			elseif (sel==3) then
				enteringhyperjumppos[id]=true
				msg2(id,"Please enter your hyperjump coordinates in tiles (X;Y)")
			end
		end
	end
end

function phaseShift(id)
	outofphase[id]=true
	tween_alpha(ship[id],1000,0.3)
	tween_color(ship[id],1000,0,255,255)
	restoringshield[id]=false
end

function revphaseShift(id)
	outofphase[id]=false
	tween_alpha(ship[id],1000,1)
	tween_color(ship[id],1000,255,255,255)
	timer(5000,"restoringshield["..id.."]=true")
end
