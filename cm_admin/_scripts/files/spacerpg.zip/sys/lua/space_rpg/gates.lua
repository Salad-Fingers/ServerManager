if (gates) then

gateinrange=initArray2(32,0)
gatemode=initArray2(32,"")
gatesimg=initArray2(512,0)
gatefimg=initArray2(512,0)
fadeout=initArray2(32,0)

function gateinit()
	if (#gates==1) then
		for g=1,#gates do
			gatesimg[g]=image("gfx/space/hypergate.png",gates[g].x*32+16,gates[g].y*32+16,0)
			gatefimg[g]=image("gfx/space/hypergate.png",gates[g].ex*32+16,gates[g].ey*32+16,0)
		end
	else
		gatesimg[1]=image("gfx/space/hypergate.png",gates[g].x*32+16,gates[g].y*32+16,0)
		gatefimg[1]=image("gfx/space/hypergate.png",gates[g].ex*32+16,gates[g].ey*32+16,0)
	end
end

gateinit()

addhook("ms100","gateenter")
function gateenter()
	for id=1,32 do
		local x=player(id,"tilex")
		local y=player(id,"tiley")
		for g=1,#gates do
			if (player(id,"exists")) then
				if (x==gates[g].x and y==gates[g].y) then
					hudtxt2(id,11,"000255000",sectors[gates[g].from].name.." >> "..sectors[gates[g].to].name,220,40)
					gateinrange[id]=g
					gatemode[id]=""
					break
				elseif (x==gates[g].ex and y==gates[g].ey) then
					hudtxt2(id,11,"000255000",sectors[gates[g].to].name.." >> "..sectors[gates[g].from].name,220,40)
					gateinrange[id]=g
					gatemode[id]="rev"
					break
				else
					hudtxt2(id,11,"000255000","",220,40)
					gateinrange[id]=nil
					gatemode[id]=""
				end
			end
		end
	end
end

addhook("serveraction","gatejump")
function gatejump(id,a)
	if (gateinrange[id]~=nil and gateinrange[id]~=0 and a==2) then
		parse("speedmod "..id.." -100")
		elib.sound3("space/gate.ogg",player(id,"x"),player(id,"y"),512)
		elib.sound3("space/gate.ogg",gates[gateinrange[id]].ex*32+16,gates[gateinrange[id]].ex*32+16,1024)
		freeimage(fadeout[id])
		fadeout[id]=0
		tween_color(ship[id],2000,255,0,0)
		fadeout[id]=image("gfx/sprites/block.bmp",320,240,2,id)
		imagescale(fadeout[id],20,15)
		imagealpha(fadeout[id],0)
		tween_alpha(fadeout[id],2000,1)
		timer(1500,"parse","lua tween_scale(ship["..id.."],500,0,0)")
		timer(2000,"parse","lua tween_alpha(fadeout["..id.."],500,0)")
		if (gatemode[id]=="") then
			timer(2000,"parse","setpos "..id.." "..(gates[gateinrange[id]].ex*32+16).." "..(gates[gateinrange[id]].ey*32+16))
		elseif (gatemode[id]=="rev") then
			timer(2000,"parse","setpos "..id.." "..(gates[gateinrange[id]].x*32+16).." "..(gates[gateinrange[id]].y*32+16))
		end
		timer(2000,"parse","speedmod "..id.." "..ships[shipt[id]].smod)
		timer(2900,"parse","lua tween_color(ship["..id.."],250,255,255,255)")
		timer(2400,"parse","lua tween_scale(ship["..id.."],400,1.5,1.5)")
		timer(2800,"parse","lua tween_scale(ship["..id.."],100,1,1)")
	end
end

end