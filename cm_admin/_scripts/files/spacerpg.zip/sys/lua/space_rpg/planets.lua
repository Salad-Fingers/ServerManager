-- THE PLANETS MODULE
-- This module allows players to land on planets
-- Planets are somewhat similar to bases

function inRange(x1,y1,x2,y2,r)
	local dx,dy=x1-x2,y1-y2
	local distance=math.sqrt(dx*dx+dy*dy)
	if distance<r then
		return true
	end
	return false
end

function inTileZone(x1,y1,x2,y2,x3,y3)
	if (x1>=x2 and x1<=x3 and y1>=y2 and y1<=y3) then
		return true
	end
	return false
end

if planets then
	for i=1,#planets do
		if (planets[i].img) then
			--planets[i].pos[2]+(math.abs(planets[i].pos[1]-planets[i].pos[2])/2)
			planets[i].iid=image(planets[i].img,planets[i].pos[1]*32+16,planets[i].pos[2]*32+16,0)
			if (planets[i].rot) then
				tween_rotateconstantly(planets[i].iid,planets[i].rot)
			end
		end
	end
	
	planets.landed=initArray2(32,false)
	planets.landedid=initArray2(32,0)
	planets.shipimg=initArray2(32,0)
	
	function planets.checkforplanet(x,y)
		for p=1,#planets do
			if (#planets[p].pos>2) then
				if (inTileZone(x,y,planets[p].pos[3],planets[p].pos[4],planets[p].pos[5],planets[p].pos[6])) then
					return p
				end
				return false
			else
				if (planets[p].rad~=0) then
					if (inRange(x*32+16,y*32+16,planets[p].pos[1]*32+16,planets[p].pos[2]*32+16,planets[p].rad)) then
						return p
					end
					return false
				end
				return false
			end
		end
	end
	
	function planets.land(id,pid)
		if (reputation[id][zones[planets[pid].base].faction]>=zones[planets[pid].base].allowrep) then
			local speed=player(id,"speedmod")
			tween_scale(ship[id],1000,0,0)
			parse("speedmod "..id.." -100")
			timer(1000,"parse","setpos "..id.." "..(planets[pid].lpos[1]*32+16).." "..(planets[pid].lpos[2]*32+16))
			timer(1000,"parse","speedmod "..id.." "..speed)
			planets.landed[id]=true
			planets.landedid[id]=pid
			planets.shipimg[id]=image("gfx/space/"..ships[shipt[id]].name..".png",planets[pid].lpos[1]*32+16,planets[pid].lpos[2]*32+16,3,id)
			msg2(id,"�000255000Permission to land granted.")
			hudtxt2(id,30,"000255000","",120,50)
		else
			msg2(id,"�255000000Permission to land denied!")
		end
	end
	
	function planets.takeoff(id,pid)
		local speed=player(id,"speedmod")
		tween_scale(planets.shipimg[id],1000,2,2)
		parse("speedmod "..id.." -100")
		timer(1000,"parse","setpos "..id.." "..(planets[pid].pos[1]*32+16).." "..(planets[pid].pos[2]*32+16))
		timer(1000,"parse","speedmod "..id.." "..speed)
		planets.landed[id]=false
		planets.landedid[id]=0
		timer(1000,"parse","lua freeimage("..planets.shipimg[id]..")")
	end
	
	addhook("movetile","planets.checkforplanets")
	function planets.checkforplanets(id,x,y)
		if (not planets.landed[id]) then
			local planet=planets.checkforplanet(x,y)
			if (planet) then
				hudtxt2(id,30,"000255000","You are orbiting "..planets[planet].name,120,50)
				if (planets[planet].landable) then
					hudtxt2(id,30,"000255000","You are orbiting "..planets[planet].name.." (F3 to land)",120,50)
				end
			else
				hudtxt2(id,30,"000255000","",120,50)
			end
		end
	end
	
	addhook("serveraction","planets.landing")
	function planets.landing(id,a)
		if (a==2) then
			if (not planets.landed[id]) then
				for p=1,#planets do
					if (planets[p].landable) then
						if (planets[p].rad~=0) then
							if (inRange(player(id,"x"),player(id,"y"),planets[p].pos[1]*32+16,planets[p].pos[2]*32+16,planets[p].rad)) then
								planets.land(id,p)
							end
						else
							if (#planets[p].pos>2) then
								if (inTileZone(x,y,planets[p].pos[3],planets[p].pos[4],planets[p].pos[5],planets[p].pos[6])) then
									if (inRange(id,x,y,planets[p].pos[1]*32+16,planets[p].pos[2]*32+16,planets[p].rad)) then
										planets.land(id,p)
									end
								end
							end
						end
					end
				end
			else
				if (player(id,"tilex")==planets[planets.landedid[id]].lpos[1] and player(id,"tiley")==planets[planets.landedid[id]].lpos[2]) then
					planets.takeoff(id,planets.landedid[id])
				end
			end
		end
	end
end
