dofile("sys/lua/basicfuncs.lua")
dofile("sys/lua/space_rpg/bases.lua")
dofile("sys/lua/space_rpg/social.lua")
dofile("sys/lua/space_rpg/ships.lua")
dofile("sys/lua/space_rpg/tradelanes.lua")
dofile("sys/lua/space_rpg/gates.lua")
--dofile("sys/lua/space_rpg/extras.lua")
dofile("sys/lua/space_rpg/asteroids.lua")
dofile("sys/lua/space_rpg/inventory.lua")
dofile("sys/lua/space_rpg/elib.lua")
dofile("sys/lua/space_rpg/equipment.lua")
dofile("sys/lua/space_rpg/proj_system_final.lua")
dofile("sys/lua/space_rpg/savesystem.lua")
dofile("sys/lua/space_rpg/cruise.lua")
dofile("sys/lua/space_rpg/factions.lua")
dofile("sys/lua/space_rpg/doctorwho_space.lua")
dofile("sys/lua/space_rpg/nebulae.lua")
dofile("sys/lua/space_rpg/planets.lua")

parse("mp_wpndmg Knife 0") -- Don't change this!
parse("mp_wpndmg Chainsaw 0") -- Don't change this!

function string.defsplit(split)
	local t = {};
	for word in string.gmatch(split, "(%w*)") do
		table.insert(t, word);
	end
	return t;
end

faction=initArray2(32,0)

-- MAIN VALUES
credits=initArray2(32,2000)
armor=initArray2(32,100)
shield=initArray2(32,100)
energy=initArray2(32,500)
fuel=initArray2(32,100)
pos=initArray2(32,spawnPos)
cpos=initArray2(32,{0,0})
restoringshield=initArray2(32,true)
firsttime=initArray2(32,true)
commodities=doublearray(32,6,0)
cargo=initArray2(32,0)
maxcargo=initArray2(32,60)
loggedin=initArray2(32,false)

addhook("startround","imagestuff")
function imagestuff()
	imagerender()
end

function imagerender()
    for tl=1,#lanes do
		if (lanesimg[tl]==0) then
			lanesimg[tl]=image("gfx/space/tradelane.png",lanes[tl].x*32+16,lanes[tl].y*32+16,0)
		end
		if (lanefimg[tl]==0) then
			lanefimg[tl]=image("gfx/space/tradelane.png",lanes[tl].ex*32+16,lanes[tl].ey*32+16,0)
		end
    end
end

imagerender()

function initHardware(id)
	shield[id]=ships[shipt[id]].shield
	armor[id]=ships[shipt[id]].armor
	energy[id]=ships[shipt[id]].energy
	fuel[id]=ships[shipt[id]].fuel
	invmaxslots[id]=ships[shipt[id]].cargo
end

addhook("join","settings")
function settings(id)
	initHardware(id)
end

addhook("ms100","updatehud")
function updatehud()
    for id=1,32 do
        if (player(id,"exists")) then
            hudtxt2(id,1,"255255255","Money: "..math.floor(credits[id]),320,380)
			if (not pstack.inMShip[id]) then
				hudtxt2(id,2,"255255255","Armor: "..math.floor(armor[id]),320,400)
			else
				hudtxt2(id,2,"255255255","Armor: "..math.floor(parties[inParty[id][2]].mshipar),320,400)
			end
			if (not pstack.inMShip[id]) then
				hudtxt2(id,3,"255255255","Shield: "..math.floor(shield[id]),320,420)
			else
				hudtxt2(id,3,"255255255","Shield: "..math.floor(parties[inParty[id][2]].mshipsh),320,420)
			end
			if (not pstack.inMShip[id]) then
				hudtxt2(id,4,"255255255","Energy: "..math.floor(energy[id]),320,440)
			else
				hudtxt2(id,4,"255255255","Energy: "..math.floor(parties[inParty[id][2]].mshipen),320,440)
			end
			if (not pstack.inMShip[id]) then
				hudtxt2(id,5,"255255255","Fuel: "..math.floor(fuel[id]),320,460)
			end
			
			--shield
			if (parties[inParty[id][2]].mship==player(id,"usgn") and pstack.inMShip[id] and restoringshield[id]) then
				if (parties[inParty[id][2]].mshipsh<=ships["ms"].shield-4 and restoringshield[id]) then
					parties[inParty[id][2]].mshipsh=parties[inParty[id][2]].mshipsh+5
				end
				if (parties[inParty[id][2]].mshipsh==ships["ms"].shield-1) then
					parties[inParty[id][2]].mshipsh=ships["ms"].shield
				end
			else
				if (restoringshield[id] and shield[id]<ships[shipt[id]].shield) then
					shield[id]=shield[id]+1
				end
				if (energy[id]<ships[shipt[id]].energy-ships[shipt[id]].energyr) then
					energy[id]=energy[id]+ships[shipt[id]].energyr
				else
					if (energy[id]~=ships[shipt[id]].energy) then
						energy[id]=ships[shipt[id]].energy
					end
				end
				--[[if (outofphase[id]) then
					if shield[id]>0 then
						shield[id]=shield[id]-1
					else
						revphaseShift(id)
					end
				end]]
			end
			for w=1,#cwslots[id] do
				if (w and w~=0 and refire[id][w]>0) then
					refire[id][w]=refire[id][w]-100
				end
			end
			--shield
			--if cruise[id] then
			--	if (shipt[id]~="ms") then
			--		energy[id]=energy[id]-1
			--	else
			--		parties[inParty[id][2]].mshipen=parties[inParty[id][2]].mshipen-1
			--	end
			--end
        end
		--if (player(id,"exists") and player(id,"health")>0 and astocc[id]~=0 and astocc[id] and distance(player(id,"x"),player(id,"y"),astpos[astocc[id]][1]*32+16,astpos[astocc[id]][1]*32+16)>=500) then
		--	deocAsteroid(id)
		--end
		--reqcld(id,2)
		--if (astocc[id]~=0) then
		--	hitAsteroid(astocc[id],id,1)
		--end
    end
end

--[[addhook("clientdata","cursorpos")
function cursorpos(id,cm,cx,cy)
	if (cm==2) then
		cpos[id][1]=cx
		cpos[id][2]=cy
	end
end]]

--[[addhook("attack2","astsel")
function astsel(id)
	for _,a in ipairs(asts) do
		if (distance(astpos[a][1]*32+16,astpos[a][2]*32+16,cpos[id][1],cpos[id][2])<=32 and distance(astpos[a][1]*32+16,astpos[a][2]*32+16,player(id,"x"),player(id,"y"))<=500) then
			print(checkFree(id,astype[a]))
			print(a)
			if (checkFree(id,astype[a])>=astype[a]) then
				if (astocc[id] and astocc[id]~=a) then deocAsteroid(id) astoc[a]=id astocc[id]=a end
				if (astoc[a]==id) then
					hitAsteroid(a,id,1)
					if (astoci[a]==0 or not astoci[a]) then
						astoci[a]=image("gfx/sprites/wave.bmp",astpos[a][1]*32+16,astpos[a][2]*32+16,3)
						imageblend(astoci[a],1)
						imagecolor(astoci[a],50,50,255)
						imagescale(astoci[a],astype[a],astype[a])
					end
				end
			else
				msg2(id,"Cargo hold full")
			end
		end
	end
end]]

addhook("hit","shieldhit")
function shieldhit(id)
	if (shield[id]>0 and armor[id]>0) then
		return 1
	end
end

addhook("die","shieldreset")
function shieldreset(id)
	initHardware(id)
end

function quitfaction(id)
	if (faction[id] and faction[id]~=0) then
		return "Leave "..factions[faction[id]].name
	end
	return ""
end

function quitconfirm(id)
	menu(id,"CONFIRMATION OF LEAVING@b,(You are about to leave "..factions[faction[id]].name..". Are you sure?),Yes|Your reputation with the faction, its allies and enemies will be reset.,No")
end

function mainmenu(id)
    menu(id,"SPACE RPG MAIN MENU@b,View Cargo Bay,View Equipment,View Reputation,,"..quitfaction(id))
end

function cargomenu(id)
    menu(id,"CARGO BAY,"..comms[1].name.."|"..commodities[id][1]..","..comms[2].name.."|"..commodities[id][2]..","..comms[3].name.."|"..commodities[id][3]..","..comms[4].name.."|"..commodities[id][4]..","..comms[5].name.."|"..commodities[id][5]..","..comms[6].name.."|"..commodities[id][6])
end

addhook("serveraction","svact")
function svact(id,a)
    if (a==1) then
        mainmenu(id)
    end
end

addhook("spawn","weps")
function weps(id)
	parse("strip "..id.." 1")
	parse("strip "..id.." 2")
	parse("equip "..id.." 85")
	parse("strip "..id.." 50")
end

addhook("menu","menus")
function menus(id,menu,sel)
    if (menu=="SPACE RPG MAIN MENU") then
        if (sel==1) then
            --cargomenu(id)
			inventory(id,1)
        end
		if (sel==2) then
			wsMenu(id)
		end
        if (sel==3) then
            repmenu(id)
        end
        if (sel==5) then
            quitconfirm(id)
        end
    end
	if (menu=="CONFIRMATION OF LEAVING") then
		if (sel==2) then
			leaveFaction(id,faction[id])
		end
	end
end

addhook("say","sayhub")
function sayhub(id,t)
	--extras
	--[[local f=t:find(";")
	if (f~=nil and enteringhyperjumppos[id]) then
		local x=tonumber(t:sub(1,f-1))
		local y=tonumber(t:sub(f+1))
		hyperjump(id,x,y)
		return 1
	end]]
	--extras end
	--party stuff
	if (pstack.enteringDAmount[id]) then
		if (type(tonumber(t))=="number") then
			depositInBank(id,inParty[id][2],tonumber(t))
			pstack.enteringDAmount[id]=false
			return 1
		end
	end
	if (pstack.enteringWAmount[id]) then
		if (type(tonumber(t))=="number") then
			withdrawFromBank(id,inParty[id][2],tonumber(t))
			pstack.enteringWAmount[id]=false
			return 1
		end
	end
	if (pstack.grantingWithdrawal[id]) then
		if (t:lower()=="y" or t:lower()=="yes" or t:lower()=="aye") then
			msg2(id,"�000255000You have granted the withdrawal")
			msg2(pstack.wplayer[id],"�000255000You have been granted the withdrawal")
			credits[pstack.wplayer[id]]=credits[pstack.wplayer[id]]+pstack.wfunds[pstack.wplayer[id]]
			parties[inParty[id][2]].bankfunds=parties[inParty[id][2]].bankfunds-pstack.wfunds[pstack.wplayer[id]]
			pstack.grantingWithdrawal[id]=false
		elseif (t:lower()=="n" or t:lower()=="no" or t:lower()=="nay") then
			msg2(id,"�255000000You have denied the withdrawal")
			msg2(pstack.wplayer[id],"�255000000Your withdrawal request has been denied")
			pstack.grantingWithdrawal[id]=false
		else
			msg2(id,"�255000000ERROR: Unhandled answer, please try again (Code MS4NYN)")
		end
		return 1
	end
	if (t=="!mdock") then
		msDock(id)
		return 1
	end
	if (t:sub(1,2)=="!p") then
		if (t:sub(4)=="create") then
			if (credits[id]>=100000) then
				pstack.creatingParty[id]=1
				msg2(id,"�255255255Please enter your party's name")
			else
				msg2(id,"�255000000ERROR: Insufficient funds (Code MS6IFP)")
			end
		end
		if (t:sub(4)=="menu") then
			if (inParty[id][1]) then
				partyMenu(id)
			end
		end
		if (t:sub(4,9)=="invite") then
			if (player(id,"usgn")==parties[inParty[id][2]].leader) then
				local iid=tonumber(t:sub(11))
				if (not player(iid,"bot")) then
					msg2(id,"�255255255Sending invite, please wait...")
					msg2(iid,"�255255255"..player(id,"name").." invites you to join "..parties[inParty[id][2]].name.." - Y/N?")
					pstack.joining[iid]=true
					pstack.pjoining[iid]=parties[inParty[id][2]]
				end
			else
				msg2(id,"�255000000ERROR: Cannot invite, not leader (Code MS6NPL)")
			end
		end
		if (t:sub(4,7)=="kick") then
			if (player(id,"usgn")==parties[inParty[id][2]].leader) then
				local kid=tonumber(t:sub(9,10))
				local r=t:sub(11)
				if (kid~=id) then
					table.remove(parties[inParty[id][2]].members,table.find(parties[inParty[id][2]].members,kid))
					inParty[kid][1]=false
					inParty[kid][2]=0
					msg2(kid,"�255000000You have been kicked from the party. Reason: "..(r or "None specified"))
				else
					msg2(id,"�255000000ERROR: You can't kick yourself (Code MS6CKS)")
				end
			end
		end
		return 1
	end
	--- party creating
	if (pstack.creatingParty[id]==1) then
		pstack.pName[id]=t
		pstack.creatingParty[id]=2
		msg2(id,"�255255255Please enter your party's tag")
		return 1
	end
	if (pstack.creatingParty[id]==2) then
		pstack.pTag[id]=t
		pstack.creatingParty[id]=3
		msg2(id,"�255255255Please enter your party's motto")
		return 1
	end
	if (pstack.creatingParty[id]==3) then
		createParty(player(id,"usgn"),pstack.pName[id],pstack.pTag[id],t)
		credits[id]=credits[id]-100000
		msg2(id,"�000255000Party creation successful!")
		pstack.pName[id]=""
		pstack.pTag[id]=""
		pstack.creatingParty[id]=0
		return 1
	end
	--- party stuff 2
	if (pstack.joining[id]) then
		if (t:lower()=="y" or t:lower()=="yes" or t:lower()=="aye") then
			joinParty(id,pstack.pjoining[id])
			for _,muid in ipairs(parties[pstack.pjoining[id]].members) do
				local mid=fromUsgn(muid)
				if (mid~=0 and mid~=id) then
					msg2(mid,player(id,"name").." has joined the party")
				end
			end
			msg2(fromUsgn(parties[pstack.pjoining[id]].leader),player(id,"name").." has joined the party")
			msg2(fromUsgn(parties[pstack.pjoining[id]].leader),"Your party has received a referral bonus")
			parties[pstack.pjoining[id]].bankfunds=parties[pstack.pjoining[id]].bankfunds+refbonus
			pstack.joining[id]=false
			pstack.pjoining[id]=0
		elseif (t:lower()=="n" or t:lower()=="no" or t:lower()=="nay") then
			msg2(id,"�255000000You have declined the invitation")
			msg2(fromUsgn(parties[pstack.pjoining[id]].leader),"�255000000Your invitation has been declined")
			pstack.joining[id]=false
			pstack.pjoining[id]=0
		else
			msg2(id,"�255000000ERROR: Unhandled answer, please try again (Code MS8NYN)")
		end
		return 1
	end
	if (pstack.enteringMPilot[id]) then
		if (tonumber(t)>=1 and tonumber(t)<=32) then
			if (contains(parties[inParty[id][2]].members,player(tonumber(t),"usgn")) or player(id,"usgn")==parties[inParty[id][2]].leader) then
				assignMPilot(tonumber(t),inParty[id][2])
			else
				msg2(id,"�255000000ERROR: Cannot assign pilot, player not in party (Code MS9NIP)")
			end
		else
			msg2(id,"�255000000ERROR: Not a correct player ID, please try again (Code MS9NCP)")
		end
		return 1
	end
	-- interaction funcs
	local tt=unique(t:defsplit())
	if (tt[1]=="a") then
		if (tt[2]=="money") then
			if (tt[3]=="set") then
				credits[tonumber(tt[4])]=tonumber(tt[5])
			elseif (tt[3]=="add") then
				credits[tonumber(tt[4])]=credits[tonumber(tt[4])]+tonumber(tt[5])
			end
		end
		if (tt[2]=="item") then
			if (tt[3]=="add") then
				if (checkFree2(tonumber(tt[4]))) then
					insertInBackpack(tonumber(tt[4]),tonumber(tt[5]))
				end
			end
		end
		if (tt[2]=="ship") then
			if (tt[3]=="set") then
				local ptg=tonumber(tt[4])
				shipt[ptg]=tonumber(tt[5])
			end
		end
		return 1
	end
	if (tt[1]=="i") then
		if (tt[2]=="item") then
			if (tt[3]=="give") then
				local ptg=tonumber(tt[4])
				if (player(ptg,"exist") and player(ptg,"health")>0) then
					if (distance(player(id,"x"),player(id,"y"),player(ptg,"x"),player(ptg,"y"))<=640) then
						if (findInSlot(id,tonumber(tt[5]))) then
							if (checkFree2(ptg)) then
								removeFromBackpack(id,tonumber(tt[5]))
								insertInBackpack(ptg,findInSlot(id,tonumber(tt[5])))
							else
								msg2(id,"Player's cargo hold is full")
							end
						else
							msg2(id,"The item you're trying to transfer does not exist!")
						end
					else
						msg2(id,"The player is too far away!")
					end
				else
					msg2(id,"Transfer failed!")
				end
			end
			return 1
		end
		if (tt[2]=="money") then
			if (tt[3]=="give") then
				local ptg=tonumber(tt[4])
				if (credits[id]>=tonumber(tt[5])) then
					credits[ptg]=credits[ptg]+tonumber(tt[5])
					credits[id]=credits[id]-tonumber(tt[5])
				else
					msg2(id,"You do not have that much money!")
				end
			end
			return 1
		end
	end
	if (t=="!load") then
		if not (loggedin[id]) then
			dataread(id)
			loggedin[id]=true
		else
			msg2(id,"You've already loaded your data!")
		end
		return 1
	end
	if (contains(doctorwho.admins,player(id,"usgn"))) then
		if (t:sub(1,5)=="!give") then
			if (t:sub(7,11)=="sonic") then
				local _=t:sub(13)
				local tid=tonumber(_)
				hasSonic[tid]=true
				msg2(id,"You have given a sonic screwdriver to "..player(tid,"name"))
				msg2(tid,player(id,"name").." has given you a sonic screwdriver")
			end
			if (t:sub(7,11)=="regen") then
				local _=t:sub(13,14)
				local __=t:sub(15)
				local tid=tonumber(__)
				local rc=tonumber(_)
				if rc<0 then if doctorwho.regencycles>=rc then doctorwho.regencycles[tid]=doctorwho.regencycles[tid]-rc else doctorwho.regencycles[tid]=doctorwho.regencycles[tid]+rc end end
				if (rc>0) then
					msg2(id,"You have given "..rc.." regeneration"..quickPlural(rc).." to "..player(tid,"name"))
					msg2(tid,player(id,"name").." has given you "..rc.." regeneration"..quickPlural(rc))
				else
					msg2(id,"You have taken "..rc.." regeneration"..quickPlural(rc).." from "..player(tid,"name"))
					msg2(tid,player(id,"name").." has taken "..rc.." regeneration"..quickPlural(rc).." from you")
				end
			end
			if (t:lower():sub(7,12)=="tardis") then
				local _=t:sub(14)
				local tid=tonumber(_)
				createTARDIS(tid,player(tid,"tilex"),player(tid,"tiley"))
				msg2(id,"You have given a TARDIS to "..player(tid,"name"))
				msg2(tid,player(id,"name").." has given you a TARDIS")
			end
			return 1
		end
	end
	if (t=="!tmenu") then
		if (tardisIn[id]~=0 and doctorwho.tardis.owner[tardisIn[id]]==id and playerSittingIn[doctorwho.tardis.tardis[id]][id]) then
			tardismenu(id)
		end
		return 1
	end
	if (t=="!sonic") then
		if (hasSonic[id]) then
			if (sonicSoundReady[id] and player(id,"team")==2) then
				sound3(player(id,"tilex"),player(id,"tiley"),5,5,"doctorwho/sonicextend.ogg")
				sonicSoundReady[id]=false
				sonicMenu(id)
				timer(1000,"parse","lua sonicSoundReady["..id.."]=true")
			end
		end
		return 1
	end
	if (enteringCoordinates[id]) then
		if (tardisIn[id]~=0) then
			local divider=t:find(";")
			local c1=t:sub(1,divider-1)
			local c2=t:sub(divider+1)
			local x=tonumber(c1)
			local y=tonumber(c2)
			if (x>=0 and x<=map("xsize") and y>=0 and y<=map("ysize")) then
				transportTARDIS(tardisIn[id],x,y)
				enteringCoordinates[id]=false
			else
				msg2(id,"�255000000ERROR: Invalid coordinates")
				enteringCoordinates[id]=false
			end
		end
		return 1
	end
end

addhook("drop","nodropping")
function nodropping()
	return 1
end

addhook("die","nodropping2")
function nodropping2(id)
	parse("explosion "..player(id,"x").." "..player(id,"y").." 64 0 "..id)
	return 1
end

addhook("buy","nobuying")
function nobuying()
	return 1
end

addhook("select","restrictswitching")
function restrictswitching(id,wpn)
	if (player(id,"usgn")==parties[inParty[id][2]].mship and player(id,"usgn")~=0) then
		if (wpn~=35) then
			parse("setweapon "..id.." 35")
		end
	else
		if (wpn~=85) then
			parse("setweapon "..id.." 85")
		end
	end
end

addhook("kill","getmoneyfk")
function getmoneyfk(k,v)
	if (credits[v]>0) then
		credits[k]=credits[k]+2000
		credits[v]=credits[v]-2000
		msg2(k,"You killed "..player(v,"name").."!")
		msg2(k,"You get a 2000 credit reward!")
	end
end

addhook("spawn","smodreset")
function smodreset(id)
	if (firsttime[id] and pos[id] and pos[id][1] and pos[id][2]) then
		parse("spawnplayer "..id.." "..pos[id][1].." "..pos[id][2])
		firsttime[id]=false
	end
	parse("speedmod "..id.." "..ships[shipt[id]].smod)
end

parse("mp_deathdrop 4")

min = 0

addhook("minute","autoreboot")
function autoreboot()
	min = min + 1
	if (min == 59) then
		msg("The server will be restarted in 1 minute!@C")
		for i=1,#player(0,"table") do
			datasave(i)
		end
	end
	if (min == 60) then
		parse("changemap srpg_pandemia_star_system")
		min = 0
	end
end