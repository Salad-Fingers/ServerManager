cwslots = initArray2(32,{1,0,0,0,0,0,0,0,0})
refire = initArray2(32,{0,0,0,0,0,0,0,0,0})
disabled = initArray2(32,{false,false,false,false,false,false,false,false,false})

eqstack={}
eqstack.sel=initArray2(32,0)
shieldimg=initArray2(32,0)

function getDisabled(id,s,m)
	if (m==1) then
		if disabled[id][s] then return " (DISABLED)" end
	elseif (m==2) then
		if disabled[id][s] then return "Enable|Turns on the weapon and gives it power to fire" else return "Disable|Turn off the weapon and prevent it from firing" end
	end
	return ""
end

function wPrint(id,s)
	if (ships[shipt[id]].wslots[s]) then
		return equipment[cwslots[id][s]].name.." (Lvl "..(equipment[cwslots[id][s]].lvl or "0")..")|"..ships[shipt[id]].wslots[s].type:sub(1,1):upper()..ships[shipt[id]].wslots[s].type:sub(2).." (Lvl "..ships[shipt[id]].wslots[s].lvl..")"..getDisabled(id,s,1)
	end
	return ""
end

function wsMenu(id)
	menu(id,"WEAPONS@b,"..wPrint(id,1)..","..wPrint(id,2)..","..wPrint(id,3)..","..wPrint(id,4)..","..wPrint(id,5)..","..wPrint(id,6)..","..wPrint(id,7)..","..wPrint(id,8)..","..wPrint(id,9))
end

function mountOnSlot(id,iid,s)
	if (ships[shipt[id]].wslots[cwslots[id][s]].class==equipment[iid].class or ships[shipt[id]].wslots[cwslots[id][s]].class=="omni") then
		cwslots[id][s]=iid
	else
		msg2(id,"Incompatible weapon slot!")
	end
end

addhook("menu","weaponfuncs")
function weaponfuncs(id,title,sel)
	if (title=="WEAPONS" and sel~=0 and cwslots[id][sel]~=0) then
		menu(id,"Weapon actions@b,"..getDisabled(id,sel,2)..",Unmount|Unmounts the weapon and moves it into the cargo hold")
		eqstack.sel[id]=sel
	end
	if (title=="Weapon actions") then
		if (sel==1) then
			if (disabled[id][eqstack.sel[id]]) then
				disabled[id][eqstack.sel[id]]=false
			else
				disabled[id][eqstack.sel[id]]=true
			end
		end
		if (sel==2) then
			if (checkFree2(id)) then
				insertInBackpack(id,cwslots[id][eqstack.sel[id]]+100,1)
				cwslots[id][eqstack.sel[id]]=0
			else
				msg2(id,"Could not unmount - cargo hold full")
			end
		end
	end
end

addhook("attack","shoot")
function shoot(id)
	for w=1,#cwslots[id] do
		if (tile(player(id,"tilex"),player(id,"tiley"),"frame")==0 and not inlane[id] and cwslots[id][w]~=0 and ships[shipt[id]].wslots[w]) then
			if (shipt[id]~="ms") then
				if (not disabled[id][w] and not cruise[id] and energy[id]>equipment[cwslots[id][w]].energy) then
					if (refire[id][w]==0) then
						createProjectile(newProj(equipment[cwslots[id][w]].img,equipment[cwslots[id][w]].blend,equipment[cwslots[id][w]].r,equipment[cwslots[id][w]].g,equipment[cwslots[id][w]].b,equipment[cwslots[id][w]].dmg,equipment[cwslots[id][w]].h,equipment[cwslots[id][w]].wd,equipment[cwslots[id][w]].energy,equipment[cwslots[id][w]].name,equipment[cwslots[id][w]].range),id,player(id,"x"),player(id,"y"),player(id,"rot")-90,equipment[cwslots[id][w]].spd)
						elib.sound3(equipment[cwslots[id][w]].sfx,player(id,"x"),player(id,"y"),1024)
						energy[id]=energy[id]-equipment[cwslots[id][w]].energy
						refire[id][w]=equipment[cwslots[id][w]].refire
					end
				else
					elib.sound3("space/energyout.ogg",player(id,"x"),player(id,"y"),1024)
				end
			else
				if (not disabled[id][w] and not cruise[id] and parties[inParty[id][2]].mshipen>equipment[cwslots[id][w]].energy) then
					if (refire[id][w]==0) then
						createProjectile(newProj(equipment[cwslots[id][w]].img,equipment[cwslots[id][w]].blend,equipment[cwslots[id][w]].r,equipment[cwslots[id][w]].g,equipment[cwslots[id][w]].b,equipment[cwslots[id][w]].dmg,equipment[cwslots[id][w]].h,equipment[cwslots[id][w]].wd,equipment[cwslots[id][w]].energy,equipment[cwslots[id][w]].name,equipment[cwslots[id][w]].range),id,player(id,"x"),player(id,"y"),player(id,"rot")-90,equipment[cwslots[id][w]].spd)
						elib.sound3(equipment[cwslots[id][w]].sfx,player(id,"x"),player(id,"y"),1024)
						parties[inParty[id][2]].mshipen=parties[inParty[id][2]].mshipen-equipment[cwslots[id][w]].energy
						refire[id][w]=equipment[cwslots[id][w]].refire
					end
				else
					elib.sound3("space/energyout.ogg",player(id,"x"),player(id,"y"),1024)
				end
			end
		end
	end
end