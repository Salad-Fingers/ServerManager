elib={}



------ TABLE FUNCTIONS ------

function elib.eliminate(t,el)
	local r = {}
	for k,v in pairs(t) do
		if v~=el then
			r[#r+1] = v
		end
	end
	return r
end

function elib.split(split,pat)
	local t = {}
	for item in string.gmatch(split, pat) do
		table.insert(t,item)
	end
	return t
end

function elib.tblprint(t)
	local str=""
	for _,v in ipairs(t) do
		if (str=="") then
			str=str..v
		else
			str=str..","..v
		end
	end
	return str
end

function elib.array2(f,v)
	local cmd={}
	for c=1,f do
		cmd[c]=v
	end
	return cmd
end

function elib.doublearray(m,n,k) -- credits to BlazzingEyed
    local a, x, y = {}
    for x = 0, m do a[x] = {}
        for y = 0, n do
            a[x][y] = k
        end
    end
    return a
end

function elib.check(table,element)
    for _,value in ipairs(table) do
        if value==element then
            return true
        end
    end
    return false
end

function elib.findintable(table, element)
    for key,value in ipairs(table) do
        if value==element then
            return key
        end
    end
    return nil
end

------ MATH FUNCTIONS ------

function elib.percent(n,p)
	if p==0 or n==0 then return n end
	return (n/100)*p
end

function elib.round(n,d)
	local pdn=0
	if (tonumber(string.sub(tostring(n),tostring(n):find("%.")+(d+1)))>5) then
		return tonumber(tonumber(tostring(n):sub(1,tostring(n):find("%.")-1)).."."..(tonumber(tostring(n):sub(tostring(n):find("%.")+(d-1))))..""..(tonumber(tostring(n):sub(tostring(n):find("%.")+d,tostring(n):find("%.")+d))+1))
	elseif (tonumber(string.sub(tostring(n),tostring(n):find("%.")+(d+1)))>5) then
		return tonumber(tonumber(tostring(n):sub(1,tostring(n):find("%.")-1)).."."..tonumber(tostring(n):sub(1,tostring(n):find("%.")+d)))
	else
		return n
	end
end

function elib.angledir(rot,x,y,factor)
	if rot<-90 then rot=rot+360 end
	local angle=math.rad(math.abs(rot+90))-math.pi
	local cx=x+(math.cos(angle)*factor)
	local cy=y+(math.sin(angle)*factor)
	return cx,cy
end

function elib.hextodecconvert(hex)
	local hd={0,1,2,3,4,5,6,7,8,9,["a"]=10,["b"]=11,["c"]=12,["d"]=13,["e"]=14,["f"]=15}
	local l=hex:len()
	local c=l
	local p=0
	local r=0
	repeat
		r=r+(hd[hex:lower():sub(c,c)]*(16^p))
		c=c-1
		p=p+1
	until c==0
	return r
end

function elib.bintodecconvert(bin)
	local l=tostring(bin):len()
	local c=l
	local p=0
	local r=0
	repeat
		r=r+(tonumber(tostring(bin):sub(c,c))*(2^p))
		c=c-1
		p=p+1
	until c==0
	return r
end

function elib.dectohexconvert(dec)
	return tonumber(dec,16)
end

------ GAME FUNCTIONS ------

function elib.hudtext(id,idt,color,text,x,y)
	local toprint=("�"..color.." "..text)
	parse('hudtxt2 '..id..' '..idt..' "'..toprint..'" '..x.." "..y)
end

function elib.pxconvert(x,y)
	return ((x*32)+16),((y*32)+16)
end

function elib.tileconvert(x,y)
	return math.floor(x/32),math.floor(y/32)
end

function elib.msg3(message, x, y, r, id) -- thanks to JetFighter::
	for key, value in ipairs(player(0, "tableliving")) do
		local dx, dy = player(value, "x") - x, player(value, "y") - y
		local distance = math.sqrt(dx * dx + dy * dy)
		if distance < r then
			msg2(value, player(value, "name")..": "..message)
		end
	end
end

function elib.sound3(sound,x,y,r) -- thanks to JetFighter::
    for key, value in ipairs(player(0, "tableliving")) do
		local dx, dy = player(value, "x") - x, player(value, "y") - y
		local distance = math.sqrt(dx * dx + dy * dy)
		if distance < r then
			parse("sv_sound2 "..value.." \""..sound.."\"")
		end
	end
end

function elib.colordecode(clr)
	return elib.hextodecconvert(clr:sub(1,2)),elib.hextodecconvert(clr:sub(3,4)),elib.hextodecconvert(clr:sub(5,6))
end