ship=initArray2(32,0)

shipt=initArray2(32,1)

function checkInZone(x,y)
	for z=1,#zones do
		if (zones[z] and x>=zones[z].xs and x<=zones[z].xe and y>=zones[z].ys and y<=zones[z].ye) then
			return z
		end
	end
	return 0
end

function scanForSpace(x,y)
	if (tile(x-1,y,"frame")==0) then
		return x-1,y
	elseif (tile(x,y-1,"frame")==0) then
		return x,y-1
	elseif (tile(x+1,y,"frame")==0) then
		return x+1,y
	elseif (tile(x,y+1,"frame")==0) then
		return x,y+1
	elseif (tile(x-1,y-1,"frame")==0) then
		return x-1,y-1
	elseif (tile(x+1,y+1,"frame")==0) then
		return x+1,y+1
	elseif (tile(x-1,y+1,"frame")==0) then
		return x-1,y+1
	elseif (tile(x+1,y-1,"frame")==0) then
		return x+1,y-1
	end
	return nil
end

addhook("movetile","addimage")
function addimage(id,x,y)
	if (not pstack.inMShip[id]) then
		if (tile(x,y,"frame")==0 and ship[id]==0 and not pstack.docked[id]) then
			ship[id]=image("gfx/space/"..ships[shipt[id]].name..".png",1,0,200+id)
			parse("setarmor "..id.." 206")
		elseif (tile(x,y,"frame")~=0 and ship[id]~=0) then
			if (reputation[id][zones[checkInZone(x,y)].faction]>=zones[checkInZone(x,y)].allowrep) then
				if (pstack.docked[id]) then
					parse("speedmod "..id.." "..ships[shipt[id]].smod)
					pstack.docked[id]=false
					table.remove(pstack.pdocked[fromUsgn(parties[inParty[id][2]].mship)],table.find(pstack.pdocked[fromUsgn(parties[inParty[id][2]].mship)],id))
				end
				if cruise[id] then cruisef(id,2) end
				freeimage(ship[id])
				ship[id]=0
				parse("setarmor "..id.." 0")
			else
				if (scanForSpace(x,y)) then
					local sx,sy=scanForSpace(x,y)
					parse("setpos "..id.." "..(sx*32+16).." "..(sy*32+16))
				end
			end
		end
	else
		if (tile(x,y,"frame")==0) then
			if (parties[inParty[id][2]].mshipi==0) then
				parties[inParty[id][2]].mshipi=image("gfx/space/"..ships["ms"].name..".png",1,0,200+id)
				parse("setarmor "..id.." 206")
			end
			parties[inParty[id][2]].msx=player(id,"tilex")
			parties[inParty[id][2]].msy=player(id,"tiley")
		elseif (tile(x,y,"frame")~=0 and parties[inParty[id][2]].mshipi~=0) then
			if (reputation[id][zones[checkInZone(x,y)].faction]>=zones[checkInZone(x,y)].allowrep) then
				if cruise[id] then cruisef(id,2) end
				freeimage(parties[inParty[id][2]].mshipi)
				parties[inParty[id][2]].mshipi=0
				parse("setarmor "..id.." 0")
			else
				if (scanForSpace(x,y)) then
					local sx,sy=scanForSpace(x,y)
					parse("setpos "..id.." "..(sx*32+16).." "..(sy*32+16))
				end
			end
		end
	end
	pos[id][1]=x*32+16
	pos[id][2]=y*32+16
	pos[id][3]=x
	pos[id][4]=y
end

addhook("always","mshipdocked")
function mshipdocked()
	for _,id in ipairs(player(0,"table")) do
		if (inParty[id][1] and player(id,"usgn")==parties[inParty[id][2]].mship and pstack.inMShip[id]) then
			parties[inParty[id][2]].msxx=player(id,"x")
			parties[inParty[id][2]].msyy=player(id,"y")
			for _,did in ipairs(pstack.pdocked[id]) do
				parse("setpos "..did.." "..parties[inParty[id][2]].msxx.." "..parties[inParty[id][2]].msyy)
			end
		end
	end
end


function harmship(id,dmg)
	if (not pstack.docked[id]) then
		local odmg=dmg
		local fdmg=0
		if (shipt[id]~="ms") then
			if (shield[id]>dmg*0.5) then
				shield[id]=shield[id]-math.ceil(dmg*0.5)
				restoringshield[id]=false
				freetimer("parse","lua restoringshield["..id.."]=true")
				timer(5000,"parse","lua restoringshield["..id.."]=true")
				shieldimg[id]=image("gfx/sprites/wave.bmp",1,0,200+id)
				imageblend(shieldimg[id],1)
				imagecolor(shieldimg[id],90,255,90)
				imagealpha(shieldimg[id],0)
				imagescale(shieldimg[id],5,5)
				tween_alpha(shieldimg[id],100,1)
				timer(100,"parse","lua tween_alpha("..shieldimg[id]..",100,0)")
				elib.sound3("space/shieldhit.ogg",player(id,"x"),player(id,"y"),1024)
			else
				fdmg=dmg-dmg*0.5
				if (fdmg>0) then
					armor[id]=armor[id]-fdmg
					elib.sound3("space/armhit.wav",player(id,"x"),player(id,"y"),1024)
				end
				shield[id]=0
				restoringshield[id]=false
				freetimer("parse","lua restoringshield["..id.."]=true")
				timer(5000,"parse","lua restoringshield["..id.."]=true")
				if (armor[id]>dmg) then
					armor[id]=armor[id]-dmg
					elib.sound3("space/armhit.wav",player(id,"x"),player(id,"y"),1024)
				else
					armor[id]=0
					fdmg=dmg-fdmg
					if (fdmg>0) then
						if (fdmg<player(id,"health")) then
							parse("sethealth "..id.." "..player(id,"health")-math.ceil(dmg*2))
						else
							parse("customkill "..shooter.." \""..name.."\" "..id)
						end
					end
					if (player(id,"health")>dmg*2) then
						parse("sethealth "..id.." "..player(id,"health")-math.ceil(dmg*2))
					end
				end
			end
		else
			if (inParty[id][1]) then
				if (parties[inParty[id][2]].mshipsh>dmg*0.5) then
					parties[inParty[id][2]].mshipsh=parties[inParty[id][2]].mshipsh-math.ceil(dmg*0.5)
					restoringshield[id]=false
					freetimer("parse","lua restoringshield["..id.."]=true")
					timer(5000,"parse","lua restoringshield["..id.."]=true")
					shieldimg[id]=image("gfx/sprites/wave.bmp",1,0,200+id)
					imageblend(shieldimg[id],1)
					imagecolor(shieldimg[id],255,90,90)
					imagealpha(shieldimg[id],0)
					imagescale(shieldimg[id],15,15)
					tween_alpha(shieldimg[id],100,1)
					timer(100,"parse","lua tween_alpha("..shieldimg[id]..",100,0)")
					elib.sound3("space/shieldhit.ogg",player(id,"x"),player(id,"y"),1024)
					return 1
				else
					fdmg=dmg-dmg*0.5
					if (fdmg>0) then
						parties[inParty[id][2]].mshipar=parties[inParty[id][2]].mshipar-fdmg
						elib.sound3("space/armhit.wav",player(id,"x"),player(id,"y"),1024)
						return 1
					end
					shield[id]=0
					restoringshield[id]=false
					freetimer("parse","lua restoringshield["..id.."]=true")
					timer(5000,"parse","lua restoringshield["..id.."]=true")
					if (parties[inParty[id][2]].mshipar>dmg) then
						parties[inParty[id][2]].mshipar=parties[inParty[id][2]].mshipar-dmg
						elib.sound3("space/armhit.wav",player(id,"x"),player(id,"y"),1024)
						return 1
					else
						parties[inParty[id][2]].mshipar=0
						fdmg=dmg-fdmg
						if (fdmg>0) then
							if (fdmg<player(id,"health")) then
								parse("sethealth "..id.." "..player(id,"health")-math.ceil(dmg*2))
								return 1
							else
								parse("customkill "..shooter.." \""..name.."\" "..id)
								return 1
							end
						end
						if (player(id,"health")>dmg*2) then
							parse("sethealth "..id.." "..player(id,"health")-math.ceil(dmg*2))
							return 1
						end
						return 1
					end
					return 1
				end
			end
		end
	end
end

