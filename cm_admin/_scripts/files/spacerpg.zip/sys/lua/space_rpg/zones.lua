zones = {}
zones.n=0

function zones.check(pl,id,x,y)
	if not x then x = player(pl,"tilex") end
	if not y then y = player(pl,"tiley") end
	if x >= zones[id].x[1] and x <= zones[id].x[2] and y >= zones[id].y[1] and y <= zones[id].y[2] then
		return true
	else
		return false
	end
end

function zones.create(x,y,name)
	if not x then x = {} end
	if not y then y = {} end
	if not name then name = "Zone" end
	zones.n = zones.n + 1
	local id = zones.n
	zones[id] = {
	x = x,
	y = y,
	name = name,
	}
end

zones.create({1,5},{1,5},"Mega-Zone")

addhook("movetile","mv")
function mv(pl,x,y)
	for id = 1,zones.n,1 do
		if zones[id] then
			if zones.check(pl,id,x,y) then
				msg2(pl,string.char(0169).."255255255You are in Zone: "..zones[id].name)
			end
		end
	end
end