----------------------------------------------------------------------------
-- This is a script that converts old-format save files to the new format --
----------------------------------------------------------------------------

for usgn=1,100000 do

	local m = io.open('sys/lua/space_rpg/savedata/'..usgn..'.sav','r')

	if m then
		local a,b,c,d,e,f,g,h,i,j
		
		linen=1
		
		lines={}

		for line in m:lines() do
			lines[linen]=line
			linen=linen+1
		end

		a,b,c,d,e,f,g,h=tonumber(lines[1]),tonumber(lines[2]),tonumber(lines[3]),tonumber(lines[4]),tonumber(lines[5]),tonumber(lines[6]),tonumber(lines[7]),tonumber(lines[8])
		i=unique(string.split(lines[9],","))
		j=unique(string.split(lines[10],","))
		
		if not a then a=2000 end
		if not b then b=100 end
		if not c then c=100 end
		if not d then d=500 end
		if not e then e=0 end
		if not f then f=1 end
		if not i then i={0,0,0} end
		if not j then j={1,0,0,0,0,0,0,0,0} end
		
		local player = {credits = a,
			shield = b,
			armor = c,
			energy = d,
			fuel = 100,
			in_party = e,
			shipt = f,
			weapon_table = i,
			inv_table = j,
			rep = {10,10,10,10,-25,0,0,0,0},
		}
		
		pickle.dump(player,'sys/lua/space_rpg/savedata/'..usgn..'.sav')
	end

end