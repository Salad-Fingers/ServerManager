reputation=initArray2(32,{0,0})
repb=initArray2(32,0)
repab=initArray2(32,{0,0})
repeb=initArray2(32,{0,0})
faction=initArray2(32,0)

for f=1,#factions do
    for id=1,32 do
        reputation[id][f]=factions[f].initrep
    end
end

function getName(id,f)
	if (factions[f].repnames) then
		for i=1,#factions[f].repnames do
			if (reputation[id][f]>=0) then
				if (reputation[id][f]>=factions[f].repnames[i].min and reputation[id][f]<=factions[f].repnames[i].max) then
					return " ("..factions[f].repnames[i].name..")"
				end
			else
				if (reputation[id][f]<=factions[f].repnames[i].min and reputation[id][f]>=factions[f].repnames[i].max) then
					return " ("..factions[f].repnames[i].name..")"
				end
			end
		end
	end
	return ""
end

function getRep(id,f)
	if (factions[f]~=nil) then
		return factions[f].tag.." - "..factions[f].name.."|"..math.floor(reputation[id][f])..getName(id,f)
	end
	return ""
end

function joinFaction(id,f)
	if (f~=0) then
		changeRep(id,f,100-reputation[id][f])
		parse("setname "..id.." \""..factions[f].tag.." "..player(id,"name").."\"")
		faction[id]=f
		factj[id]=0
		factp[id]=0
	end
end

function leaveFaction(id)
	for i=1,#factions[faction[id]].allies do
		--changeRep(id,factions[faction[id]].allies[i],-(reputation[id][factions[faction[id]].allies[i]]-factions[factions[faction[id]].allies[i]].initrep))
		reputation[id][factions[faction[id]].allies[i]]=factions[factions[faction[id]].allies[i]].initrep
	end
	for i=1,#factions[faction[id]].enemies do
		--changeRep(id,factions[faction[id]].enemies[i],reputation[id][factions[faction[id]].enemies[i]]-factions[factions[faction[id]].enemies[i]].initrep)
		reputation[id][factions[faction[id]].enemies[i]]=factions[factions[faction[id]].enemies[i]].initrep
	end
	--changeRep(id,faction[id],-(reputation[id][faction[id]]-factions[faction[id]].initrep))
	reputation[id][faction[id]]=factions[faction[id]].initrep
	
	parse("setname "..id.." "..(player(id,"name"):sub(factions[faction[id]].tag:len()+2)))
	faction[id]=0
	
	msg2(id,"You are now an independent pilot.")
end

function repmenu(id,p)
	local checknext = function(p) if p>1 then return "Next" end return "" end
	p=p or 1
	local pages=math.ceil(#factions/7)
	if (p==1) then
		menu(id,"REPUTATION 1@b,"..getRep(id,1)..","..getRep(id,2)..","..getRep(id,3)..","..getRep(id,4)..","..getRep(id,5)..","..getRep(id,6)..","..getRep(id,7)..","..checknext(pages))
	elseif (p>1 and p<pages) then
		menu(id,"REPUTATION "..p.."@b,"..getRep(id,1+(7*(p-1)))..","..getRep(id,2+(7*(p-1)))..","..getRep(id,3+(7*(p-1)))..","..getRep(id,4+(7*(p-1)))..","..getRep(id,5+(7*(p-1)))..","..getRep(id,6+(7*(p-1)))..","..getRep(id,7+(7*(p-1)))..",Next,Previous")
	elseif (p==pages) then
		menu(id,"REPUTATION "..pages.."@b,"..getRep(id,1+(7*(pages-1)))..","..getRep(id,2+(7*(pages-1)))..","..getRep(id,3+(7*(pages-1)))..","..getRep(id,4+(7*(pages-1)))..","..getRep(id,5+(7*(pages-1)))..","..getRep(id,6+(7*(pages-1)))..","..getRep(id,7+(7*(pages-1)))..",,Previous")
	end
end

addhook("menu","repmenusel")
function repmenusel(id,menu,sel)
	if (menu:sub(1,10)=="REPUTATION") then
		local page=tonumber(menu:sub(12))
		if (sel>0 and sel<8) then
			if (factions[sel+(7*(page-1))].desc) then
				msg2(id,factions[sel+(7*(page-1))].desc)
			end
		end
		if (sel==8) then
			repmenu(id,page+1)
		end
		if (sel==9) then
			repmenu(id,page-1)
		end
	end
end

function playerInRange(x,y,rx,ry)
    for id=1,#player(0,"tableliving") do
        if (player(id,"exists") and player(id,"x")<=x+rx and player(id,"x")>=x-rx and player(id,"y")<=y+ry and player(id,"y")>=y-ry) then
            return id
        else
            return nil
        end
    end
end

function changeRep(id,f,r)
	repb[id]=reputation[id][f]
	reputation[id][f]=reputation[id][f]+r
	for i=1,#factions[f].repnames do
		if (factions[f].repnames[i].max>=0) then
			if ((repb[id]<factions[f].repnames[i].min or repb[id]>factions[f].repnames[i].max) and reputation[id][f]>=factions[f].repnames[i].min and reputation[id][f]<=factions[f].repnames[i].max) then
				msg2(id,"You are now a "..factions[f].repnames[i].name.." to "..factions[f].name)
			elseif ((repb[id]<factions[f].repnames[i].min or repb[id]>factions[f].repnames[i].max) and reputation[id][f]<0 and reputation[id][f]<=factions[f].repnames[i].min and reputation[id][f]>=factions[f].repnames[i].max) then
				msg2(id,"You are now a "..factions[f].repnames[i].name.." to "..factions[f].name)
			end
		end
	end
	for i=1,#factions[f].allies do
		repab[id][i]=reputation[id][factions[f].allies[i]]
		reputation[id][factions[f].allies[i]]=reputation[id][factions[f].allies[i]]+math.floor(r/2)
		for n=1,#factions[f].repnames do
			if ((repab[id][i]<factions[factions[f].allies[i]].repnames[n].min or repab[id][i]>factions[factions[f].allies[i]].repnames[n].max) and reputation[id][factions[f].allies[i]]>=factions[factions[f].allies[i]].repnames[n].min and reputation[id][factions[f].allies[i]]<=factions[factions[f].allies[i]].repnames[n].max) then
				msg2(id,"You are now a "..factions[factions[f].allies[i]].repnames[n].name.." to "..factions[factions[f].allies[i]].name)
			elseif ((repab[id][i]>factions[factions[f].allies[i]].repnames[n].min or repab[id][i]<factions[factions[f].allies[i]].repnames[n].max) and reputation[id][factions[f].allies[i]]<0 and reputation[id][factions[f].allies[i]]<=factions[factions[f].allies[i]].repnames[n].min and reputation[id][factions[f].allies[i]]>=factions[factions[f].allies[i]].repnames[n].max) then
				msg2(id,"You are now a "..factions[factions[f].allies[i]].repnames[n].name.." to "..factions[factions[f].allies[i]].name)
			end
		end
	end
	for i=1,#factions[f].enemies do
		repeb[id][i]=reputation[id][factions[f].enemies[i]]
		reputation[id][factions[f].enemies[i]]=reputation[id][factions[f].enemies[i]]-(r/1.5)
		for n=1,#factions[f].repnames do
			if ((repeb[id][i]<factions[factions[f].enemies[i]].repnames[n].min or repeb[id][i]>factions[factions[f].enemies[i]].repnames[n].max) and reputation[id][factions[f].enemies[i]]>=factions[factions[f].enemies[i]].repnames[n].min and reputation[id][factions[f].enemies[i]]<=factions[factions[f].enemies[i]].repnames[n].max) then
				msg2(id,"You are now a "..factions[factions[f].enemies[i]].repnames[n].name.." to "..factions[factions[f].enemies[i]].name)
			elseif ((repeb[id][i]>factions[factions[f].enemies[i]].repnames[n].min or repeb[id][i]<factions[factions[f].enemies[i]].repnames[n].max) and reputation[id][factions[f].enemies[i]]<0 and reputation[id][factions[f].enemies[i]]<=factions[factions[f].enemies[i]].repnames[n].min and reputation[id][factions[f].enemies[i]]>=factions[factions[f].enemies[i]].repnames[n].max) then
				msg2(id,"You are now a "..factions[factions[f].enemies[i]].repnames[n].name.." to "..factions[factions[f].enemies[i]].name)
			end
		end
	end
end

addhook("always","attackhostiles")
function attackhostiles()
    for id=1,#player(0,"tableliving") do
        if (player(id,"exists") and player(id,"bot") and playerInRange(player(id,"x"),player(id,"y"),512,512)~=nil and reputation[playerInRange(player(id,"x"),player(id,"y"),512,512)][faction[id]]<=-25) then
            local x=player(playerInRange(player(id,"x"),player(id,"y"),512,512),"x")
            local y=player(playerInRange(player(id,"x"),player(id,"y"),512,512),"y")
            ai_aim(id,x,y)
            ai_iattack(id)
        end
    end
end

addhook("kill","repchange")
function repchange(src,id)
	if (faction[id]~=0) then
		reputation[src][faction[id]]=reputation[src][faction[id]]-1
		for _,f in ipairs(factions[faction[id]].allies) do
			reputation[src][f]=reputation[src][f]-0.5
		end
		for _,f in ipairs(factions[faction[id]].enemies) do
			reputation[src][f]=reputation[src][f]+0.5
		end
	end
end

addhook("spawn","factionset")
function factionset(id)
	if (faction[id] and faction[id]~=0) then
		if (not player(id,"name"):find(factions[faction[id]].tag)) then
			parse("setname "..id.." "..factions[faction[id]].tag.." "..player(id,"name"))
		end
	end
end