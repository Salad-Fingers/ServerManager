-- THE NEBULAE MODULE
-- Allows the creation of different nebulae with different properties.
-- When a player enters a nebula, their screen is filled with the gas of the nebula - i.e. coloured differently.
-- Nebulae can also have an effect on ships.

function inTileRange(x1,y1,x2,y2,xr,yr)
	if (x1>=x2-xr and x1<=x2+xr and y1>=y2-yr and y1<=y2+yr) then
		return true
	end
	return false
end

function nebulae_load(nid) --a special function for creating nebulae out of a ready table. don't change!
	nebulae[nid].iid=image("gfx/space/nebula"..(nebulae[nid].niid or math.random(1,2))..".png",nebulae[nid].pos[1]*32+16,nebulae[nid].pos[2]*32+16,3)
	local r,g,b=tonumber(nebulae[nid].colour:sub(1,3)),tonumber(nebulae[nid].colour:sub(4,6)),tonumber(nebulae[nid].colour:sub(7,9))
	imagecolor(nebulae[nid].iid,r,g,b)
	imagealpha(nebulae[nid].iid,nebulae[nid].opacity/100)
	if (nebulae[nid].rad~=0) then
		imagescale(nebulae[nid].iid,nebulae[nid].rad*2,nebulae[nid].rad*2)
	else
		imagescale(nebulae[nid].iid,nebulae[nid].scale[1],nebulae[nid].scale[2])
	end
	tween_rotateconstantly(nebulae[nid].iid,nebulae[nid].rotation)
end

if nebulae then
	for i=1,#nebulae do
		nebulae_load(i)
	end
else
	nebulae={}
end

nebulae.next=1
nebulae.nebula=initArray2(32,0)

function nebulae.create(tx,ty,radius,scalex,scaley,colour,opacity,rotation,effect) --create a nebula. x and y are the coordinates in tiles, radius is the radius of the nebula (if you want to make it a circle); if 0 then scalex and scaley will be used, colour is the colour of the nebula ("255255255" for white, with quotes as string), opacity is its transparency (0-100), rotation is its rotation speed and effect is its effect (string)
	nebulae[nebulae.next]={}
	nebulae[nebulae.next].pos={tx,ty}
	if (radius~=0) then
		nebulae[nebulae.next].rad=radius
		nebulae[nebulae.next].scale={0,0}
	else
		nebulae[nebulae.next].rad=0
		nebulae[nebulae.next].scale={scalex,scaley}
	end
	nebulae[nebulae.next].colour=colour
	nebulae[nebulae.next].opacity=opacity
	nebulae[nebulae.next].effect=effect
	nebulae[nebulae.next].iid=image("gfx/space/nebula"..math.random(1,2)..".png",tx*32+16,ty*32+16,3)
	local r,g,b=tonumber(colour:sub(1,3)),tonumber(colour:sub(4,6)),tonumber(colour:sub(7,9))
	imagecolor(nebulae[nebulae.next].iid,r,g,b)
	imagealpha(nebulae[nebulae.next].iid,opacity/100)
	if (radius~=0) then
		imagescale(nebulae[nebulae.next].iid,radius*2,radius*2)
	else
		imagescale(nebulae[nebulae.next].iid,scalex,scaley)
	end
	nebulae[nid].rotation=rotation
	tween_rotateconstantly(nebulae[nebulae.next].iid,rotation)
	nebulae.next=nebulae.next+1
end

function nebulae.enter(id,nid) --function executed when a player enters a nebula - only edit the function if you have a good reason for it!
	nebulae.effects[nebulae[nid].effect].begin(id)
	nebulae[nid].screenimg=image("gfx/sprites/block.bmp",320,240,2,id)
	imagescale(nebulae[nid].screenimg,30,25)
	local r,g,b=tonumber(nebulae[nid].colour:sub(1,3)),tonumber(nebulae[nid].colour:sub(4,6)),tonumber(nebulae[nid].colour:sub(7,9))
	imagecolor(nebulae[nid].screenimg,r,g,b)
	imagealpha(nebulae[nid].screenimg,0)
	tween_alpha(nebulae[nid].screenimg,500,nebulae[nid].opacity/100)
	nebulae.nebula[id]=nid
	nebulae[nid].ply=id
end

function nebulae.exit(id,nid) --function executed when a player exits a nebula - only edit the function if you have a good reason for it!
	nebulae.effects[nebulae[nid].effect].finish(id)
	tween_alpha(nebulae[nid].screenimg,500,0)
	timer(500,"parse","lua freeimage(nebulae["..nid.."].screenimg)")
	nebulae.nebula[id]=0
	nebulae[nid].ply=0
end

addhook("movetile","nebulae.checkfornebulae")
function nebulae.checkfornebulae(id,x,y)
	if (nebulae.nebula[id]==0) then
		for n=1,#nebulae do
			if (nebulae[n].rad~=0) then
				if (inTileRange(x,y,nebulae[n].pos[1],nebulae[n].pos[2],nebulae[n].rad,nebulae[n].rad)) then
					nebulae.enter(id,n)
				end
			else
				if (inTileRange(x,y,nebulae[n].pos[1],nebulae[n].pos[2],nebulae[n].scale[1],nebulae[n].scale[2])) then
					nebulae.enter(id,n)
				end
			end
		end
	else
		local n=nebulae.nebula[id]
		if (nebulae[n].rad~=0) then
			if (not inTileRange(x,y,nebulae[n].pos[1],nebulae[n].pos[2],nebulae[n].rad,nebulae[n].rad)) then
				nebulae.exit(id,n)
			end
		else
			if (not inTileRange(x,y,nebulae[n].pos[1],nebulae[n].pos[2],nebulae[n].scale[1],nebulae[n].scale[2])) then
				nebulae.exit(id,n)
			end
		end
	end
end
