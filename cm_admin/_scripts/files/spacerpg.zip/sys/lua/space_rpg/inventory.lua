invfreeslot=initArray2(32,1)
invmaxslots=initArray2(32,14)
invslot=initArray2(32,{})
invsel=initArray2(32,0)

invstack={}
invstack.slot=initArray2(32,0)

invitems={}
if (comms~=nil) then
	for i=1,#comms do
		invitems[i]={
			name=comms[i].name,
		}
	end
end

if (equipment~=nil) then
	for i=1,#equipment do
		invitems[i+100]={
			name=equipment[i].name,
			desc=equipment[i].desc,
			class=equipment[i].class,
		}
	end
end
	

function fillBackpack(id,i)
    for c=1,invmaxslots[id] do
        invslot[id][c]=i
    end
end

function insertInBackpack(id,i,c)
	c = c or 1
    if (invfreeslot[id]<=invmaxslots[id]) then
        if (c==1 or c==nil) then
            if (invslot[id][invfreeslot[id]]==nil or invslot[id][invfreeslot[id]]==0) then
                invslot[id][invfreeslot[id]]=i
				if (invfreeslot[id]+1>invmaxslots[id]) then
					invfreeslot[id]=1
				else
					if (invslot[id][invfreeslot[id]+1]==0 or not invslot[id][invfreeslot[id]+1]) then
						invfreeslot[id]=invfreeslot[id]+1
					else
						invfreeslot[id]=invfreeslot[id]+2
					end
				end
            else	
                invfreeslot[id]=invfreeslot[id]+1
				if (invfreeslot[id]>invmaxslots[id]) then
					invfreeslot[id]=1
				end
				insertInBackpack(id,i,c)
            end
        end	
    else
		invfreeslot[id]=1
	end
    if (c>1) then	
        for v=1,c do
            invslot[id][invfreeslot[id]]=i
            invfreeslot[id]=invfreeslot[id]+1
        end
    end
end

function removeFromBackpack(id,slot)
    invslot[id][slot]=nil
    invfreeslot[id]=slot
    if (invslot[id][1]==0) then
        invfreeslot[id]=1
    end
    if (invslot[id][slot-1]==0) then
        invfreeslot[id]=slot-1
    end
end

function findInBackpack(id,iid)
	for s=1,invmaxslots[id] do
		if (s and invslot[id][s]==iid) then
			return s
		end
	end
	return nil
end

function findInSlot(id,s)
	if (invslot[id][s] and invslot[id][s]==0) then
		return invslot[id][s]
	end
	return nil
end

function checkInBackpack(id,s)
    if (invslot[id][s] and invslot[id][s]~=0) then
        return invitems[invslot[id][s]].name
    else
        return ""
    end
end

function checkFree(id,c)
	c = c or 1
	d = 0
	for s=1,invmaxslots[id] do
		if (c>1) then
			for n=1,c do
				if (invslot[id][s]==nil or invslot[id][s]==0) then
					d=d+1
				end
			end
			return d
		end
		if (invslot[id][s]==nil or invslot[id][s]==0) then
			return s
		end
	end
	return false
end

function checkFree2(id)
	if (invslot[id][invfreeslot[id]]==0 or not invslot[id][invfreeslot[id]]) then
		return invfreeslot[id]
	else
		if (invfreeslot[id]+1<=invmaxslots[id]) then
			invfreeslot[id]=invfreeslot[id]+1
		else
			invfreeslot[id]=1
		end
		checkFree2(id)
	end
end

function itemUse(id,slot)
	if (invslot[id][slot]<101) then
		if (comms[invslot[id][slot]].func) then
			menu(id,"Item actions@b,,Use|Use the item,,,,,,,Jettison|The item will be lost forever!")
		else
			menu(id,"Item actions@b,,,,,,,,,Jettison|The item will be lost forever!")
		end
	else
		menu(id,"Item actions@b,Equip|Mount the weapon onto the ship,,,,,,,,Jettison|The item will be lost forever!")
	end
	invstack.slot[id]=slot
end


--Shows inventory to the user, page p
function inventory(id,p)
	local pages=math.ceil(invmaxslots[id]/7)
    if (p==1) then
        menu(id,"Inventory 1,"..checkInBackpack(id,1)..","..checkInBackpack(id,2)..","..checkInBackpack(id,3)..","..checkInBackpack(id,4)..","..checkInBackpack(id,5)..","..checkInBackpack(id,6)..","..checkInBackpack(id,7)..",,Next")
    elseif (p>1 and p<pages) then
		menu(id,"Inventory "..p..","..checkInBackpack(id,(1+(7*(p-1))))..","..checkInBackpack(id,(2+(7*(p-1))))..","..checkInBackpack(id,(3+(7*(p-1))))..","..checkInBackpack(id,(4+(7*(p-1))))..","..checkInBackpack(id,(5+(7*(p-1))))..","..checkInBackpack(id,(6+(7*(p-1))))..","..checkInBackpack(id,(7+(7*(p-1))))..",Back,Next")
	elseif (p==pages) then
		menu(id,"Inventory "..pages..","..checkInBackpack(id,(1+(7*(pages-1))))..","..checkInBackpack(id,(2+(7*(pages-1))))..","..checkInBackpack(id,(3+(7*(pages-1))))..","..checkInBackpack(id,(4+(7*(pages-1))))..","..checkInBackpack(id,(5+(7*(pages-1))))..","..checkInBackpack(id,(6+(7*(pages-1))))..","..checkInBackpack(id,(7+(7*(pages-1))))..",Back")
	end
end

addhook("menu","menusels")
function menusels(id,title,sel)
    for p=1,math.ceil(invmaxslots[id]/7) do
        if (title=="Inventory "..p) then
            local page=tonumber(title:sub(11))
            if (sel>0 and sel<=7) then
                invsel[id]=(sel+(7*(page-1)))
                itemUse(id,invsel[id])
            end
            if (sel==8) then
                inventory(id,page-1)
            end
            if (sel==9) then
                inventory(id,page+1)
            end
        end
    end
	if (title=="Item actions") then
		if (sel==1) then
			menu(id,"Equip weapon@b,"..wPrint(id,1)..","..wPrint(id,2)..","..wPrint(id,3)..","..wPrint(id,4)..","..wPrint(id,5)..","..wPrint(id,6)..","..wPrint(id,7)..","..wPrint(id,8)..","..wPrint(id,9))
		end
		if (sel==2) then
			comms[invslot[id][invsel[id]]].func(id)
			removeFromBackpack(id,invsel[id])
		end
		if (sel==9) then
			removeFromBackpack(id,invstack.slot[id])
			invstack.slot[id]=nil
		end
	end
	if (title=="Equip weapon") then
		if (sel~=0 and cwslots[id][sel] and cwslots[id][sel]==0 and ships[shipt[id]].wslots[sel].lvl>=equipment[invslot[id][invstack.slot[id]]-100].lvl and (ships[shipt[id]].wslots[sel].type==equipment[invslot[id][invstack.slot[id]]-100].class or ships[shipt[id]].wslots[sel].type=="omni")) then
			cwslots[id][sel]=invslot[id][invstack.slot[id]]-100
			removeFromBackpack(id,invstack.slot[id])
			invstack.slot[id]=nil
		else
			msg2(id,"Something went wrong. Are you sure you did everything right?")
		end
	end
end
