cruise=initArray2(32,false)
cruiseactivating=initArray2(32,false)
cruiseper=initArray2(32,0)
ztick=initArray2(32,0)

function cruisef(id,m)
	if (m==1) then
		cruise[id]=true
		elib.sound3("space/cruise_engage.ogg",player(id,"x"),player(id,"y"),512)
		elib.sound3("space/cruise_burn.wav",player(id,"x"),player(id,"y"),512)
		parse("speedmod "..id.." "..(ships[shipt[id]].smod+20))
	elseif (m==2) then
		cruise[id]=false
		elib.sound3("space/cruise_disengage.ogg",player(id,"x"),player(id,"y"),512)
		parse("speedmod "..id.." "..ships[shipt[id]].smod)
	end
end

addhook("serveraction","cruiseactivate")
function cruiseactivate(id,a)
	if (a==3) then
		if not cruise[id] then
			if (tile(player(id,"tilex"),player(id,"tiley"),"frame")==0 and not inlane[id]) then
				if (fuel[id]>0) then
					cruiseactivating[id]=true
					hudtxt2(id,45,"000255000","Cruise engine charge: "..cruiseper[id].."%",320,360)
				else
					msg2(id,"�255000000You are out of fuel!")
				end
			end
		else
			cruisef(id,2)
		end
	end
end

addhook("ms100","cruisefire")
function cruisefire()
	for id=1,#player(0,"table") do
		ztick[id]=ztick[id]+1
		if cruiseactivating[id] then
			if cruiseper[id]<100 then
				hudtxt2(id,45,"000255000","Cruise engine charge: "..cruiseper[id].."%",320,360)
				cruiseper[id]=cruiseper[id]+10
			else
				hudtxt2(id,45,"000255000","Cruise engine charge: 100%",320,360)
				cruisef(id,1)
				cruiseactivating[id]=false
			end
		end
		if cruise[id] then
			if (shipt[id]~="ms") then
				if (fuel[id]>0) then
					fuel[id]=fuel[id]-1
				else
					fuel[id]=0
					cruisef(id,2)
				end
			end
			if (ztick[id]>=20) then
				elib.sound3("space/cruise_burn.wav",player(id,"x"),player(id,"y"),512)
				ztick[id]=0
			end
		else
			if not cruiseactivating[id] then
				if cruiseper[id]>0 then
					hudtxt2(id,45,"000255000","Cruise engine charge: "..cruiseper[id].."%",320,360)
					cruiseper[id]=cruiseper[id]-10
				else
					cruiseper[id]=0
					hudtxt2(id,45,"000255000","",320,360)
				end
			end
		end
	end
end
