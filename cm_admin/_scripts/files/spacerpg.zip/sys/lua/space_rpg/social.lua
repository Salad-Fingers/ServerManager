function table.find(t,v)
	for k,e in ipairs(t) do
		if (e==v) then
			return k
		end
	end
	return nil
end

function fromUsgn(usgn)
	for _,id in ipairs(player(0,"table")) do
		if (player(id,"usgn")==usgn) then
			return id
		end
	end
	return 0
end

---------------------------------
------ PARTY SYSTEM - CORE ------
---------------------------------
parties = {}

curparty = 1
inParty = {}
pstack = {
	enteringDAmount={},
	enteringWAmount={},
	grantingWithdrawal={},
	wplayer={},
	wfunds={},
	
	enteringMPilot={},
	inMothership={},
	inMShip={},
	docked={},
	pdocked={},
	
	creatingParty={},
	pName={},
	pTag={},
	joining={},
	pjoining={},
}

parties[0]={
	name="",
	tag="",
	motto="",
	leader=0,
	vleader1=0,
	vleader2=0,
	members={},
	maxmembers=0,
	maxposmembers=0,
	bankfunds=0,
	bankwlimit=0,
	promptwithdrawal=false,
	mship=0,
	cship=0,
}

for id=1,32 do
	inParty[id]={}
	inParty[id][1]=false
	inParty[id][2]=0
	pstack.inMShip[id]=false
	pstack.pdocked[id]={}
end

prevsh=initArray2(32,0)
prevcw=initArray2(32,{})

function createParty(c,n,t,m)
	parties[curparty]={
		name=n,
		tag=t,
		motto=m,
		leader=c,
		vleader1=0,
		vleader2=0,
		members={},
		maxmembers=6,
		maxposmembers=12,
		bankfunds=1000,
		bankwlimit=1000,
		promptwithdrawal=false,
		mship=0,
		mshipconfig={7,8,8,8,8,8,8},
		cship=0,
		mshipi=0,
	},
	parse("setname "..fromUsgn(c).." "..t.."{L}"..player(fromUsgn(c),"name"))
	inParty[fromUsgn(c)][1]=true
	inParty[fromUsgn(c)][2]=curparty
	curparty=curparty+1
end

function disbandParty(id)
	parse("setname "..fromUsgn(parties[id].leader).." "..player(fromUsgn(parties[id].leader),"name"):sub(parties[id].tag:len()+4))
	for _,pid in ipairs(parties[id].members) do
		parse("setname "..fromUsgn(pid).." "..player(fromUsgn(pid),"name"):sub(parties[id].tag:len()+1))
	end
	parties[party]=nil
end

function joinParty(id,pid)
	table.insert(parties[pid].members,id)
	parse("setname "..fromUsgn(id).." "..t..""..player(fromUsgn(c),"name"))
end

function leaveParty(id,pid)
	table.remove(parties[pid].members,table.find(parties[pid].members,id))
	parse("setname "..fromUsgn(id).." "..player(fromUsgn(id),"name"):sub(parties[pid].tag:len()+1))
end

function depositInBank(id,pid,a)
	if (credits[id]>=a) then
		credits[id]=credits[id]-a
		parties[pid].bankfunds=parties[pid].bankfunds+a
		msg2(id,"�000255000Deposit successful")
	else
		msg2(id,"�255000000ERROR: Insufficient funds (Code SB1UIF)")
	end
end

function withdrawFromBank(id,pid,a)
	if (a<=parties[pid].bankwlimit) then
		if (a<=parties[pid].bankfunds) then
			if (not parties[pid].promptwithdrawal) then
				credits[id]=credits[id]+a
				parties[pid].bankfunds=parties[pid].bankfunds-a
				msg2(id,"�000255000Withdrawal successful")
			else
				msg2(id,"�255255255Sending a request to party leader, please wait...")
				for _,lid in ipairs(player(0,"table")) do
					if (lid==parties[pid].leader) then
						pstack.grantingWithdrawal[lid]=true
						msg2(id,"�000255000Connection established")
						msg2(lid,"�255255255"..player(id,"name").." wishes to withdraw "..a.." credits - Y/N?")
						pstack.wplayer[lid]=id
						pstack.wfunds[id]=a
					else
						timer(5000,"parse","lua msg2("..id..",\"Request timed out (Code SB2LNP)\")")
					end
				end
			end
		else
			msg2(id,"�255000000ERROR: Insufficient funds in bank to withdraw (Code SB2BIF)")
		end
	else
		msg2(id,"�255000000ERROR: Withdrawal amount exceeds limit (Code SB2AEL)")
	end
end

--------------------------------
------ PARTY SYSTEM - GUI ------
--------------------------------

function msElement(id)
	if (not pstack.inMShip[id]) then
		if (player(id,"tilex")==parties[inParty[id][2]].msx and player(id,"tiley")==parties[inParty[id][2]].msy and player(id,"usgn")==parties[inParty[id][2]].mship) then
			return "Enter Mothership"
		end
	else
		return "Exit Mothership"
	end
	return ""
end

function partyMenu(id)
	if (inParty[id][1]) then
		if (parties[inParty[id][2]].leader==player(id,"usgn")) then
			menu(id,"PARTY LEADER MENU,Party Details,Party Bank,Upgrades,Settings,"..msElement(id))
		else
			menu(id,"PARTY MENU,Party Details,Party Bank,"..msElement(id))
		end
	end
end

function partyBankMenu(id)
	menu(id,"PARTY BANK,(Funds)|"..parties[inParty[id][2]].bankfunds..",Deposit,Withdraw")
end

function upgradesMenu(id)
	menu(id,"PARTY UPGRADES,(Premium|Not implemented),Mothership|"..msPrice..",(Constructor Ship|Not Implemented),Extra Member Slot|"..emSlotPrice)
end

function settingsMenu(id)
	menu(id,"PARTY SETTINGS@b,Ask leader about withdrawal|"..tostring(parties[inParty[id][2]].promptwithdrawal)..",Withdraw limit|"..parties[inParty[id][2]].bankwlimit)
end

function getMShip(pid)
	if (parties[pid].mship~=0) then
		return "True"
	end
	return "False"
end

addhook("menu","partyMenuSel")
function partyMenuSel(id,menu,sel)
	if (sel==1) then
		if (menu=="PARTY LEADER MENU" or menu=="PARTY MENU") then
			msg2(id,"Information about "..parties[inParty[id][2]].tag.." - "..parties[inParty[id][2]].name)
			msg2(id,"Members - "..(#parties[inParty[id][2]].members+1).."/"..parties[inParty[id][2]].maxmembers)
			msg2(id,"Leader - USGN #"..parties[inParty[id][2]].leader)
			msg2(id,"Mothership - "..getMShip(inParty[id][2]))
		end
	end
	if (sel==2) then
		if (menu=="PARTY LEADER MENU" or menu=="PARTY MENU") then
			partyBankMenu(id)
		end
	end
	if (sel==3) then
		if (menu=="PARTY MENU") then
			if (msElement(id)=="Enter Mothership") then
				msEnter(id)
			elseif (msElement(id)=="Exit Mothership") then
				msExit(id)
			end
		elseif (menu=="PARTY LEADER MENU") then
			upgradesMenu(id)
		end
	end
	if (sel==4 and menu=="PARTY LEADER MENU") then
		settingsMenu(id)
	end
	if (sel==5 and menu=="PARTY LEADER MENU") then
		if (msElement(id)=="Enter Mothership") then
			msEnter(id)
		elseif (msElement(id)=="Exit Mothership") then
			msExit(id)
		end
	end
	------------
	if (menu=="PARTY BANK") then
		if (sel==2) then
			pstack.enteringDAmount[id]=true
			msg2(id,"�255255255Please enter the amount you wish to deposit")
		end
		if (sel==3) then
			pstack.enteringWAmount[id]=true
			msg2(id,"�255255255Please enter the amount you wish to withdraw")
		end
	end
	------------
	if (menu=="PARTY UPGRADES") then
		if (sel==2) then
			if (parties[inParty[id][2]].mship==0) then
				if (parties[inParty[id][2]].bankfunds>=msPrice) then
					parties[inParty[id][2]].bankfunds=parties[inParty[id][2]].bankfunds-msPrice
					pstack.enteringMPilot[id]=true
					msg2(id,"�255255255Please enter the ID of the mothership pilot")
				else
					msg2(id,"�255000000ERROR: Insufficient funds (Code SU2MIF)")
				end
			else
				msg2(id,"�255000000ERROR: Party already has mothership (Code SU2AHM)")
			end
		end
		if (sel==4) then
			if (parties[inParty[id][2]].maxmembers<parties[inParty[id][2]].maxposmembers) then
				if (parties[inParty[id][2]].bankfunds>=emSlotPrice) then
					parties[inParty[id][2]].bankfunds=parties[inParty[id][2]].bankfunds-emSlotPrice
					parties[inParty[id][2]].maxmembers=parties[inParty[id][2]].maxmembers+1
					msg2(id,"�000255000Transaction completed successfully")
				else
					msg2(id,"�255000000ERROR: Insufficient funds (Code SU4SIF)")
				end
			else
				msg2(id,"�255000000ERROR: Slots limit reached (Code SU4SLR)")
			end
		end
	end
	------------
	if (menu=="PARTY SETTINGS") then
		if (sel==1) then
			if (parties[inParty[id][2]].promptwithdrawal) then
				parties[inParty[id][2]].promptwithdrawal=false
			else
				parties[inParty[id][2]].promptwithdrawal=true
			end
			settingsMenu(id)
		end
	end
end

------------------------
------ MOTHERSHIP ------
------------------------

function assignMPilot(id,pid)
	for _,muid in ipairs(parties[pid].members) do
		local mid=fromUsgn(muid)
		if (mid~=id) then
			msg2(mid,player(id,"name").." is now the party's mothership pilot")
		end
	end
	msg2(fromUsgn(parties[pid].leader),player(id,"name").." is now the party's mothership pilot")
	msg2(id,"You are now the party's mothership pilot")
	------
	local xx=player(id,"tilex")
	local yy=player(id,"tiley")
	if (tile(xx,yy,"frame")==0) then
		parties[pid].msx=xx
		parties[pid].msy=yy
		msEnter(id)
	end
	parties[pid].mship=player(id,"usgn")
	parties[inParty[id][2]].mshipsh=ships["ms"].shield
	parties[inParty[id][2]].mshipar=ships["ms"].armor
	parties[inParty[id][2]].mshipen=ships["ms"].energy
	pstack.inMShip[id]=true
end

function msEnter(id)
	local xx=player(id,"tilex")
	local yy=player(id,"tiley")
	if (tile(xx,yy,"frame")==0) then
		freeimage(parties[inParty[id][2]].mshipi)
		pstack.inMShip[id]=true
		parties[inParty[id][2]].mshipi=image("gfx/space/"..ships["ms"].name..".png",1,0,200+id)
		parse("setarmor "..id.." 206")
		prevsh[id]=shipt[id]
		shipt[id]="ms"
		shield[id]=parties[inParty[id][2]].mshipsh
		armor[id]=parties[inParty[id][2]].mshipar
		energy[id]=parties[inParty[id][2]].mshipen
		prevcw[id]=cwslots[id]
		cwslots[id]=parties[inParty[id][2]].mshipconfig
	end
end

function msExit(id)
	local xx=player(id,"tilex")
	local yy=player(id,"tiley")
	if (tile(xx,yy,"frame")==0) then
		freeimage(parties[inParty[id][2]].mshipi)
		parties[inParty[id][2]].mshipi=0
		parties[inParty[id][2]].mshipi=image("gfx/space/"..ships["ms"].name..".png",player(id,"x"),player(id,"y"),3)
		imagepos(parties[inParty[id][2]].mshipi,player(id,"x"),player(id,"y"),player(id,"rot"))
		tween_move(parties[inParty[id][2]].mshipi,1000,math.floor(player(id,"tilex")*32+16),math.floor(player(id,"tiley")*32+16))
		shield[id]=ships[shipt[id]].shield
		pstack.inMShip[id]=false
		shipt[id]=prevsh[id]
		parties[inParty[id][2]].mshipsh=shield[id]
		parties[inParty[id][2]].mshipar=armor[id]
		parties[inParty[id][2]].mshipen=energy[id]
		parties[inParty[id][2]].mshipconfig=cwslots[id]
		cwslots[id]=prevcw[id]
	end
end

function msDock(id)
	if (player(id,"tilex")==parties[inParty[id][2]].msx and player(id,"tiley")==parties[inParty[id][2]].msy and tile(player(id,"tilex"),player(id,"tiley"),"frame")==0) then
		if (not pstack.docked[id]) then
			pstack.docked[id]=true
			table.insert(pstack.pdocked[fromUsgn(parties[inParty[id][2]].mship)],id)
			parse("speedmod "..id.." -100")
			freeimage(ship[id])
			ship[id]=0
		else
			pstack.docked[id]=false
			parse("speedmod "..id.." "..ships[shipt[id]].smod)
			ship[id]=image("gfx/space/"..ships[shipt[id]].name..".png",1,0,200+id)
			parse("setarmor "..id.." 206")
		end
	end
end
