inlane=initArray2(32,false)
laneinrange=initArray2(32,0)
lanesimg=initArray2(512,0)
lanefimg=initArray2(512,0)
lanemode=initArray2(32,"")
lanewhence=initArray2(32,0)
xspeed=initArray2(32,0)
yspeed=initArray2(32,0)

addhook("ms100","tradelaneenter")
function tradelaneenter()
	for id=1,#player(0,"tableliving") do
		local x=player(id,"tilex")
		local y=player(id,"tiley")
		for tl=1,#lanes do
			if (player(id,"exists") and x==lanes[tl].x and y==lanes[tl].y) then
				if (inlane[id]==false) then
					hudtxt2(id,10,"000255000",zones[lanes[tl].from].name.." > "..zones[lanes[tl].to].name,220,40)
					laneinrange[id]=tl
					lanemode[id]=""
					break
				else
					if (lanemode[id]~="") then
						hudtxt2(id,10,"000255000",zones[lanes[tl].from].name.." > "..zones[lanes[tl].to].name,220,40)
						inlane[id]=false
						laneinrange[id]=tl
						xspeed[id]=0
						yspeed[id]=0
						parse("speedmod "..id.." "..ships[shipt[id]].smod)
						lanewhence[id]=0
						break
					end
				end
			elseif (x==lanes[tl].ex and y==lanes[tl].ey) then
				if (inlane[id]==false) then
					hudtxt2(id,10,"000255000",zones[lanes[tl].to].name.." > "..zones[lanes[tl].from].name,220,40)
					laneinrange[id]=tl
					lanemode[id]="rev"
					break
				else
					if (lanemode[id]~="rev") then
						hudtxt2(id,10,"000255000",zones[lanes[tl].to].name.." > "..zones[lanes[tl].from].name,220,40)
						inlane[id]=false
						laneinrange[id]=tl
						xspeed[id]=0
						yspeed[id]=0
						parse("speedmod "..id.." "..ships[shipt[id]].smod)
						lanewhence[id]=0
						break
					end
				end
			else
				hudtxt2(id,10,"000255000","",220,40)
				laneinrange[id]=nil
			end
		end
	end
end

addhook("serveraction","tradelanethru")
function tradelanethru(id,a)
    if (a==2) then
		if not inlane[id] then
			if (lanemode[id]=="" and laneinrange[id]~=nil) then
				lanewhence[id]=laneinrange[id]
				inlane[id]=true
				xspeed[id]=lanes[laneinrange[id]].sx
				yspeed[id]=lanes[laneinrange[id]].sy
				parse("speedmod "..id.." -100")
				cruisef(id,2)
			elseif (lanemode[id]=="rev" and laneinrange[id]~=nil) then
				lanewhence[id]=laneinrange[id]
				inlane[id]=true
				xspeed[id]=-(lanes[laneinrange[id]].sx)
				yspeed[id]=-(lanes[laneinrange[id]].sy)
				parse("speedmod "..id.." -100")
				cruisef(id,2)
			end
		else
			inlane[id]=false
			xspeed[id]=0
			yspeed[id]=0
			parse("speedmod "..id.." "..ships[shipt[id]].smod)
		end
    end
end

addhook("always","moooove")
function moooove()
    for id=1,#player(0,"tableliving") do
        if (inlane[id]) then
			if (player(id,'exists') and xspeed[id] and yspeed[id]) then
            	parse("setpos "..id.." "..(player(id,"x")+xspeed[id]).." "..(player(id,"y")+yspeed[id]))
			end
        end
    end
end