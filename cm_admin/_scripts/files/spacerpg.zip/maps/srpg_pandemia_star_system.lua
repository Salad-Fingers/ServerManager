zones = {
	[0] = {
		name = "",
		faction = 0,
		allowrep = -100,
		xs = 0,
		ys = 0,
		xe = 0,
		ye = 0,
	},
    [1] = {
        name = "Hestia Starbase",
        faction = 1,
		allowrep = -50,
        xs = 93,
        ys = 10,
        xe = 133,
        ye = 50,
        comm = {
            x1 = 109,
            y1 = 25,
            x2 = 112,
            y2 = 28,
        },
		bar = {
			x1 = 101,
			y1 = 30,
			x2 = 104,
			y2 = 32,
		},
    },
    [2] = {
        name = "Asteroid GB10Z5",
        faction = 3,
		allowrep = -50,
        xs = 102,
        ys = 157,
        xe = 138,
        ye = 193,
        comm = {
            x1 = 115,
            y1 = 177,
            x2 = 126,
            y2 = 181,
        },
    },
	[3] = {
        name = "Freeport 1",
        faction = 6,
		allowrep = -50,
        xs = 23,
        ys = 107,
        xe = 53,
        ye = 137,
        comm = {
            x1 = 44,
            y1 = 115,
            x2 = 46,
            y2 = 118,
        },
    },
	[4] = {
        name = "Atlas Depot",
        faction = 4,
		allowrep = -50,
        xs = 231,
        ys = 110,
        xe = 261,
        ye = 130,
        comm = {
            x1 = 247,
            y1 = 120,
            x2 = 249,
            y2 = 127,
        },
    },
	[5] = {
		name = "Ithaca Research Station",
		faction = 1,
		allowrep = -50,
		xs = 38,
		ys = 233,
		xe = 77,
		ye = 272,
        comm = {
            x1 = 54,
            y1 = 241,
            x2 = 56,
            y2 = 245,
        },
	},
	[6] = {
		name = "Artemis Laboratory Complex",
		faction = 2,
		allowrep = -50,
		xs = 265,
		ys = 270,
		xe = 290,
		ye = 299,
        comm = {
            x1 = 271,
            y1 = 277,
            x2 = 276,
            y2 = 280,
        },
	},
	[7] = {
		name = "Hephaestus Shipyards",
		faction = 1,
		allowrep = -50,
		xs = 217,
		ys = 186,
		xe = 254,
		ye = 222,
        comm = {
            x1 = 239,
            y1 = 202,
            x2 = 242,
            y2 = 205,
        },
	},
	[8] = {
		name = "Eos Hypergate",
		faction = 4,
		allowrep = -50,
		xs = 99,
		ys = 337,
		xe = 116,
		ye = 359,
        comm = {
            x1 = 106,
            y1 = 351,
            x2 = 111,
            y2 = 355,
        },
	},
	[9] = {
		name = "Hub Hypergate",
		faction = 4,
		allowrep = -50,
		xs = 351,
		ys = 102,
		xe = 362,
		ye = 125,
        comm = {
            x1 = 356,
            y1 = 106,
            x2 = 359,
            y2 = 108,
        },
	},
	[10] = {
		name = "Outpost Faraway",
		faction = 8,
		allowrep = -50,
		xs = 313,
		ys = 179,
		xe = 348,
		ye = 202,
        comm = {
            x1 = 335,
            y1 = 188,
            x2 = 338,
            y2 = 191,
        },
	},
	[11] = {
		name = "Mercury Trading Post",
		faction = 9,
		allowrep = -50,
		xs = 285,
		ys = 47,
		xe = 307,
		ye = 68,
        comm = {
            x1 = 290,
            y1 = 52,
            x2 = 292,
            y2 = 54,
        },
	},
	[12] = {
		name = "Eremus Prime",
		type = "planet",
		planet = 1,
		faction = 1,
		allowrep = -50,
		xs = 0,
		ys = 443,
		xe = 25,
		ye = 470,
		comm = {
			x1 = 21,
			y1 = 445,
			x2 = 21,
			y2 = 445,
		},
	},
}

basedata = {
    [1] = {
        commtr = {
            [1] = {
                type = 4,
                price = 30,
            },
        },
        commb = {
            [1] = {
                type = 6,
                price = 160,
            },
			[2] = {
				type = 1,
				price = 30,
			},
        },
		eqtr = {
			[1] = {
				type = 1,
				price = 200,
			},
			[2] = {
				type = 2,
				price = 500,
			},
			[3] = {
				type = 3,
				price = 1500,
			},
		},
		shtr = {
			[1] = {
				type = 2,
				price = 169500,
			},
		},
		bribes = {
			[1] = {
				faction = 3,
				price = 64000,
				factor = 20,
			},
			[2] = {
				faction = 2,
				price = 59000,
				factor = 20,
			},
		},
		factc = 130000,
    },
	[2] = {
        commtr = {
            [1] = {
                type = 6,
                price = 40,
            },
        },
        commb = {
            [1] = {
                type = 5,
                price = 160,
            },
        },
		shtr = {
			[1] = {
				type = 4,
				price = 130750,
			},
		},
    },
	[3] = {
		commtr = {
			[1] = {
				type = 8,
				price = 1500,
			},
		},
		eqtr = {
			[1] = {
				type = 4,
				price = 2150,
			},
			[2] = {
				type = 5,
				price = 4620,
			},
		},
		shtr = {
			[1] = {
				type = 3,
				price = 253250,
			},
		},
	},
	[4] = {
        commtr = {
            [1] = {
                type = 5,
                price = 80,
            },
            [2] = {
                type = 1,
                price = 25,
            },
            [3] = {
                type = 2,
                price = 15,
            },
            [4] = {
                type = 3,
                price = 400,
            },
        },
    },
	[5] = {
        commb = {
            [1] = {
                type = 4,
                price = 120,
            },
            [2] = {
                type = 2,
                price = 30,
            },
        },
		eqtr = {
			[1] = {
				type = 9,
				price = 2600,
			},
			[2] = {
				type = 10,
				price = 2740,
			},
		},
	},
	[6] = {
		commtr = {
			[1] = {
				type = 7,
				price = 2,
			},
		},
        commb = {
            [1] = {
                type = 8,
                price = 3000,
            },
        },
		eqtr = {
			[1] = {
				type = 11,
				price = 2370,
			},
			[2] = {
				type = 12,
				price = 4740,
			},
		},
		shtr = {
			[1] = {
				type = 9,
				price = 534730,
			},
			[2] = {
				type = 12,
				price = 822580,
			},
		},
	},
	[7] = {
        commb = {
            [1] = {
                type = 3,
                price = 800,
            },
            [2] = {
                type = 4,
                price = 90,
            },
        },
		eqtr = {
			[1] = {
				type = 13,
				price = 12500,
			},
			[2] = {
				type = 14,
				price = 25175,
			},
			[3] = {
				type = 15,
				price = 45250,
			},
			[4] = {
				type = 16,
				price = 74650,
			},
			[5] = {
				type = 17,
				price = 123140,
			},
		},
		shtr = {
			[1] = {
				type = 6,
				price = 863500,
			},
			[2] = {
				type = 7,
				price = 1474730,
			},
			[3] = {
				type = 8,
				price = 2340910,
			},
		},
	},
	[10] = {
		shtr = {
			[1] = {
				type = 10,
				price = 673150,
			},
			[2] = {
				type = 11,
				price = 756345,
			},
		},
		eqtr = {
			[1] = {
				type = 20,
				price = 27230,
			},
			[2] = {
				type = 21,
				price = 42170,
			},
		},
		commb = {
			[1] = {
				type = 1,
				price = 75,
			},
			[2] = {
				type = 2,
				price = 30,
			},
		},
	},
	[11] = {
		commtr = {
			[1] = {
				type = 6,
				price = 20,
			},
			[2] = {
				type = 4,
				price = 20,
			},
		},
		eqtr = {
			[1] = {
				type = 18,
				price = 3500,
			},
			[2] = {
				type = 19,
				price = 4250,
			},
		},
		shtr = {
			[1] = {
				type = 5,
				price = 364100,
			},
			[2] = {
				type = 13,
				price = 989350,
			},
		},
	},
}

lanes = {
    [1] = {
        from = 1,
        to = 2,
        x = 116,
        y = 43,
        ex = 116,
        ey = 157,
        sx = 0,
		sy = 5,
    },
    [2] = {
        from = 1,
        to = 3,
        x = 107,
        y = 43,
        ex = 47,
        ey = 103,
        sx = -5,
        sy = 5,
    },
	[3] = {
        from = 2,
        to = 5,
        x = 106,
        y = 157,
        ex = 58,
        ey = 237,
        sx = -3,
        sy = 5,
    },
	[4] = {
        from = 9,
        to = 11,
        x = 349,
        y = 111,
        ex = 292,
        ey = 65,
        sx = -5,
        sy = -4,
    },
	[5] = {
        from = 9,
        to = 10,
        x = 354,
        y = 119,
        ex = 328,
        ey = 184,
        sx = -2,
        sy = 5,
    },
	[6] = {
        from = 10,
        to = 7,
        x = 321,
        y = 187,
        ex = 226,
        ey = 187,
        sx = -5,
        sy = 0,
    },
	[7] = {
        from = 10,
        to = 6,
        x = 321,
        y = 193,
        ex = 261,
        ey = 268,
        sx = -4,
        sy = 5,
    },
	[8] = {
        from = 9,
        to = 4,
        x = 349,
        y = 114,
        ex = 236,
        ey = 114,
        sx = -5,
        sy = 0,
    },
	[9] = {
        from = 5,
        to = 8,
        x = 71,
        y = 255,
        ex = 102,
        ey = 332,
        sx = 2,
        sy = 5,
    },
}

sectors = {
	[1] = {
		name = "Hub",
		x1 = 0,
		y1 = 0,
		x2 = 204,
		y2 = 399,
	},
	[2] = {
		name = "Eos",
		x1 = 206,
		y1 = 0,
		x2 = 399,
		y2 = 399,
	},
}

gates = {
	[1] = {
		from = 1,
		to = 2,
		x = 100,
		y = 338,
		ex = 362,
		ey = 122,
	},
}

astfields = {
	[1] = {
		density = 1,
		comm = 1,
		xs = 20,
		ys = 3,
		xe = 40,
		ye = 23,
	},
}

nebulae = {
	[1] = {
		pos = {114,62},
		rad = 5,
		scale = {0,0},
		colour = "255000000",
		opacity = 90,
		rotation = 0.05,
		effect = "radiation",
		niid = 1,
	},
}

nebulae.effects={ --the table containing effects of nebulae
	["radiation"] = { --continuous effect, begin is executed when a player gets into a field, finish - when they get out. if only begin or finish is specified, only those will be executed
		begin = function(id)
			timer(1000,"parse","lua harmship("..id..",50)",0)
		end,
		finish = function(id)
			freetimer("parse","lua harmship("..id..",50)")
		end,
	},
}

planets = {
	[1] = {
		name = "Eremus Prime",
		img = "gfx/space/planet1.png",
		--pos = {146,69},
		pos = {98,53},
		lpos = {2,446},
		rad = 98,
		landable = true,
		rot = 0.01,
		base = 12,
	},
}

-- FACTIONS
factions = {
    [0] = {
        name = "Independent Pilots",
        initrep = 0,
        tag = "",
    },
    [1] = {
        name = "Biolith Inc.",
        initrep = 10,
        tag = "[BIO]",
		allies = {3,4,8,9},
		enemies = {5},
		repnames = {
			[1] = {
				min = -10,
				max = 20,
				name = "Pilot",
			},
			[2] = {
				min = 21,
				max = 40,
				name = "Helper",
			},
			[3] = {
				min = 41,
				max = 60,
				name = "Friend",
			},
			[4] = {
				min = 61,
				max = 80,
				name = "Trusted Friend",
			},
			[5] = {
				min = 81,
				max = 100,
				name = "One of Own",
			},
			[6] = {
				min = -11,
				max = -20,
				name = "Nuisance",
			},
			[7] = {
				min = -21,
				max = -30,
				name = "Saboteur",
			},
			[8] = {
				min = -31,
				max = -50,
				name = "Minor Threat",
			},
			[9] = {
				min = -51,
				max = -70,
				name = "Major Threat",
			},
			[10] = {
				min = -71,
				max = -90,
				name = "Enemy",
			},
			[11] = {
				min = -91,
				max = -500,
				name = "Enemy of the Corporation",
			},
		},
    },
    [2] = {
        name = "Minotaur Weapons Systems",
        initrep = 10,
        tag = "[MWS]",
		allies = {3,4,8,9},
		enemies = {5},
		repnames = {
			[1] = {
				min = -10,
				max = 20,
				name = "Pilot",
			},
			[2] = {
				min = 21,
				max = 40,
				name = "Helper",
			},
			[3] = {
				min = 41,
				max = 60,
				name = "Friend",
			},
			[4] = {
				min = 61,
				max = 80,
				name = "Trusted Friend",
			},
			[5] = {
				min = 81,
				max = 100,
				name = "One of Own",
			},
			[6] = {
				min = -11,
				max = -20,
				name = "Nuisance",
			},
			[7] = {
				min = -21,
				max = -30,
				name = "Saboteur",
			},
			[8] = {
				min = -31,
				max = -50,
				name = "Minor Threat",
			},
			[9] = {
				min = -51,
				max = -70,
				name = "Major Threat",
			},
			[10] = {
				min = -71,
				max = -90,
				name = "Enemy",
			},
			[11] = {
				min = -91,
				max = -500,
				name = "Enemy of the Corporation",
			},
		},
    },
    [3] = {
        name = "Hannan Mining Facilities",
        initrep = 10,
        tag = "[HMF]",
		allies = {1,2,4,8,9},
		enemies = {5},
		repnames = {
			[1] = {
				min = -10,
				max = 20,
				name = "Pilot",
			},
			[2] = {
				min = 21,
				max = 40,
				name = "Helper",
			},
			[3] = {
				min = 41,
				max = 60,
				name = "Friend",
			},
			[4] = {
				min = 61,
				max = 80,
				name = "Trusted Friend",
			},
			[5] = {
				min = 81,
				max = 100,
				name = "One of Own",
			},
			[6] = {
				min = -11,
				max = -20,
				name = "Nuisance",
			},
			[7] = {
				min = -21,
				max = -30,
				name = "Saboteur",
			},
			[8] = {
				min = -31,
				max = -50,
				name = "Minor Threat",
			},
			[9] = {
				min = -51,
				max = -70,
				name = "Major Threat",
			},
			[10] = {
				min = -71,
				max = -90,
				name = "Enemy",
			},
			[11] = {
				min = -91,
				max = -500,
				name = "Enemy of the Corporation",
			},
		},
    },
    [4] = {
        name = "TeleTec Inc.",
        initrep = 10,
        tag = "[TEL]",
		allies = {1,2,3,8,9},
		enemies = {5},
		repnames = {
			[1] = {
				min = -10,
				max = 20,
				name = "Pilot",
			},
			[2] = {
				min = 21,
				max = 40,
				name = "Helper",
			},
			[3] = {
				min = 41,
				max = 60,
				name = "Friend",
			},
			[4] = {
				min = 61,
				max = 80,
				name = "Trusted Friend",
			},
			[5] = {
				min = 81,
				max = 100,
				name = "One of Own",
			},
			[6] = {
				min = -11,
				max = -20,
				name = "Nuisance",
			},
			[7] = {
				min = -21,
				max = -30,
				name = "Saboteur",
			},
			[8] = {
				min = -31,
				max = -50,
				name = "Minor Threat",
			},
			[9] = {
				min = -51,
				max = -70,
				name = "Major Threat",
			},
			[10] = {
				min = -71,
				max = -90,
				name = "Enemy",
			},
			[11] = {
				min = -91,
				max = -500,
				name = "Enemy of the Corporation",
			},
		},
    },
    [5] = {
        name = "Les Flibustieres",
        initrep = -25,
        tag = "[FBS]",
		enemies = {1,2,3,4,8,9},
		repnames = {
			[1] = {
				min = -10,
				max = 20,
				name = "Rookie",
			},
			[2] = {
				min = 21,
				max = 40,
				name = "Amateur",
			},
			[3] = {
				min = 41,
				max = 60,
				name = "War Dog",
			},
			[4] = {
				min = 61,
				max = 80,
				name = "Veteran",
			},
			[5] = {
				min = 81,
				max = 100,
				name = "Ace",
			},
			[6] = {
				min = -11,
				max = -20,
				name = "Nuisance",
			},
			[7] = {
				min = -21,
				max = -30,
				name = "Corp Attack Dog",
			},
			[8] = {
				min = -31,
				max = -50,
				name = "Corp Agent",
			},
			[9] = {
				min = -51,
				max = -70,
				name = "Threat",
			},
			[10] = {
				min = -71,
				max = -90,
				name = "Enemy",
			},
			[11] = {
				min = -91,
				max = -500,
				name = "Sworn Enemy",
			},
		},
    },
	[6] = {
		name = "The Independents",
		initrep = 0,
		tag = "[IND]",
	},
	[7] = {
		name = "UNKNOWN",
		initrep = 0,
		tag = "[?]",
	},
	[8] = {
		name = "Far Space Research",
		initrep = 10,
		tag = "[FSR]",
		allies = {1,2,3,4,9},
		enemies = {5},
		repnames = {
			[1] = {
				min = -10,
				max = 20,
				name = "Pilot",
			},
			[2] = {
				min = 21,
				max = 40,
				name = "Helper",
			},
			[3] = {
				min = 41,
				max = 60,
				name = "Friend",
			},
			[4] = {
				min = 61,
				max = 80,
				name = "Trusted Friend",
			},
			[5] = {
				min = 81,
				max = 100,
				name = "One of Own",
			},
			[6] = {
				min = -11,
				max = -20,
				name = "Nuisance",
			},
			[7] = {
				min = -21,
				max = -30,
				name = "Saboteur",
			},
			[8] = {
				min = -31,
				max = -50,
				name = "Minor Threat",
			},
			[9] = {
				min = -51,
				max = -70,
				name = "Major Threat",
			},
			[10] = {
				min = -71,
				max = -90,
				name = "Enemy",
			},
			[11] = {
				min = -91,
				max = -500,
				name = "Enemy of the Corporation",
			},
		},
	},
	[9] = {
		name = "Core Worlds Exports",
		initrep = 10,
		tag = "[CWE]",
		allies = {1,2,3,4},
		enemies = {5},
		repnames = {
			[1] = {
				min = -10,
				max = 20,
				name = "Pilot",
			},
			[2] = {
				min = 21,
				max = 40,
				name = "Helper",
			},
			[3] = {
				min = 41,
				max = 60,
				name = "Friend",
			},
			[4] = {
				min = 61,
				max = 80,
				name = "Trusted Friend",
			},
			[5] = {
				min = 81,
				max = 100,
				name = "One of Own",
			},
			[6] = {
				min = -11,
				max = -20,
				name = "Nuisance",
			},
			[7] = {
				min = -21,
				max = -30,
				name = "Saboteur",
			},
			[8] = {
				min = -31,
				max = -50,
				name = "Minor Threat",
			},
			[9] = {
				min = -51,
				max = -70,
				name = "Major Threat",
			},
			[10] = {
				min = -71,
				max = -90,
				name = "Enemy",
			},
			[11] = {
				min = -91,
				max = -500,
				name = "Enemy of the Corporation",
			},
		},
	},
}

-- COMMODITIES
comms = {
    [1] = {
        name = "Water",
    },
    [2] = {
        name = "Food Rations",
    },
    [3] = {
        name = "Heavy Machinery",
    },
    [4] = {
        name = "Exurum",
    },
    [5] = {
        name = "ZP Energy Rods",
    },
    [6] = {
        name = "Durium",
    },
    [7] = {
        name = "Nuclear Waste",
		func = function(id) fuel[id]=fuel[id]+20 end,
    },
    [8] = {
        name = "MOX Fuel",
		func = function(id) fuel[id]=fuel[id]+100 end,
    },
	[9] = {
		name = "Shield Booster Mk I",
		func = function(id) shield[id]=shield[id]+100 end,
	},
	[10] = {
		name = "Shield Booster Mk II",
		func = function(id) shield[id]=shield[id]+1000 end,
	},
	[11] = {
		name = "Energy Battery Mk I",
		func = function(id) energy[id]=energy[id]+100 end,
	},
	[12] = {
		name = "Energy Battery Mk II",
		func = function(id) energy[id]=energy[id]+1000 end,
	},
}

ships = {
    [1] = {
        name = "Essex",
        shield = 500,
        armor = 250,
		energy = 750,
		energyr = 2,
		fuel = 100,
		smod = 10,
		cargo = 14,
		wslots = {
			[1] = {
				type = "laser",
				lvl = 3,
			},
			[2] = {
				type = "omni",
				lvl = 2,
			},
			[3] = {
				type = "omni",
				lvl = 2,
			},
		}
    },
    [2] = {
        name = "Lexington",
        shield = 750,
        armor = 500,
		energy = 1000,
		energyr = 3,
		fuel = 150,
		smod = 9,
		cargo = 21,
		wslots = {
			[1] = {
				type = "omni",
				lvl = 5,
			},
			[2] = {
				type = "omni",
				lvl = 5,
			},
			[3] = {
				type = "omni",
				lvl = 4,
			},
			[4] = {
				type = "omni",
				lvl = 4,
			},
		}
    },
    [3] = {
        name = "Liberty",
        shield = 1250,
        armor = 750,
		energy = 1500,
		energyr = 5,
		fuel = 200,
		smod = 8,
		cargo = 28,
		wslots = {
			[1] = {
				type = "laser",
				lvl = 8,
			},
			[2] = {
				type = "omni",
				lvl = 8,
			},
			[3] = {
				type = "omni",
				lvl = 7,
			},
			[4] = {
				type = "omni",
				lvl = 7,
			},
			[5] = {
				type = "omni",
				lvl = 7,
			},
		}
    },
    [4] = {
        name = "Drone",
        shield = 650,
        armor = 325,
		energy = 750,
		energyr = 3,
		fuel = 300,
		smod = 11,
		cargo = 28,
		wslots = {
			[1] = {
				type = "laser",
				lvl = 5,
			},
			[2] = {
				type = "laser",
				lvl = 5,
			},
		}
    },
    [5] = {
        name = "Bumblebee",
        shield = 1100,
        armor = 650,
		energy = 950,
		energyr = 4,
		fuel = 450,
		smod = 10,
		cargo = 35,
		wslots = {
			[1] = {
				type = "laser",
				lvl = 5,
			},
			[2] = {
				type = "laser",
				lvl = 5,
			},
			[3] = {
				type = "omni",
				lvl = 4,
			},
		}
    },
    [6] = {
        name = "Rapier",
        shield = 2750,
        armor = 1500,
		energy = 3500,
		energyr = 7,
		fuel = 600,
		smod = 6,
		cargo = 21,
		wslots = {
			[1] = {
				type = "laser",
				lvl = 7,
			},
			[2] = {
				type = "laser",
				lvl = 7,
			},
			[3] = {
				type = "omni",
				lvl = 6,
			},
			[4] = {
				type = "omni",
				lvl = 6,
			},
			[5] = {
				type = "omni",
				lvl = 6,
			},
		}
    },
    [7] = {
        name = "Sword",
        shield = 3500,
        armor = 2150,
		energy = 4500,
		energyr = 8,
		fuel = 700,
		smod = 5,
		cargo = 28,
		wslots = {
			[1] = {
				type = "laser",
				lvl = 8,
			},
			[2] = {
				type = "laser",
				lvl = 8,
			},
			[3] = {
				type = "omni",
				lvl = 7,
			},
			[4] = {
				type = "omni",
				lvl = 7,
			},
			[5] = {
				type = "omni",
				lvl = 7,
			},
		}
    },
    [8] = {
        name = "Saber",
        shield = 5000,
        armor = 3250,
		energy = 5500,
		energyr = 10,
		fuel = 800,
		smod = 3,
		cargo = 28,
		wslots = {
			[1] = {
				type = "laser",
				lvl = 9,
			},
			[2] = {
				type = "laser",
				lvl = 9,
			},
			[3] = {
				type = "omni",
				lvl = 8,
			},
			[4] = {
				type = "omni",
				lvl = 8,
			},
			[5] = {
				type = "omni",
				lvl = 8,
			},
		}
    },
    [9] = {
        name = "Orion",
        shield = 1675,
        armor = 925,
		energy = 2000,
		energyr = 6,
		fuel = 300,
		smod = 7,
		cargo = 28,
		wslots = {
			[1] = {
				type = "laser",
				lvl = 9,
			},
			[2] = {
				type = "laser",
				lvl = 8,
			},
			[3] = {
				type = "omni",
				lvl = 8,
			},
			[4] = {
				type = "omni",
				lvl = 7,
			},
			[5] = {
				type = "omni",
				lvl = 7,
			},
		}
    },
    [10] = {
        name = "Poseidon",
        shield = 2000,
        armor = 1000,
		energy = 2500,
		energyr = 7,
		fuel = 450,
		smod = 8,
		cargo = 21,
		wslots = {
			[1] = {
				type = "laser",
				lvl = 8,
			},
			[2] = {
				type = "laser",
				lvl = 8,
			},
			[3] = {
				type = "omni",
				lvl = 8,
			},
			[4] = {
				type = "omni",
				lvl = 8,
			},
			[5] = {
				type = "omni",
				lvl = 8,
			},
		}
    },
    [11] = {
        name = "Phoenix",
        shield = 2250,
        armor = 1250,
		energy = 2750,
		energyr = 8,
		fuel = 500,
		smod = 7,
		cargo = 21,
		wslots = {
			[1] = {
				type = "laser",
				lvl = 8,
			},
			[2] = {
				type = "laser",
				lvl = 8,
			},
			[3] = {
				type = "omni",
				lvl = 7,
			},
			[4] = {
				type = "omni",
				lvl = 7,
			},
			[5] = {
				type = "omni",
				lvl = 7,
			},
			[6] = {
				type = "omni",
				lvl = 7,
			},
		}
    },
    [12] = {
        name = "Pegasus",
        shield = 2500,
        armor = 1500,
		energy = 3000,
		fuel = 600,
		energyr = 8,
		smod = 6,
		cargo = 28,
		wslots = {
			[1] = {
				type = "laser",
				lvl = 9,
			},
			[2] = {
				type = "laser",
				lvl = 9,
			},
			[3] = {
				type = "omni",
				lvl = 8,
			},
			[4] = {
				type = "omni",
				lvl = 8,
			},
			[5] = {
				type = "omni",
				lvl = 8,
			},
			[6] = {
				type = "omni",
				lvl = 8,
			},
		}
    },
    [13] = {
        name = "Barge",
        shield = 2000,
        armor = 1500,
		energy = 1250,
		energyr = 5,
		fuel = 900,
		smod = 7,
		cargo = 49,
		wslots = {
			[1] = {
				type = "laser",
				lvl = 7,
			},
			[2] = {
				type = "laser",
				lvl = 7,
			},
			[3] = {
				type = "omni",
				lvl = 6,
			},
			[3] = {
				type = "omni",
				lvl = 6,
			},
		}
    },
    [14] = {
        name = "Millenium Falcon",
        shield = 1000000000,
        armor = 1000000000,
		energy = 1000000000,
		fuel = 1000000000,
		energyr = 1000000000,
		smod = 15,
		cargo = 35,
		wslots = {
			[1] = {
				type = "laser",
				lvl = 10,
			},
			[2] = {
				type = "laser",
				lvl = 10,
			},
			[3] = {
				type = "omni",
				lvl = 10,
			},
			[4] = {
				type = "omni",
				lvl = 10,
			},
			[5] = {
				type = "omni",
				lvl = 10,
			},
			[6] = {
				type = "omni",
				lvl = 10,
			},
		}
    },
    [15] = {
        name = "Orion MK II",
        shield = 8000,
        armor = 4000,
		energy = 3000,
		energyr = 6,
		fuel = 500,
		smod = 8,
		cargo = 28,
		wslots = {
			[1] = {
				type = "laser",
				lvl = 10,
			},
			[2] = {
				type = "omni",
				lvl = 9,
			},
			[3] = {
				type = "omni",
				lvl = 9,
			},
			[4] = {
				type = "omni",
				lvl = 9,
			},
			[5] = {
				type = "omni",
				lvl = 9,
			},
		}
    },
    [16] = {
        name = "Asshole",
        shield = 7500,
        armor = 2500,
		energy = 8000,
		energyr = 9,
		fuel = 500,
		smod = 12,
		cargo = 21,
		wslots = {
			[1] = {
				type = "laser",
				lvl = 10,
			},
			[2] = {
				type = "laser",
				lvl = 10,
			},
			[3] = {
				type = "laser",
				lvl = 10,
			},
			[4] = {
				type = "laser",
				lvl = 10,
			},
			[5] = {
				type = "omni",
				lvl = 10,
			},
			[6] = {
				type = "omni",
				lvl = 10,
			},
		}
    },
    [17] = {
        name = "Wintern Fury",
        shield = 8500,
        armor = 4250,
		energy = 8500,
		energyr = 9,
		fuel = 750,
		smod = 13,
		cargo = 21,
		wslots = {
			[1] = {
				type = "laser",
				lvl = 10,
			},
			[2] = {
				type = "laser",
				lvl = 10,
			},
			[3] = {
				type = "omni",
				lvl = 10,
			},
			[4] = {
				type = "omni",
				lvl = 10,
			},
			[5] = {
				type = "omni",
				lvl = 10,
			},
		}
    },
    [18] = {
        name = "Liberator",
        shield = 12500,
        armor = 4750,
		energy = 9000,
		energyr = 8,
		fuel = 650,
		smod = 14,
		cargo = 28,
		wslots = {
			[1] = {
				type = "laser",
				lvl = 10,
			},
			[2] = {
				type = "laser",
				lvl = 10,
			},
			[3] = {
				type = "omni",
				lvl = 10,
			},
			[4] = {
				type = "omni",
				lvl = 10,
			},
			[5] = {
				type = "omni",
				lvl = 10,
			},
		}
    },

	["ms"] = {
		name = "Midway",
		shield = 1000000,
		armor = 500000,
		energy = 50000,
		fuel = 1200,
		cargo = 140,
		wslots = {
			[1] = {
				type = "mcannon",
				lvl = 11,
			},
			[2] = {
				type = "lcannon",
				lvl = 11,
			},
			[3] = {
				type = "lcannon",
				lvl = 11,
			},
			[4] = {
				type = "lcannon",
				lvl = 11,
			},
			[5] = {
				type = "lcannon",
				lvl = 11,
			},
			[6] = {
				type = "lcannon",
				lvl = 11,
			},
			[7] = {
				type = "lcannon",
				lvl = 11,
			},
		}
	},
}

equipment = {
	[0] = {
		name = "None",
		desc = "None",
		lvl = 0,
		dmg = 0,
		wid = 0,
	},
	[1] = {
		name = "Pulse Emitter Mark I",
		desc = "The most basic civilian weapon.",
		lvl = 1,
		dmg = 24,
		img = "gfx/sprites/raindrop.bmp",
		spd = 10,
		r = 0,
		g = 128,
		b = 255,
		blend = 1,
		h = 15,
		wd = 8,
		range = 256,
		energy = 10,
		refire = 300,
		sfx = "space/lightlaser.ogg",
		class = "laser",
	},
	[2] = {
		name = "Pulse Emitter Mark II",
		desc = "A more sophisticated civilian laser.",
		lvl = 2,
		dmg = 48,
		img = "gfx/sprites/raindrop.bmp",
		spd = 10,
		r = 0,
		g = 98,
		b = 255,
		blend = 1,
		h = 15,
		wd = 8,
		refire = 300,
		range = 256,
		energy = 10,
		sfx = "space/lightlaser.ogg",
		class = "laser",
	},
	[3] = {
		name = "Pulse Torpedo Mark I",
		desc = "A powerful but slow weapon.",
		lvl = 2,
		dmg = 200,
		img = "gfx/sprites/snowflake.bmp",
		spd = 3,
		r = 50,
		g = 255,
		b = 50,
		blend = 1,
		h = 32,
		wd = 32,
		range = 400,
		energy = 100,
		refire = 2000,
		sfx = "space/torpedo.ogg",
		class = "torpedo",
	},
	[4] = {
		name = "Tachyon Cannon Mark I",
		desc = "A decommissioned military laser.",
		lvl = 3,
		dmg = 128,
		img = "gfx/sprites/raindrop.bmp",
		spd = 10,
		r = 50,
		g = 255,
		b = 50,
		blend = 1,
		h = 15,
		wd = 8,
		refire = 500,
		range = 300,
		energy = 20,
		sfx = "space/laser.ogg",
		class = "laser",
	},
	[5] = {
		name = "Tachyon Cannon Mark II",
		desc = "An improved version of its predecessor.",
		lvl = 5,
		dmg = 256,
		img = "gfx/sprites/raindrop.bmp",
		spd = 10,
		r = 25,
		g = 255,
		b = 25,
		blend = 1,
		h = 15,
		wd = 8,
		refire = 500,
		range = 300,
		energy = 30,
		sfx = "space/laser.ogg",
		class = "laser",
	},
	[6] = {
		name = "Tachyon Cannon Mark III",
		desc = "The most powerful weapon in the series.",
		lvl = 7,
		dmg = 512,
		img = "gfx/sprites/raindrop.bmp",
		spd = 10,
		r = 25,
		g = 255,
		b = 25,
		blend = 1,
		h = 15,
		wd = 8,
		refire = 200,
		range = 300,
		energy = 50,
		sfx = "space/laser.ogg",
		class = "laser",
	},
	[7] = {
		name = "Mothership Main Cannon",
		desc = "A humongous pulse emitter for a mothership.",
		lvl = 11,
		dmg = 200000,
		img = "gfx/sprites/flare2.bmp",
		spd = 2,
		r = 255,
		g = 255,
		b = 255,
		blend = 1,
		h = 95,
		wd = 95,
		refire = 5000,
		range = 1000,
		energy = 1000,
		sfx = "space/mcannon.wav",
		class = "mcannon",
		explode = true,
	},
	[8] = {
		name = "Mothership Auxiliary Cannon",
		desc = "A lighter mothership pulse emitter.",
		lvl = 11,
		dmg = 2000,
		img = "gfx/sprites/raindrop.bmp",
		spd = 5,
		r = 255,
		g = 50,
		b = 50,
		blend = 1,
		h = 15,
		wd = 8,
		refire = 1000,
		range = 500,
		energy = 100,
		sfx = "space/lcannon.wav",
		class = "lcannon",
		explode = true,
	},
	[9] = {
		name = "Pulse Torpedo Mark II",
		desc = "An improved version of the previous mark.",
		lvl = 5,
		dmg = 400,
		img = "gfx/sprites/snowflake.bmp",
		spd = 3,
		r = 50,
		g = 255,
		b = 50,
		blend = 1,
		h = 32,
		wd = 32,
		range = 400,
		energy = 100,
		refire = 2000,
		sfx = "space/torpedo.ogg",
		class = "torpedo",
	},
	[10] = {
		name = "Pulse Emitter Mark III",
		desc = "The most powerful civilian PE.",
		lvl = 2,
		dmg = 96,
		img = "gfx/sprites/raindrop.bmp",
		spd = 10,
		r = 0,
		g = 25,
		b = 255,
		blend = 1,
		h = 15,
		wd = 8,
		refire = 300,
		range = 256,
		energy = 15,
		sfx = "space/lightlaser.ogg",
		class = "laser",
	},
	[11] = {
		name = "Photon Cannon Mark I",
		desc = "A rapid-firing but low-damage weapon.",
		lvl = 4,
		dmg = 40,
		img = "gfx/sprites/raindrop.bmp",
		spd = 15,
		r = 255,
		g = 50,
		b = 50,
		blend = 1,
		h = 15,
		wd = 8,
		range = 256,
		energy = 5,
		refire = 100,
		sfx = "space/photon.wav",
		class = "laser",
	},
	[12] = {
		name = "Photon Cannon Mark II",
		desc = "An improved version of the Mark I.",
		lvl = 6,
		dmg = 50,
		img = "gfx/sprites/raindrop.bmp",
		spd = 15,
		r = 255,
		g = 40,
		b = 40,
		blend = 1,
		h = 15,
		wd = 8,
		range = 256,
		energy = 7,
		refire = 100,
		sfx = "space/photon.wav",
		class = "laser",
	},
	[13] = {
		name = "Cruiser Light Blaster",
		desc = "A weapon designed for use on cruisers.",
		lvl = 6,
		dmg = 300,
		img = "gfx/sprites/raindrop.bmp",
		spd = 15,
		r = 255,
		g = 255,
		b = 75,
		blend = 1,
		h = 15,
		wd = 8,
		range = 300,
		energy = 60,
		refire = 700,
		sfx = "space/lcannon.wav",
		class = "laser",
	},
	[14] = {
		name = "Cruiser Medium Blaster",
		desc = "A heavier cruiser weapon.",
		lvl = 7,
		dmg = 400,
		img = "gfx/sprites/raindrop.bmp",
		spd = 15,
		r = 255,
		g = 255,
		b = 0,
		blend = 1,
		h = 15,
		wd = 8,
		range = 300,
		energy = 70,
		refire = 800,
		sfx = "space/lcannon.wav",
		class = "laser",
	},
	[15] = {
		name = "Cruiser Heavy Blaster",
		desc = "The most powerful weapon available to cruisers.",
		lvl = 8,
		dmg = 400,
		img = "gfx/sprites/raindrop.bmp",
		spd = 15,
		r = 255,
		g = 200,
		b = 0,
		blend = 1,
		h = 15,
		wd = 8,
		range = 300,
		energy = 90,
		refire = 1000,
		sfx = "space/lcannon.wav",
		class = "laser",
	},
	[16] = {
		name = "Destroyer Light Cannon",
		desc = "A huge pulse emitter designed for use on Destroyer-class ships.",
		lvl = 7,
		dmg = 500,
		img = "gfx/sprites/raindrop.bmp",
		spd = 15,
		r = 255,
		g = 125,
		b = 255,
		blend = 1,
		h = 15,
		wd = 8,
		range = 400,
		energy = 110,
		refire = 1000,
		sfx = "space/lcannon.wav",
		class = "laser",
	},
	[17] = {
		name = "Destroyer Heavy Cannon",
		desc = "A huge pulse emitter designed for use on Destroyer-class ships.",
		lvl = 8,
		dmg = 650,
		img = "gfx/sprites/raindrop.bmp",
		spd = 15,
		r = 255,
		g = 0,
		b = 255,
		blend = 1,
		h = 15,
		wd = 8,
		range = 400,
		energy = 150,
		refire = 1500,
		sfx = "space/mcannon.wav",
		class = "laser",
	},
	[18] = {
		name = "Barge Light Cannon",
		desc = "A rather weak weapon for transports.",
		lvl = 6,
		dmg = 200,
		img = "gfx/sprites/raindrop.bmp",
		spd = 15,
		r = 228,
		g = 255,
		b = 0,
		blend = 1,
		h = 15,
		wd = 8,
		range = 300,
		energy = 20,
		refire = 1500,
		sfx = "space/lcannon.wav",
		class = "laser",
	},
	[19] = {
		name = "Barge Heavy Cannon",
		desc = "An improved version.",
		lvl = 7,
		dmg = 300,
		img = "gfx/sprites/raindrop.bmp",
		spd = 15,
		r = 200,
		g = 255,
		b = 0,
		blend = 1,
		h = 15,
		wd = 8,
		range = 300,
		energy = 20,
		refire = 1500,
		sfx = "space/lcannon.wav",
		class = "laser",
	},
	[20] = {
		name = "Neutron Emitter Mk I",
		desc = "A neutron weapon with moderate damage and refire rate.",
		lvl = 7,
		dmg = 150,
		img = "gfx/sprites/raindrop.bmp",
		spd = 15,
		r = 255,
		g = 107,
		b = 107,
		blend = 1,
		h = 15,
		wd = 8,
		range = 300,
		energy = 20,
		refire = 700,
		sfx = "space/lcannon.wav",
		class = "laser",
	},
	[21] = {
		name = "Neutron Emitter Mk II",
		desc = "A better version.",
		lvl = 8,
		dmg = 200,
		img = "gfx/sprites/raindrop.bmp",
		spd = 15,
		r = 255,
		g = 80,
		b = 80,
		blend = 1,
		h = 15,
		wd = 8,
		range = 300,
		energy = 25,
		refire = 800,
		sfx = "space/lcannon.wav",
		class = "laser",
	},
	[22] = {
		name = "Cheat Cannon",
		desc = "Hax0r admin laz0r.",
		lvl = 1,
		dmg = 100500,
		img = "gfx/sprites/raindrop.bmp",
		spd = 100,
		r = 255,
		g = 80,
		b = 80,
		blend = 1,
		h = 15,
		wd = 8,
		range = 800,
		energy = 1,
		refire = 100,
		sfx = "space/photon.wav",
		class = "laser",
	},
	[23] = {
		name = "VIP Cannon Mk I",
		desc = "4lm0s7-h4x0r V1P l4z0r.",
		lvl = 9,
		dmg = 1000,
		img = "gfx/sprites/raindrop.bmp",
		spd = 7,
		r = 255,
		g = 80,
		b = 80,
		blend = 1,
		h = 15,
		wd = 8,
		range = 800,
		energy = 100,
		refire = 1000,
		sfx = "space/mcannon.wav",
		class = "laser",
	},
	[24] = {
		name = "VIP Cannon Mk II",
		desc = "4lm0s7-h4x0r V1P l4z0r. 1mpr0v3d.",
		lvl = 10,
		dmg = 2000,
		img = "gfx/sprites/raindrop.bmp",
		spd = 6,
		r = 255,
		g = 40,
		b = 40,
		blend = 1,
		h = 15,
		wd = 8,
		range = 800,
		energy = 150,
		refire = 1200,
		sfx = "space/mcannon.wav",
		class = "laser",
	},
}

msPrice = 1500000
emSlotPrice = 350000
msConfig = {7,8,8,8,8,8,8}
spawnPos = {8,8}
administrators = {7749,18582,79279}

dofile("sys/lua/space_rpg/main.lua")