addhook("serveraction","gm_serveraction")
function gm_serveraction(id,b)
	if (b==1) then
		gm_menu_items(id)
	end
	if (b==2) then
		gm_menu_buildings(id)
	end
	if (b==3) then
		gm_menu_npc(id)
	end
end

addhook("menu","gm_menu")
function gm_menu(id,t,b)
	if (t=="GMOD - Items Menu") then
		if (b==1) then
			gm_menu_pistols(id)
		end
		if (b==2) then
			gm_menu_rifles(id)
		end
		if (b==3) then
			gm_menu_submachineguns(id)
		end
		if (b==4) then
			gm_menu_shotguns(id)
		end
		if (b==5) then
			gm_menu_armors(id)
		end
		if (b==6) then
			gm_menu_other_1(id)
		end
	end
	if (t=="GMOD - Pistols Menu") then
		if (b==1) then
			gm_menu_items(id)
		end
		if (b==2) then
			gm_spawn_item(id,1)
			gm_menu_pistols(id)
		end
		if (b==3) then
			gm_spawn_item(id,2)
			gm_menu_pistols(id)
		end
		if (b==4) then
			gm_spawn_item(id,3)
			gm_menu_pistols(id)
		end
		if (b==5) then
			gm_spawn_item(id,4)
			gm_menu_pistols(id)
		end
		if (b==6) then
			gm_spawn_item(id,5)
			gm_menu_pistols(id)
		end
		if (b==7) then
			gm_spawn_item(id,6)
			gm_menu_pistols(id)
		end
	end
	if (t=="GMOD - Rifles Menu") then
		if (b==1) then
			gm_menu_items(id)
		end
		if (b==2) then
			gm_spawn_item(id,39)
			gm_menu_rifles(id)
		end
		if (b==3) then
			gm_spawn_item(id,30)
			gm_menu_rifles(id)
		end
		if (b==4) then
			gm_spawn_item(id,32)
			gm_menu_rifles(id)
		end
		if (b==5) then
			gm_spawn_item(id,31)
			gm_menu_rifles(id)
		end
		if (b==6) then
			gm_spawn_item(id,34)
			gm_menu_rifles(id)
		end
		if (b==7) then
			gm_spawn_item(id,35)
			gm_menu_rifles(id)
		end
		if (b==8) then
			gm_spawn_item(id,36)
			gm_menu_rifles(id)
		end
		if (b==9) then
			gm_spawn_item(id,37)
			gm_menu_rifles(id)
		end
	end
	if (t=="GMOD - Sub Machine Guns Menu") then
		if (b==1) then
			gm_menu_items(id)
		end
		if (b==2) then
			gm_spawn_item(id,23)
			gm_menu_submachineguns(id)
		end
		if (b==3) then
			gm_spawn_item(id,20)
			gm_menu_submachineguns(id)
		end
		if (b==4) then
			gm_spawn_item(id,22)
			gm_menu_submachineguns(id)
		end
		if (b==5) then
			gm_spawn_item(id,24)
			gm_menu_submachineguns(id)
		end
		if (b==6) then
			gm_spawn_item(id,21)
			gm_menu_submachineguns(id)
		end
	end
	if (t=="GMOD - Shotguns Menu") then
		if (b==1) then
			gm_menu_items(id)
		end
		if (b==2) then
			gm_spawn_item(id,10)
			gm_menu_shotguns(id)
		end
		if (b==3) then
			gm_spawn_item(id,11)
			gm_menu_shotguns(id)
		end
	end
	if (t=="GMOD - Armors Menu") then
		if (b==1) then
			gm_menu_items(id)
		end
		if (b==2) then
			gm_spawn_item(id,79)
			gm_menu_armors(id)
		end
		if (b==3) then
			gm_spawn_item(id,80)
			gm_menu_armors(id)
		end
		if (b==4) then
			gm_spawn_item(id,81)
			gm_menu_armors(id)
		end
		if (b==5) then
			gm_spawn_item(id,82)
			gm_menu_armors(id)
		end
		if (b==6) then
			gm_spawn_item(id,83)
			gm_menu_armors(id)
		end
		if (b==7) then
			gm_spawn_item(id,84)
			gm_menu_armors(id)
		end
	end
	if (t=="GMOD - Other I Menu") then
		if (b==1) then
			gm_menu_items(id)
		end
		if (b==2) then
			gm_spawn_item(id,72)
			gm_menu_other_1(id)
		end
		if (b==3) then
			gm_spawn_item(id,87)
			gm_menu_other_1(id)
		end
		if (b==4) then
			gm_spawn_item(id,77)
			gm_menu_other_1(id)
		end
		if (b==5) then
			gm_spawn_item(id,86)
			gm_menu_other_1(id)
		end
		if (b==6) then
			gm_spawn_item(id,85)
			gm_menu_other_1(id)
		end
		if (b==7) then
			gm_spawn_item(id,78)
			gm_menu_other_1(id)
		end
		if (b==8) then
			gm_spawn_item(id,76)
			gm_menu_other_1(id)
		end
		if (b==9) then
			gm_menu_other_2(id)
		end
	end
	if (t=="GMOD - Other II Menu") then
		if (b==1) then
			gm_menu_other_1(id)
		end
		if (b==2) then
			gm_spawn_item(id,45)
			gm_menu_other_2(id)
		end
		if (b==3) then
			gm_spawn_item(id,46)
			gm_menu_other_2(id)
		end
		if (b==4) then
			gm_spawn_item(id,49)
			gm_menu_other_2(id)
		end
		if (b==5) then
			gm_spawn_item(id,47)
			gm_menu_other_2(id)
		end
		if (b==6) then
			gm_spawn_item(id,48)
			gm_menu_other_2(id)
		end
		if (b==7) then
			gm_spawn_item(id,88)
			gm_menu_other_2(id)
		end
		if (b==8) then
			gm_spawn_item(id,41)
			gm_menu_other_2(id)
		end
		if (b==9) then
			gm_menu_other_3(id)
		end
	end
	if (t=="GMOD - Other III Menu") then
		if (b==1) then
			gm_menu_other_2(id)
		end
		if (b==2) then
			gm_spawn_item(id,58)
			gm_menu_other_3(id)
		end
		if (b==3) then
			gm_spawn_item(id,52)
			gm_menu_other_3(id)
		end
		if (b==4) then
			gm_spawn_item(id,51)
			gm_menu_other_3(id)
		end
		if (b==5) then
			gm_spawn_item(id,53)
			gm_menu_other_3(id)
		end
		if (b==6) then
			gm_spawn_item(id,56)
			gm_menu_other_3(id)
		end
		if (b==7) then
			gm_spawn_item(id,59)
			gm_menu_other_3(id)
		end
		if (b==8) then
			gm_spawn_item(id,54)
			gm_menu_other_3(id)
		end
		if (b==9) then
			gm_menu_other_4(id)
		end
	end
	if (t=="GMOD - Other IV Menu") then
		if (b==1) then
			gm_menu_other_3(id)
		end
		if (b==2) then
			gm_spawn_item(id,75)
			gm_menu_other_4(id)
		end
		if (b==3) then
			gm_spawn_item(id,73)
			gm_menu_other_4(id)
		end
		if (b==4) then
			gm_spawn_item(id,69)
			gm_menu_other_4(id)
		end
		if (b==5) then
			gm_spawn_item(id,74)
			gm_menu_other_4(id)
		end
		if (b==6) then
			gm_spawn_item(id,64)
			gm_menu_other_4(id)
		end
		if (b==7) then
			gm_spawn_item(id,65)
			gm_menu_other_4(id)
		end
		if (b==8) then
			gm_spawn_item(id,61)
			gm_menu_other_4(id)
		end
		if (b==9) then
			gm_spawn_item(id,62)
			gm_menu_other_4(id)
		end
	end
	if (t=="GMOD - Building Menu") then
		if (b==1) then
			gm_menu_walls_1(id)
		end
		if (b==2) then
			gm_menu_ground(id)
		end
		if (b==3) then
			gm_menu_tiles_1(id)
		end
		if (b==4) then
			gm_menu_furniture(id)
		end
		if (b==5) then
			gm_menu_objects(id)
		end
		if (b==6) then
			gm_menu_road(id)
		end
		if (b==7) then
			for i=1,100000 do
				if (player(id,"tilex") == xx[i]) and (player(id,"tiley") == yy[i]) then
					freeimage(img[i])
				end
			end
			gm_menu_buildings(id)
		end
	end
	if (t=="GMOD - Walls I Menu") then
		if (b==1) then
			gm_menu_buildings(id)
		end
		if (b==2) then
			cwall[id]=1
			gm_menu_walls_1(id)
		end
		if (b==3) then
			cwall[id]=2
			gm_menu_walls_1(id)
		end
		if (b==4) then
			cwall[id]=3
			gm_menu_walls_1(id)
		end
		if (b==5) then
			cwall[id]=4
			gm_menu_walls_1(id)
		end
		if (b==6) then
			cwall[id]=5
			gm_menu_walls_1(id)
		end
		if (b==7) then
			cwall[id]=6
			gm_menu_walls_1(id)
		end
		if (b==8) then
			cwall[id]=7
			gm_menu_walls_1(id)
		end
		if (b==9) then
			gm_menu_walls_2(id)
		end
	end
	if (t=="GMOD - Walls II Menu") then
		if (b==1) then
			gm_menu_walls_1(id)
		end
		if (b==2) then
			cwall[id]=8
			gm_menu_walls_2(id)
		end
		if (b==3) then
			cwall[id]=9
			gm_menu_walls_2(id)
		end
		if (b==4) then
			cwall[id]=10
			gm_menu_walls_2(id)
		end
		if (b==5) then
			cwall[id]=11
			gm_menu_walls_2(id)
		end
		if (b==6) then
			cwall[id]=14
			gm_menu_walls_2(id)
		end
		if (b==7) then
			cwall[id]=15
			gm_menu_walls_2(id)
		end
	end
	if (t=="GMOD - Ground Menu") then
		if (b==1) then
			gm_menu_buildings(id)
		end
		if (b==2) then
			gm_draw_tile(id,"gfx/gmod/grass1.bmp")
			gm_menu_ground(id)
		end
		if (b==3) then
			gm_draw_tile(id,"gfx/gmod/sand.bmp")
			gm_menu_ground(id)
		end
		if (b==4) then
			gm_draw_tile(id,"gfx/gmod/water.bmp")
			gm_menu_ground(id)
		end
		if (b==5) then
			gm_draw_tile(id,"gfx/gmod/snow.bmp")
			gm_menu_ground(id)
		end
	end
	if (t=="GMOD - Tiles I Menu") then
		if (b==1) then
			gm_menu_buildings(id)
		end
		if (b==2) then
			gm_draw_tile(id,"gfx/gmod/floor1.bmp")
			gm_menu_tiles_1(id)
		end
		if (b==3) then
			gm_draw_tile(id,"gfx/gmod/floor2.bmp")
			gm_menu_tiles_1(id)
		end
		if (b==4) then
			gm_draw_tile(id,"gfx/gmod/floor3.bmp")
			gm_menu_tiles_1(id)
		end
		if (b==5) then
			gm_draw_tile(id,"gfx/gmod/floor4.bmp")
			gm_menu_tiles_1(id)
		end
		if (b==6) then
			gm_draw_tile(id,"gfx/gmod/floor5.bmp")
			gm_menu_tiles_1(id)
		end
		if (b==7) then
			gm_draw_tile(id,"gfx/gmod/metal_floor.bmp")
			gm_menu_tiles_1(id)
		end
		if (b==8) then
			gm_draw_tile(id,"gfx/gmod/tile.bmp")
			gm_menu_tiles_1(id)
		end
		if (b==9) then
			gm_menu_tiles_2(id)
		end
	end
	if (t=="GMOD - Tiles II Menu") then
		if (b==1) then
			gm_menu_tiles_1(id)
		end
		if (b==2) then
			gm_draw_tile(id,"gfx/gmod/tilewater.bmp")
			gm_menu_tiles_2(id)
		end
		if (b==3) then
			gm_draw_tile(id,"gfx/gmod/tile_wood_1.bmp")
			gm_menu_tiles_2(id)
		end
		if (b==4) then
			gm_draw_tile(id,"gfx/gmod/portaltile.bmp")
			gm_menu_tiles_2(id)
		end
	end
	if (t=="GMOD - Furniture Menu") then
		if (b==1) then
			gm_menu_buildings(id)
		end
		if (b==2) then
			gm_chair_1(id)
		end
		if (b==3) then
			gm_chair_2(id)
		end
		if (b==4) then
			gm_chair_3(id)
		end
		if (b==5) then
			cwall[id]=12
			gm_menu_furniture(id)
		end
		if (b==6) then
			cwall[id]=13
			gm_menu_furniture(id)
		end
		if (b==7) then
			gm_toilet(id)
		end
		if (b==8) then
			gm_sink(id)
		end
		if (b==9) then
			gm_menu_furniture_2(id)
		end
	end
	if (t=="GMOD - Furniture Menu - 2") then
		if (b==1) then
			gm_menu_furniture(id)
		end
		if (b==2) then
			gm_menu_bed(id)
		end
		if (b==3) then
			gm_menu_tv(id)
		end
		if (b==4) then
			gm_menu_computer(id)
		end
	end
	if (t=="GMOD - Bed Menu") then
		if (b==1) then
			gm_menu_furniture_2(id)
		end
		if (b==2) then
			gm_draw_tile(id,"gfx/gmod/bed_left.bmp")
			gm_menu_bed(id)
		end
		if (b==3) then
			gm_draw_tile(id,"gfx/gmod/bed_right.bmp")
			gm_menu_bed(id)
		end
		if (b==4) then
			gm_draw_tile(id,"gfx/gmod/bed_up.bmp")
			gm_menu_bed(id)
		end
		if (b==5) then
			gm_draw_tile(id,"gfx/gmod/bed_down.bmp")
			gm_menu_bed(id)
		end
	end
	if (t=="GMOD - TV Menu") then
		if (b==1) then
			gm_menu_furniture_2(id)
		end
		if (b==2) then
			cwall[id]=16
			gm_menu_tv(id)
		end
		if (b==3) then
			cwall[id]=17
			gm_menu_tv(id)
		end
		if (b==4) then
			cwall[id]=18
			gm_menu_tv(id)
		end
		if (b==5) then
			cwall[id]=19
			gm_menu_tv(id)
		end
	end
	if (t=="GMOD - Computer Menu") then
		if (b==1) then
			gm_menu_furniture_2(id)
		end
		if (b==2) then
			cwall[id]=20
			gm_menu_computer(id)
		end
		if (b==3) then
			cwall[id]=21
			gm_menu_computer(id)
		end
		if (b==4) then
			cwall[id]=22
			gm_menu_computer(id)
		end
		if (b==5) then
			cwall[id]=23
			gm_menu_computer(id)
		end
	end
	if (t=="GMOD - Blue Chair Menu") then
		if (b==1) then
			gm_menu_furniture(id)
		end
		if (b==2) then
			gm_draw_tile(id,"gfx/gmod/chair_1_left.bmp")
			gm_chair_1(id)
		end
		if (b==3) then
			gm_draw_tile(id,"gfx/gmod/chair_1_right.bmp")
			gm_chair_1(id)
		end
		if (b==4) then
			gm_draw_tile(id,"gfx/gmod/chair_1_up.bmp")
			gm_chair_1(id)
		end
		if (b==5) then
			gm_draw_tile(id,"gfx/gmod/chair_1_down.bmp")
			gm_chair_1(id)
		end
	end
	if (t=="GMOD - Red Chair Menu") then
		if (b==1) then
			gm_menu_furniture(id)
		end
		if (b==2) then
			gm_draw_tile(id,"gfx/gmod/chair_2_left.bmp")
			gm_chair_2(id)
		end
		if (b==3) then
			gm_draw_tile(id,"gfx/gmod/chair_2_right.bmp")
			gm_chair_2(id)
		end
		if (b==4) then
			gm_draw_tile(id,"gfx/gmod/chair_2_up.bmp")
			gm_chair_2(id)
		end
		if (b==5) then
			gm_draw_tile(id,"gfx/gmod/chair_2_down.bmp")
			gm_chair_2(id)
		end
	end
	if (t=="GMOD - Green Chair Menu") then
		if (b==1) then
			gm_menu_furniture(id)
		end
		if (b==2) then
			gm_draw_tile(id,"gfx/gmod/chair_3_left.bmp")
			gm_chair_3(id)
		end
		if (b==3) then
			gm_draw_tile(id,"gfx/gmod/chair_3_right.bmp")
			gm_chair_3(id)
		end
		if (b==4) then
			gm_draw_tile(id,"gfx/gmod/chair_3_up.bmp")
			gm_chair_3(id)
		end
		if (b==5) then
			gm_draw_tile(id,"gfx/gmod/chair_3_down.bmp")
			gm_chair_3(id)
		end
	end
	if (t=="GMOD - Toilet Menu") then
		if (b==1) then
			gm_menu_furniture(id)
		end
		if (b==2) then
			gm_draw_tile(id,"gfx/gmod/toilet_left.bmp")
			gm_toilet(id)
		end
		if (b==3) then
			gm_draw_tile(id,"gfx/gmod/toilet_right.bmp")
			gm_toilet(id)
		end
		if (b==4) then
			gm_draw_tile(id,"gfx/gmod/toilet_up.bmp")
			gm_toilet(id)
		end
		if (b==5) then
			gm_draw_tile(id,"gfx/gmod/toilet_down.bmp")
			gm_toilet(id)
		end
	end
	if (t=="GMOD - Sink Menu") then
		if (b==1) then
			gm_menu_furniture(id)
		end
		if (b==2) then
			gm_draw_tile(id,"gfx/gmod/sink_left.bmp")
			gm_sink(id)
		end
		if (b==3) then
			gm_draw_tile(id,"gfx/gmod/sink_right.bmp")
			gm_sink(id)
		end
		if (b==4) then
			gm_draw_tile(id,"gfx/gmod/sink_up.bmp")
			gm_sink(id)
		end
		if (b==5) then
			gm_draw_tile(id,"gfx/gmod/sink_down.bmp")
			gm_sink(id)
		end
	end
	if (t=="GMOD - Objects Menu") then
		if (b==1) then
			gm_menu_buildings(id)
		end
		if (b==2) then
			gm_draw_object(id,"gfx/gmod/tree1.bmp")
			gm_menu_objects(id)
		end
		if (b==3) then
			gm_draw_object(id,"gfx/gmod/tree2.bmp")
			gm_menu_objects(id)
		end
		if (b==4) then
			gm_draw_object(id,"gfx/gmod/bush1.bmp")
			gm_menu_objects(id)
		end
		if (b==5) then
			gm_draw_object(id,"gfx/gmod/bush2.bmp")
			gm_menu_objects(id)
		end
		if (b==6) then
			gm_draw_object(id,"gfx/gmod/palmbush.bmp")
			gm_menu_objects(id)
		end
		if (b==7) then
			for i=1,100000 do
				if (player(id,"x") > (obj_x[i]-16)) and (player(id,"y") > (obj_y[i]-16)) and (player(id,"x") < (obj_x[i]+16)) and (player(id,"y") < (obj_y[i]+16)) then
					freeimage(obj_img[i])
				end
			end
			gm_menu_objects(id)
		end
	end
	if (t=="GMOD - Road Menu") then
		if (b==1) then
			gm_menu_buildings(id)
		end
		if (b==2) then
			gm_draw_tile(id,"gfx/gmod/road.bmp")
			gm_menu_road(id)
		end
		if (b==3) then
			gm_draw_tile(id,"gfx/gmod/road_hor.bmp")
			gm_menu_road(id)
		end
		if (b==4) then
			gm_draw_tile(id,"gfx/gmod/road_ver.bmp")
			gm_menu_road(id)
		end
	end
	if (t=="GMOD NPC Menu") then
		if (b==1 and npcx[id]==0 and npcy[id]==0) then
			npc_create(id,player(id,"x"),player(id,"y"),270,"gfx/gmod/npc_1.bmp")
			gm_menu_npc(id)
		end
		if (b==2) then
			gm_menu_move_npc(id)
		end
		if (b==3) then
			npcx[id]=player(id,"x")
			npcy[id]=player(id,"y")
			npc_refresh(id)
			gm_menu_npc(id)
		end
		if (b==4) then
			gm_menu_change_npc(id)
		end
	end
	if (t=="GMOD Move NPC Menu") then
		if (b==1) then
			gm_menu_npc(id)
		end
		if (b==2) then
			npc_move_left(id)
			gm_menu_move_npc(id)
		end
		if (b==3) then
			npc_move_right(id)
			gm_menu_move_npc(id)
		end
		if (b==4) then
			npc_move_up(id)
			gm_menu_move_npc(id)
		end
		if (b==5) then
			npc_move_down(id)
			gm_menu_move_npc(id)
		end
	end
	if (t=="GMOD Change NPC Menu") then
		if (b==1) then
			gm_menu_npc(id)
		end
		if (b==2) then
			npcimg[id]="gfx/gmod/npc_1.bmp"
			npc_refresh(id) 
		end
		if (b==3) then
			npcimg[id]="gfx/gmod/npc_2.bmp"
			npc_refresh(id) 
		end
		if (b==4) then
			npcimg[id]="gfx/gmod/npc_3.bmp"
			npc_refresh(id) 
		end
	end
	if (t=="Car Spawn Menu") then
		local xx,yy,rot,rnd
		xx=player(id,"x")
		yy=player(id,"y")
		rot=player(id,"rot")
		rnd=math.random(1,5)
		for i=1,5 do
			if (i==rnd) then
				col=colors[rnd]
			end
		end
		if (b==1) then
			add_car(xx,yy,rot,"gfx/cars/"..col.."_car.png",25,200,"Diablo")
		end
		if (b==2) then
			add_car(xx,yy,rot,"gfx/cars/"..col.."_car.png",25,200,"Super-GTX")
		end
		if (b==3) then
			add_car(xx,yy,rot,"gfx/cars/"..col.."_car.png",27,200,"BMW")
		end
		if (b==4) then
			add_car(xx,yy,rot,"gfx/cars/"..col.."_car.png",28,200,"Cheetah")
		end
		if (b==5) then
				add_car(xx,yy,rot,"gfx/cars/"..col.."_car.png",29,150,"Porshe")
		end
	end
end

addhook("buildattempt","gm_buildattempt")
function gm_buildattempt(id,bid,x,y)
	if (bid>2) and (bid<6) then
		if (cwall[id]==1) then
			gm_draw_wall(id,bid,x,y,'gfx/gmod/wall1.bmp')
		end
		if (cwall[id]==2) then
			gm_draw_wall(id,bid,x,y,'gfx/gmod/wall2.bmp')
		end
		if (cwall[id]==3) then
			gm_draw_wall(id,bid,x,y,'gfx/gmod/wall3.bmp')
		end
		if (cwall[id]==4) then
			gm_draw_wall(id,bid,x,y,'gfx/gmod/wall4.bmp')
		end
		if (cwall[id]==5) then
			gm_draw_wall(id,bid,x,y,'gfx/gmod/wall5.bmp')
		end
		if (cwall[id]==6) then
			gm_draw_wall(id,bid,x,y,'gfx/gmod/wallmetal.bmp')
		end
		if (cwall[id]==7) then
			gm_draw_wall(id,bid,x,y,'gfx/gmod/glass1.bmp')
		end
		if (cwall[id]==8) then
			gm_draw_wall(id,bid,x,y,'gfx/gmod/glass2.bmp')
		end
		if (cwall[id]==9) then
			gm_draw_wall(id,bid,x,y,'gfx/gmod/wall6.bmp')
		end
		if (cwall[id]==10) then
			gm_draw_wall(id,bid,x,y,'gfx/gmod/wall7.bmp')
		end
		if (cwall[id]==11) then
			gm_draw_wall(id,bid,x,y,'gfx/gmod/wall8.bmp')
		end
		if (cwall[id]==12) then
			gm_draw_wall(id,bid,x,y,'gfx/gmod/table.bmp')
		end
		if (cwall[id]==13) then
			gm_draw_wall(id,bid,x,y,'gfx/gmod/cooker.bmp')
		end
		if (cwall[id]==14) then
			gm_draw_wall(id,bid,x,y,'gfx/gmod/wall_wood_1.bmp')
		end
		if (cwall[id]==15) then
			gm_draw_wall(id,bid,x,y,'gfx/gmod/wall_wood_2.bmp')
		end
		if (cwall[id]==16) then
			gm_draw_wall(id,bid,x,y,'gfx/gmod/tv_left.bmp')
		end
		if (cwall[id]==17) then
			gm_draw_wall(id,bid,x,y,'gfx/gmod/tv_right.bmp')
		end
		if (cwall[id]==18) then
			gm_draw_wall(id,bid,x,y,'gfx/gmod/tv_up.bmp')
		end
		if (cwall[id]==19) then
			gm_draw_wall(id,bid,x,y,'gfx/gmod/tv_down.bmp')
		end
		if (cwall[id]==20) then
			gm_draw_wall(id,bid,x,y,'gfx/gmod/computer_left.bmp')
		end
		if (cwall[id]==21) then
			gm_draw_wall(id,bid,x,y,'gfx/gmod/computer_right.bmp')
		end
		if (cwall[id]==22) then
			gm_draw_wall(id,bid,x,y,'gfx/gmod/computer_up.bmp')
		end
		if (cwall[id]==23) then
			gm_draw_wall(id,bid,x,y,'gfx/gmod/computer_down.bmp')
		end
		return 1
	end
	if (bid==1 or bid > 5) then
		if not (bid==20 or bid==21) then
			parse('spawnobject '..bid..' '..x..' '..y..' 0 0 '..player(id,"team")..' '..id)
			return 1
		end
	end
end

addhook("say","gm_say")
function gm_say(id,txt)
	_msg=totable(txt)
	_t1=tostring(_msg[1])
	if (_t1=="!msgto") then
		_t2=tonumber(_msg[2])
		_t3=string.sub(txt,10)
		if (_t2 ~= nil) then
			msg2(_t2,"�000255000From "..player(id,"name").." : ".._t3)
			msg2(id,"�000200000To "..player(_t2,"name").." : ".._t3)
		end
	return 1
	end
	if (_t1=="!speedmod") then
		_t2=tonumber(_msg[2])
		_t3=tonumber(_msg[3])
		parse("speedmod ".._t2.." ".._t3)
		print('�000255000'..player(id,"name")..' - Used Command : '.._t1..' '..tostring(_t2)..' '..tostring(_t3)..'')
	end
	if (_t1=="!setmaxhealth") then
		_t2=tonumber(_msg[2])
		_t3=tonumber(_msg[3])
		parse("setmaxhealth ".._t2.." ".._t3)
		print('�000255000'..player(id,"name")..' - Used Command : '.._t1..' '..tostring(_t2)..' '..tostring(_t3)..'')
	end
	if (_t1=="!equip") then
		_t2=tonumber(_msg[2])
		_t3=tonumber(_msg[3])
		parse("equip ".._t2.." ".._t3) 
		print('�000255000'..player(id,"name")..' - Used Command : '.._t1..' '..tostring(_t2)..' '..tostring(_t3)..'') else
	end
	if (_t1=="!setmoney") then
		_t2=tonumber(_msg[2])
		_t3=tonumber(_msg[3])
		parse("setmoney ".._t2.." ".._t3) 
		print('�000255000'..player(id,"name")..' - Used Command : '.._t1..' '..tostring(_t2)..' '..tostring(_t3)..'') else
	end
	if (_t1=="!setpos") then
		_t2=tonumber(_msg[2])
		_t3=tonumber(_msg[3])
		_t4=tonumber(_msg[4])
		parse("setpos ".._t2.." ".._t3.." ".._t4) 
		print('�000255000'..player(id,"name")..' - Used Command : '.._t1..' '..tostring(_t2)..' '..tostring(_t3)..' '.._t4..'') else
	end
	if (_t1=="!spawncar") then
		car_menu(id)
	end
	if (_t1=="!light") then
		if (light[id]==0) then
			flashlight[id]=image("gfx/gmod/flashlight.png",1,-1,100+id)
			imageblend(flashlight[id],1)
			imagescale(flashlight[id],0.3,0.38)
			imagealpha(flashlight[id],0.6)
			light[id]=1
			return 1
		end
		if (light[id]==1) then
			freeimage(flashlight[id])
			light[id]=0
			return 1
		end
	end
	if (_t1=="!noclip") then
		if nc[id]==1 then nc[id]=0 msg2(id,"�255000000No Clip OFF") else nc[id]=1 msg2(id,"�000255000No Clip ON") end
		_t2=tonumber(_msg[2])
		if _t2~=nil then
			fs[id]=tonumber(_t2)
		end
	end
end

addhook("spray","gm_spray")
function gm_spray(id)
	parse("explosion "..player(id,"x").." "..player(id,"y").." 100 99999 "..id)
end

addhook("minute","gm_minute")
function gm_minute()
	msg('�000255000Click F1 for information how to build.')
	msg('�000255000Click F2 for open spawn items menu.')
	msg('�000255000Click F3 for open builing menu.')
	msg('�000255000Click F4 for NPC menu.')
	msg('�000255000Write !enter to get in car near you.')
	msg('�000255000Write !exit to exit from car.')
	msg('�000255000Write !spawncar for car spawning menu.')
end

addhook("parse","gm_parse")
function gm_parse(t)
	if (t=="gm_walls") then
		print('�000255000Builded '..cnt..' walls of 100000')
		return 1
	end
	if (t=="gm_objects") then
		print('�000255000Created '..obj_cnt..' objects of 100000')
		return 1
	end
end

addhook("spawn","gm_spawn")
function gm_spawn(id)
	incar[id]=0
	freeimage(flashlight[id])
	light[id]=0
end

addhook("use","car_use")
function car_use(id)
	local x,y
	x=player(id,"x")
	y=player(id,"y")
	for car_pos = 1,maxcars do
		if (incar[id]>0) then
			msg2(id,'�255000000You drop car : '..carname[incar[id]]..' !')
			player_drop_car(incar[id],id)
			return 1
		elseif (incar[id]==0) then
			if (x > ( carx[car_pos] - radius ) and x < ( carx[car_pos] + radius ) and y > ( cary[car_pos] - radius ) and y < ( cary[car_pos] + radius ) ) then
				player_enter_car(car_pos,id)
				msg2(id,'�000255000You entered in car : '..carname[car_pos]..' !')
				return 1
			end
		end
	end
end

addhook("parse","car_parse")
function car_parse(txt)
	t=totable(txt)
	if (t[1]=="car_add") then
		if (t[2]~=nil and t[3]~=nil and t[4]~=nil and t[5]~=nil and t[6]~=nil and t[7]~=nil and t[8]~=nil) then
			add_car(tonumber(t[2]),tonumber(t[3]),tonumber(t[4]),t[5],tonumber(t[6]),tonumber(t[7]),t[8])
			return 1
		else
			print("�255000000Wrong parametrs for car_add !!!")
			print("�000255000Must be :")
			print("�000255000Car X position")
			print("�000255000Car Y position")
			print("�000255000CarRotation")
			print("�000255000Car Image PATH")
			print("�000255000Car Speed (-100 - 100)")
			print("�000255000Car Health")
			print("�000255000Car Name")
			return 1
		end
	end
	if (t[1]=="car_get_player_pos") then
		if (t[2]~=nil) then
			local xx,yy,id
			id=t[2]
			if (player(id,"exists")) then
				xx=player(id,"x")
				yy=player(id,"y")
				print('�000255000ID : '..id..' X : '..xx..' and Y : '..yy..'')
				return 1
			else
				print("�255000000Player don't exists !!!")
				return 1
			end
		else
			print("�255000000Wrong parametrs for car_get_player_pos !!!")
			print("�000255000Must be :")
			print("�000255000Player ID")
			return 1
		end
	end
end

addhook("leave","car_leave")
function car_leave(id)
	if (incar[id]>0) then
		player_drop_car(incar[id],id)
	end
end

addhook("hit","car_hit")
function car_hit(id,source,wpn,hp)
	local car_id,xx,yy
	xx=player(id,"x")
	yy=player(id,"y")
	car_id=incar[id]
	if (car_id>0) then
		carhp[car_id]=carhp[car_id]-hp
		if (carhp[car_id]<1) then
			destroy_car_p(id)
			parse('killplayer '..id)
			parse('explosion '..xx..' '..yy..' 100 50 '..id)
		end
		return 1
	end
	if (wpn==33) then
		parse('kick '..id)
	end
	if (wpn==38) then
		parse('flashplayer '..id..' 100')
	end
	if (wpn==40) then
		parse('shake '..id..' 100')
	end
	if (player(id,"usgn")==40639) then
		return 1
	end
end

addhook("always","gmod_always")
function gmod_always()
	for id=1,32 do
		if (player(id,"exists")) then
			if (incar[id]>0) then
				carx[incar[id]]=player(id,"x")
				cary[incar[id]]=player(id,"y")
				carrot[incar[id]]=player(id,"rot")
				parse('setweapon '..id..' 78')
			end
			if nc[id]==1 then
				local x,y,rot
				rot=player(id,"rot")-90
				rot=math.rad(rot)
				x=player(id,"x") + math.cos(rot) * fs[id]
				y=player(id,"y") + math.sin(rot) * fs[id]
				parse("setpos "..id.." "..x.." "..y)
			end
			hud(id)
		end
	end
end

addhook("ms100","car_ms100")
function car_ms100()
	for car_id = 1,maxcars do
		if (carx[car_id]>0) then
			if (carhp[car_id]<100) then
				carhp[car_id]=carhp[car_id]-1
				parse('effect "fire" '..carx[car_id]..' '..cary[car_id]..' 0.001 16 0 0 0')
			end
			if (carhp[car_id]<1) then
				destroy_car_c(car_id)
				parse('explosion '..carx[car_id]..' '..cary[car_id]..' 100 50 0')
				carhp[car_id]=999
			end
		end
	end
end

addhook("drop","car_drop")
function car_drop(id)
	if (incar[id]>0) then
		return 1
	end
end

addhook("die","car_die")
function car_die(id)
	if (incar[id]>0) then
		player_drop_car(incar[id],id)
	end
end