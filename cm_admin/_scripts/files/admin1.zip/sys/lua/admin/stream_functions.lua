function ByteMax(count)
	return (256^count) - 1
end

function ReadBytes(s)
	local b = {}
	for i = 1, string.len(s) do
		table.insert(b, string.byte(s,i))
	end

	local n = 0
	for i = 1, #b do
		n = n + b[i] * (256 ^ (i-1))
	end
	return n
end

function WriteBytes(n,cnt)
	local i = 1
	local b = {n%256}
	local p = {n}

	while b[i] and p[i] ~= 0 do
		i = i + 1
		p[i] = (p[i-1] - b[i-1])/256
		b[i] = p[i]%256
	end

	local str = ""
	for i = 1, cnt do
		if i <= #b - 1 then
			str = str .. string.char(b[i])
		else
			str = str .. string.char(0)
		end
	end
	return str
end

TStream = {}

function TStream:Pos()
	return self.f:seek()
end

function TStream:Size()
	local pos = self.f:seek()
	local size = self.f:seek("end")
	self.f:seek("set", pos)
	return size
end

function TStream:Seek(pos)
	return self.f:seek("set", pos)
end

function TStream:Read(n)
	return self.f:read(n)
end

function TStream:Write(data)
	return self.f:write(data)
end

function TStream:Close()
	return self.f:close()
end

function ReadStream(dir)
	local f = io.open(dir, "r")
	if f then
		local stream = CreateStream()
		stream.f = f
		return stream
	end
end

function WriteStream(dir)
	local f = io.open(dir, "w")
	if f then
		local stream = CreateStream()
		stream.f = f
		return stream
	end
end

function TStream:ReadBytes(count)
	local s = self:Read(count)
	if s and string.len(s) <= count then return ReadBytes(s) end
end

function TStream:WriteBytes(n,count)
	if n > ByteMax(count) then
		return false
	end
	return self:Write(WriteBytes(n, count))
end

function TStream:SkipBytes(count)
	return self.f:seek("cur", count)
end

function ReadByte(stream)
	return stream:ReadBytes(1)
end

function WriteByte(stream,n)
	return stream:WriteBytes(n, 1)
end

function ReadShort(stream)
	return stream:ReadBytes(2)
end

function WriteShort(stream,n)
	return stream:WriteBytes(n, 2)
end

function ReadInt(stream)
	return stream:ReadBytes(4)
end

function WriteInt(stream,n)
	return stream:WriteBytes(n, 4)
end

function ReadLong(stream)
	return stream:ReadBytes(8)
end

function WriteLong(stream,n)
	return stream:WriteBytes(n, 8)
end

function ReadFloat(stream)
	return stream:ReadBytes(4)
end

function WriteFloat(stream,n)
	return stream:WriteBytes(n, 4)
end

function ReadDouble(stream)
	return stream:ReadBytes(8)
end

function WriteDouble(stream,n)
	return stream:WriteBytes(n, 8)
end

function ReadLine(stream)
	return stream:Read("*l")
end

function WriteLine(stream,str)
	return stream:Write(str..string.char(13)..string.char(10))
end

function ReadString(stream,length)
	return stream:Read(length)
end

function WriteString(stream,str)
	return stream:Write(str)
end

function Eof(stream)
	return stream:Pos() >= stream:Size()
end

function StreamPos(stream)
	return stream:Pos()
end

function StreamSize(stream)
	return stream:Size()
end

function SeekStream(stream,pos)
	return stream:Seek(pos)
end

function CloseStream(stream)
	if stream then
		return stream:Close()
	end
end

function CreateStream()
	return CopyTable(TStream)
end

function CreateBankStream()
	local stream = CreateStream()
	stream.f = io.tmpfile()
	return stream
end

if string.find(os.name(), "unix") then
	function ReadDir(dir,readFolders,readFiles)
		if readFolders == nil then readFolders = true end
		if readFiles == nil then readFiles = true end
		os.execute('ls -a1 "'..dir..'" > tmp')

		local dir_files = {}
		for f in io.lines("tmp") do
			if string.find(f, "<DIR>") then
				local file_name = string.sub(f, 37)
				local file_dir = dir.."/"..file_name

				if file_name ~= "." and file_name ~= ".." then
					if readFolders then table.insert(dir_files, file_dir) end
				end
			else
				local foundPrefix = string.find(f, "-")
				local isFile = foundPrefix and foundPrefix == 3
				if isFile then
					local file_name = string.sub(f, 37)
					local file_dir = dir.."/"..file_name
					if readFiles then table.insert(dir_files, file_dir) end
				end
			end
		end
		os.execute('rm tmp')
		return dir_files
	end
elseif string.find(os.name(), "windows") then
	function ReadDir(dir,readFolders,readFiles)
		if readFolders == nil then readFolders = true end
		if readFiles == nil then readFiles = true end
		local dir_files = {}

		if os.dirent and os.dir then
			if os.dirent(dir) then
				for entry in os.dir(dir) do
					if entry.type == "directory" then
						if readFolders then
							table.insert(dir_files, dir.."/"..entry.name)
						end
					elseif entry.type == "file" then
						if readFiles then
							table.insert(dir_files, dir.."/"..entry.name)
						end
					end
				end
			end
		else
			os.execute('dir "'..dir..'" > tmp')
			for f in io.lines("tmp") do
				if string.find(f, "<DIR>") then
					local file_name = string.sub(f, 37)
					local file_dir = dir.."/"..file_name

					if file_name ~= "." and file_name ~= ".." then
						if readFolders then table.insert(dir_files, file_dir) end
					end
				else
					local foundPrefix = string.find(f, "-")
					local isFile = foundPrefix and foundPrefix == 3
					if isFile then
						local file_name = string.sub(f, 37)
						local file_dir = dir.."/"..file_name
						if readFiles then table.insert(dir_files, file_dir) end
					end
				end
			end
			os.execute('del tmp')
		end
		return dir_files
	end
end
