stream_dll_loaded = true

function HTTPRequest(url,socket,skip)
	local socket = socket
	local s, pos = url:split("/")
	local host, port, file
	if s[1] == "http:" then
		local s2 = s[3]:split(":")
		host = s2[1]
		port = tonumber(s2[2]) or 80
		file = "/"..string.sub(url, pos[4])
	else
		local s2 = s[1]:split(":")
		host = s2[1]
		port = tonumber(s2[2]) or 80
		file = "/"..string.sub(url, pos[2])
	end

	if not socket then
		socket = OpenTCPStream(host, port)
	end

	if socket then
		WriteLine(socket, "GET "..file.." HTTP/1.1")
		WriteLine(socket, "Host: "..host)
		WriteLine(socket, "Connection: keep-alive")
		WriteLine(socket, "User-Agent: "..mod_name.." "..mod_version)
		WriteLine(socket, "Accept: text/html")
		WriteLine(socket, "")

		if not skip then
			local init = os.clock()
			while ReadAvail(socket) == 0 do
				if os.clock() - init >= 3 then
					CloseTCPStream(socket)
					return nil
				end
			end

			while ReadAvail(socket) > 0 do
				local l = ReadLine(socket)
				if string.len(l) == 0 then
					break
				end
			end
		end
		return socket
	end
end

if string.find(os.name(), "unix") then
	function ReadDir(dir,readFolders,readFiles)
		if readFolders == nil then readFolders = true end
		if readFiles == nil then readFiles = true end
		os.execute('ls -a1 "'..dir..'" > tmp')

		local dir_files = {}
		for f in io.lines("tmp") do
			if string.find(f, "<DIR>") then
				local file_name = string.sub(f, 37)
				local file_dir = dir.."/"..file_name

				if file_name ~= "." and file_name ~= ".." then
					if readFolders then table.insert(dir_files, file_dir) end
				end
			else
				local foundPrefix = string.find(f, "-")
				local isFile = foundPrefix and foundPrefix == 3
				if isFile then
					local file_name = string.sub(f, 37)
					local file_dir = dir.."/"..file_name
					if readFiles then table.insert(dir_files, file_dir) end
				end
			end
		end
		os.execute('rm tmp')
		return dir_files
	end
elseif string.find(os.name(), "windows") then
	function ReadDir(dir,readFolders,readFiles)
		if readFolders == nil then readFolders = true end
		if readFiles == nil then readFiles = true end
		os.execute('dir "'..dir..'" > tmp')

		local dir_files = {}
		for f in io.lines("tmp") do
			if string.find(f, "<DIR>") then
				local file_name = string.sub(f, 37)
				local file_dir = dir.."/"..file_name

				if file_name ~= "." and file_name ~= ".." then
					if readFolders then table.insert(dir_files, file_dir) end
				end
			else
				local foundPrefix = string.find(f, "-")
				local isFile = foundPrefix and foundPrefix == 3
				if isFile then
					local file_name = string.sub(f, 37)
					local file_dir = dir.."/"..file_name
					if readFiles then table.insert(dir_files, file_dir) end
				end
			end
		end
		os.execute('del tmp')
		return dir_files
	end
end
