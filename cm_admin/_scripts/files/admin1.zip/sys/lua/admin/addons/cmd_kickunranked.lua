CreateChat "@kickunranked" "" (26) [[
	for _, pid in pairs(player(0,"table")) do
		ServerMSG2(pid, Translate(pid, 127, PlayerName(id)))
	end
	for _, p in pairs(player(0,"table")) do
		if player(p,"usgn") == 0 then
			parse("kick "..p)
		end
	end
]]
