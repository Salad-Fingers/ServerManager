team_attachments = {}
addon_team_hook = addhook
addon_team_freehook = freehook

addhook("team","AM.Team")
function AM.Team(id,team)
	local r = 0
	for _, f in pairs(team_attachments) do
		local v = f(id, team)
		if v and v == 1 then
			r = v
		end
	end
	return r
end

function addhook(...)
	local arg = {...}
	if arg[1] and arg[2] then
		if arg[1] == "team" then
			local func = _G[arg[2]]
			if func then
				return CreateTeamAttachment(func)
			end
		end
	end
	return addon_team_hook(...)
end

function freehook(...)
	local arg = {...}
	if arg[1] and arg[2] then
		if arg[1] == "team" then
			local func = _G[arg[2]]
			if func then
				return RemoveTeamAttachment(func)
			end
		end
	end
	return addon_team_freehook(...)
end

function CreateTeamAttachment(f)
	table.insert(team_attachments, f)
end

function RemoveTeamAttachment(f)
	for id, at in pairs(team_attachments) do
		if at == f then
			team_attachments[id] = nil
			break
		end
	end
end
