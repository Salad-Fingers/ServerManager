CreateChat "!makespec" "<id>" (25) [[
	if args >= 2 then
		local p = tonumber(s[2])
		if p and player(p,"exists") then
			parse("makespec "..p)
			msg2(p, Translate(p, 130, PlayerName(id)))
		end
	end
]]
