tile_image = {}

function SetTileImage(x,y,id)
	if not tile_image[x] then tile_image[x] = {} end
	tile_image[x][y] = id
end

function DeleteTileImage(x,y)
	if not tile_image[x] then return nil end
	if tile_image[x][y] then
		freeimage(tile_image[x][y])
		tile_image[x][y] = nil
	end
	if #tile_image[x] == 0 then
		tile_image[x] = nil
	end
end

function mouse_tile_warn(id)
	msgc2(id, Translate(id, 36), 0, 255)
end

function spawn_tile_func(id,x,y)
	local tileid = USERTEMP[id]["tilespawnid"]
	if tileid then
		local tx = math.floor(x/32)
		local ty = math.floor(y/32)

		DeleteTileImage(tx, ty)

		local img = image("<tile:"..tileid..">", 0, 0, 0)
		if img then
			imagepos(img, tx*32, ty*32, 0)
			SetTileImage(tx, ty, img)
		end
	else
		ErrorMSG(id, Translate(id, 37))
	end
	USERTEMP[id]["mouseevent"] = nil
end
spawn_tile_event = CreateMouseEvent(spawn_tile_func)
CreateMouseFunc("Spawn Tile", spawn_tile_event, mouse_tile_warn, 30)

CreateChat "!tile" "<tile id>" (30) [[
	if args >= 2 then
		local tileid = tonumber(s[2])
		USERTEMP[id]["tilespawnid"] = tileid
	end
]]

addhook("startround_prespawn","CleanTileImage")
function CleanTileImage()
	tile_image = {}
end
