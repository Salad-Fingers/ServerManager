CreateChat "@disablecmd" "[command name]" (30) [[
	if args >= 2 then
		local command_name = s[2]

		if command_name == "@disablecmd" or command_name == "@enablecmd" then
			ErrorMSG(id, Translate(id, 107))
		elseif CHAT_CMD[command_name] and not SERVER_DATA["disabled_cmd"][command_name] then
			SERVER_DATA["disabled_cmd"][command_name] = true
			for _, pid in pairs(player(0,"table")) do
				ServerMSG2(pid, Translate(pid, 105, PlayerName(id), command_name))
			end
		end
	end
]]

CreateChat "@enablecmd" "[command name]" (30) [[
	if args >= 2 then
		local command_name = s[2]

		if CHAT_CMD[command_name] and SERVER_DATA["disabled_cmd"][command_name] then
			SERVER_DATA["disabled_cmd"][command_name] = nil
			for _, pid in pairs(player(0,"table")) do
				ServerMSG2(pid, Translate(pid, 106, PlayerName(id), command_name))
			end
		end
	end
]]

CreateChat "@disabledcmds" "" (30) [[
	local t = SERVER_DATA["disabled_cmd"]
	local i = 0
	for k, v in pairs(t) do
		i = i + 100
		AddTimer(i, false, msgc2, id, k, 0, 255)
	end
]]
