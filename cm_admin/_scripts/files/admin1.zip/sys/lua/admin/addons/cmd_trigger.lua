CreateChat "@trigger" "[trigger name]" (26) [[
	if args >= 2 then
		local trigger_name = string.sub(txt, pos[2])
		if string.len(trigger_name) > 0 then
			parse("trigger "..trigger_name)
		end
	end
]]