-- Mouse menu
mouse_action_key = 1
if ADDONSET["mouse_key"] then
	if ADDONSET["mouse_key"] == "F2" then
		mouse_action_key = 1
	elseif ADDONSET["mouse_key"] == "F3" then
		mouse_action_key = 2
	elseif ADDONSET["mouse_key"] == "F4" then
		mouse_action_key = 3
	end
end

mouse_menu = CreateMenu(339)
function mouse_menu:click(id,b)
	USERTEMP[id]["mousefunction"] = b
	if EXTRA_MOUSEFUNCTION[b] and EXTRA_MOUSEFUNCTION[b]["func"] then
		EXTRA_MOUSEFUNCTION[b]["func"](id)
	end
end

function mouse_menu:getcustombutton(b,id,d)
	if EXTRA_MOUSEFUNCTION[b] then
		if EXTRA_MOUSEFUNCTION[b].lvl and PlayerLevel(id) < EXTRA_MOUSEFUNCTION[b].lvl then
			return "("..EXTRA_MOUSEFUNCTION[b]["name"]
		end
		return EXTRA_MOUSEFUNCTION[b]["name"]
	end
end

AddMenu(mouse_menu, 15)

EXTRA_MOUSEFUNCTION = {}
EXTRA_MOUSEFUNCTION_COUNT = 1
function CreateMouseFunc(name,event,func,lvl)
	EXTRA_MOUSEFUNCTION[EXTRA_MOUSEFUNCTION_COUNT] = {name = name,func = func,event = event,lvl = lvl}
	EXTRA_MOUSEFUNCTION_COUNT = EXTRA_MOUSEFUNCTION_COUNT + 1
end

EXTRA_MOUSEEVENT = {}
EXTRA_MOUSEEVENT_COUNT = 1
function CreateMouseEvent(func)
	EXTRA_MOUSEEVENT_COUNT = EXTRA_MOUSEEVENT_COUNT + 1
	EXTRA_MOUSEEVENT[EXTRA_MOUSEEVENT_COUNT] = func
	return EXTRA_MOUSEEVENT_COUNT
end

addhook("serveraction","CallMouse")
function CallMouse(id,event)
	if event == mouse_action_key then
		local func = USERTEMP[id]["mousefunction"]
		if func then
			if EXTRA_MOUSEFUNCTION[func] then
				USERTEMP[id]["mouseevent"] = EXTRA_MOUSEFUNCTION[func]["event"]
			end
		end
	end
end

addhook("always","RequestMouse")
function RequestMouse()
	for _, id in pairs(player(0,"table")) do
		if USERTEMP[id]["mouseevent"] then
			reqcld(id, 2)
		end
	end
end

addhook("clientdata","ReceiveMouse")
function ReceiveMouse(id,mode,x,y)
	if not id or not mode or not x or not y then return end

	local event = USERTEMP[id]["mouseevent"]
	if event then
		if EXTRA_MOUSEEVENT[event] then
			EXTRA_MOUSEEVENT[event](id, x, y)
		end
	end
end
