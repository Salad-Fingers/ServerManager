CreateChat "@resetmap" "<delay>" (30) [[
	if args >= 2 then
		local delay = tonumber(s[2])
		if delay then
			for i = 0, delay-1 do
				AddTimer(i*1000, false, ServerMSG, "trans:155("..Color(255,0,0)..(delay - i)..Color(255,255,0)..")")
			end
			AddTimer(delay*1000, false, parse, "changemap "..map("name"))
		else
			ErrorMSG(id, Translate(id, 156))
		end
	else
		parse("changemap "..map("name"))
	end
]]
