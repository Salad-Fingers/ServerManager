__usgn_source = player
function player(...)
	local arg = {...}
	local id = arg[1]
	local value = arg[2]
	if not id or not value then return nil end
	if value == "usgn" then
		if player(id,"exists") then
			local name = USERTEMP[id]["log_name"]
			if name then
				if SERVER_DATA["reg_link_u"][name] then
					return SERVER_DATA["reg_link_u"][name]
				end
			end

			local u = __usgn_source(id, "usgn") or 0
			local ip = player(id,"ip")

			if u == 0 then
				local emulated_usgnid = USERIP[ip]["usgnid"]
				if emulated_usgnid and USGNDataExists(emulated_usgnid) then
					if USGN[emulated_usgnid]["game_ip"] == ip then
						u = emulated_usgn or 0
					end
				end
			end

			if u and u > 0 then
				if USERIP[ip]["usgnid"] ~= u then
					USERIP[ip]["usgnid"] = u
					SaveIPData(ip)
				end
			end
			return u or 0
		end
		return 0
	end
	return __usgn_source(...)
end
