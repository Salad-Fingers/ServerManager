CreateChat "!finduser" "[name/ip/usgn] <name/ip/usgn>" (25) [[
	if args >= 3 then
		local mode = s[2]
		local data = string.sub(txt, pos[3])
		if mode and string.len(data) > 0 then
			mode = string.lower(mode)

			local usgn_id
			local player_name
			local player_ip

			if mode == "name" then
				player_name = data

				for usgnid, u in pairs(USGN_DATA) do
					if u["game_name"] == player_name then
						usgn_id = usgnid
						player_ip = u["game_ip"]

						if player_ip then
							msgc2(id, "IP: "..player_ip)
							msgc2(id, "USGN: "..usgn_id)
							msgc2(id, Translate(id, 99)..": "..player_name)
						else
							msgc2(id, "USGN: "..usgn_id)
							msgc2(id, Translate(id, 99)..": "..player_name)
						end
						return nil
					end
				end

				for ipadr, ip in pairs(USERIP_DATA) do
					usgn_id = USERIP[ipadr]["usgnid"]
					if USGNDataExists(usgn_id) then
						if USGN[usgn_id]["game_name"] == player_name then
							player_ip = USGN[usgn_id]["game_ip"]
							if player_ip then
								msgc2(id, "IP: "..player_ip)
								msgc2(id, "USGN: "..usgn_id)
								msgc2(id, Translate(id, 99)..": "..player_name)
							else
								msgc2(id, "USGN: "..usgn_id)
								msgc2(id, Translate(id, 99)..": "..player_name)
							end
							return nil
						end
					end
				end

				return ErrorMSG(id, Translate(id, 111))
			elseif mode == "ip" then
				player_ip = data

				if IPDataExists(player_ip) then
					usgn_id = USERIP[player_ip]["usgnid"]
					if usgn_id then
						if USGNDataExists(usgn_id) then
							msgc2(id, "IP: "..player_ip)
							msgc2(id, "USGN: "..usgn_id)
							msgc2(id, Translate(id, 99)..": "..USGN[usgn_id]["game_name"])
						else
							msgc2(id, "IP: "..player_ip)
							msgc2(id, "USGN: "..usgn_id)
						end
					else
						return ErrorMSG(id, Translate(id, 111))
					end
				else
					return ErrorMSG(id, Translate(id, 111))
				end
			elseif mode == "usgn" then
				usgn_id = tonumber(data)
				if usgn_id then
					if USGNDataExists(usgn_id) then
						player_name = USGN[usgn_id]["game_name"]
						player_ip = USGN[usgn_id]["game_ip"]

						msgc2(id, "IP: "..player_ip)
						msgc2(id, "USGN: "..usgn_id)
						msgc2(id, Translate(id, 99)..": "..player_name)
					else
						return ErrorMSG(id, Translate(id, 111))
					end
				end
			else
				return ErrorMSG(id, Translate(id,112))
			end
		end
	end
]]
