function CopyObject(o)
	if type(o) == "table" then
		local t = {}
		for k, v in pairs(o) do
			t[k] = CopyObject(v)
		end
		return t
	elseif type(o) == "function" then
		local _o = ProtectedCall(string.dump, o)
		if _o then return loadstring(_o) end
	end
	return o
end

function Compare(x,y)
	if type(x) == "table" and type(y) == "table" then
		return table.compare(x,y)
	elseif type(x) == "function" and type(y) == "function" then
		return string.dump(x) == string.dump(Y)
	elseif type(x) == type(y) then
		return x == y
	end
end

function CopyTable(o)
	local new = {}
	for k, v in pairs(o) do
		if type(v) == "table" then
			new[k] = CopyTable(v)
		elseif type(v) == "function" then
			new[k] = loadstring(string.dump(v))
		else
			new[k] = v
		end
	end
	return new
end

function FileExists(dir)
	local f = io.open(dir)
	if f then
		f:close()
		return true
	end
end

function CopyBytes(fromStream,toStream,count)
	local data = ReadStream(fromStream, count)
	WriteString(toStream, data)
end

function CopyStream(streamA,streamB)
	if streamA and streamB then
		CopyBytes(streamA, streamB, StreamSize(streamA))
	end
end

function toboolean(x)
	local value = tostring(x)
	if value == "true" then
		return true
	elseif value == "false" then
		return false
	end
end
