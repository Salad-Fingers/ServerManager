CONSOLE_CMD = {}
CONSOLE_ATTACHMENTS = {}
addon_console_hook = addhook
addon_console_freehook = freehook

addhook("parse","AM.Console")
function AM.Console(txt)
	local s, sp = txt:split()
	local command_name = s[1]
	local command = CONSOLE_CMD[command_name]
	if command then
		return ProtectedCall(command, txt, s, sp, #s) or 2
	end

	local ret = 1
	for _, f in pairs(CONSOLE_ATTACHMENTS) do
		local v = f(txt)
		if v then
			if ret == 0 and v == 1 then
				ret = 1
			elseif v == 2 then
				ret = 2
			end
		end
	end
	return ret
end

function CreateConsole(name)
	return function (code)
		local f, e = loadstring("return function (txt,s,pos,args) "..code.."; end")
		if f then
			CONSOLE_CMD[name] = f()
		else
			error_get("CONSOLE CMD ERR ("..name.."): "..e)
		end
	end
end

function CreateConsoleAttachment(f)
	table.insert(CONSOLE_ATTACHMENTS, f)
end

function RemoveConsoleAttachment(f)
	for id, at in pairs(CONSOLE_ATTACHMENTS) do
		if at == f then
			CONSOLE_ATTACHMENTS[id] = nil
			break
		end
	end
end

function addhook(...)
	local arg = {...}
	if arg[1] and arg[2] then
		if arg[1] == "parse" then
			local func = _G[arg[2]]
			if func then
				return CreateConsoleAttachment(func)
			end
		end
	end
	return addon_console_hook(...)
end

function freehook(...)
	local arg = {...}
	if arg[1] and arg[2] then
		if arg[1] == "parse" then
			local func = _G[arg[2]]
			if func then
				return RemoveConsoleAttachment(func)
			end
		end
	end
	return addon_console_freehook(...)
end
