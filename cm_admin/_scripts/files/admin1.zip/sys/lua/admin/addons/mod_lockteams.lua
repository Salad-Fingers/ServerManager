lockteam_minlvl = 10

lockteams_menu = CreateMenu(363, "trans:214,trans:215,trans:216")
team_locked = {}

function lockteams_menu:getcustombutton(b,id,def)
	if def then
		if team_locked[b-1] then
			return def.."|"..Translate(id, 352)
		end
		return def.."|"..Translate(id, 353)
	end
end

function lockteams_menu:click(id,b,p)
	if b > 0 then
		if team_locked[b-1] then
			team_locked[b-1] = nil
		else
			team_locked[b-1] = true
		end
		lockteams_menu:OpenPlayer(id, p)
	end
end

function lockteam_switchteam(id,t)
	if team_locked[t] and PlayerLevel(id) < lockteam_minlvl then
		ErrorMSG(id, Translate(id, 217))
		return 1
	end
end
CreateTeamAttachment(lockteam_switchteam)

AddMenu(lockteams_menu, 30)
