SERVER_DATA["ranklist"] = SERVER_DATA["ranklist"] or {}

function RanklistExists(usgn)
	if usgn <= 0 then
		return false
	end
	if not RankExists(USGNRank(usgn)) then
		return false
	end
	if USGNLevel(usgn) == 0 then
		return false
	end
	return USGNRank(usgn) ~= DefaultRank()
end

function AddRanklist(usgn)
	if RanklistExists(usgn) and not SERVER_DATA["ranklist"][usgn] then
		SERVER_DATA["ranklist"][usgn] = true
		SaveServer()
	end
end

function getRanklistId(id)
	local i = 0
	for k, v in pairs(SERVER_DATA["ranklist"]) do
		if RanklistExists(k) then
			i = i + 1
			if i == id then
				return k
			end
		else
			SERVER_DATA["ranklist"][k] = nil
		end
	end
end

function getRanklistLevel(l)
	local rl = {}
	local l = l or 0
	for k, v in pairs(SERVER_DATA["ranklist"]) do
		if RanklistExists(k) then
			if USGNLevel(k) >= l then
				table.insert(rl, k)
			end
		else
			SERVER_DATA["ranklist"][k] = nil
		end
	end
	return rl
end

-- Check ranks
checkrank_menu = CreateMenu("342@b")
function checkrank_menu:getcustombutton(b,id,def)
	if b > 0 then
		local k = getRanklistId(b)
		if k then
			return (FixedName(USGN[k]["game_name"]) or "#"..k).."|Lvl. "..USGNLevel(k).." "..RankPrefix(USGNRank(k))
		end
	end
end

function checkrank_menu:click(id,b,p)
	if b > 0 then
		local k = getRanklistId(b)
		if k then
			USERTEMP[id]["ranklist_user"] = k
			checkrank_actions_menu:OpenPlayer(id, 1)
		end
	end
end

AddMenu(checkrank_menu, 30)

-- Action menu
checkrank_actions_menu = CreateMenu(343, "trans:340,trans:238,trans:239,trans:240,trans:241,trans:242,trans:243")
function checkrank_actions_menu:getcustombutton(b,id,def)
	local usgn = USERTEMP[id]["ranklist_user"]

	if b == 6 and def then
		if IPRangeBanned(USGN[usgn]["game_ip"]) then
			def = def.."|"..Translate(id, 244)
		else
			def = def.."|"..Translate(id, 245)
		end
	end

	if not RankLower(USGNRank(usgn), PlayerRank(id)) and def and b < 7 then
		return "("..def
	end
	return def
end

function checkrank_actions_menu:click(id,b,p)
	local usgn = USERTEMP[id]["ranklist_user"]

	if b > 0 and usgn and usgn > 0 then
		if not RankLower(USGNRank(usgn), PlayerRank(id)) then
			return ErrorMSG(id, Translate(id, 246))
		end

		if b == 1 then
			-- Set rank
			urank_optionmenu:OpenPlayer(id, 1)
		elseif b == 2 then
			-- Remove
			SetUSGNRank(usgn, DefaultRank())
			SERVER_DATA["ranklist"][usgn] = nil
			SaveUSGN(usgn)

			if PlayerLevel(id) >= 30 then
				checkrank_menu:OpenPlayer(id, 1)
			end

			USERTEMP[id]["ranklist_user"] = nil
		elseif b == 3 then
			if USGN[usgn]["game_name"] then
				parse('banname "'..USGN[usgn]["game_name"]..'"')
			end
			if USGN[usgn]["game_ip"] then
				parse('banip "'..USGN[usgn]["game_ip"]..'"')
			end
			parse("banusgn "..usgn)
		elseif b == 4 then
			if USGN[usgn]["game_name"] then
				parse('unban "'..USGN[usgn]["game_name"]..'"')
			end
			if USGN[usgn]["game_ip"] then
				parse('unban "'..USGN[usgn]["game_ip"]..'"')
			end
			parse("unban "..usgn)
		elseif b == 5 then
			ranklist_tempban_menu:OpenPlayer(id, 1)
		elseif b == 6 then
			if IPRangeBanned(USGN[usgn]["game_ip"]) then
				IPRangeUnban(USGN[usgn]["game_ip"])
			else
				IPRangeBan(USGN[usgn]["game_ip"])
			end
		elseif b == 7 then
			msg2(id, "--------------------------------------------")
			msgc2(id, Translate(id, 247)..": #"..usgn, 0, 255)
			msgc2(id, "IP: "..USGN[usgn]["game_ip"], 0, 255)
			msgc2(id, Translate(id, 248)..": "..USGN[usgn]["game_name"], 0, 255)
			if USGN[usgn]["name"] then
				msgc2(id, Translate(id, 24)..": "..USGN[usgn]["name"], 0, 255)
			end
			msgc2(id, Translate(id, 184)..": "..IPToCountry(USGN[usgn]["game_ip"]).." ("..IPToIso(USGN[usgn]["game_ip"])..")", 0, 255)
			msgc2(id, Translate(id, 249)..": "..RankPrefix(USGNRank(usgn)).." ("..USGNRank(usgn)..")", 0, 255)
		end
	end
end

-- Temp ban
ranklist_tempban_time = {5,10,20,60,120,360,720,1440,2880,7200}
ranklist_tempban_menu = CreateMenu(344, "trans:251,trans:252,trans:253,trans:254,trans:255,trans:256,trans:257,trans:258,trans:259,trans:260")
function ranklist_tempban_menu:click(id,b,p)
	if b > 0 then
		if ranklist_tempban_time[b] then
			local usgn = USERTEMP[id]["ranklist_user"]
			if usgn then
				if RankLower(USGNRank(usgn), PlayerRank(id)) then
					local name = USGN[usgn]["game_name"]
					local ip = USGN[usgn]["game_ip"]

					TempbanUSGN(usgn, ranklist_tempban_time[b])
					TempbanIP(ip, ranklist_tempban_time[b])
					TempbanName(name, ranklist_tempban_time[b])
				else
					ErrorMSG(id, Translate(id, 174))
				end
			else
				ErrorMSG(id, Translate(id, 261))
			end
		else
			ErrorMSG(id, Translate(id, 262))
		end
	end
end

-- Set rank
urank_optionmenu = CreateMenu(345, RankList())
function urank_optionmenu:getcustombutton(b,id,default)
	if default then
		if RankExists(default) then
			if SERVER_RANK[default].lvl < PlayerLevel(id) then
				return SERVER_RANK[default].prefix.."|Lvl. "..SERVER_RANK[default].lvl
			else
				return "("..SERVER_RANK[default].prefix.."|Lvl. "..SERVER_RANK[default].lvl
			end
		end
		return ""
	end
end

function urank_optionmenu:click(id,b,page)
	local usgn = USERTEMP[id]["ranklist_user"]
	if b > 0 and SERVER_DATA["ranklist"][usgn] then
		local rank_name = RankList()[b]
		if rank_name and SERVER_RANK[rank_name] then
			if RankLower(rank_name, PlayerRank(id)) then
				if RankLower(USGNRank(usgn), PlayerRank(id)) then
					SetUSGNRank(usgn, rank_name)
					msgc2(id, Translate(id, 263, SERVER_RANK[rank_name].prefix), 0, 255)

					SaveUSGN(usgn)
				else
					ErrorMSG(id, Translate(id, 264))
				end
			else
				urank_optionmenu:OpenPlayer(id, 1)
				ErrorMSG(id, Translate(id, 265))
			end
		else
			ErrorMSG(id, Translate(id, 266))
		end
	elseif b > 0 then
		ErrorMSG(id, Translate(id, 267))
		USERTEMP[id]["ranklist_user"] = nil
	end
end

addhook("join","rank_list_autoadd")
addhook("leave","rank_list_autoadd")
function rank_list_autoadd(id)
	if player(id,"usgn") > 0 then
		AddRanklist(player(id,"usgn"))

		USER[id]["game_ip"] = player(id,"ip")
		USER[id]["game_name"] = player(id,"name")
		USER[id]["last_played"] = os.time()
	end
end

addhook("name","game_name_update")
function game_name_update(id)
	USER[id]["game_name"] = player(id,"name")
	SaveUSER(id)
end
