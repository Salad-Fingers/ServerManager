CreateChat "!sound" "[sound]" (26) [[
	if args >= 2 then
		local file = s[2]

		if string.len(file) > 0 then
			if FileExists("sfx/"..file) then
				parse("sv_sound "..file)
			else
				ErrorMSG(id, Translate(id, 163, file))
			end
		end
	end
]]
