CreateChat "@bancountry" "[country]" (30) [[
	if args >= 2 then
		for _, pid in pairs(player(0,"table")) do
			ServerMSG2(pid, Translate(pid, 100, PlayerName(id), country))
		end
		local country = string.sub(txt, pos[2])
		for _, p in pairs(player(0,"table")) do
			if IPToCountry(player(p,"ip")) == country and Bannable(p, id) then
				local ip = player(p,"ip")
				local name = player(p,"name")
				local usgn = player(p,"usgn")

				parse('banip "'..ip..'"')
				parse('banname "'..name..'"')
				parse('banusgn "'..usgn..'"')
			end
		end
	end
]]

CreateChat "@tbancountry" "<minutes> [country]" (26) [[
	if args >= 3 then
		local minutes = tonumber(s[2])
		local country = string.sub(txt, pos[3])

		if minutes and country then
			for _, pid in pairs(player(0,"table")) do
				ServerMSG2(pid, Translate(pid, 101, PlayerName(id), country))
			end
			for _, p in pairs(player(0,"table")) do
				if IPToCountry(player(p,"ip")) == country then
					AddTempban(p, minutes, id)
				end
			end
		end
	end
]]
