CreateChat "!luadata" "<id>" (30) [[
	if args >= 2 then
		local p = tonumber(s[2])
		if p and player(p,"exists") then
			msg2(id, "-----------------------------")
			msg2(id, Translate(id, 128, PlayerName(p)))

			local i = 0
			for k, v in pairs(USER[p]["data"]) do
				i = i + 120
				AddTimer(i, false, msgc2, id, k.."("..type(k)..") = "..tostring(v).."("..type(v)..")")
			end
		end
	end
]]
