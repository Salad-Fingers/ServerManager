CreateChat "!slap" "<id>" (15) [[
	if args >= 2 then
		local p = tonumber(s[2])
		if p and player(p,"exists") then
			parse("slap "..p)
			ServerMSG("trans:162("..PlayerName(id).."�"..PlayerName(p)..")")
		end
	end
]]
