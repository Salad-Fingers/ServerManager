function Init()
	local rf = WriteStream(mod_path.."res/cmds.txt", "w")
	if rf then
		local rl = RankList()
		for i, rn in pairs(rl) do
			local cmds = RankCmds(rn)
			if #cmds > 0 then
				local x = 1
				WriteLine(rf, "--- "..SERVER_RANK[rn].prefix.." ---")
				for _, cmd_name in pairs(cmds) do
					if string.sub(cmd_name, 1, 1) == "@" then
						WriteLine(rf, x..".- "..cmd_name.." "..CHAT_CMD[cmd_name].params)
						x = x + 1
					end
				end

				for _, cmd_name in pairs(cmds) do
					if string.sub(cmd_name, 1, 1) == "!" then
						WriteLine(rf, x..".- "..cmd_name.." "..CHAT_CMD[cmd_name].params)
						x = x + 1
					end
				end

				if i < #rl then WriteLine(rf, "") end
			end
		end
		CloseStream(rf)
	end
end
