CreateChat "!fixpos" "" (0) [[
	if player(id,"health") > 0 then
		local x = player(id,"tilex")
		local y = player(id,"tiley")
		parse("setpos "..id.." "..(x*32+16).." "..(y*32+16))
	else
		ErrorMSG(id, Translate(id, 115))
	end
]]
