server_ad = [[
�255255000]]..mod_name..[[ v]]..mod_version..[[.
�255010010By Starkkz (#10464)
�000000255http://www.facebook.com/starkkz

If you see any hacker, please report it with !report <id> [reason]
]]

server_ad_sound = "starkkz/powered.wav"

addhook("minute","ad_minute")
function ad_minute()
	if SERVER_DATA["ad_toggle"] then
		for _, m in pairs(server_ad:split("\n")) do
			if string.len(m) > 0 then
				msg(m)
			end
		end

		if string.len(server_ad_sound) > 0 then
			parse("sv_sound "..server_ad_sound)
		end
	end
end

function AdButton(id)
	if SERVER_DATA["ad_toggle"] then
		return Translate(id, 268).."|"..Translate(id, 2)
	end
	return Translate(id, 268).."|"..Translate(id, 3)
end

function AdToggle(id)
	if SERVER_DATA["ad_toggle"] then
		SERVER_DATA["ad_toggle"] = nil
	else
		SERVER_DATA["ad_toggle"] = true
	end
end

CreateSetting(AdButton, AdToggle)
AddTransferFile("sfx/"..server_ad_sound)
