CreateChat "!freeze" "<id>" (10) [[
	local p = tonumber(s[2])
	if p and player(p,"exists") then
		parse("speedmod "..p.." -100")
	end
]]

CreateChat "!unfreeze" "<id>" (10) [[
	local p = tonumber(s[2])
	if p and player(p,"exists") then
		if player(p,"speedmod") < 0 then
			parse("speedmod "..p.." 0")
		end
	end
]]