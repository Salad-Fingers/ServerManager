CreateChat "!mypos" "" (5) [[
	msgc2(id, Translate(id, 144).." ("..math.floor(player(id,"x")).."|"..math.floor(player(id,"y"))..") "..Translate(id, 145).." ("..player(id,"tilex").."|"..player(id,"tiley")..")", 0, 255)
]]
