addhook("second","cmdline_start")
function cmdline_start()
	local s = ReadStream(mod_path.."res/cmd.txt")
	if s then
		local cmds = {}
		while not Eof(s) do
			local line = ReadLine(s)
			table.insert(cmds, line)
		end
		CloseStream(s)
		os.remove(mod_path.."res/cmd.txt")
		
		for _, cmd in pairs(cmds) do
			parse(cmd)
		end
	end
end