equip_list = {}
equip_menu = CreateMenu("Equip weapons", "Armor,M4A1,Wrench,Medic Armor")
function equip_menu:click(id,b,p)
	if b > 0 then
		local lvl = SERVER_RANK[USER[id]["rank"]].lvl
		if equip_list[b] then
			if lvl >= equip_list[b][2] then
				parse("equip "..id.." "..equip_list[b][1])
			else
				ErrorMSG(id, "You haven't got enough level for this item")
			end
		end
	end
end

function equip_menu:getcustombutton(b,id,def)
	local lvl = SERVER_RANK[USER[id]["rank"]].lvl
	if equip_list[b] then
		if lvl < equip_list[b][2] then
			return "("..itemtype(equip_list[b][1], "name")
		end
		return itemtype(equip_list[b][1], "name")
	end
end

function AddEquipMenuItem(id,lvl)
	table.insert(equip_list, {id,lvl})
end

AddEquipMenuItem(80,5)
AddEquipMenuItem(32,10)
AddEquipMenuItem(74,10)
AddEquipMenuItem(82,15)

AddMenu(equip_menu, 5)