CreateChat "!pm" "<id> <text>" (0) [[
	if args >= 3 then
		local p = tonumber(s[2])
		local message = string.sub(txt, pos[3])
		if p and player(p,"exists") and string.len(message) > 0 then
			if p == id then
				ErrorMSG(id, Translate(id, 146))
			else
				if not IPMuted(player(id,"ip")) then
					msgc2(id, "["..Translate(id, 147).."] "..PlayerName(p)..": "..message, 255, 255, 0)
					msgc2(p, "["..Translate(p, 148).."] "..PlayerName(id)..": "..message, 255, 255, 0)
				else
					ErrorMSG(id, Translate(id, 149))
				end
			end
		end
	end
]]
