addhook("projectile","ProjectileFlash")
function ProjectileFlash(id,wpn)
	if wpn == 52 then
		for x = -1, 1 do
			for y = -1, 1 do
				if not tile(x+player(id,"tilex"),y+player(id,"tiley"),"wall") then
					local oid = SpawnObject(5, x+player(id,"tilex"), y+player(id,"tiley"))
					AddTimer(0, true, parse, "killobject "..oid)
				end
			end
		end
	end
end