function FowButton(id)
	if game("sv_fow") == "1" then
		return Translate(id, 278).."|"..Translate(id, 2)
	end
	return Translate(id, 278).."|"..Translate(id, 3)
end

function FowToggle()
	if game("sv_fow") == "1" then
		parse("sv_fow 0")
	elseif game("sv_fow") == "0" then
		parse("sv_fow 1")
	end
end

CreateSetting(FowButton, FowToggle)
