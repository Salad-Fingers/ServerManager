CreateChat "@svname" "[server name]" (35) [[
	if args >= 2 then
		local name = string.sub(txt, pos[2])
		ServerMSG("trans:169("..PlayerName(id).."�"..name..")")
		parse('sv_name "'..name..'"')
		if servertitle_draw then servertitle_draw(p) end
	end
]]
