server_menu = {}
menu_attachments = {}
serveraction_attachments = {}
addon_menu_hook = addhook
addon_menu_freehook = freehook
addon_men_func = menu
navigation_key = 1

if ADDONSET["menu_key"] then
	if ADDONSET["menu_key"] == "F2" then
		navigation_key = 1
	elseif ADDONSET["menu_key"] == "F3" then
		navigation_key = 2
	elseif ADDONSET["menu_key"] == "F4" then
		navigation_key = 3
	end
end

function WaitMenus(id)
	USERTEMP[id]["navwait"] = true
end

function menu(id,line)
	if USERTEMP[id]["navwait"] then
		local s = line:split(",")
		local title = s[1]:split("@")[1]

		USERTEMP[id]["navmen"] = {}
		USERTEMP[id]["navmen"][title] = {}
		for i = 2, #s do
			table.insert(USERTEMP[id]["navmen"][title], s[i])
		end
	else
		addon_men_func(id, line)
	end
end

function MenuFunction(men)
	if men.OpenPlayer then
		return function (id)
			men:OpenPlayer(id)
		end
	elseif men.f then
		return men.f
	end
end

function HookedFunc(id, b)
	local MenuCount = USERTEMP[id]["navmens"][1][1]
	local MenuID
	for i = 2, #USERTEMP[id]["navmens"] do
		local Cnt = USERTEMP[id]["navmens"][i][1]
		if b >= MenuCount and b <= MenuCount + Cnt then
			MenuID = i
			break
		end
		MenuCount = MenuCount + Cnt

		if i == #USERTEMP[id]["navmens"] then
			return
		end
	end

	local title = USERTEMP[id]["navmens"][MenuID][2]
	for _, f in pairs(menu_attachments) do
		f(id, title, b - MenuCount)
	end
end

function GenerateMenu(id)
	local men = PlayerMenus(id)
	USERTEMP[id]["navfunc"] = {}
	USERTEMP[id]["navtxt"] = {}
	USERTEMP[id]["navmens"] = {}

	for i = 1, #men do
		local text
		if men[i].gettitle then
			text = men[i]:gettitle(id)
		elseif men[i].title then
			text = men[i].title
		end
		table.insert(USERTEMP[id]["navfunc"], MenuFunction(men[i]))
		table.insert(USERTEMP[id]["navtxt"], text)
	end
	USERTEMP[id]["navmens"][1] = {#USERTEMP[id]["navtxt"]}

	if USERTEMP[id]["navmen"] then
		for title, buttons in pairs(USERTEMP[id]["navmen"]) do
			for _, button in pairs(buttons) do
				table.insert(USERTEMP[id]["navtxt"], button)
			end
			table.insert(USERTEMP[id]["navmens"], {#USERTEMP[id]["navtxt"], title})
		end
	end

	USERTEMP[id]["navwait"] = false
end

function AddMenuButton(f,txt,lvl)
	table.insert(server_menu, {f = f,txt = txt,lvl = lvl})
end

function AddMenu(m,lvl)
	table.insert(server_menu, {m = m,lvl = lvl})
end

function PlayerMenus(id, b)
	local menus = {}
	for _, b in pairs(server_menu) do
		if PlayerLevel(id) >= b.lvl then
			if b.m then
				table.insert(menus, b.m)
			else
				if type(b.txt) == "string" then
					table.insert(menus, {f=b.f,title=b.txt})
				elseif type(b.txt) == "function" then
					local title = b.txt(id)
					if title and title:len() > 0 then
						table.insert(menus, {f=b.f,title=b.txt(id)})
					end
				end
			end

			if b and #menus == b then
				return menus[b]
			end
		end
	end
	return menus
end

server_navigation = CreateMenu("337@b")
function server_navigation:getcustombutton(b,id)
	return USERTEMP[id]["navtxt"][b]
end

function server_navigation:click(id,b,p)
	local f = USERTEMP[id]["navfunc"][b] or HookedFunc
	if f then
		f(id, b)
	end
end

addhook("serveraction","AM.Navigation")
function AM.Navigation(id,s)
	if s == navigation_key then
		WaitMenus(id)
	end
	for _, f in pairs(serveraction_attachments) do
		f(id, s)
	end
	if s == navigation_key then
		GenerateMenu(id)
		server_navigation:OpenPlayer(id, 1)
	end
end

-- Hook extension
function addhook(...)
	local arg = {...}
	if arg[1] and arg[2] then
		local func = _G[arg[2]]
		if func then
			if arg[1] == "menu" then
				return CreateMenuAttachment(func)
			elseif arg[1] == "serveraction" then
				return CreateServeractionAttachment(func)
			end
		end
	end
	return addon_menu_hook(...)
end

function freehook(...)
	local arg = {...}
	if arg[1] and arg[2] then
		local func = _G[arg[2]]
		if func then
			if arg[1] == "menu" then
				return RemoveMenuAttachment(func)
			elseif arg[1] == "serveraction" then
				return RemoveServeractionAttachment(func)
			end
		end
	end
	return addon_menu_freehook(...)
end

function CreateMenuAttachment(f)
	table.insert(menu_attachments, f)
end

function RemoveMenuAttachment(f)
	for id, at in pairs(menu_attachments) do
		if at == f then
			menu_attachments[id] = nil
			break
		end
	end
end

function CreateServeractionAttachment(f)
	table.insert(serveraction_attachments, f)
end

function RemoveServeractionAttachment(f)
	for id, at in pairs(serveraction_attachments) do
		if at == f then
			serveraction_attachments[id] = nil
			break
		end
	end
end
