server_team = {}

team_color = {}
team_color[1] = {name = 76,r=255,g=255,b=255}
team_color[2] = {name = 77,r=160,g=160,b=160}
team_color[3] = {name = 78,r=255,g=0,b=0}
team_color[4] = {name = 79,r=255,g=125,b=0}
team_color[5] = {name = 80,r=255,g=255,b=0}
team_color[6] = {name = 81,r=0,g=255,b=0}
team_color[7] = {name = 82,r=0,g=128,b=0}
team_color[8] = {name = 83,r=0,g=255,b=255}
team_color[9] = {name = 84,r=0,g=0,b=255}
team_color[10] = {name = 85,r=128,g=0,b=128}
team_color[11] = {name = 86,r=255,g=192,b=203}
team_color[12] = {name = 87,r=150,g=75,b=0}
team_color[13] = {name = 88,r=245,g=245,b=220}

addhook("startround_prespawn","team_sprite_remove")
function team_sprite_remove()
	for i = 1, game("sv_maxplayers") do
		USERTEMP[i]["team_ring"] = nil
		USERTEMP[i]["team_color"] = nil
	end
end

function get_color_list()
	local color_list = {}
	for id, color in pairs(team_color) do
		table.insert(color_list, {"trans:"..color.name,id})
	end

	for team_name, team_tab in pairs(server_team) do
		color_list[team_tab.color][1] = "("..color_list[team_tab.color][1]
	end
	return color_list
end

function get_random_color()
	local disabled_color = {}
	for team_name, team_tab in pairs(server_team) do
		disabled_color[team_tab.color] = true
	end

	local color_tab = {}
	for id, color in pairs(team_color) do
		if not disabled_color[id] then
			table.insert(color_tab, id)
		end
	end
	return color_tab[math.random(1, #color_tab)]
end

function set_team_color(team,color)
	if server_team[team] then
		server_team[team].color = color
		set_team_ring(team)
	end
end

function team_mate(id,p)
	if player(id,"exists") and player(p,"exists") then
		local id_t = player_team(id)
		local p_t = player_team(p)

		if id_t and p_t and id_t == p_t then
			return true
		end
	end
end

function team_leader(t,id)
	if server_team[t] then
		local pt = player_team(id)
		if pt and pt == t then
			return server_team[t].leader == id or PlayerLevel(id) >= 26
		end
	end
end

function team_damage(id,p)
	if player(id,"exists") and player(p,"exists") then
		local t = player_team(id)
		if t then
			if server_team[t].prot and team_mate(id, p) then
				return false
			end
		end
		return true
	end
end

function player_team(id)
	local t = USERTEMP[id]["team_current"]
	if t and not server_team[t] then
		USERTEMP[id]["team_current"] = nil
	end
	return USERTEMP[id]["team_current"]
end

function team_message(team,txt,r,g,b)
	if server_team[team] then
		for id, _ in pairs(server_team[team].members) do
			msgc2(id, "["..Translate(id, 91).."] "..txt, r, g, b)
		end
	end
end

function create_team(name,leader)
	if not USERTEMP[leader]["team_current"] then
		if table.size(server_team) < 5 then
			if not server_team[team] then
				msgc("trans:23("..PlayerName(leader).."�"..Color(0,255)..name..Color(255,255)..")", 0, 255)
				server_team[name] = {
					leader = leader,
					color = get_random_color(),
					prot = false,
					members = {}
				}
				join_team(leader, name, true)
			end
		else
			ErrorMSG(leader, Translate(leader, 24))
		end
	else
		ErrorMSG(leader, Translate(leader, 25))
	end
end

function set_player_team_ring(id)
	local t = player_team(id)
	if t then
		if not USERTEMP[id]["team_ring"] then
			USERTEMP[id]["team_ring"] = image("gfx/sprites/wave.bmp", 0, 0, 100+id)
			imageblend(USERTEMP[id]["team_ring"], 1)
			tween_scale(USERTEMP[id]["team_ring"], 600, 1.8, 1.8)
		end

		if not USERTEMP[id]["team_color"] or USERTEMP[id]["team_color"] ~= server_team[t].color then
			USERTEMP[id]["team_color"] = server_team[t].color
			local r = team_color[server_team[t].color].r
			local g = team_color[server_team[t].color].g
			local b = team_color[server_team[t].color].b
			imagecolor(USERTEMP[id]["team_ring"], r, g, b)
		end
	else
		if USERTEMP[id]["team_ring"] then
			freeimage(USERTEMP[id]["team_ring"])
			USERTEMP[id]["team_ring"] = nil
			USERTEMP[id]["team_color"] = nil
		end
	end
end

function set_team_ring(team)
	if server_team[team] then
		for id, _ in pairs(server_team[team].members) do
			set_player_team_ring(id)
		end
	end
end

function join_team(id,team,hidden_message)
	if not player_team(id) then
		if server_team[team] then
			if not hidden_message then
				msg("trans:26("..PlayerName(id)..Color(255,255).."�"..team..")")
			end
			USERTEMP[id]["team_current"] = team
			server_team[team].members[id] = true
			set_player_team_ring(id)
		else
			ErrorMSG(id, Translate(id, 27))
		end
	else
		ErrorMSG(id, Translate(id, 28))
	end
end

addhook("leave", "team_leave")
function team_leave(id)
	local t = player_team(id)
	if t then
		if server_team[t] then
			if server_team[t].leader == id then
				if table.size(server_team[t].members) > 1 then
					leave_team(id)
					for p, _ in pairs(server_team[t].members) do
						server_team[t].leader = p
						team_message(t, "trans:29("..PlayerName(p)..Color(255,255)..")", 0, 255)
						break
					end
				else
					destroy_team(t)
				end
			else
				leave_team(id)
			end
		else
			leave_team(id)
		end
	end
end

function leave_team(id,hidden_message)
	local t = player_team(id)
	if t then
		if server_team[t] then
			if not hidden_message then
				msg("trans:55("..PlayerName(id)..Color(255,255).."�"..player_team(id)..")")
			end
			server_team[t].members[id] = nil
		end
		USERTEMP[id]["team_current"] = nil
		set_player_team_ring(id)
	end
end

function destroy_team(team)
	if server_team[team] then
		msgc("trans:54("..team..")", 255)
		for id, _ in pairs(server_team[team].members) do
			leave_team(id, true)
		end
		server_team[team] = nil
	end
end

function kick_team(id)
	leave_team(id, true)
	msgc2(id, Translate(id, 89))
end

function invite_team(id,team)
	USERTEMP[id]["team_invitation"] = team
	msgc2(id, Translate(id, 30, team), 0, 255)
	team_message(team, "trans:31("..PlayerName(id)..Color(255,255)..")")
end

function accept_invite(id)
	if not player_team(id) then
		local t = USERTEMP[id]["team_invitation"]
		USERTEMP[id]["team_invitation"] = nil
		if t then
			if server_team[t] then
				join_team(id, t)
			else
				ErrorMSG(id, Translate(id, 56))
			end
		else
			ErrorMSG(id, Translate(id, 57))
		end
	else
		ErrorMSG(id, Translate(id, 58))
	end
end

function invitable_list(team)
	local list = {}
	for _, id in pairs(player(0,"table")) do
		if not USERTEMP[id]["team_invitation"] and (player_team(id) or "") ~= team then
			table.insert(list, id)
		end
	end
	return list
end

function kickable_list(team)
	local list = {}
	for _, id in pairs(player(0,"table")) do
		local t = player_team(id) or ""
		if t == team and server_team[t].leader ~= id then
			table.insert(list, id)
		end
	end
	return list
end

team_color_menu = CreateMenu(237)
function team_color_menu:getcustombutton(b,id,def)
	local t = player_team(id)
	if t and server_team[t] and team_leader(t, id) then
		local list = get_color_list()
		if list[b] then return list[b][1] end
	end
end

function team_color_menu:click(id,b,p)
	local t = player_team(id)
	if t and server_team[t] and team_leader(t, id) then
		local list = get_color_list(id)
		if list[b] then
			if string.sub(list[b][1], 1, 1) == "(" then
				team_color_menu:OpenPlayer(id, p)
				ErrorMSG(id, Translate(id, 59))
			else
				set_team_color(t, list[b][2])
			end
		elseif b > 0 then
			team_color_menu:OpenPlayer(id, p)
			ErrorMSG(id, Translate(id, 60))
		end
	end
end

team_invite_menu = CreateMenu(356)
function team_invite_menu:getcustombutton(b,id,def)
	local t = player_team(id)
	if t and server_team[t] and team_leader(t, id) then
		local list = invitable_list(t)
		if list[b] then return player(list[b], "name") end
	end
end

function team_invite_menu:click(id,b,p)
	local t = player_team(id)
	if t and server_team[t] and team_leader(t, id) then
		local list = invitable_list(t)
		if list[b] then
			invite_team(list[b], t)
			team_invite_menu:OpenPlayer(id, p)
		elseif b > 0 then
			ErrorMSG(id, Translate(id, 61))
		end
	end
end

team_kick_menu = CreateMenu(74)
function team_kick_menu:getcustombutton(b,id,def)
	local t = player_team(id)
	if t and server_team[t] and team_leader(t, id) then
		local list = kickable_list(t)
		if list[b] then return player(list[b], "name") end
	end
end

function team_kick_menu:click(id,b,p)
	local t = player_team(id)
	if t and server_team[t] and team_leader(t, id) then
		local list = kickable_list(t)
		if list[b] then
			kick_team(list[b])
			team_message(t, "trans:32("..PlayerName(list[b])..Color(255)..")")
			team_kick_menu:OpenPlayer(id, p)
		elseif b > 0 then
			ErrorMSG(id, Translate(id, 61))
		end
	end
end

team_menu = CreateMenu(91)
function team_menu:click(id,b,p)
	if b == 1 then
		if player_team(id) then
			leave_team(id)
		end
		accept_invite(id)
		team_menu:OpenPlayer(id, p)
	elseif b == 2 then
		local t = player_team(id)
		if t then
			if server_team[t] then
				if team_leader(t, id) then
					team_invite_menu:OpenPlayer(id, 1)
				else
					ErrorMSG(id, Translate(id, 68))
				end
			else
				ErrorMSG(id, Translate(id, 63))
			end
		else
			ErrorMSG(id, Translate(id, 66))
		end
	elseif b == 3 then
		local t = player_team(id)
		if t then
			if server_team[t] then
				if server_team[t].leader == id then
					destroy_team(t)
				else
					leave_team(id)
				end
				team_menu:OpenPlayer(id, p)
			else
				ErrorMSG(id, Translate(id, 65))
				USERTEMP[id]["team_current"] = nil
			end
		else
			ErrorMSG(id, Translate(id, 66))
		end
	elseif b == 4 then
		if table.size(server_team) > 0 then
			msg2(id, "--- "..Translate(id, 90).." ---")

			local i = 0
			for team_name, team_tab in pairs(server_team) do
				i = i + 1
				msgc2(id, i..".- "..team_name, 255)
			end
		else
			ErrorMSG(id, Translate(id, 67))
		end
	elseif b == 5 then
		local t = player_team(id)
		if t then
			if server_team[t] then
				if team_leader(t, id) then
					team_kick_menu:OpenPlayer(id, 1)
				else
					ErrorMSG(id, Translate(id, 68))
				end
			else
				ErrorMSG(id, Translate(id, 65))
			end
		else
			ErrorMSG(id, Translate(id, 66))
		end
	elseif b == 6 then
		local t = player_team(id)
		if t then
			if server_team[t] then
				if team_leader(t, id) then
					team_color_menu:OpenPlayer(id, 1)
				else
					ErrorMSG(id, Translate(id, 68))
				end
			else
				ErrorMSG(id, Translate(id, 65))
			end
		else
			ErrorMSG(id, Translate(id, 66))
		end
	elseif b == 7 then
		local t = player_team(id)
		if t then
			if server_team[t] then
				if team_leader(t, id) then
					server_team[t].prot = not server_team[t].prot
					if server_team[t].prot then
						team_message(t, Translate(id, 33), 0, 255)
					else
						team_message(t, Translate(id, 34), 255)
					end
				else
					ErrorMSG(id, Translate(id, 68))
				end
			else
				ErrorMSG(id, Translate(id, 65))
			end
		else
			ErrorMSG(id, Translate(id, 66))
		end
		team_menu:OpenPlayer(id, p)
	end
end

function team_menu:getcustombutton(b,id,d)
	if b == 1 then
		local t = USERTEMP[id]["team_invitation"]
		if t then
			if server_team[t] then
				return Translate(id, 69).."|"..t
			else
				USERTEMP[id]["team_invitation"] = nil
			end
		end
		return "("..Translate(id, 69)
	elseif b == 2 then
		local t = player_team(id)
		if t and team_leader(t, id) then
			return Translate(id, 70)
		end
		return "("..Translate(id, 70)
	elseif b == 3 then
		local t = player_team(id)
		if t then
			if server_team[t] then
				if server_team[t].leader == id then
					return Translate(id, 71)
				else
					return Translate(id, 72)
				end
			end
		end
		return "("..Translate(id, 72)
	elseif b == 4 then
		return Translate(id, 73)
	elseif b == 5 then
		local t = player_team(id)
		if t and team_leader(t, id) then
			return Translate(id, 74)
		end
		return "("..Translate(id, 74)
	elseif b == 6 then
		local t = player_team(id)
		if t and team_leader(t, id) then
			return Translate(id, 237)
		end
		return "("..Translate(id, 237)
	elseif b == 7 then
		local t = player_team(id)
		if t and server_team[t] then
			if team_leader(t, id) then
				if server_team[t].prot then
					return Translate(id, 75).."|"..Translate(id, 2)
				end
				return Translate(id, 75).."|"..Translate(id, 3)
			end
			if server_team[t].prot then
				return "("..Translate(id, 75).."|"..Translate(id, 2)
			end
			return "("..Translate(id, 75).."|"..Translate(id, 3)
		end
		return "("..Translate(id, 75)
	elseif b == 8 then
		local t = player_team(id)
		if t and server_team[t] then
			return Translate(id, 64, t)
		end
	end
end

CreateChat "!team" "<team name>" (0) [[
	if not player_team(id) then
		if args >= 2 then
			local team_name = string.sub(txt, pos[2])
			if string.len(team_name) > 0 then
				if not server_team[team_name] then
					create_team(team_name, id)
				else
					ErrorMSG(id, Translate(id, 62))
				end
			end
		end
	else
		ErrorMSG(id, Translate(id, 58))
	end
]]

CreateChat "!inviteteam" "<id>" (0) [[
	local t = player_team(id)
	if t then
		if args >= 2 then
			local p = tonumber(s[2])
			if p and player(p,"exists") then
				if server_team[t] then
					if team_leader(t, id) then
						invite_team(p, t)
					else
						ErrorMSG(id, Translate(id, 56))
					end
				else
					ErrorMSG(id, Translate(id, 65))
				end
			else
				ErrorMSG(id, Translate(id, 160))
			end
		end
	else
		ErrorMSG(id, Translate(id, 66))
	end
]]

CreateChat "!kickteam" "<id>" (0) [[
	local t = player_team(id)
	if t then
		if args >= 2 then
			local p = tonumber(s[2])
			if p and player(p,"exists") then
				if server_team[t] then
					if team_leader(t, id) then
						if server_team[t].members[id] then
							kick_team(p)
							team_message(t, "trans:32("..PlayerName(p)..")", 255)
						else
							ErrorMSG(id, Translate(id, 61))
						end
					else
						ErrorMSG(id, Translate(id, 68))
					end
				else
					ErrorMSG(id, Translate(id, 65))
				end
			else
				ErrorMSG(id, Translate(id, 160))
			end
		end
	else
		ErrorMSG(id, Translate(id, 66))
	end
]]

CreateChat "!teamchat" "[text]" (0) [[
	local t = player_team(id)
	if t then
		if server_team[t] then
			if args >= 2 then
				local message = string.sub(txt, pos[2])
				if string.len(message) > 0 then
					team_message(t,PlayerName(id)..Color(255, 255)..": "..message, 255, 255, 0)
				end
			end
		else
			ErrorMSG(id, Translate(id, 65))
		end
	else
		ErrorMSG(id, Translate(id, 66))
	end
]]

function team_hit(id,source,wpn,hpdmg,apdmg,rawdmg)
	if player(source,"exists") then
		if not team_damage(source, id) then
			return 1
		end
	end
end
CreateHitAttachment(team_hit)

AddMenu(team_menu, 0)
