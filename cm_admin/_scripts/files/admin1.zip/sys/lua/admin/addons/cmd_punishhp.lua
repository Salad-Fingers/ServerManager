CreateChat "@punishhp" "<id>" (16) [[
	if args >= 2 then
		local p = tonumber(s[2])
		if p and player(p,"exists") and player(p,"health") > 0 then
			parse("sethealth "..p.." 1")
			for _, pid in pairs(player(0,"table")) do
				ServerMSG2(pid, Translate(pid, 150, PlayerName(id), PlayerName(p)))
			end
		end
	end
]]
