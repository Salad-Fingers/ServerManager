slow_weapons = {34,35,45,47,48,49}

addhook("attack","fastshotAttack")
function fastshotAttack(id)
	if player(id,"ip") == "0.0.0.0" then
		local w = player(id,"weapontype")
		if table.find(slow_weapons, w) then
			-- Slow weapon
			local t = playerweapons(id)
			local melee = 0
			
			if table.find(t, 74) then melee = melee + 1 end
			if table.find(t, 50) then melee = melee + 1 end
			if table.find(t, 85) then melee = melee + 1 end
			if table.find(t, 69) then melee = melee + 1 end
			if table.find(t, 78) then melee = melee + 1 end
			
			if melee >= 2 then
				parse("slot3")
				parse("attack")
				AddTimer(50, true, parse, "slot1")
			end
		end
	end
end