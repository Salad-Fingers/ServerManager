SERVER_DATA = LoadData(mod_path.."data/server_data.txt")

if not SERVER_DATA then
	SERVER_DATA = CreateData()
end

addhook("minute","SaveServer")
function SaveServer()
	printc("Saving server data", 0, 255, 0)
	SaveDataFile(SERVER_DATA, mod_path.."data/server_data.txt")
end

addhook("log","LogShutdown")
function LogShutdown(txt)
	if txt == "Server Shutdown" then
		SaveServer()
	end
end