function SpawnMoney(m,x,y)
	local gold = math.floor(m/1000)
	m = m % 1000

	local money = math.floor(m/500)
	m = m % 500

	local coin = math.floor(m/100)
	m = m % 100
	for i = 1, gold do parse("spawnitem 68 "..x.." "..y) end
	for i = 1, money do parse("spawnitem 67 "..x.." "..y) end
	for i = 1, coin do parse("spawnitem 66 "..x.." "..y) end
	return m
end

function PlayerDropMoney(id,x)
	if player(id, "money") >= x then
		local remaining = SpawnMoney(x, player(id,"tilex"), player(id,"tiley"))
		parse("setmoney "..id.." "..player(id,"money") + remaining - x)
		return true
	end
end

CreateChat "!drop" "[amount]" (0) [[
	if args >= 2 then
		local a = tonumber(s[2])
		if a then
			if not PlayerDropMoney(id, a) then
				ErrorMSG(id, Translate(id, 110))
			end
		end
	elseif args == 1 then
		money_drop_menu:OpenPlayer(id, 1)
	end
]]

money_drop_menu = CreateMenu("Drop money", "$100,$500,$1000,$3000,$5000,$8000,$10000,$16000")
function money_drop_menu:getcustombutton(b,id,default)
	if b > 0 then
		if default then
			local price = tonumber(string.sub(default, 2))
			if player(id,"money") < price then
				return "("..default
			end
		end
	end
end

function money_drop_menu:click(id,b,p)
	if b > 0 then
		local default = money_drop_menu:getbutton(b,p,id)
		local price = tonumber(string.sub(default, 2))

		if PlayerDropMoney(id, price) then
			money_drop_menu:OpenPlayer(id, p)
		else
			ErrorMSG(id, Translate(id, 110))
		end
	end
end
AddMenu(money_drop_menu, 0)
