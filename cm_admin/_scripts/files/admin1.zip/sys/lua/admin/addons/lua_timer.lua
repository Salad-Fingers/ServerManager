server_timer = {}

addhook("always","timerAlways")
function timerAlways()
	for k, v in pairs(server_timer) do
		if Millisecs() - v.finish >= 0 then
			v.f(unpack(v.arg))
			server_timer[k] = nil
		end
	end
end

addhook("startround_prespawn","timerRemover")
function timerRemover()
	for k, v in pairs(server_timer) do
		if v.r then server_timer[k] = nil end
	end
end

function AddTimer(delay,restart,f,...)
	table.insert(server_timer, {finish = Millisecs() + delay,f = f,r = restart,arg = arg})
end