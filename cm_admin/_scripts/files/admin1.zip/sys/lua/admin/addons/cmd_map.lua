CreateChat "!map" "[map name]" (30) [[
	if args >= 2 then
		local map_name = string.sub(txt, pos[2])
		if string.len(map_name) > 0 then
			if FileExists("maps/"..map_name..".map") then
				parse("changemap "..map_name)
			else
				ErrorMSG(id, Translate(id, 132, map_name))
			end
		end
	end
]]
