USERTEMP_DEFAULTDATA["hud"] = {}
USERTEMP_DEFAULTDATA["renderhud"] = {}

function Hudtxt2(id,hid,txt,x,y,a,r,g,b)
	if id == 0 then return Hudtxt(hid, txt, x, y, a, r, g, b) end
	if r then txt = Color(r,g,b)..txt end

	local t = {txt = txt,x = x,y = y,a = a or 0}
	if player(id,"exists") and not player(id,"bot") then
		if not USERTEMP[id]["hud"][hid] or not table.compare(t, USERTEMP[id]["hud"][hid]) then
			USERTEMP[id]["hud"][hid] = t
			parse('hudtxt2 '..id..' '..hid..' "'..InsertTags(id, txt)..'" '..x..' '..y..' '..(a or 0))
		end
	end
end

function Hudtxt(hid,txt,x,y,a,r,g,b)
	for _, id in pairs(player(0,"table")) do
		Hudtxt2(id, hid, txt, x, y, a, r, g, b)
	end
end

function HudExists(id,h)
	return USERTEMP[id]["hud"][h] ~= nil
end

function Freehud(id,h)
	if id == 0 then
		for _, i in pairs(player(0,"table")) do
			Freehud(i, h)
		end
	elseif id and h then
		parse('hudtxt2 '..id..' '..h..' "" 0 0')
		if player(id,"exists") and not player(id,"bot") then
			USERTEMP[id]["hud"][h] = nil
		end
	end
end

hud_slot = 0
function GenerateHud()
	hud_slot = hud_slot + 1
	return hud_slot
end
