CreateChat "!maket" "<id>" (25) [[
	if args >= 2 then
		local p = tonumber(s[2])
		if p and player(p,"exists") then
			parse("maket "..p)
			msg2(p, Translate(id, 131, PlayerName(id)))
		end
	end
]]
