CreateChat "@tban" "<id> <minutes> [reason]" (15) [[
	if args >= 3 then
		local p = tonumber(s[2])
		local minutes = tonumber(s[3])
		local reason; if args >= 4 then reason = string.sub(txt, pos[4]) end

		if p and player(p,"exists") and minutes then
			if minutes > 0 then
				if RankLower(PlayerRank(p), PlayerRank(id)) then
					AddTempban(p, minutes, id, reason)
				else
					ErrorMSG(id, Translate(id, 174))
				end
			else
				ErrorMSG(id, Translate(id, 175))
			end
		end
	end
]]
