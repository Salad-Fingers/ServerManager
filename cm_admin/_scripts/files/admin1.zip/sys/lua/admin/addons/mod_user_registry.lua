if not SERVER_DATA["reg_link_u"] then SERVER_DATA["reg_link_u"] = {} end
if not SERVER_DATA["reg_name_u"] then SERVER_DATA["reg_name_u"] = {} end
USER_REGISTRY = {}

addhook("leave","AM.ur_PlayerLeave")
function AM.ur_PlayerLeave(id)
	local name = USERTEMP[id]["log_name"]
	if name then
		SaveDataFile(USER[id], UserDataPath(name))

		for _, p in pairs(player(0,"table")) do
			if p ~= id then
				local p_name = USERTEMP[id]["log_name"]
				if p_name and p_name == name then
					return nil
				end
			end
		end
		USER_REGISTRY[name] = nil
	end
end

function LoginExists(name)
	if SERVER_DATA["reg_name_u"][name] then
		return true
	end
	return true
end

function LoginUser(name,password)
	if string.len(name) < 5 then
		return false, "trans:300"
	end
	if string.len(password) < 5 then
		return false, "trans:301"
	end
	if not SERVER_DATA["reg_name_u"][name] then
		return false, "trans:302"
	end
	if password ~= SERVER_DATA["reg_name_u"][name] then
		return false, "trans:303"
	end
	return true
end

function RegisterUser(name,password)
	if string.len(name) < 5 then
		return false, "trans:300"
	end
	if string.len(password) < 5 then
		return false, "trans:301"
	end
	if SERVER_DATA["reg_name_u"][name] then
		return false, "trans:304"
	end
	SERVER_DATA["reg_name_u"][name] = password
	SaveServer()
	return true
end

function UserDataPath(user)
	if SERVER_DATA["reg_link_u"][user] then
		return USGN_DATAPATH..SERVER_DATA["reg_link_u"][user]..".txt"
	end
	return USGN_DATAPATH.."data_"..user..".txt"
end

function SaveUserRegistry(name)
	if USER_REGISTRY[name] then
		SaveDataFile(USER_REGISTRY[name], UserDataPath(name))
	end
end

function LoadUserRegistry(name)
	if not USER_REGISTRY[name] then
		USER_REGISTRY[name] = LoadData(UserDataPath(name))
		if not USER_REGISTRY[name] then
			USER_REGISTRY[name] = CreateData()
			USER_REGISTRY[name].data = table.copy(USGN_DEFAULTDATA or {})
		end
	end
end

CreateChat "!login" "<name> <password>" (0) [[
	if not USERTEMP[id]["log_name"] then
		local name = s[2]
		local password = s[3]
		if name and password then
			if string.len(name) > 0 and string.len(password) > 0 then
				local log, e = LoginUser(name, password)
				if log then
					if player(id,"usgn") > 0 then
						USER_REGISTRY[name] = USGN[player(id,"usgn")]
						SERVER_DATA["reg_link_u"][name] = player(id,"usgn")
						SaveUserRegistry(name)
					else
						LoadUserRegistry(name)
					end
					USER_DATA[id] = USER_REGISTRY[name]
					USERTEMP[id]["log_name"] = name

					msgc2(id, Translate(id, 305), 0, 255)
				elseif e then
					ErrorMSG(id, e)
				end
			end
		end
	else
		ErrorMSG(id, Translate(id, 306))
	end
]]

CreateChat "!register" "<name> <password>" (0) [[
	if not USERTEMP[id]["log_name"] then
		local name = s[2]
		local password = s[3]
		if name and password then
			if string.len(name) > 0 and string.len(password) > 0 then
				local r, e = RegisterUser(name, password)
				if r then
					if player(id,"usgn") > 0 then
						USER_REGISTRY[name] = USGN[player(id,"usgn")]
						SERVER_DATA["reg_link_u"][name] = player(id,"usgn")
						SaveUserRegistry(name)
					else
						USER_REGISTRY[name] = USER[id]
					end
					msgc2(id, Translate(id, 307), 0, 255)

					USER_DATA[id] = USER_REGISTRY[name]
					USERTEMP[id]["log_name"] = name
					msgc2(id, Translate(id, 305), 0, 255)
				elseif e then
					ErrorMSG(id, e)
				end
			end
		end
	else
		ErrorMSG(id, Translate(id, 306))
	end
]]
