hit_attachments = {}
addon_hit_hook = addhook
addon_hit_freehook = freehook

addhook("hit","AM.Hit")
function AM.Hit(id,source,wpn,hpdmg,apdmg,rawdmg,data)
	if not data then data = {} end
	local r = 0
	for k, f in pairs(hit_attachments) do
		local v = f(id, source, wpn, hpdmg, apdmg, rawdmg, data)
		if v and v == 1 then
			r = 1
		end
	end
	return r
end

function CalcDamage(h,a,d)
	local d = math.floor(d * game("mp_damagefactor"))
	if a >= 0 and a <= 200 then
		local _a = a - d
		local _h = h - d*(1 - game("mp_kevlar"))
		if _a < 0 then
			_h = _h + _a
			_a = 0
		end
		return math.floor(_h), math.floor(_a)
	elseif a == 201 then
		local _h = h - d*0.75
		return math.floor(_h), a
	elseif a == 202 or a == 204 then
		local _h = h - d*0.5
		return math.floor(_h), a
	elseif a == 203 then
		local _h = h - d*0.25
		return math.floor(_h), a
	elseif a == 205 then
		local _h = h - d*0.05
		return math.floor(_h), a
	elseif a == 206 then
		local _h = h - d
		return math.floor(_h), a
	end
end

function HitPlayer(id,dmg,source,wpn,data)
	local h, a = CalcDamage(player(id,"health"), player(id,"armor"), dmg)
	local source = source or 0
	local wpn = wpn or 0

	if h and a then
		if AM.Hit(id, source, wpn, player(id,"health") - h, player(id,"armor") - a, dmg, data) == 0 then
			if h > 0 then
				if player(id,"armor") ~= a then
					parse("setarmor "..id.." "..a)
				end
				parse("sethealth "..id.." "..h)
				Sound3("player/hit"..math.random(1,3)..".wav", player(id,"x"), player(id,"y"), 380)
			else
				if ItemName(wpn) then
					local w_name = ItemName(wpn)
					local w_fname = w_name:gsub(" ", ""):lower().."_k"
					if FileExists("gfx/weapons/"..w_fname..".bmp") then
						parse('customkill '..source..' "'..w_name..',gfx/weapons/'..w_fname..'.bmp" '..id)
					else
						parse('customkill '..source..' "'..w_name..'" '..id)
					end
				elseif wpn == 0 then
					parse('customkill '..source..' "" '..id)
				else
					parse('customkill '..source..' "'..wpn..'" '..id)
				end
			end
		end
	end
end

function CreateHitAttachment(f)
	table.insert(hit_attachments, f)
end

function RemoveHitAttachment(f)
	for id, at in pairs(hit_attachments) do
		if at == f then
			hit_attachments[id] = nil
			break
		end
	end
end

function addhook(...)
	local arg = {...}
	if arg[1] and arg[2] then
		if arg[1] == "hit" then
			local func = _G[arg[2]]
			if func then
				return CreateHitAttachment(func)
			end
		end
	end
	return addon_hit_hook(...)
end

function freehook(...)
	local arg = {...}
	if arg[1] and arg[2] then
		if arg[1] == "hit" then
			local func = _G[arg[2]]
			if func then
				return RemoveHitAttachment(func)
			end
		end
	end
	return addon_hit_freehook(...)
end
