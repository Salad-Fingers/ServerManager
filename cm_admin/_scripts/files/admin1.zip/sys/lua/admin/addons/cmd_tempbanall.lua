CreateChat "@tempbanall" "<level required> [reason]" (30) [[
	if args >= 2 then
		local level = tonumber(s[2])
		local reason; if args >= 3 then reason = string.sub(txt, pos[3]) end
		
		if level then
			for _, p in pairs(player(0,"table")) do
				if PlayerLevel(p) < level then
					AddTempban(p, 20, id, reason)
				end
			end
		end
	end
]]