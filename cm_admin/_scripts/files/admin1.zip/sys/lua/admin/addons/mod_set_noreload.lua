addhook("attack","noreloadAttack")
function noreloadAttack(id)
	if SERVER_DATA["noreload"] then
		local w = player(id,"weapontype")
		if w > 0 then
			parse("equip "..id.." "..w)
		end
	end
end

addhook("buildattempt","noreloadBuild")
function noreloadBuild(id,t,x,y,m)
	if SERVER_DATA["noreload"] then
		if t == 20 then
			parse("equip "..id.." 77")
		elseif t == 21 then
			parse("equip "..id.." 87")
		end
	end
end

function NoreloadButton(id)
	if SERVER_DATA["noreload"] then
		return Translate(id, 286).."|"..Translate(id, 2)
	end
	return Translate(id, 286).."|"..Translate(id, 3)
end

function NoreloadToggle()
	if SERVER_DATA["noreload"] then
		SERVER_DATA["noreload"] = nil
		msg("trans:287@C")
	else
		SERVER_DATA["noreload"] = true
		msg("trans:288@C")
	end
end

CreateSetting(NoreloadButton, NoreloadToggle)

CreateConsole "sv_noreload" [[
	if args >= 2 then
		local mode = tonumber(s[2])
		if mode then
			if mode == 1 then
				if not SERVER_DATA["noreload"] then
					SERVER_DATA["noreload"] = true
					msg("trans:288@C")
				end
			elseif mode == 0 then
				if SERVER_DATA["noreload"] then
					SERVER_DATA["noreload"] = nil
					msg("trans:287@C")
				end
			end
		end
	end
]]
