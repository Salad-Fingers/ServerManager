CreateChat "!god" "" (15) [[
	USERTEMP[id]["god"] = not USERTEMP[id]["god"]
	if USERTEMP[id]["god"] then
		msgc2(id, Translate(id, 116), 0, 255)
	else
		msgc2(id, Translate(id, 117), 255)
	end
]]

CreateChat "!togglegod" "<id>" (25) [[
	local p = tonumber(s[2])
	if p and player(p,"exists") then
		if USERTEMP[p]["god"] then
			USERTEMP[p]["god"] = nil
			msgc2(id, Translate(id, 118, PlayerName(p)), 255)
			msg2(p, Translate(p, 119, PlayerName(id)))
		else
			USERTEMP[p]["god"] = true
			msgc2(id, Translate(id, 120, PlayerName(p)), 0, 255)
			msg2(p, Translate(p, 121, PlayerName(id)), 0, 255)
		end
	end
]]

function togglegod(id)
	USERTEMP[id]["god"] = not USERTEMP[id]["god"]
	if USERTEMP[id]["god"] then
		msgc2(id, Translate(id, 116), 0, 255)
	else
		msgc2(id, Translate(id, 117), 255)
	end
end

function godmodebutton(id)
	if USERTEMP[id]["god"] then
		return Translate(id, 122).."|"..Translate(id, 2)
	end
	return Translate(id, 122).."|"..Translate(id, 3)
end

function godhit(id,source)
	if USERTEMP[id]["god"] then
		return 1
	end
	if player(source, "exists") then
		if USERTEMP[source]["god"] then
			if PlayerLevel(source) < 25 then
				return 1
			end
		end
	end
end
CreateHitAttachment(godhit)
AddMenuButton(togglegod, godmodebutton, 15)
