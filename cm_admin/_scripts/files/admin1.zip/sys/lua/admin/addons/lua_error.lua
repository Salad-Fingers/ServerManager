error_log = {}

function error_get(e)
	local error_tab = {"("..math.floor(os.clock())..") "..e}
	for i = 1, 7 do
		if error_log[i] then
			error_tab[i+1] = error_log[i]
		end
	end
	error_log = error_tab
	print(string.char(169).."255000000LUA ERROR: "..e, 255, 0, 0)
end

function ProtectedCall(f,...)
	local r = {pcall(f, unpack(arg))}
	if r[1] then
		r[1] = nil
		return unpack(table.order(r))
	elseif not r[1] then
		error_get(r[2])
		return nil, r[2]
	end
end

function dofile(dir)
	local f, e = loadfile(dir)
	if f then
		ProtectedCall(f)
	elseif e then
		error_get(e)
	end
end