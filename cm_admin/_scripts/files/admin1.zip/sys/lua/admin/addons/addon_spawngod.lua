spawngod_time = 5000

addhook("spawn","spawn_god")
function spawn_god(id)
	USERTEMP[id]["spawnms"] = Millisecs()
	msgc2(id, Translate(id, 22, math.floor(spawngod_time/1000)), 0, 255, 0)
end

function spawn_godhit(id)
	if Millisecs() - USERTEMP[id]["spawnms"] <= spawngod_time then
		return 1
	end
end
CreateHitAttachment(spawn_godhit)
