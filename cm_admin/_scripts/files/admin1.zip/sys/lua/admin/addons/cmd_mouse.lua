-- !mouse
CreateChat "!mouse" "" (15)[[mouse_menu:OpenPlayer(id, 1)]]