addhook("use","AntiSupply")
function AntiSupply(id,o,button,x,y)
	if o==150 then
		if button == 7 or button == 8 or button == 9 then
			local objectlist = object(0,"table")
			for _, ido in pairs(objectlist) do
				if object(ido, "player") == id and object(ido,"typename")=="Supply" then
					if object(ido,"tilex") == x and object(ido,"tiley")==y then
						RankMSG(15, "trans:188("..PlayerName(id)..")", 255)
						break
					end
				end
			end
		end
	end
end
