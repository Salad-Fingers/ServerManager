CreateChat "@settrank" "<id> <rank> [days] [hours] [minutes]" (30) [[
	if args >= 3 then
		local p = tonumber(s[2])
		local rank = s[3]
		local days = tonumber(s[4]) or 0
		local hours = tonumber(s[5]) or 0
		local minutes = tonumber(s[6]) or 0

		local day_secs = days * 86400
		local hour_secs = hours * 3600
		local min_secs = minutes * 60

		local end_time = os.time() + min_secs + hour_secs + day_secs

		if p and rank then
			if player(p,"exists") then
				if SERVER_RANK[rank] then
					USER[p]["trdate"] = end_time
					USER[p]["trank"] = rank
					ServerMSG("trans:158("..PlayerName(id).."�"..PlayerName(p).."�"..RankPrefix(rank).."�"..os.date("%d", end_time).." "..os.date("%B", end_time).." "..os.date("%Y", end_time)..")")
				else
					ErrorMSG(id, Translate(id, 159, rank))
				end
			else
				ErrorMSG(id, Translate(id, 160))
			end
		end
	end
]]

CreateChat "@removetrank" "<id>" (30) [[
	if args >= 2 then
		local p = tonumber(s[2])
		if p and player(p,"exists") then
			if TempRank(p) then
				SetExpireRank(p)
			else
				ErrorMSG(id, Translate(id, 161))
			end
		else
			ErrorMSG(id, Translate(id, 160))
		end
	end
]]
