SERVER_DATA["iprangeban"] = SERVER_DATA["iprangeban"] or {}

function IPRangeBanned(ip)
	local ipAr = {ip:match('(%d+)%p(%d+)%p(%d+)%p(%d+)')}
	for aip, bool in pairs(SERVER_DATA["iprangeban"]) do
		local ipMatch = {aip:match('(%d+)%p(%d+)%p(%d+)%p(%d+)')}
		local matchCount = 0
		for i = 1, 4 do
			if ipMatch[i] == ipAr[i] then matchCount = matchCount + 1 end
		end
		if matchCount >= 3 then return true end
	end
end

function IPRangeBan(ip)
	SERVER_DATA["iprangeban"][ip] = true
	
	local p = IPPlayer(ip)
	if p then
		parse('kick '..p..' "IP. Range banned"')
	end
end

function IPRangeUnban(ip)
	if IPRangeBanned(ip) then
		local ipAr = {ip:match('(%d+)%p(%d+)%p(%d+)%p(%d+)')}
		for aip, bool in pairs(SERVER_DATA["iprangeban"]) do
			local ipMatch = {aip:match('(%d+)%p(%d+)%p(%d+)%p(%d+)')}
			local matchCount = 0
			for i = 1, 4 do
				if ipMatch[i] == ipAr[i] then matchCount = matchCount + 1 end
			end
			if matchCount >= 3 then
				SERVER_DATA["iprangeban"][aip] = nil
			end
		end
	end
end

addhook("join","iprange_kick")
function iprange_kick(id)
	if IPRangeBanned(player(id,"ip")) then
		parse('kick '..id..' "IP. Range detected"')
	end
end