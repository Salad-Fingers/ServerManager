safe_zone_hud = GenerateHud()
safe_zone_duration = 3

function last_safe_zone(id)
	return USERTEMP[id]["lastsafezone"] or 0
end

addhook("second","safezone_check_all")
function safezone_check_all()
	for _, id in pairs(player(0,"tableliving")) do
		safezone_check(id, player(id,"x"), player(id,"y"))
	end
end

addhook("move","safezone_check")
function safezone_check(id,x,y)
	if inSafeZone(math.floor(x/32), math.floor(y/32)) then
		Hudtxt2(id, safe_zone_hud, "SAFE ZONE", 15, 85)
		USERTEMP[id]["insafezone"] = true
		USERTEMP[id]["lastsafezone"] = os.clock()
	else
		local t = last_safe_zone(id) - os.clock() + safe_zone_duration
		if t > 0 then
			Hudtxt2(id, safe_zone_hud, Translate(id, 20, math.floor(t+1)), 15, 85)
		elseif USERTEMP[id]["insafezone"] then
			Freehud(id, safe_zone_hud)
			USERTEMP[id]["insafezone"] = nil
		end
	end
end

function safezone_hit(id,source,hpdmg,apdmg)
	if hpdmg + apdmg > 0 then
		if source and player(source,"exists") and USERTEMP[source]["insafezone"] then
			return 1
		elseif USERTEMP[id]["insafezone"] then
			return 1
		end
	end
end
CreateHitAttachment(safezone_hit)

function inSafeZone(x,y)
	for _, e in pairs(safe_zone_entity) do
		if x >= e[1] and y >= e[2] and x < e[3] and y < e[4] then
			return {x = e[1], y = e[2]}
		end
	end
end

safe_zone_entity = {}
function Init()
	for _, e in pairs(entitylist()) do
		if entity(e.x, e.y, "type") == 27 and entity(e.x, e.y, "int0") <= -100 then
			table.insert(safe_zone_entity, {e.x, e.y, e.x+entity(e.x, e.y, "int2"), e.y+entity(e.x, e.y, "int3")})
		end
	end
end
