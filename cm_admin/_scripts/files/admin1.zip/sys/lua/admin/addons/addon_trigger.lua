luamap_triggers = {}

function AddLevelTrigger(button,trigger,lvl)
	luamap_triggers[button] = {trigger = trigger,lvl = lvl}
end

addhook("use","buttonUse")
function buttonUse(id,event,data,x,y)
	if event == 100 then
		local button_name = entity(x, y, "name")
		local lua_trigger = luamap_triggers[button_name]
		if lua_trigger then
			if PlayerLevel(id) >= lua_trigger.lvl then
				parse("trigger "..lua_trigger.trigger)
			end
		end
	end
end