CreateChat "!modbc" "[text]" (30) [[
	if args >= 2 then
		local mbc = string.sub(txt, pos[2])
		local usgnlist = getRanklistLevel(15)
		for _, u in pairs(usgnlist) do
			if USGNDataExists(u) then
				--local p = USGNPlayer(u)
				--if p then
				--	msgc2(p, "[MOD BC]: "..Color(255,255,0)..mbc, 100, 100, 100)
				--else
					table.insert(USGN[u]["pm"], Color(100,100,100).."[MOD BC]: "..Color(255,255,0)..mbc)
					SaveUSGN(u)
				--end
			end
		end
	end
]]