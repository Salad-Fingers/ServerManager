CreateChat "!speed" "<speed>" (5) [[
	local sp = tonumber(s[2])
	if sp then
		parse("speedmod "..id.." "..sp)
	end
]]