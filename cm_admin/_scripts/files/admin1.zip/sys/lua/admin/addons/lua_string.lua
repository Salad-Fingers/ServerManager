function string.split(txt,d)
	if not d then d = " " end
	local split = {}
	local splitpos = {}
	local lastPos = 1
	for i = 1, string.len(txt)+1 do
		if string.sub(txt,i,i+string.len(d)-1) == d or i == string.len(txt)+1 then
			local newSplit = string.sub(txt,lastPos,i-1)
			table.insert(split,newSplit)
			table.insert(splitpos, lastPos)
			lastPos = i + string.len(d)
		end
	end
	return split, splitpos
end

function string.findString(str)
	local f = string.find(str, '"')
	if f then
		local f2 = string.find(string.sub(str, f+1), '"')
		if f2 then
			return string.sub(str, f+1, f2+f - 1), f2+f+1
		end
	end
end

function string.getStrings(str)
	local t = {}
	local st, f = string.findString(str)
	while st and f do
		table.insert(t, st)
		str = string.sub(str, f)

		st, f = string.findString(str)
	end
	return t
end