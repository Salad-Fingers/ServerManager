CreateChat "@kick" "<id> [reason]" (15) [[
	if args >= 2 then
		local p = tonumber(s[2])
		local reason = "";
		if args >= 3 then
			reason = string.sub(txt, pos[3])
		end

		if p and player(p,"exists") then
			if RankLower(PlayerRank(p), PlayerRank(id)) then
				if string.len(reason) > 0 then
					for _, pid in pairs(player(0,"table")) do
						ServerMSG2(pid, Translate(pid, 125, PlayerName(id), PlayerName(p), reason))
					end
					parse('kick '..p..' "'..reason..'"')
				else
					for _, pid in pairs(player(0,"table")) do
						ServerMSG2(pid, Translate(pid, 126, PlayerName(id), PlayerName(p)))
					end
					parse("kick "..p)
				end
			else
				ErrorMSG(id, Translate(id, 95))
			end
		elseif not p then
			kick_menu:OpenPlayer(id, 1)
		end
	end
]]
