if stream_dll_loaded then
	if not toboolean(ADDONSET["connect_irc"]) then
		return nil
	end

	local function game_version()
		local f = io.open("sys/core/version.cfg", "r")
		local ver = f:read("*a")
		f:close()

		ver = string.sub(ver,1,string.len(ver)-1)
		ver = string.gsub(ver, " ", "")
		ver = string.gsub(ver, "%p", "")
		return ver
	end

	local function game_irc_nick()
		local name = game("sv_name")
		name = string.gsub(name, " ", "")
		return name
	end

	IRC = {}

	--[[ Modifiable data ]]--
	IRC.Nick = game_irc_nick() -- Nick in chat
	IRC.Server = "irc.quakenet.org" -- IRC server IP
	IRC.Chan = "#cs2d" -- IRC server channel
	IRC.Port = 6667 -- IRC server port

	-- CS2D stuff
	IRC.UserName = game_version()
	IRC.RealName = "Counter-Strike 2D"

	--[[ DO NOT MODIFY ]]--
	IRC.InChan = false
	IRC.InChat = false
	IRC.Disconnected = false

	function IRC.Connect()
		IRC.Disconnected = false

		for _, id in pairs(player(0,"table")) do
			msgc2(id, "[IRC]: "..Color(255,255,0)..Translate(id, 9), 255)
		end
		if IRC.Stream then
			CloseTCPStream(IRC.Stream)
		end

		IRC.Stream = OpenTCPStream(IRC.Server, IRC.Port)

		if IRC.Stream then
			IRC.InChan = false
			IRC.InChat = false
			WriteLine(IRC.Stream,"USER "..IRC.UserName.." localhost "..IRC.Server.." :"..IRC.RealName)
			WriteLine(IRC.Stream,"NICK "..IRC.Nick)
			WriteLine(IRC.Stream,"PONG ")
			for _, id in pairs(player(0,"table")) do
				msgc2(id, "[IRC]: "..Color(255,255,0)..Translate(id, 6), 255)
			end
		else
			for _, id in pairs(player(0,"table")) do
				msgc2(id, "[IRC]: "..Color(255,255,0)..Translate(id, 7), 255)
			end
		end
	end

	function IRC.Disconnect()
		if IRC.Stream then
			CloseTCPStream(IRC.Stream)
			IRC.Stream = nil
		end
	end

	function Mid(str,l1,l2)
		l2 = l2 or -1
		if l2 < 0 then
			return string.sub(str,l1,string.len(str)-l2+1)
		else
			return string.sub(str,l1,l1+l2)
		end
	end

	function Instr(str,txt)
		return string.find(str,txt) or 0
	end

	function Left(str,dist)
		return string.sub(str,1,dist)
	end

	function IRC.Send(msg)
		if not IRC.Stream then return 0 end
		if not TCPStreamConnected(IRC.Stream) then return 0 end
		WriteLine(IRC.Stream,msg)
		return 1
	end

	function IRC.Get()
		if not IRC.Stream then return nil end
		if not TCPStreamConnected(IRC.Stream) then return nil end
		if ReadAvail(IRC.Stream) then
			local fullResp = ReadLine(IRC.Stream)
			local resp = fullResp
			local s = resp:split()
			if s[1] == "PING" then
				WriteLine(IRC.Stream,"PONG "..string.sub(s[2],2))
				return nil
			end

			local br = {}

			if string.sub(resp,1,1) == ":" then resp = string.sub(resp,2) end
			br[1] = Instr(resp,":")
			local cmsg; if br[1] == 0 then cmsg = resp else cmsg = Mid(resp,br[1]+1,-2) end

			-- Analyze
			local irca_def = Mid(resp,1,br[1]-1)

			-- First string
			br[2] = Instr(irca_def," ")
			local irca_fstring = Mid(irca_def,1,br[2]-1)

			-- Nick
			br[3] = Instr(irca_def,"!")
			local irca_nick = ""
			if br[3] > 0 then
				irca_nick = irca_def
				while br[3] > 0 do
					irca_nick = string.sub(irca_nick,1,br[3]-1)
					br[3] = Instr(irca_nick,"!")
				end
			end

			-- Command
			br[4] = Instr(resp," ",br[2]+1)
			local irca_com
			if br[4] == 0 then irca_com = "" else irca_com = Mid(resp,br[2]+1,-1) end

			-- Command Parameter
			br[5] = Instr(irca_com," ")
			local irca_comp
			if br[5] == 0 then irca_comp = "" else
				irca_comp = Mid(irca_com,br[5]+1,-1)
				if Left(irca_comp,1) == ":" then irca_comp = Mid(irca_comp,2,-1) end
			end

			-- Normal chat
			if Instr(irca_def,"PRIVMSG") > 0 then
				if Left(cmsg,7) == "ACTION" then
					msg(irca_nick..": "..Mid(cmsg,9,-1))
				else
					for _, id in pairs(player(0,"table")) do
						msgc2(id, Translate(id, 13, irca_nick..Color(255,0,255)).." "..Color(255,255,0)..cmsg, 255, 255, 255)
					end
				end
				return nil
			elseif Instr(irca_def,"NOTICE") > 0 then
				msgc("* "..Color(255,255,255)..irca_nick..Color(255,0,255).." Notice: "..Color(255,255,0)..cmsg, 255, 0, 255)
				return nil
			elseif Left(irca_com,4) == "JOIN" then
				for _, id in pairs(player(0,"table")) do
					msgc2(id, Translate(id, 10, irca_nick..Color(255,255,0)), 255, 255, 255)
				end
				return nil
			elseif Left(irca_com,4) == "PART" then
				for _, id in pairs(player(0,"table")) do
					msgc2(id, Translate(id, 11, irca_nick..Color(255,255,0)), 255, 255, 255)
				end
				return nil
			elseif Left(irca_com,4) == "QUIT" then
				for _, id in pairs(player(0,"table")) do
					msgc2(id, Translate(id, 11, irca_nick..Color(255,255,0)), 255, 255, 255)
				end
				return nil
			elseif Left(irca_com,4) == "MODE" then
				for _, id in pairs(player(0,"table")) do
					msgc2(id, Translate(id, 12, irca_nick..Color(255,255,0)).." "..irca_comp, 255, 255, 255)
				end
				return nil
			end
			return cmsg
		end
	end

	addhook("always","IRC.Always")
	function IRC.Always()
		if IRC.Stream then
			local line = IRC.Get()
			if line then
				if string.find(line,"End of") and string.find(line,"MOTD") then
					IRC.InChat = true
					WriteLine(IRC.Stream,"JOIN "..IRC.Chan)
					WriteLine(IRC.Stream,"NAMES "..IRC.Chan)
				end
			end

			if not TCPStreamConnected(IRC.Stream) and not IRC.Disconnected then
				for _, id in pairs(player(0,"table")) do
					msgc2(id, "[IRC]: "..Color(255,255,0)..Translate(id, 8), 255)
				end
				IRC.Disconnected = true
			end
		end
	end

	function PlayerIRC(id,txt)
		IRC.Send("PRIVMSG "..IRC.Chan.." :"..player(id,"name")..": "..txt)
	end

	CreateChat "!irc" "[message]" (0) [[
		if IRC.Stream and TCPStreamConnected(IRC.Stream) then
			if IRC.InChat then
				local irc_msg = string.sub(txt, 6)
				if string.len(irc_msg) > 0 then
					if not USERIP[player(id,"ip")]["mute"] then
						PlayerIRC(id, irc_msg)
						msg(PlayerName(id).." "..Color(138, 43, 226).." -> IRC: "..Color(255,255,0)..irc_msg)
					else
						ErrorMSG(id, Translate(id, 14))
					end
				else
					ErrorMSG(id, Translate(id, 15))
				end
			else
				ErrorMSG(id, Translate(id, 16, IRC.Chan))
			end
		else
			ErrorMSG(id,"IRC is offline")
		end
	]]

	CreateChat "!ircreset" "" (30) [[
		if not IRC.Stream or not TCPStreamConnected(IRC.Stream) then
			IRC.Stream = nil
			IRC.Connect()
		else
			ErrorMSG(id, Translate(id, 17))
		end
	]]

	CreateChat "!ircquit" "" (30) [[
		if IRC.Stream and TCPStreamConnected(IRC.Stream) then
			CloseTCPStream(IRC.Stream)
			IRC.Stream = nil
		else
			ErrorMSG(id, Translate(id, 17))
		end
	]]

	IRC.Connect()
end
