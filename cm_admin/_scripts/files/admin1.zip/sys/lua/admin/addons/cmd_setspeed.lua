CreateChat "!setspeed" "<id> <speed>" (20) [[
	local p = tonumber(s[2])
	local sp = tonumber(s[3])
	if p and player(p,"exists") then
		parse("speedmod "..p.." "..sp)
	end
]]