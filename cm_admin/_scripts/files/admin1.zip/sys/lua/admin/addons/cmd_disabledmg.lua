CreateChat "!toggledmg" "<id>" (26) [[
	if args >= 2 then
		local p = tonumber(s[2])
		if p and player(p,"exists") then
			if not USERTEMP[p]["disableddmg"] then
				USERTEMP[p]["disableddmg"] = true
				for _, pid in pairs(player(0,"table")) do
					ServerMSG2(pid, Translate(pid, 108, PlayerName(id), PlayerName(p)))
				end
			else
				USERTEMP[p]["disableddmg"] = nil
				for _, pid in pairs(player(0,"table")) do
					ServerMSG2(pid, Translate(pid, 109, PlayerName(id), PlayerName(p)))
				end
			end
		end
	end
]]

function anti_dmg(id,source)
	if source and player(source,"exists") then
		if USERTEMP[source]["disableddmg"] then
			return 1
		end
	end
end
CreateHitAttachment(anti_dmg)
