CreateChat "@servermsg" "[text]" (30) [[
	if args >= 2 then
		local text = string.sub(txt, pos[2])
		if string.len(text) > 0 then
			ServerMSG(text)
		end
	end
]]