CreateChat "!help" "[command name]" (0) [[
	if args >= 2 then
		local command_name = string.sub(txt, pos[2])
		local v = CHAT_CMD[command_name]
		if v then
			if PlayerLevel(id) >= v.lvl then
				msgc2(id, "["..Translate(id, 124).."] "..command_name.." "..v.params, 0, 255)
			end
		else
			ErrorMSG(id, Translate(id, 123, command_name))
		end
	else
		local i = 0
		for k, v in pairs(CHAT_CMD) do
			if not v.hidden then
				if PlayerLevel(id) >= v.lvl then
					i = i + 100
					AddTimer(i, false, msgc2, id, "["..Translate(id, 124).."] "..k.." "..v.params, 0, 255)
				end
			end
		end
	end
]]
