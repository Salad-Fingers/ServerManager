CreateChat "!speclock" "<id> <minutes> [reason]" (10) [[
	if args >= 2 then
		local p = tonumber(s[2])
		local mins = tonumber(s[3])
		local reason
		if args >= 4 then
			reason = string.sub(txt, pos[4])
		end

		if PlayerLevel(p) < PlayerLevel(id) then
			if p and player(p,"exists") and mins and mins > 0 then
				SpeclockPlayer(p, mins)
				if reason then
					ServerMSG("trans:164("..PlayerName(id).."�"..PlayerName(p).."�"..mins.."�"..reason..")")
				else
					ServerMSG("trans:165("..PlayerName(id).."�"..PlayerName(p).."�"..mins..")")
				end
			end
		else
			ErrorMSG(id, Translate(id, 166))
		end
	end
]]

CreateChat "!unspeclock" "<id>" (15) [[
	local p = tonumber(s[2])
	if p and player(p,"exists") then
		if PlayerSpeclocked(p) then
			ServerMSG("trans:167("..PlayerName(id).."�"..PlayerName(p)..")")
			SpeclockPlayer(p, 0)
		end
	end
]]

function SpeclockPlayer(id,mins)
	if mins <= 0 then
		USERIP[player(id,"ip")]["speclock"] = nil
	else
		USERIP[player(id,"ip")]["speclock"] = os.time() + mins*60
		parse("makespec "..id)
	end
end

function PlayerSpeclocked(id)
	local t = USERIP[player(id,"ip")]["speclock"]
	if t then
		return os.time() <= t
	end
end

function SpeclockBan(id,team)
	if PlayerSpeclocked(id) and team > 0 then
		ErrorMSG(id, Translate(id, 168))
		parse("makespec "..id)
		return 1
	end
end
CreateTeamAttachment(SpeclockBan)
