CreateChat "@broadcast" "[text]" (30) [[
	if args >= 2 then
		local text = string.sub(txt, pos[2])
		if string.len(text) > 0 then
			ServerBroadcast(text)
		end
	end
]]