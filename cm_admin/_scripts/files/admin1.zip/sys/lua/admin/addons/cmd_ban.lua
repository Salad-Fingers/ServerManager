-- !ban [id]

CreateChat "@ban" "<id>" (20) [[
	local p = tonumber(s[2])
	if p and player(p,"exists") and not player(p,"bot") then
		if PlayerLevel(p) < PlayerLevel(id) then
			for _, pid in pairs(player(0,"table")) do
				ServerMSG2(pid, Translate(pid, 94, PlayerName(id), PlayerName(p)))
			end

			local name = player(p,"name")
			local ip = player(p,"ip")
			local usgn = player(p,"usgn")

			parse('banname "'..name..'"')
			if ip ~= "0.0.0.0" then
				parse('banip "'..ip..'"')
			end

			if usgn > 0 then
				parse('banusgn "'..usgn..'"')
			end
		else
			ErrorMSG(id, Translate(id, 95))
		end
	end
]]

CreateChat "@ipban" "[ip]" (20) [[
	if args >= 2 then
		local ip = s[2]
		if ip then
			local pl = IPPlayer(ip)
			if pl then
				if PlayerLevel(pl) < PlayerLevel(id) then
					for _, pid in pairs(player(0,"table")) do
						ServerMSG2(pid, Translate(pid, 94, PlayerName(id), PlayerName(pl)))
					end
					parse('banip "'..ip..'"')
				else
					ErrorMSG(id, Translate(id, 95))
				end
			else
				ErrorMSG(id, Translate(id, 96))
			end
		end
	end
]]

CreateChat "@usgnban" "<usgn>" (20) [[
	if args >= 2 then
		local usgn = tonumber(s[2])
		if usgn then
			local pl = USGNPlayer(usgn)
			if pl then
				if PlayerLevel(pl) < PlayerLevel(id) then
					for _, pid in pairs(player(0,"table")) do
						ServerMSG2(pid, Translate(pid, 94, PlayerName(id), PlayerName(pl)))
					end
					parse('banusgn "'..usgn..'"')
				else
					ErrorMSG(id, Translate(id, 95))
				end
			else
				ErrorMSG(id, Translate(id, 97))
			end
		end
	end
]]

CreateChat "@nameban" "[name]" (20) [[
	if args >= 2 then
		local name = string.sub(txt, pos[2])
		if name then
			local pl = NamePlayer(name)
			if pl then
				if PlayerLevel(pl) < PlayerLevel(id) then
					for _, pid in pairs(player(0,"table")) do
						ServerMSG2(pid, Translate(pid, 94, PlayerName(id), PlayerName(pl)))
					end
					parse('banname "'..name..'"')
				else
					ErrorMSG(id, Translate(id, 95))
				end
			else
				ErrorMSG(id, Translate(id, 98))
			end
		end
	end
]]

function BanList()
	ban_requested = true
	parse("bans")
	return ban_list
end

ban_count = 0
ban_requested = false
ban_counting = false

addhook("log","ban_logger")
function ban_logger(txt)
	if ban_requested then
		if txt == "----- List of Bans -----" then
			return 1
		elseif string.sub(txt, 1, 11) == "bans total:" then
			ban_list = {}
			ban_counting = true
			ban_count = tonumber(string.sub(txt, 13))
			return 1
		elseif ban_counting and string.sub(txt, 1, 2) == "* " then
			txt = string.sub(txt, 3)

			ban_count = ban_count - 1

			local ban_type
			local ban_id
			if string.sub(txt, 1, 7) == "USGN ID" then
				ban_id = tonumber(string.sub(txt, 10))
				ban_type = "usgn"
			elseif string.sub(txt, 1, 2) == "IP" then
				ban_id = string.sub(txt, 4)
				ban_type = "ip"
			elseif string.sub(txt, 1, 4) == "Name" then
				ban_id = string.sub(txt, 6)
				ban_type = "name"
			end

			-- Temporal ban?
			if string.find(txt, "%(temp") then
				local tban_id
				local tban_time
				local tban_reason

				if ban_type == "usgn" then
					tban_id = string.sub(txt, 10, txt:find("%(temp")-2)
				elseif ban_type == "ip" then
					tban_id = string.sub(txt, 4, txt:find("%(temp")-2)
				elseif ban_type == "name" then
					tban_id = string.sub(txt, 6, txt:find("%(temp")-2)
				end
				tban_time, tban_reason = txt:match('%(temp, (%d+) sec%) %[(.+)%]')

				table.insert(ban_list, {t = ban_type,id = tban_id,extra = tban_reason.." ("..tban_time.." secs.)"})
			elseif ban_type and ban_id then
				table.insert(ban_list, {t = ban_type,id = ban_id,extra=""})
			end

			if ban_count <= 0 then
				ban_counting = false
				ban_requested = false
			end
			return 1
		end
	end
end

player_unban_menu = CreateMenu("350@b")
function player_unban_menu:getcustombutton(b,id,def)
	if ban_list[b] then
		local but = ban_list[b]
		if but.t == "usgn" then
			return "USGN ID #"..but.id.."|"..but.extra
		elseif but.t == "ip" then
			return "IP "..but.id.."|"..but.extra
		elseif but.t == "name" then
			return Translate(id, 99).." "..FixedName(but.id).."|"..but.extra
		end
	end
end

function player_unban_menu:click(id,b,page)
	if ban_list[b] then
		local but = ban_list[b]
		if but.t == "usgn" then
			parse("unban "..but.id)
		elseif but.t == "name" then
			parse('unban "'..but.id..'"')
		elseif but.t == "ip" then
			parse("unban "..but.id)
		end

		player_unban_menu:OpenPlayer(id, 1)
		BanList()
	end
end

function player_unban_menu:OpenPlayer(id,page)
	BanList()
	local page = page or 1
	menu(id, player_unban_menu.title.." | Page "..page.."@b,"..player_unban_menu:PageText(page, id))
end

AddMenu(player_unban_menu, 25)
