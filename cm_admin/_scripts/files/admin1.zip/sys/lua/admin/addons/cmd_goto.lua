CreateChat "!goto" "<id>" (15)[[
	local p = tonumber(s[2])
	if p and player(p,"exists") and player(p,"health") > 0 then
		if player(id,"health") > 0 then
			parse("setpos "..id.." "..player(p,"x").." "..player(p,"y"))
		elseif player(id,"team") > 0 then
			parse("spawnplayer "..id.." "..player(p,"x").." "..player(p,"y"))
		end
	elseif not p then
		goto_menu:OpenPlayer(id, 1)
	end
]]

goto_menu = CreateMenu("Go to")
function goto_menu:getcustombutton(b)
	return player(b,"name")
end

function goto_menu:click(id,b,p)
	if player(b,"exists") and player(b,"health") > 0 then
		if player(id,"health") > 0 then
			parse("setpos "..id.." "..player(b,"x").." "..player(b,"y"))
		elseif player(id,"team") > 0 then
			parse("spawnplayer "..id.." "..player(b,"x").." "..player(b,"y"))
		end
	end
end