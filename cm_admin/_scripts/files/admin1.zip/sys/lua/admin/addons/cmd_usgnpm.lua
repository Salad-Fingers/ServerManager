USGN_DEFAULTDATA["pm"] = {}

function USGNPM(usgnid,txt)
	if USGNDataExists(usgnid) then
		table.insert(USGN[usgnid]["pm"], txt)
		SaveUSGN(usgnid)
	end
end

CreateChat "!usgnpm" "<usgn> [text]" (0) [[
	if args >= 3 then
		local u = tonumber(s[2])
		local text = string.sub(txt, pos[3])

		if u then
			if string.len(text) > 0 then
				local p = USGNPlayer(u)
				if p then
					if p ~= id then
						msgc2(id, "["..Translate(id, 147).."] "..PlayerName(p)..": "..text, 255, 255, 0)
						msgc2(p, "["..Translate(p, 174).."] "..PlayerName(id)..": "..text, 255, 255, 0)
					else
						ErrorMSG(id, Translate(id, 146))
					end
				else
					if USGNDataExists(u) then
						msgc2(id, "[trans:147()] #"..u..": "..text, 255, 255, 0)
						table.insert(USGN[u]["pm"], Color(255,255,0).."[trans:148()] "..PlayerName(id).." #"..player(id,"usgn")..": "..text)
						SaveUSGN(u)
					else
						ErrorMSG(id, Translate(id, 178))
					end
				end
			else
				ErrorMSG(id, Translate(id, 176))
			end
		else
			ErrorMSG(id, Translate(id, 177))
		end
	end
]]

CreateChat "!checkpm" "" (0) [[
	if #USER[id]["pm"] > 0 then
		local i = 0
		for k, text in pairs(USER[id]["pm"]) do
			USER[id]["pm"][k] = nil
			i = i + 100
			AddTimer(i, false, msg2, id, text)
		end
	else
		ErrorMSG(id, Translate(id, 179))
	end
]]

addhook("join","player_count_pms")
function player_count_pms(id)
	if player(id, "usgn") > 0 then
		if not USER[id]["pm"] then USER[id]["pm"] = {} end
		local pm_count = #USER[id]["pm"]
		if pm_count > 0 then
			msgc2(id, Translate(id, 180, pm_count), 0, 255)
			msgc2(id, Translate(id, 181), 0, 255)
		end
	end
end
