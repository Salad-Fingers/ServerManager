CreateChat "@bancaps" "<id>" (30) [[
	if args >= 2 then
		local p = tonumber(s[2])
		if p and player(p,"exists") then
			USER[p]["banuc"] = true
			ServerMSG("trans:170("..PlayerName(id).."�"..PlayerName(p)..")")
		end
	end
]]

CreateChat "@unbancaps" "<id>" (30) [[
	if args >= 2 then
		local p = tonumber(s[2])
		if p and player(p,"exists") then
			USER[p]["banuc"] = nil
			ServerMSG("trans:171("..PlayerName(id).."�"..PlayerName(p)..")")
		end
	end
]]

CreateChat "!tag" "" (1)[[
	if USER[id]["tag"] then
		msgc2(id, Translate(id, 172), 255, 0, 0)
		USER[id]["tag"] = nil
	else
		msgc2(id, Translate(id, 173), 0, 255, 0)
		USER[id]["tag"] = true
	end
]]

CreateChat "@say" "[text]" (1)[[
	if args >= 2 then
		local text = string.sub(txt, pos[2])
		if string.len(text) > 0 then
			USER[id]["tag"] = true
			AM.Say(id, text)
			USER[id]["tag"] = nil
		end
	end
]]
