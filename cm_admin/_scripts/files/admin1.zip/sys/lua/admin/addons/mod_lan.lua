USGN_DEFAULTDATA["lan"] = "en"

Language = {}
Translation = {}
CountryLanguage = {}

lan_menu = CreateMenu(349)
function lan_menu:getcustombutton(b,id)
	if Language[b] then
		return Language[b].Name
	end
end

function lan_menu:click(id,b)
	if Language[b] then
		USER[id]["lan"] = Language[b].Type
	end
end
AddMenu(lan_menu, 0)

function Translate(id, msgid,...)
	if Translation[USER[id]["lan"]] then
		if #{...} > 0 then
			return string.format(Translation[USER[id]["lan"]][msgid], ...)
		end
		return Translation[USER[id]["lan"]][msgid]
	elseif Translation[USGN_DEFAULTDATA["lan"]] then
		return Translation[USGN_DEFAULTDATA["lan"]][msgid]
	end
end

function TranslationID(trans, lanid)
	if Translation[lanid] then
		for id, sentence in pairs(Translation[lanid]) do
			if trans == sentence then
				return id, lanid
			end
		end
	end

	for lan, sentence_tab in pairs(Translation) do
		if not lanid or lan ~= lanid then
			for id, sentence in pairs(sentence_tab) do
				if trans == sentence then
					return id, lan
				end
			end
		end
	end
end

function LoadTranslations(i)
	local f = ReadStream(mod_path.."lan/"..Language[i].Type..".txt")
	if f then
		while not Eof(f) do
			local s = ReadLine(f):split("=")
			local TranslationID = tonumber(s[1])
			local Sentence = s[2]
			if TranslationID and Sentence then
				if not Translation[Language[i].Type] then Translation[Language[i].Type] = {} end
				Translation[Language[i].Type][TranslationID] = Sentence
			end
		end
		CloseStream(f)
	end
end

function LoadLanguages()
	local f = ReadStream(mod_path.."translations.txt")
	if f then
		while not Eof(f) do
			local s = ReadLine(f):split("|")
			if s then
				local name = s[1]
				local lang = s[2]
				if name and lang and name:len() > 0 and lang:len() > 0 then
					print("Initializing language "..name)
					table.insert(Language, {Name = name,Type = lang})

					if #s > 2 then
						for i = 2, #s do
							CountryLanguage[s[i]] = {name, lang}
						end
					end
				end
			end
		end
		CloseStream(f)
	else
		print("Failed to load languages, closing server")
		parse("quit")
	end

	for i = 1, #Language do
		LoadTranslations(i)
	end
end; LoadLanguages()

addhook("spawn","ChooseLanguage")
function ChooseLanguage(id,team)
	if not USER[id]["lanset"] then
		local Lan = CountryLanguage[PlayerCountry(id)]
		if Lan and Lan[2] ~= USGN_DEFAULTDATA["lan"] then
			msg2(id, Translate(id, 364, Lan[1]))
			lan_menu:OpenPlayer(id, 1)
			USER[id]["lanset"] = true
		end
	end
end
