CreateChat "!tp" "<x> <y>" (16) [[
	if args >= 3 then
		local x = tonumber(s[3])
		local y = tonumber(s[4])
		if x and y then
			if player(id,"health") > 0 then
				parse("setpos "..id.." "..x.." "..y)
			else
				parse("spawnplayer "..id.." "..x.." "..y)
			end
		end
	end
]]