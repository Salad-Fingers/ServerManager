CreateChat "!findusgn" "<usgn>" (16) [[
	if args >= 2 then
		local usgn = tonumber(s[2])
		if usgn then
			local p = USGNPlayer(usgn)
			if p then
				msgc2(id, Translate(id, 113, PlayerName(p), usgn), 0, 255)
			else
				msgc2(id, Translate(id, 114, usgn), 255)
			end
		end
	end
]]
