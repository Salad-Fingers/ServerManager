spawnobject_menu = CreateMenu(231)

-- Spawn object menu
building_name = {}
building_name[1] = "Barricade"
building_name[2] = "Barbed Wire"
building_name[3] = "Wall I"
building_name[4] = "Wall II"
building_name[5] = "Wall III"
building_name[6] = "Gate Field"
building_name[7] = "Dispenser"
building_name[8] = "Turret"
building_name[9] = "Supply"
building_name[10] = "Build Place"
building_name[11] = "Dual Turret"
building_name[12] = "Triple Turret"
building_name[13] = "Teleporter Entrance"
building_name[14] = "Teleporter Exit"
building_name[15] = "Super Supply"
building_name[16] = "Orange Portal"
building_name[17] = "Blue Portal"

function spawnobject_menu:getcustombutton(b)
	return building_name[b]
end

function spawnobject_menu:click(id,b,p)
	if b > 0 then
		if building_name[b] and b <= 15 then
			USERTEMP[id]["buildobject"] = b
		elseif b == 16 then
			USERTEMP[id]["buildobject"] = 22
		elseif b == 17 then
			USERTEMP[id]["buildobject"] = 23
		end
	end
end

function spawn_obj_func_event(id,x,y)
	if USERTEMP[id]["buildobject"] and USERTEMP[id]["buildobject"] > 0 then
		parse("spawnobject "..USERTEMP[id]["buildobject"].." "..math.floor(x/32).." "..math.floor(y/32).." 0 0 "..player(id,"team").." "..id)
	end
	USERTEMP[id]["mouseevent"] = nil
end
spawn_obj_event = CreateMouseEvent(spawn_obj_func_event); spawn_obj_func_event = nil

CreateMouseFunc("trans:231", spawn_obj_event,
	function (id)
		spawnobject_menu:OpenPlayer(id, 1)
	end
, 20)
