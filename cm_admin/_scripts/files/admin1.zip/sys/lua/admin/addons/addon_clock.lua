clock_hud = GenerateHud()

addhook("second","ClockDraw")
function ClockDraw()
	if SERVER_DATA["clock"] then
		for _, id in pairs(player(0,"table")) do
			Hudtxt2(id, clock_hud, Translate(id, 1, os.date()), 200, 430, 0, 100, 255)
		end
	end
end

function ClockButton()
	if SERVER_DATA["clock"] then
		return "Clock|Enabled"
	end
	return "Clock|Disabled"
end

function ClockToggle()
	if SERVER_DATA["clock"] then
		SERVER_DATA["clock"] = nil
		Freehud(0, clock_hud)
	else
		SERVER_DATA["clock"] = true
	end
end

CreateSetting(ClockButton, ClockToggle)
