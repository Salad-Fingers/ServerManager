function mouse_botgrab_func_event(id,x,y)
	if USERTEMP[id]["targetbot"] then
		USERTEMP[id]["targetbot"] = nil
		USERTEMP[id]["mouseevent"] = nil
		msgc2(id, "Dropped bot", 255)
	else
		USERTEMP[id]["mouseevent"] = nil

		for _, p in pairs(player(0,"table")) do
			if math.sqrt((x-player(p,"x"))^2 + (y-player(p,"y"))^2) < 32 and player(p,"bot") then
				msgc2(id, "Grabed bot", 0, 255)
				USERTEMP[id]["targetbot"] = p
				USERTEMP[id]["mouseevent"] = mouse_botmove_event
				break
			end
		end
	end
end

function mouse_botmove_func_event(id,x,y)
	local p = USERTEMP[id]["targetbot"]
	if p and player(p,"exists") and player(p,"health") > 0 then
		USERTEMP[p]["bot_aim"] = {x = x,y = y}
		USERTEMP[p]["bot_move"] = {x = math.floor(x/32),y = math.floor(y/32)}
	elseif USERTEMP[id]["targetbot"] then
		USERTEMP[id]["mouseevent"] = nil
		USERTEMP[id]["targetbot"] = nil
		msgc2(id, Translate(id, 222), 255)
	else
		USERTEMP[id]["mouseevent"] = nil
		msgc2(id, Translate(id, 222), 255)
	end
end

mouse_botgrab_event = CreateMouseEvent(mouse_botgrab_func_event); mouse_botgrab_func_event = nil
mouse_botmove_event = CreateMouseEvent(mouse_botmove_func_event); mouse_botmove_func_event = nil

CreateMouseFunc("trans:223", mouse_botgrab_event, nil, 30)

function botsay_func(id,txt)
	local p = USERTEMP[id]["targetbot"]
	if p and player(p,"exists") then
		ai_say(p, txt)
		return 1
	end
end
CreateChatAttachment(botsay_func)

addhook("always","update_bot_target")
function update_bot_target()
	for _, id in pairs(player(0,"table")) do
		if player(id,"bot") then
			if USERTEMP[id]["bot_move"] then
				if player(id,"tilex") ~= USERTEMP[id]["bot_move"]["x"] or player(id,"tiley") ~= USERTEMP[id]["bot_move"]["y"] then
					ai_goto(id, USERTEMP[id]["bot_move"]["x"], USERTEMP[id]["bot_move"]["y"])
				else
					USERTEMP[id]["bot_move"] = nil
				end
			end

			if USERTEMP[id]["bot_aim"] then
				ai_aim(id, USERTEMP[id]["bot_aim"]["x"], USERTEMP[id]["bot_aim"]["y"])
			end
		end
	end
end
