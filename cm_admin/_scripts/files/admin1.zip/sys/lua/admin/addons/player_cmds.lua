CHAT_CMD = {}
CHAT_ATTACHMENT = {}
addon_say_hook = addhook
addon_say_freehook = freehook

SERVER_DATA["disabled_cmd"] = SERVER_DATA["disabled_cmd"] or {}

addhook("say","AM.Say")
function AM.Say(id,txt)
	if txt == "rank" then
		return 0
	end

	if string.sub(txt, -2) == "@C" then
		txt = string.sub(txt, 1, -3)
	end

	local ret = 0
	if string.sub(txt, 1, 1) == "!" or string.sub(txt, 1, 1) == "@" then
		local s, sp = txt:split()
		local command_name = s[1]
		local command_table = CHAT_CMD[command_name]
		if command_table then
			if not SERVER_DATA["disabled_cmd"][command_name] then
				if PlayerLevel(id) >= command_table.lvl then
					ProtectedCall(command_table.f, id, txt, s, sp, #s)
				else
					ErrorMSG(id, Translate(id, 308))
				end
			else
				ErrorMSG(id, Translate(id, 309))
			end
		else
			ErrorMSG(id, Translate(id, 310, command_name))
		end
		ret = 1
	end

	for _, f in pairs(CHAT_ATTACHMENT) do
		local v = ProtectedCall(f, id, txt)
		if v and v == 1 and ret == 0 then
			ret = 1
		end
	end

	if ret == 0 then
		if not USERIP[player(id,"ip")]["mute"] then
			for _, p in pairs(player(0,"table")) do
				msg2(p, FormatChat(id, p, txt))
			end
			return 1
		end
	end
	return 1
end

function FormatChat(id,p,txt)
	local txt = string.gsub(txt, string.char(169), "")

	if USER[id]["banuc"] and p ~= id then
		txt = string.lower(txt)
	end

	local r, g, b = NameColor(id)
	local name = player(id,"name")

	if USER[id]["tag"] then
		name = USER[id]["name"] or "["..RankPrefix(PlayerRank(id)).."] "..player(id,"name")
	end

	return Color(r,g,b)..name..": "..Color(USER[id]["ccolorr"] or 255,USER[id]["ccolorg"] or 255,USER[id]["ccolorb"] or 0)..txt
end

function RankCmds(name)
	local list = {}
	for k, v in pairs(CHAT_CMD) do
		if SERVER_RANK[name].lvl >= v.lvl then
			table.insert(list, k)
		end
	end
	return list
end

function CreateChat(name)
	return function (params)
		return function (lvl)
			return function (code)
				local f, e = loadstring("return function (id,txt,s,pos,args) "..code.."; end")
				if f then
					CHAT_CMD[name] = {f = f(),lvl = lvl,params = params}
				elseif e then
					error_get("CHAT CMD ERR ("..name.."): "..e)
				end
				return function (hidden)
					CHAT_CMD[name].hidden = hidden
				end
			end
		end
	end
end

function CreateChatAttachment(f)
	table.insert(CHAT_ATTACHMENT, f)
end

function RemoveChatAttachment(f)
	for id, at in pairs(CHAT_ATTACHMENT) do
		if at == f then
			CHAT_ATTACHMENT[id] = nil
			break
		end
	end
end

function addhook(...)
	local arg = {...}
	if arg[1] and arg[2] then
		if arg[1] == "say" then
			local func = _G[arg[2]]
			if func then
				return CreateChatAttachment(func)
			end
		end
	end
	return addon_say_hook(...)
end

function freehook(...)
	local arg = {...}
	if arg[1] and arg[2] then
		if arg[1] == "say" then
			local func = _G[arg[2]]
			if func then
				return RemoveChatAttachment(func)
			end
		end
	end
	return addon_say_freehook(...)
end
