addhook("buildattempt","Fastbuild_mod")
function Fastbuild_mod(id,t,x,y,m)
	if SERVER_DATA["fastbuild"] then
		if t >= 1 and t <= 15 then
			parse("spawnobject "..t.." "..x.." "..y.." "..player(id,"rot").." "..m.." "..player(id,"team").." "..id)
			return 1
		end
	end
end

function SpawnObject(t,x,y,rot,mode,team,p)
	local ol = object(0,"table")
	rot = tonumber(rot) or 0
	mode = tonumber(mode) or 0
	team = tonumber(team) or 0
	p = tonumber(p) or 0
	parse("spawnobject "..t.." "..x.." "..y.." "..rot.." "..mode.." "..team.." "..p)

	local ol2 = object(0,"table")
	for k, v in pairs(ol2) do
		if not ol[k] or ol[k] ~= v then
			return v
		end
	end
end

function FastbuildButton(id)
	if SERVER_DATA["fastbuild"] then
		return Translate(id, 275).."|"..Translate(id, 2)
	end
	return Translate(id, 275).."|"..Translate(id, 3)
end

function FastbuildToggle()
	if SERVER_DATA["fastbuild"] then
		SERVER_DATA["fastbuild"] = nil
		msg("trans:276@C")
	else
		SERVER_DATA["fastbuild"] = true
		msg("trans:277@C")
	end
end

CreateSetting(FastbuildButton, FastbuildToggle)
