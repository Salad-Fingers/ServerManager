CreateChat "!setcolor" "<r> <g> <b>" (16) [[
	if args >= 4 then
		local r = tonumber(s[2])
		local g = tonumber(s[3])
		local b = tonumber(s[4])
		if r and g and b then
			USER[id]["colorr"] = r
			USER[id]["colorg"] = g
			USER[id]["colorb"] = b
		end
	end
]]

CreateChat "!removecolor" "" (16) [[
	USER[id]["colorr"] = nil
	USER[id]["colorg"] = nil
	USER[id]["colorb"] = nil
]]