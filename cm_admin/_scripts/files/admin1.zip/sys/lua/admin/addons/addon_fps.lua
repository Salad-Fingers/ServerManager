fps_cnt = 0
fps = 0
fps_ms = 0
fps_hud = GenerateHud()

addhook("second","fpsDraw")
function fpsDraw()
	if SERVER_DATA["fps_enabled"] then
		for _, id in pairs(player(0,"table")) do
			Hudtxt2(id, fps_hud, Translate(id, 5, fps), 15, 100)
		end
	end
end

addhook("always","fpsAlways")
function fpsAlways()
	if SERVER_DATA["fps_enabled"] then
		fps_cnt = fps_cnt + 1
		if Millisecs() - fps_ms >= 1000 then
			fps_ms = Millisecs()
			fps = fps_cnt
			fps_cnt = 0
		end
	end
end

function FpsButton(id)
	if SERVER_DATA["fps_enabled"] then
		return Translate(id,4).."|"..Translate(id, 2)
	end
	return Translate(id,4).."|"..Translate(id, 3)
end

function FpsToggle()
	if SERVER_DATA["fps_enabled"] then
		SERVER_DATA["fps_enabled"] = nil
		Freehud(0, fps_hud)
	else
		SERVER_DATA["fps_enabled"] = true
	end
end
CreateSetting(FpsButton, FpsToggle)
