CreateChat "!ranks" "" (0) [[
	local _rank, i = RankList(), 0
	for _, name in pairs(_rank) do
		i = i + 100
		
		local v = SERVER_RANK[name]
		AddTimer(i, false, msgc2, id, "["..v.prefix.."] "..name.." (Lvl. "..v.lvl..")", v.r, v.g, v.b)
	end
]]