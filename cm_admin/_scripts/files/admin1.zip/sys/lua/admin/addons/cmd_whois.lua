CreateChat "@whois" "<id>" (15) [[
	if args >= 2 then
		local p = tonumber(s[2])
		if p and player(p,"exists") then
			msgc2(id, Translate(id, 182, PlayerName(p)), 0, 255)
			if player(p,"usgn") > 0 then
				msgc2(id, "USGN: "..player(p,"usgn"), 0, 255)
			else
				msgc2(id, Translate(id, 183), 0, 255)
			end
			msgc2(id, "IP: "..player(p,"ip"), 0, 255)

			if IPToCountry then
				msgc2(id, Translate(id, 184)..": "..IPToCountry(player(p,"ip")), 0, 255)
			end
		end
	end
]]
