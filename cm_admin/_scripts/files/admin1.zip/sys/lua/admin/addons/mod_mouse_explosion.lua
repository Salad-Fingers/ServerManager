mouse_explosion_event = CreateMouseEvent(function (id,x,y)
	parse("explosion "..x.." "..y.." 320 300 "..id)
	USERTEMP[id]["mouseevent"] = nil
end)
CreateMouseFunc("trans:225", mouse_explosion_event, nil, 20)
