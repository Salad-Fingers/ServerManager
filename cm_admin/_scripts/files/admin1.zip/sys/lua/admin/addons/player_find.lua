function USGNPlayer(u)
	for _, id in pairs(player(0,"table")) do
		if player(id,"usgn") == u then
			return id
		end
	end
end

function IPPlayer(ip)
	for _, id in pairs(player(0,"table")) do
		if player(id,"ip") == ip then
			return id
		end
	end
end

function NamePlayer(name)
	for _, id in pairs(player(0,"table")) do
		if player(id,"name") == name then
			return id
		end
	end
end