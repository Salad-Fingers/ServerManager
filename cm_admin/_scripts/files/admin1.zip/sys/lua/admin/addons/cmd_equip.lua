CreateChat "!equip" "<id> <weapon>" (16) [[
	local p = tonumber(s[2])
	local w = tonumber(s[3])
	if p and player(p,"exists") and w then
		parse("equip "..p.." "..w)
	end
]]