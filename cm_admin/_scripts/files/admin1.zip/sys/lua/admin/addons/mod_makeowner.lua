function make_owner_button(id)
	if RankExists("owner") then
		if player(id,"ip") == "0.0.0.0" then
			if PlayerLevel(id) < RankLevel("owner") then
				PlayerSetRank(nil, id, "owner")
			else
				ErrorMSG(id, Translate(id, 218))
			end
		else
			ErrorMSG(id, Translate(id, 219))
		end
	else
		ErrorMSG(id, Translate(id, 220))
	end
end

function make_owner_button_text(id)
	if RankExists("owner") and player(id,"ip") == "0.0.0.0" then
		if PlayerLevel(id) < RankLevel("owner") then
			return Translate(id, 221)
		end
	end
end

AddMenuButton(make_owner_button, make_owner_button_text, 0)
