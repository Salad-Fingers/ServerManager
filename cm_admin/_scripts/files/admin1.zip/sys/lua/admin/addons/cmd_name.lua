CreateChat "!name" "[name]" (26) [[
	if args >= 2 then
		local name = string.sub(txt, pos[2])
		if string.len(name) > 0 then
			USER[id]["name"] = name
		end
	elseif args == 1 then
		USER[id]["name"] = nil
	end
]]