server_title_hud = GenerateHud()
server_name_hud = GenerateHud()

function servertitle_draw(id)
	if SERVER_DATA["title_enabled"] then
		Hudtxt2(id, server_name_hud, game("sv_name"), 250, 35, 0, 255, 100, 0)
		Hudtxt2(id, server_title_hud, SERVER_DATA["server_title"] or "", 250, 50, 0, SERVER_DATA["titleR"], SERVER_DATA["titleG"], SERVER_DATA["titleB"])
	end
end
CreateTeamAttachment(servertitle_draw)

CreateChat "@settitle" "[text] <r> <g> <b>" (30) [[
	if args >= 2 then
		local title = string.findString(txt)

		local r = tonumber(s[args-2])
		local g = tonumber(s[args-1])
		local b = tonumber(s[args])

		if title and string.len(title) > 0 then
			SERVER_DATA["server_title"] = title
			SERVER_DATA["titleR"] = r or SERVER_DATA["titleR"]
			SERVER_DATA["titleG"] = g or SERVER_DATA["titleG"]
			SERVER_DATA["titleB"] = b or SERVER_DATA["titleB"]
			servertitle_draw(0)
		end
	end
]]

function TitlesetButton(id)
	if SERVER_DATA["title_enabled"] then
		return Translate(id, 21).."|"..Translate(id, 2)
	end
	return Translate(id, 21).."|"..Translate(id, 2)
end

function TitlesetToggle()
	if SERVER_DATA["title_enabled"] then
		SERVER_DATA["title_enabled"] = nil
		Freehud(0, server_title_hud)
		Freehud(0, server_name_hud)
	else
		SERVER_DATA["title_enabled"] = true
		servertitle_draw(0)
	end
end

CreateSetting(TitlesetButton, TitlesetToggle)
