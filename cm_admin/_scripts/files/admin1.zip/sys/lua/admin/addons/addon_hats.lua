CreateChat "!hat" "" (5) [[HatMenu:OpenPlayer(id,1)]]

Hats = {}
function AddHat(name, dir, lvl)
	if FileExists(dir) then
		Hats[name] = {dir = dir,lvl = lvl or 0}
		AddTransferFile(dir)
	end
end

function GetHat(id,i)
	local x = 0
	for k, v in pairs(Hats) do
		if PlayerLevel(id) >= v.lvl then
			x = x + 1
			if i == x then
				return k
			end
		end
	end
end

for i = 1, #Hats do
	AddTransferFile(Hats[i])
end

HatMenu = CreateMenu("Hats"); AddMenu(HatMenu, 0)
function HatMenu:getcustombutton(b,id,def)
	if b > 1 then
		local hat = GetHat(id, b)
		return hat
	elseif b == 1 then
		return "Remove hat"
	end
end

function HatMenu:click(id,b,p)
	if b > 0 then
		if USERTEMP[id]["hat"] then
			freeimage(USERTEMP[id]["hat"])
		end
	end

	if b > 1 then
		local hat = GetHat(id, b)
		if hat then
			USERTEMP[id]["hat"] = image(Hats[hat].dir, 1, 0, 200+id)
		end
	end
end

addhook("leave","player_hat_remove")
function player_hat_remove(id)
	if USERTEMP[id]["hat"] then
		freeimage(USERTEMP[id]["hat"])
	end
end

addhook("startround_prespawn","hat_remove")
function hat_remove()
	for i = 1, 32 do
		USERTEMP[i]["hat"] = nil
	end
end

--[[
AddHat("Alien", "gfx/nopainhats/Alien.png")
AddHat("All", "gfx/nopainhats/all.png")
AddHat("Angel", "gfx/nopainhats/Angel.png")
AddHat("Armor", "gfx/nopainhats/armorhat.png")
AddHat("Black Dragon", "gfx/nopainhats/blackdragon.png")
AddHat("Black Wings", "gfx/nopainhats/blackwings.png", 5)
AddHat("Bossc", "gfx/nopainhats/bossc.bmp", 5)
AddHat("Box", "gfx/nopainhats/box.png")
AddHat("Cap", "gfx/nopainhats/Cap.png")
AddHat("Cowboy Hat", "gfx/nopainhats/CowboyHat.png")
AddHat("Devil Wings", "gfx/nopainhats/devilwings.png", 5)
AddHat("Fire", "gfx/nopainhats/fire.png")
AddHat("Kratos", "gfx/nopainhats/Kratosina.png", 35)
AddHat("Luigi", "gfx/nopainhats/luigi.png")
AddHat("Mario", "gfx/nopainhats/mario.png")
AddHat("Megaman", "gfx/nopainhats/megaman.png")
AddHat("Monkey", "gfx/nopainhats/monkey.png")
AddHat("Monster", "gfx/nopainhats/monster.bmp")
AddHat("Phoenix", "gfx/nopainhats/phoenix.png")
AddHat("Pikachu", "gfx/nopainhats/pikachu.png")
AddHat("Pinocchio", "gfx/nopainhats/pinocchio.png")
AddHat("Pirate", "gfx/nopainhats/pirate.png")
AddHat("Purple Wings", "gfx/nopainhats/PurpleWings.png", 5)
AddHat("Santa", "gfx/nopainhats/santa.png")
AddHat("Skull", "gfx/nopainhats/Skull.png", 5)
AddHat("Snowman", "gfx/nopainhats/snowman.png")
AddHat("Sonic", "gfx/nopainhats/sonic.png")
AddHat("Sparta", "gfx/nopainhats/sparta.png", 5)
AddHat("SuperMan", "gfx/nopainhats/superman.png")
AddHat("Toad", "gfx/nopainhats/toad.png")
AddHat("Blue Umbrella", "gfx/nopainhats/umbrella.png")
AddHat("Red Umbrella", "gfx/nopainhats/UmbrellaT.png")
AddHat("Wizard", "gfx/nopainhats/wizard.png")
AddHat("Wolf", "gfx/nopainhats/wolf.png")
AddHat("Ying Yang", "gfx/nopainhats/YingYang 2.png", 5)
AddHat("Yoshi", "gfx/nopainhats/yoshi.png")
]]--
