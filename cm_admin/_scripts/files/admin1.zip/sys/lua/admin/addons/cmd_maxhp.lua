CreateChat "!maxhp" "<id> <health>" (25) [[
	if args >= 3 then
		local p = tonumber(s[2])
		local health = tonumber(s[3])
		if p and health and player(p,"exists") then
			parse("setmaxhealth "..p.." "..health)
			msg2(p, Translate(p, 133, PlayerName(id), health))
			msg2(id, Color(255,255)..Translate(id, 134, PlayerName(p), health))
		end
	end
]]
