spawn_npc_event = CreateMouseEvent(function (id,x,y)
	if USERTEMP[id]["spawnnpctype"] then
		if tile(math.floor(x/32), math.floor(y/32), "walkable") then
			parse("spawnnpc "..USERTEMP[id]["spawnnpctype"].." "..math.floor(x/32).." "..math.floor(y/32).." 0")
		end
	end
	USERTEMP[id]["mouseevent"] = nil
end)

spawn_npc_menu = CreateMenu("trans:228", "Zombie,Headcrab,Snark,Vortigaunt,Soldier")
function spawn_npc_menu:click(id,b,p)
	if b > 0 then
		USERTEMP[id]["spawnnpctype"] = b
	end
end

function spawn_npc_menu_open(id)
	spawn_npc_menu:OpenPlayer(id, 1)
end
CreateMouseFunc("trans:228", spawn_npc_event, spawn_npc_menu_open, 25)
