addon_set_stream = ReadStream(mod_path.."addon_setting.txt")
ADDONSET = {}

if addon_set_stream then
	while not Eof(addon_set_stream) do
		local line = ReadLine(addon_set_stream)
		local s = line:split("=")

		s[1] = s[1]:gsub(" ", "")
		s[2] = s[2]:gsub(" ", "")

		local n = tonumber(s[2])
		if n then s[2] = n end

		ADDONSET[s[1]] = s[2]
	end
	CloseStream(addon_set_stream)
end
