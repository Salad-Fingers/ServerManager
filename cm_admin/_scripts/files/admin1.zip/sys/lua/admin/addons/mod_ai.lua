-- Artificial intelligence functions

AI = {}

function AI.GetAngle(fx,fy,tx,ty)
	local Angle = math.atan2(fy-ty,fx-tx) - math.pi/2
	if Angle < -math.pi then return Angle + math.pi*2 end
	return Angle
end

function AI.GetDist(fx,fy,tx,ty)
	return math.sqrt((fx-tx)^2 + (fy-ty)^2)
end

-- Detect players in a radius
function AI.DetectPlayers(x,y,radius,alive)
	local t = {}
	for _, id in pairs(player(0,"table")) do
		if AI.GetDist(x, y, player(id,"x"), player(id,"y")) < radius then
			if (alive and player(id,"health") > 0) or not alive then
				table.insert(t, id)
			end
		end
	end
	return t
end

-- Closest player from table
function AI.ClosestPlayer(x,y,tab)
	if not tab then tab = AI.DetectPlayers(x, y, 380) end
	local p, d
	for _, id in pairs(tab) do
		local Dist = AI.GetDist(x, y, player(id,"x"), player(id,"y"))
		if not p or Dist < d then
			p = id
			d = Dist
		end
	end
	return p
end

function AI.MaxLine(fx,fy,tx,ty)
	local Angle = AI.GetAngle(fx,fy,tx,ty)
	local Dist = math.round(AI.GetDist(fx,fy,tx,ty)/8)

	for i = 1, Dist*8 do
		local x = fx + math.sin(Angle) * i * 8
		local y = fy - math.cos(Angle) * i * 8
		if not tile(math.floor(x/32), math.floor(y/32), "walkable") then
			return (i-1)*8
		end
	end
	return Dist
end

-- Check free line from two vectors
function AI.Freeline(fx,fy,tx,ty)
	local Angle = AI.GetAngle(fx,fy,tx,ty)
	local Dist = math.round(AI.GetDist(fx,fy,tx,ty)/8)

	for i = 1, Dist*8 do
		local x = fx + math.sin(Angle) * i * 8
		local y = fy - math.cos(Angle) * i * 8
		if not tile(math.floor(x/32), math.floor(y/32), "walkable") then
			return false
		end
	end
	return true
end

function AI.ViewArea(fx,fy,tx,ty,a,spread)
	local Angle = math.deg(AI.GetAngle(fx, fy, tx, ty))
	return math.abs(Angle - a) <= aspread or math.abs(Angle - a) >= 360 - aspread
end

function MapTeleporter(x,y)
	if entity(x, y, "exists") and entity(x, y, "typename") == "Func_Teleport" then
		if entity(x, y, "state") then
			return entity(x, y, "int0"), entity(x, y, "int1")
		end
	end
end

function PathWalkable(path)
	for k, v in pairs(path) do
		if not tile(v.x,v.y,"walkable") then
			return false
		end
	end
	return true
end

function PathMap(x,y)
	if tile(x,y,"walkable") then
		return 0
	end
	return 1
end

function FindPath(fx,fy,tx,ty,Map)
	if Map == nil then Map = PathMap end

	if Map(fx,fy) == 1 or Map(tx,ty) == 1 then
		return nil, "The start or the goal is not walkable"
	end

	local Node = {}
	local curbase = {x = fx,y = fy}
	local openlist = {{x = fx,y = fy}}

	local function Euclidean(fx,fy,tx,ty)
		return math.sqrt((fx-tx)^2 + (fy-ty)^2)
	end

	function CreateNodeConfig(x,y,open)
		if not Node[x] then Node[x] = {} end
		if not Node[x][y] then
			if open == nil then open = false end
			local n = {
				Open = open,
				Closed = false,
				parent = {}
			}
			n.G = 0
			n.H = Euclidean(x,y,tx,ty)
			n.F = n.H
			Node[x][y] = n
		end
	end

	CreateNodeConfig(fx,fy,1)

	local function FixedPath()
		local i = {x = tx,y = ty}
		local path = {}
		while Node[i.x][i.y].parent.x and Node[i.x][i.y].parent.y do
			local Details = {
				x = i.x,
				y = i.y
			}
			table.insert(path,Details)
			i = Node[i.x][i.y].parent
		end
		return path, #path, -1
	end

	local function CheckNode(l,x,y,p)
		CreateNodeConfig(x,y)
		if not Node[x][y].Closed and Map(x,y) == 0 then
			local t = {x = x,y = y}
			if p then t.parent = p end
			table.insert(l, t)

			local nx, ny = MapTeleporter(x, y)
			if nx and ny then
				CheckNode(l, nx, ny, t)
			end
		end
	end

	local function AddNode(v,p)
		local score = Node[p.x][p.y].G + math.sqrt((v.x-p.x)^2 + (v.y-p.y)^2)*32
		if not Node[v.x][v.y].Open then
			local pos = #openlist+1
			openlist[pos] = {x = v.x,y = v.y}
			Node[v.x][v.y].Open = pos
			Node[v.x][v.y].parent = p
			Node[v.x][v.y].G = score
			Node[v.x][v.y].F = score + Node[v.x][v.y].H
		elseif score <= Node[v.x][v.y].G then
			Node[v.x][v.y].parent = p
			Node[v.x][v.y].G = score
			Node[v.x][v.y].F = Node[v.x][v.y].G + Node[v.x][v.y].H
		end
	end

	local function LowestNode()
		local lVal, lID
		for k, v in pairs(openlist) do
			if not lVal or Node[v.x][v.y].F < Node[lVal.x][lVal.y].F then
				lVal = v
				lID = k
			end
		end
		return lVal, lID
	end

	local function OpenListEmpty()
		for k, v in pairs(openlist) do
			return false
		end
		return true
	end

	while not OpenListEmpty() do
		local lW, lWID = LowestNode()

		if not lW or not lWID then
			return nil, "Failed to find path"
		else
			Node[lW.x][lW.y].Closed = true
			Node[lW.x][lW.y].Open = false
			openlist[lWID] = nil
			curbase = lW
		end

		if curbase.x == tx and curbase.y == ty then
			return FixedPath()
		end

		local NearNodes = {}
		CheckNode(NearNodes,curbase.x,curbase.y+1)
		CheckNode(NearNodes,curbase.x+1,curbase.y)
		CheckNode(NearNodes,curbase.x,curbase.y-1)
		CheckNode(NearNodes,curbase.x-1,curbase.y)
		if Map(curbase.x+1,curbase.y) == 0 and Map(curbase.x,curbase.y+1) == 0 then CheckNode(NearNodes,curbase.x+1,curbase.y+1) end
		if Map(curbase.x+1,curbase.y) == 0 and Map(curbase.x,curbase.y-1)== 0 then CheckNode(NearNodes,curbase.x+1,curbase.y-1) end
		if Map(curbase.x-1,curbase.y) == 0 and Map(curbase.x,curbase.y+1) == 0 then CheckNode(NearNodes,curbase.x-1,curbase.y+1) end
		if Map(curbase.x-1,curbase.y) == 0 and Map(curbase.x,curbase.y-1) == 0 then CheckNode(NearNodes,curbase.x-1,curbase.y-1) end
		for i = 1, #NearNodes do
			AddNode(NearNodes[i], NearNodes[i].parent or curbase)
		end
	end
	return nil, "Couldn't find the path"
end
