CreateChat "!luaerror" "" (30) [[
	USERTEMP[id]["error_console"] = not USERTEMP[id]["error_console"]
	UpdateErrorConsole(id)
]]

error_hud_slot = {}
for i = 1, 7 do
	error_hud_slot[i] = GenerateHud()
end

function UpdateErrorConsole(id)
	if USERTEMP[id]["error_console"] then
		for i = 1, 7 do
			if error_log[i] then
				Hudtxt2(id, error_hud_slot[i], 'Lua Error: '..string.gsub(error_log[i], '"', "'"), 10, 120 - (i*15), 0, 255)
			else
				Freehud(error_hud_slot[i])
			end
		end
	else
		for i = 1, 7 do
			Freehud(error_hud_slot[i])
		end
	end
end
CreateChatAttachment(UpdateErrorConsole)