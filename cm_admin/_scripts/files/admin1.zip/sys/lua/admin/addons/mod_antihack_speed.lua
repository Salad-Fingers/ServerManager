CreateChat "@checkspeeders" "" (15) [[
	local i = 0
	for k, p in pairs(player(0,"table")) do
		if USERTEMP[p]["speedwarn"] then
			i = i + 1
			AddTimer(i*100, false, msgc2, id, i..".- "..player(p,"name"), 255)
		end
	end
	if i > 0 then
		msgc2(id, Translate(id, 185), 255)
	else
		ErrorMSG(id, Translate(id, 186))
	end
]]

CreateConsole "setpos" [[
	if args >= 4 then
		local id = tonumber(s[2])
		local x = tonumber(s[3])
		local y = tonumber(s[4])

		if id and x and y and player(id,"exists") and player(id,"health") > 0 then
			antispeed_reset(id)
		end
		return 1
	end
]]

addhook("spawn","antispeed_reset")
addhook("die","antispeed_reset")
function antispeed_reset(id)
	USERTEMP[id]["pos"] = {}
end

addhook("move","antispeed_move")
function antispeed_move(id,x,y)
	if not USERTEMP[id]["speedwarn"] then
		local pos = USERTEMP[id]["pos"]

		table.insert(pos, {x = x,y = y})
		if #pos >= 10 then
			table.remove(pos, 1)
		end

		local count = 0
		local dist = 0
		for i, y in pairs(pos) do
			local x = pos[i-1]

			if x then
				local d = math.sqrt((x.x-y.x)^2 + (x.y-y.y)^2)
				if d <= 80 then
					dist = dist + d
					count = count + 1
				end
			end
		end

		if count >= 8 then
			local average = dist / count
			local speed = 16 + player(id,"speedmod")*0.6

			if average >= speed * 1.5 and player(id,"ping") < 400 then
				USERTEMP[id]["speedwarn"] = true
				USERTEMP[id]["pos"] = nil
				RankMSG(15, "trans:187("..PlayerName(id)..")", 255)
			end
		end
	end
end
