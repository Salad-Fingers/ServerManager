rank_menu = CreateMenu(340)
function rank_menu:getcustombutton(b)
	local id = player(0,"table")[b]
	if id then return FixedName(player(id, "name")).."|"..RankPrefix(PlayerRank(id)) end
end

function rank_menu:click(id,b,p)
	msg("Click")
	local p = player(0,"table")[b]
	if p and player(p,"exists") then
		USERTEMP[id]["setrank"] = p
		rank_optionmenu:OpenPlayer(id, 1)
	end
end

rank_optionmenu = CreateMenu(341, RankList())
function rank_optionmenu:getcustombutton(b,id,default)
	if default then
		if RankExists(default) then
			if RankLower(default, PlayerRank(id)) then
				return SERVER_RANK[default].prefix.."|Lvl. "..SERVER_RANK[default].lvl
			else
				return "("..SERVER_RANK[default].prefix.."|Lvl. "..SERVER_RANK[default].lvl
			end
		end
		return ""
	end
end

function rank_optionmenu:click(id,b,page)
	local p = USERTEMP[id]["setrank"]
	if player(p, "exists") then
		local rank_name = RankList()[b]
		if rank_name then
			PlayerSetRank(id, p, rank_name)
		end
	else
		USERTEMP[id]["setrank"] = nil
	end
end

function PlayerSetRank(id,p,rank)
	if not RankExists(rank) then
		return ErrorMSG(id, Translate(id, 295))
	end

	if not id or PlayerLevel(p) < PlayerLevel(id) then
		if not id or RankLevel(rank) < PlayerLevel(id) then
			SetUSERRank(p, rank)
			SaveUSER(p)

			if PlayerLevel(p) < RankLevel(rank) then
				if id then msgc2(id, Translate(id, 289, PlayerName(p), RankPrefix(rank)), 255, 255, 0) end
				msgc2(p, Translate(p, 290, RankPrefix(rank)), 0, 100, 255)
			elseif PlayerLevel(p) > RankLevel(rank) then
				if id then msgc2(id, Translate(id, 291, PlayerName(p), RankPrefix(rank)), 255, 255, 0) end
				msgc2(p, Translate(p, 292, RankPrefix(rank)), 0, 100, 255)
			elseif PlayerLevel(p) == RankLevel(rank) then
				if id then msgc2(id, Translate(id, 293, PlayerName(p), RankPrefix(rank)), 255, 255, 0) end
				msgc2(p, Translate(p, 295, RankPrefix(rank)), 0, 100, 255)
			end
		elseif id then
			ErrorMSG(id, Translate(id, 265))
		end
	elseif id then
		ErrorMSG(id, Translate(id, 264))
	end
end

AddMenu(rank_menu, 30)
