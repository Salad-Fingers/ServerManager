function Sound(f)
	parse('sv_sound "'..f..'"')
end

function Sound2(id,f)
	parse('sv_sound2 '..id..' "'..f..'"')
end

function Sound3(f,x,y,r)
	for _, id in pairs(player(0,"table")) do
		if math.dist(player(id,"x"), player(id,"y"), x, y) < r then
			parse('sv_sound2 '..id..' "'..f..'"')
		end
	end
end