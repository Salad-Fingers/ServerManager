bot_menu = CreateMenu(346)
AddMenu(bot_menu, 26)

function BotCount(team)
	local count = 0
	for _, id in pairs(player(0,"table")) do
		if player(id,"bot") then
			if player(id,"team") == team or team == 0 then
				count = count + 1
			end
		end
	end
	return count
end

function bot_menu:getcustombutton(b,id,default)
	if b == 1 then
		return Translate(id, 189).."|("..BotCount(0)..")"
	elseif b == 2 then
		return Translate(id, 190).."|("..BotCount(1)..")"
	elseif b == 3 then
		return Translate(id, 191).."|("..BotCount(2)..")"
	elseif b == 4 then
		return Translate(id, 192).."|("..BotCount(1)..")"
	elseif b == 5 then
		return Translate(id, 193).."|("..BotCount(2)..")"
	elseif b == 6 then
		return Translate(id, 194).."|("..BotCount(0)..")"
	elseif b == 7 then
		return Translate(id, 195)
	elseif b == 8 then
		return Translate(id, 196)
	elseif b == 9 then
		return Translate(id, 197)
	end
end

function bot_menu:click(id,b,p)
	if b == 1 then
		parse("bot_kill")
		bot_menu:OpenPlayer(id, 1)
	elseif b == 2 then
		parse("bot_add_t")
		bot_menu:OpenPlayer(id, 1)
	elseif b == 3 then
		parse("bot_add_ct")
		bot_menu:OpenPlayer(id, 1)
	elseif b == 4 then
		parse("bot_remove_t")
		bot_menu:OpenPlayer(id, 1)
	elseif b == 5 then
		parse("bot_remove_ct")
		bot_menu:OpenPlayer(id, 1)
	elseif b == 6 then
		parse("bot_remove_all")
		bot_menu:OpenPlayer(id, 1)
	elseif b == 7 then
		for i = 1, tonumber(game("sv_maxplayers")) - #player(0,"table") do
			AddTimer(i*300, false, parse, "bot_add")
		end
		bot_menu:OpenPlayer(id, 1)
	elseif b == 8 then
		bot_skills_menu:OpenPlayer(id, 1)
	elseif b == 9 then
		bot_weapon_menu:OpenPlayer(id, 1)
	end
end

bot_skills_menu = CreateMenu(347, "trans:198,trans:199,trans:200,trans:201,trans:202")
function bot_skills_menu:getcustombutton(b,id,def)
	if tonumber(game("bot_skill"))+1 == b then
		return "("..def
	end
end

function bot_skills_menu:click(id,b,p)
	if b > 0 then
		parse("bot_skill "..b-1)
		bot_menu:OpenPlayer(id, 1)
	end
end

bot_weapon_menu = CreateMenu(348, "trans:203,trans:204,trans:205,trans:206,trans:207,trans:208,trans:209,trans:210")
function bot_weapon_menu:getcustombutton(b,id,def)
	if tonumber(game("bot_weapons"))+1 == b then
		return "("..def
	end
end

function bot_weapon_menu:click(id,b,p)
	if b > 0 then
		parse("bot_weapons "..b-1)
		bot_menu:OpenPlayer(id, 2)
	end
end
