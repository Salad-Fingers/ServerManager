CreateChat "!voterestart" "" (15) [[
	for _, p in pairs(player(0,"table")) do
		msgc2(p, Translate(id, 44, PlayerName(id)..Color(0,255)), 0, 255, 0)
	end
	CreateRestartPoll()
]]

restart_vote_yes = 0
restart_vote_no = 0
restart_delay = 15
restart_time = 0
restart_poll = false

restart_hud = GenerateHud()
restart_vote_hud = GenerateHud()

function CreateRestartPoll()
	restart_poll = true
	restart_vote_yes = 0
	restart_vote_no = 0
	restart_time = 0
	restart_vote_menu:OpenPlayer(0, 1)
end

restart_vote_menu = CreateMenu("Restart round?")
function restart_vote_menu:getcustombutton(b,id)
	if b == 1 then
		return Translate(id, 92)
	elseif b == 2 then
		return Translate(id, 93)
	end
end

function restart_vote_menu:click(id,b,p)
	if not USERTEMP[id]["vote"] then
		if b == 1 then
			for _, p in pairs(player(0,"table")) do
				msg2(p, Translate(p, 45, PlayerName(id), Color(0,255)..Translate(p,46)))
			end
			USERTEMP[id]["vote"] = true

			restart_vote_yes = restart_vote_yes + 1
		elseif b == 2 then
			for _, p in pairs(player(0,"table")) do
				msg2(p, Translate(p, 45, PlayerName(id), Color(255)..Translate(p,47)))
			end
			USERTEMP[id]["vote"] = true

			restart_vote_no = restart_vote_no + 1
		end
	else
		ErrorMSG(id, Translate(id, 48))
	end
end

addhook("second","RestartvoteSec")
function RestartvoteSec()
	if restart_time <= restart_delay and restart_poll then
		restart_time = restart_time + 1
		if restart_time > restart_delay then
			-- Check votes
			if restart_vote_yes > restart_vote_no then
				parse("sv_restart")
			end
			for _, p in pairs(player(0,"table")) do
				msg2(p, Translate(p, 49, restart_vote_yes, restart_vote_no))
			end

			for _, id in pairs(player(0,"table")) do
				USERTEMP[id]["vote"] = nil
			end

			Freehud(0, restart_hud)
			Freehud(0, restart_vote_hud)

			restart_poll = false
		else
			for _, p in pairs(player(0,"table")) do
				Hudtxt2(p, restart_hud, Translate(p, 50, restart_time, restart_delay), 15, 115, 0, 255, 255, 255)
				Hudtxt2(p, restart_vote_hud, Translate(p, 51, restart_vote_yes, restart_vote_no), 15, 130)
			end
		end
	end
end
