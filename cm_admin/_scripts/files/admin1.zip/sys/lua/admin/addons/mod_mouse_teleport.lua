function mouse_teleport_func_event(id,x,y)
	if player(id,"health") > 0 then
		parse("setpos "..id.." "..x.." "..y)
	else
		parse("spawnplayer "..id.." "..x.." "..y)
	end
	USERTEMP[id]["mouseevent"] = nil
end
mouse_teleport_event = CreateMouseEvent(mouse_teleport_func_event); mouse_teleport_func_event = nil

CreateMouseFunc("trans:232", mouse_teleport_event, nil, 15)
