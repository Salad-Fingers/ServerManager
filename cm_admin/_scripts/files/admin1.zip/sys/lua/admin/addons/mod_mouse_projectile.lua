function projectile_mouse_event_func(id,x,y)
	if USERTEMP[id]["projectiletype"] then
		local r = math.rad(player(id,"rot"))
		local _x = player(id,"x") + math.sin(r) * 24
		local _y = player(id,"y") - math.cos(r) * 24
		local _dir = math.deg(math.atan2(_y-y,_x-x)) + 270
		local _dist = AI.GetDist(_x, _y, x, y)
		parse("spawnprojectile "..id.." "..USERTEMP[id]["projectiletype"].." ".._x.." ".._y.." ".._dist.." ".._dir)
	end
	USERTEMP[id]["mouseevent"] = nil
end

projectile_type_menu = CreateMenu(229, "RPG Launcher,Rocket Launcher,Grenade Launcher,He,Flashbang,Smoke,Flare,Gas,Molotov,Snowball,Airstrike,Gut Bomb,Satchel Charge")

function projectile_type_menu:click(id,b,p)
	if b > 0 then
		if b == 1 then
			USERTEMP[id]["projectiletype"] = 47
		elseif b == 2 then
			USERTEMP[id]["projectiletype"] = 48
		elseif b == 3 then
			USERTEMP[id]["projectiletype"] = 49
		elseif b == 4 then
			USERTEMP[id]["projectiletype"] = 51
		elseif b == 5 then
			USERTEMP[id]["projectiletype"] = 52
		elseif b == 6 then
			USERTEMP[id]["projectiletype"] = 53
		elseif b == 7 then
			USERTEMP[id]["projectiletype"] = 54
		elseif b == 8 then
			USERTEMP[id]["projectiletype"] = 72
		elseif b == 9 then
			USERTEMP[id]["projectiletype"] = 73
		elseif b == 10 then
			USERTEMP[id]["projectiletype"] = 75
		elseif b == 11 then
			USERTEMP[id]["projectiletype"] = 76
		elseif b == 12 then
			USERTEMP[id]["projectiletype"] = 86
		elseif b == 13 then
			USERTEMP[id]["projectiletype"] = 89
		end

		projectile_type_menu:OpenPlayer(id, p)
	end
end

mouse_projectile_event = CreateMouseEvent(projectile_mouse_event_func); projectile_mouse_event_func = nil
CreateMouseFunc("trans:229", mouse_projectile_event, function (id) projectile_type_menu:OpenPlayer(id, 1) end, 26)
