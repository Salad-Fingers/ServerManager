CreateChat "@spam" "[text]" (30) [[
	if args >= 2 then
		local text = string.sub(txt, pos[2])
		for i = 1, 15 do
			AddTimer(i*50, false, msg, text)
		end
	end
]]