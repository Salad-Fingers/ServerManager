function mouse_ograb_func_event(id,x,y)
	if USERTEMP[id]["targetobject"] then
		USERTEMP[id]["targetobject"] = nil
		USERTEMP[id]["mouseevent"] = nil
	else
		USERTEMP[id]["mouseevent"] = nil

		local closest
		for _, o in pairs(object(0,"table")) do
			local dist = math.sqrt((x-object(o,"x"))^2 + (y-object(o,"y"))^2)
			if dist < 32 then
				if not closest or dist < closest[2] then
					closest = {o, dist}
				end
			end
		end

		if closest then
			USERTEMP[id]["targetobject"] = closest[1]
			USERTEMP[id]["mouseevent"] = mouse_ograbmove_event
		end
	end
end

function mouse_ograbmove_func_event(id,x,y)
	local o = USERTEMP[id]["targetobject"]
	if o and object(o,"exists") then
		imagepos(o, x-16, y-16, object(o,"rot"))
	elseif USERTEMP[id]["targetobject"] then
		USERTEMP[id]["mouseevent"] = nil
		USERTEMP[id]["targetobject"] = nil
	else
		USERTEMP[id]["mouseevent"] = nil
	end
end

mouse_ograb_event = CreateMouseEvent(mouse_ograb_func_event); mouse_ograb_func_event = nil
mouse_ograbmove_event = CreateMouseEvent(mouse_ograbmove_func_event); mouse_ograbmove_func_event = nil

CreateMouseFunc("trans:227", mouse_ograb_event, nil, 25)
