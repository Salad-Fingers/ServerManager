--!poll "Question" "Answer1,Answer2"
CreateChat "!poll" [["question" "button1,b2,b3,b4,..."]] (30) [[
	if args >= 2 then
		local values = string.getStrings(txt)
		local poll_name = values[1]
		local answers = values[2]
		
		if poll_name and answers then
			CreatePoll(12, poll_name, answers)
		end
	end
]]