spawnpoints = {}
function AddLevelSpawnpoint(lvl,x,y)
	if not spawnpoints[lvl] then spawnpoints[lvl] = {} end
	table.insert(spawnpoints[lvl], {x = x,y = y})
end

usgn_spawnpoints = {}
function AddUSGNSpawnpoint(id,x,y)
	if not usgn_spawnpoints[id] then usgn_spawnpoints[id] = {} end
	table.insert(usgn_spawnpoints[id], {x = x,y = y})
end

function getHighestSpawnpoints(lvl)
	local highest
	for k, v in pairs(spawnpoints) do
		if k <= lvl then
			if not highest or k > highest then
				highest = k
			end
		end
	end
	if highest then return spawnpoints[highest] end
end

function getRandomSpawnpoint(level)
	local sp = getHighestSpawnpoints(level)
	if sp and table.size(sp) > 0 then
		return sp[math.random(1,#sp)]
	end
end

function getRandomUSGNSpawnpoint(id)
	if usgn_spawnpoints[id] then
		if table.size(usgn_spawnpoints[id]) > 0 then
			return usgn_spawnpoints[id][math.random(1, #usgn_spawnpoints[id])]
		end
	end
end

addhook("spawn","spawnpoint_tele")
function spawnpoint_tele(id)
	local choosen_sp = getRandomUSGNSpawnpoint(player(id,"usgn"))
	if choosen_sp == nil then
		choosen_sp = getRandomSpawnpoint(PlayerLevel(id))
	end
	if choosen_sp then
		parse("setpos "..id.." "..((choosen_sp.x*32)+16).." "..(choosen_sp.y*32)+16)
	end
end
