CreateChat "!lua" "[code]" (26) [[
	if args >= 2 then
		local code = string.sub(txt, pos[2])
		local f = loadstring(code)
		ProtectedCall(f)
	end
]]