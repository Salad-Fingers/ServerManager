if stream_dll_loaded then
	require("ex")

	FTP = {}
	FTP.Client = {}
	FTP.Queue = {}

	function FTP.InitServer()
		local e
		FTP.Server = CreateTCPServer(ADDONSET["ftp_port"])

		if FTP.Server then
			local port = TCPStreamPort(FTP.Server)
			print("[FTP] Initialized FTP server  "..game("remoteip")..":"..port)
			return true
		end
	end

	function FTP.ProcessClient(id,line)
		local Client = FTP.Client[id]

		if line then
			if string.sub(line, 1, 4) == "USER" then
				local UserName = string.sub(line, 6)
				if UserName:len() > 0 then
					Client.User = UserName
					WriteLine(Client.Socket, "331 Password required to access user account "..UserName..".")
				end
				return true
			elseif string.sub(line, 1, 4) == "PASS" then
				local Password = string.sub(line, 6)
				if Password:len() > 0 then
					if LoginUser(Client.User, Password) then
						Client.Password = Password
						Client.Logged = true
						WriteLine(Client.Socket, "230 Logged in.")
					else
						WriteLine(Client.Socket, "530 Login authentication failed")
					end
				else
					WriteLine(Client.Socket, "331 Password required to access user account "..UserName..".")
				end
				return true
			elseif string.sub(line, 1, 3) == "CWD" then
				if Client.Logged then
					local Folder = string.sub(line, 5)
					while string.sub(Folder, 1, 1) == "/" do
						Folder = string.sub(Folder, 2)
					end

					if Folder == ".." then
						local find
						for i = 1, #Client.Dir do
							if string.sub(Client.Dir, i, i) == "/" then
								find = i
							end
						end

						if find then
							Client.Dir = string.sub(Client.Dir, 1, find - 1) or ""
							WriteLine(Client.Socket, '250 "/'..Client.Dir..'" is new working directory')
						else
							Client.Dir = ""
							WriteLine(Client.Socket, '250 "/'..Client.Dir..'" is new working directory')
						end
					elseif Folder:len() > 0 then
						if line:sub(5, 5) == "/" or Client.Dir:len() <= 0 then
							Client.Dir = Folder
						else
							Client.Dir = Client.Dir.."/"..Folder
						end
						WriteLine(Client.Socket, '250 "/'..Client.Dir..'" is new working directory')
					else
						Client.Dir = ""
						WriteLine(Client.Socket, '250 "/'..Client.Dir..'" is new working directory')
					end
				else
					WriteLine(Client.Socket, "530 You aren't logged in")
				end
				return true
			elseif string.sub(line, 1, 4) == "SYST" then
				WriteLine(Client.Socket, "215 Lua Virtual Machine")
				return true
			elseif string.sub(line, 1, 4) == "TYPE" then
				if Client.Logged then
					local NewType = string.sub(line, 6)
					if NewType == "I" then
						WriteLine(Client.Socket, "200 TYPE is now 8-bit binary")
					elseif NewType == "A" then
						WriteLine(Client.Socket, "200 TYPE is now ASCII")
					end
				else
					WriteLine(Client.Socket, "530 You aren't logged in")
				end
				return true
			elseif string.sub(line, 1, 4) == "LIST" then
				if Client.Logged then
					if not Client.LSTART then
						Client.LSTART = os.clock()
					end

					if Client:ConnectData() then
						WriteLine(Client.Socket, "150 Opening ASCII mode data connection for file list.")
						local Dir
						if Client.Dir:len() > 0 then
							Dir = Client.Dir
						else
							Dir = os.currentdir()
						end

						if os.dirent(Dir) then
							for entry in os.dir(Dir) do
								if entry.type == "directory" then
									WriteLine(Client.DataSocket, "drwxr--r--	1	"..Client.User.."	PC	"..id.."	"..entry.size.."	"..entry.name)
								elseif entry.type == "file" then
									WriteLine(Client.DataSocket, "-rwxr--r--	1	"..Client.User.."	PC	"..id.."	"..entry.size.."	"..entry.name)
								end
							end
						end
						WriteLine(Client.Socket, "226 Transfer complete.")
						Client:CloseData()
						Client.LSTART = nil
						return true
					elseif os.clock() - Client.LSTART >= 2 then
						WriteLine(Client.Socket, "425 Can't open data connection")
						Client.LSTART = nil
						return true
					end
				else
					WriteLine(Client.Socket, "530 You aren't logged in")
					return true
				end
			elseif string.sub(line, 1, 4) == "PASV" then
				if Client.Logged then
					Client:ClosePasv()
					local sock = CreateTCPServer(0)
					if sock then
						local port = TCPStreamPort(sock)
						local ports = {}
						ports[1] = math.floor(port/256)
						ports[2] = port - ports[1]*256

						local ips = game("remoteip"):split(".")

						WriteLine(Client.Socket, "227 Entering Passive Mode ("..ips[1]..","..ips[2]..","..ips[3]..","..ips[4]..","..ports[1]..","..ports[2]..")")
						Client.PasvServer = sock
						Client.CONMODE = 1
					end
				else
					WriteLine(Client.Socket, "530 You aren't logged in")
				end
				return true
			elseif string.sub(line, 1, 4) == "PORT" then
				if Client.Logged then
					Client:CloseConMode()
					local adr = {string.match(line, "PORT (%d+),(%d+),(%d+),(%d+),(%d+),(%d+)")}
					if #adr >= 6 then
						local ip = adr[1].."."..adr[2].."."..adr[3].."."..adr[4]
						local port = tonumber(adr[5])*256 + tonumber(adr[6])

						if ip == Client:ip() then
							Client.DataSocket = DataSocket
							WriteLine(Client.Socket, "200 PORT command successful")
							Client.DIP = ip
							Client.DPORT = port
							Client.CONMODE = 2
						else
							WriteLine(Client.Socket, "500 I won't open a connection to "..ip.." (only to "..Client:ip()..")")
						end
					else
						WriteLine(Client.Socket, "500 I won't open a connection")
					end
				else
					WriteLine(Client.Socket, "530 You aren't logged in")
				end
				return true
			elseif string.sub(line, 1, 3) == "MKD" then
				if Client.Logged then
					local Folder = string.sub(line, 5)
					local Dir
					while string.sub(Folder, 1, 1) == "/" do
						Folder = string.sub(Folder, 2)
					end

					if Client.Dir:len() > 0 then
						Dir = Client.Dir.."/"..Folder
					else
						Dir = Folder
					end

					local success, e = os.mkdir(Dir)
					if success then
						WriteLine(Client.Socket, '257 "'..Folder..'" : The directory was successfully created')
					else
						local e = e or "File exists"
						WriteLine(Client.Socket, "550 Can't create directory: "..e.."")
					end
				else
					WriteLine(Client.Socket, "530 You aren't logged in")
				end
				return true
			elseif string.sub(line, 1, 3) == "RMD" then
				if Client.Logged then
					local Folder = string.sub(line, 5)
					local Dir
					while string.sub(Folder, 1, 1) == "/" do
						Folder = string.sub(Folder, 2)
					end

					if Client.Dir:len() > 0 then
						Dir = Client.Dir.."/"..Folder
					else
						Dir = Folder
					end

					local success, e = os.remove(Dir)
					if success then
						WriteLine(Client.Socket, "250 The directory was successfully removed")
					else
						WriteLine(Client.Socket, "550 Can't remove directory: "..e)
					end
				else
					WriteLine(Client.Socket, "530 You aren't logged in")
				end
				return true
			elseif string.sub(line, 1, 4) == "PWD" then
				if Client.Logged then
					WriteLine(Client.Socket, '257 "/'..Client.Dir..'" is the current working directory')
				else
					WriteLine(Client.Socket, "530 You aren't logged in")
				end
				return true
			elseif string.sub(line, 1, 4) == "RNFR" then
				local File = string.sub(line, 6)
				local Dir
				if Client.Dir:len() > 0 then
					Dir = Client.Dir.."/"..File
				else
					Dir = File
				end

				if File:len() <= 0 then
					WriteLine(Client.Socket, "550 No file name")
				elseif File:len() > 0 then
					if os.dirent(Dir) then
						WriteLine(Client.Socket, "350 RNFR accepted - file exists, ready for destination")
						Client.RenameFrom = File
					else
						WriteLine(Client.Socket, "550 Sorry, but that file doesn't exist")
					end
				end
				return true
			elseif string.sub(line, 1, 4) == "RNTO" then
				if not Client.RenameFrom or Client.RenameFrom:len() <= 0 then
					WriteLine(Client.Socket, "503 Need RNFR before RNTO")
					return true
				end

				local File = string.sub(line, 6)
				local RenameDir, SourceDir
				if Client.Dir:len() > 0 then
					RenameDir = Client.Dir.."/"..File
					SourceDir = Client.Dir.."/"..Client.RenameFrom
				else
					RenameDir = File
					SourceDir = Client.RenameFrom
				end

				if File:len() <= 0 then
					WriteLine(Client.Socket, "550 No file name")
				elseif File:len() > 0 then
					if os.dirent(RenameDir) then
						WriteLine(Client.Socket, "550 RENAME Failed - destination file already exists")
					else
						WriteLine(Client.Socket, "250 File successfully renamed")
						os.rename(SourceDir, RenameDir)
					end
				end
				return true
			elseif string.sub(line, 1, 4) == "DELE" then
				local File = string.sub(line, 6)
				local Dir
				while string.sub(File, 1, 1) == "/" do
					File = string.sub(File, 2)
				end

				if Client.Dir:len() > 0 then
					Dir = Client.Dir.."/"..File
				else
					Dir = File
				end

				local success, e = os.remove(Dir)
				if success then
					WriteLine(Client.Socket, "250 Deleted FILENAME")
				else
					WriteLine(Client.Socket, "550 Could not delete FILENAME: "..e)
				end
				return true
			elseif string.sub(line, 1, 4) == "STOR" then
				if Client.Logged then
					local File = string.sub(line, 6)
					while string.sub(File, 1, 1) == "/" do
						File = string.sub(File, 2)
					end
					while string.sub(File, string.len(File), string.len(File)) == "/" do
						File = string.sub(File, string.len(File) - 1)
					end

					if File:len() <= 0 then
						WriteLine(Client.Socket, "550 No file name")
						return true
					end

					local Dir, Path
					if Client.Dir:len() > 0 then
						Dir = Client.Dir.."/"..File
						Path = Client.Dir
					else
						Dir = File
					end

					if not os.dirent(Path) then
						if not Path then
							WriteLine(Client.Socket, "500 /"..Dir..": The system cannot find the path specified.")
							return true
						else
							local folders = Path:split("/")
							local NewPath = os.currentdir()
							for i = 1, #folders do
								NewPath = NewPath.."/"..folders[i]
								if not os.dirent(NewPath) then
									local success, e = os.mkdir(NewPath)
									if not success then
										WriteLine(Client.Socket, "500 /"..Dir..": "..e..".")
										return true
									end
								end
							end
						end
					end

					if not Client.SSTART then
						Client.SSTART = os.clock()
					end

					if Client:ConnectData() then
						if not Client.SWARN then
							Client.SFILE = io.open(Dir, "w")
							Client.SWARN = true
							WriteLine(Client.Socket, "150 Accepted data connection")
						end

						local data, e = Client.DataSocket:receive("*a")
						if data then
							if Client.SFILE then
								Client.SFILE:write(data)
							end
						elseif e == "closed" then
							Client.DataSocket = nil
							if Client.SFILE then
								Client.SFILE:close()
								Client.SFILE = nil
							end
							Client.SWARN = nil
							Client.SSTART = nil
							WriteLine(Client.Socket, "226 File successfully transferred")
							return true
						end
					elseif os.clock() - Client.SSTART >= 2 then
						Client.SSTART = nil
						Client.SWARN = nil
						WriteLine(Client.Socket, "425 Can't open data connection")
						return true
					end
				else
					WriteLine(Client.Socket, "530 You aren't logged in")
					return true
				end
			elseif string.sub(line, 1, 4) == "RETR" then
				if Client.Logged then
					local File = string.sub(line, 6)
					while string.sub(File, 1, 1) == "/" do
						File = string.sub(File, 2)
					end

					if File:len() <= 0 then
						WriteLine(Client.Socket, "550 No file name")
						return true
					end

					local Dir
					if Client.Dir:len() > 0 then
						Dir = Client.Dir.."/"..File
					else
						Dir = File
					end

					if not os.dirent(Dir) then
						WriteLine(Client.Socket, "550 Can't open "..File..": No such file or directory")
						return true
					end

					if not Client.RSTART then
						Client.RSTART = os.clock()
					end

					if Client:ConnectData() then
						if not Client.RWARN then
							Client.RWARN = true
							WriteLine(Client.Socket, "150 Accepted data connection")
							Client.RFILE = io.open(Dir, "r")
						end

						if Client.RFILE then
							local data = Client.RFILE:read(256)
							if data then
								Client.DataSocket:send(data)
							else
								if Client.RFILE then
									Client.RFILE:close()
									Client.RFILE = nil
								end
								Client.DataSocket:close()
								Client.RSTART = nil
								Client.RWARN = nil
								WriteLine(Client.Socket, "226 File successfully transferred")
								return true
							end
						else
							Client.RSTART = nil
							Client.RWARN = nil
							Client.DataSocket:close()
							WriteLine(Client.Socket, "226 File successfully transferred")
							return true
						end
					elseif os.clock() - Client.RSTART >= 2 then
						Client.RSTART = nil
						Client.RWARN = nil
						WriteLine(Client.Socket, "425 Can't open data connection")
						return true
					end
				else
					WriteLine(Client.Socket, "530 You aren't logged in")
					return true
				end
			elseif string.sub(line, 1, 4) == "FEAT" then
				WriteLine(Client.Socket, "211-Extensions supported:")
				WriteLine(Client.Socket, " USER")
				WriteLine(Client.Socket, " PASS")
				WriteLine(Client.Socket, " CWD")
				WriteLine(Client.Socket, " SYST")
				WriteLine(Client.Socket, " LIST")
				WriteLine(Client.Socket, " PASV")
				WriteLine(Client.Socket, " PORT")
				WriteLine(Client.Socket, " MKD")
				WriteLine(Client.Socket, " RMD")
				WriteLine(Client.Socket, " PWD")
				WriteLine(Client.Socket, " RNFR")
				WriteLine(Client.Socket, " RNTO")
				WriteLine(Client.Socket, " DELE")
				WriteLine(Client.Socket, " STOR")
				WriteLine(Client.Socket, " RETR")
				WriteLine(Client.Socket, "211 End.")
				return true
			else
				WriteLine(Client.Socket, "502 Command not implemented.")
				return true
			end
		end
	end

	function FTP.ProcessClients()
		for id, Client in pairs(FTP.Client) do
			if TCPStreamConnected(Client.Socket) then
				if ReadAvail(Client.Socket) > 0 then
					local line = ReadLine(Client.Socket)
					table.insert(Client.CMDQUEUE, line)
				end

				for CMDID, CMD in pairs(Client.CMDQUEUE) do
					if FTP.ProcessClient(id, CMD) then
						Client.CMDQUEUE[CMDID] = nil
					end
				end
			else
				local ip = StringIP(TCPStreamIP(Client.Socket))
				local port = TCPStreamPort(Client.Socket)
				print("[FTP] Client "..ip..":"..port.." disconnected")
				Client:Close()
				FTP.Client[id] = nil
			end
		end
	end

	function FTP.ProcessServer()
		if FTP.Server then
			local CurrentClient = AcceptTCPStream(FTP.Server)
			if CurrentClient then
				local ip = StringIP(TCPStreamIP(CurrentClient))
				local port = TCPStreamPort(CurrentClient)
				print("[FTP] New Client "..ip..":"..port)

				WriteLine(CurrentClient, "220 Hello, this is Starkkz's FTP Service")

				local Client = {}
				Client.Socket = CurrentClient
				Client.RenameFrom = ""
				Client.User = ""
				Client.Password = ""
				Client.Dir = ""
				Client.Logged = false
				Client.CONMODE = 0
				Client.DIP = ""
				Client.DPORT = 0
				Client.CMDQUEUE = {}

				function Client:ip()
					return StringIP(TCPStreamIP(Client.Socket))
				end

				function Client:port()
					return TCPStreamPort(Client.Socket)
				end

				function Client:DataIP()
					if Client.DataSocket then
						return StringIP(TCPStreamIP(Client.DataSocket))
					end
				end

				function Client:DataPort()
					if Client.DataSocket then
						return TCPStreamPort(Client.DataSocket)
					end
				end

				function Client:ConnectData()
					if Client.DataSocket then
						return true
					end

					if Client.CONMODE == 1 then
						if Client.PasvServer then
							local Sock = AcceptTCPStream(Client.PasvServer)
							if Sock then
								Client.DataSocket = Sock
								return true
							end
						end
					elseif Client.CONMODE == 2 then
						if Client.DIP:len() > 0 and Client.DPORT > 0 then
							local Sock = OpenTCPStream(Client.DIP, Client.DPORT)
							if Sock then
								Client.DataSocket = Sock
								return true
							end
						end
					end
					return false
				end

				function Client:CloseData()
					if Client.DataSocket then
						CloseTCPStream(Client.DataSocket)
						Client.DataSocket = nil
					end
				end

				function Client:ClosePasv()
					if Client.PasvServer then
						CloseTCPStream(Client.PasvServer)
						Client.PasvServer = nil
						Client:CloseData()
					end
				end

				function Client:CloseConMode()
					if Client.CONMODE == 1 then
						Client:ClosePasv()
					elseif Client.CONMODE == 2 then
						Client:CloseData()
					end
				end

				function Client:Close()
					Client:CloseData()
					Client:ClosePasv()
					CloseTCPStream(Client.Socket)
				end

				table.insert(FTP.Client, Client)
			end
		end
	end

	CreateChat "@initftp" "" (30) [[
		if FTP.InitServer() then
			msgc2(id, Color(0, 255, 0)..Translate(id, 357, TCPStreamPort(FTP.Server)))
		else
			ErrorMSG(id, Translate(id, 358))
		end
	]]

	CreateChat "@closeftp" "" (30) [[
		if FTP.Server then
			CloseTCPStream(FTP.Server)
			msgc2(id, Color(0, 255, 0)..Translate(id, 359))
		else
			ErrorMSG(id, Translate(id, 360))
		end
	]]

	function FTPButton(id)
		if FTP.Server then
			return Translate(id, 361).."|"..Translate(id, 362, TCPStreamPort(FTP.Server))
		end
		return Translate(id, 361).."|"..Translate(id, 3)
	end

	function FTPToggle(id)
		if FTP.Server then
			CloseTCPStream(FTP.Server)
			FTP.Server = nil
		else
			FTP.InitServer()
		end
	end
	CreateSetting(FTPButton, FTPToggle)

	addhook("always","FTP.Process")
	function FTP.Process()
		FTP.ProcessServer()
		FTP.ProcessClients()
	end
end
