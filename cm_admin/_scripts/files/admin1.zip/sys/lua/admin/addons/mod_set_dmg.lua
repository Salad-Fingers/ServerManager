function DMGAntiHit()
	if SERVER_DATA["setdmg"] then
		return 1
	end
end
CreateHitAttachment(DMGAntiHit)

function DmgsetButton(id)
	if SERVER_DATA["setdmg"] then
		return Translate(id, 274).."|"..Translate(id, 3)
	end
	return Translate(id, 274).."|"..Translate(id, 2)
end

function DmgsetToggle()
	if SERVER_DATA["setdmg"] then
		SERVER_DATA["setdmg"] = nil
	else
		SERVER_DATA["setdmg"] = true
	end
end

CreateSetting(DmgsetButton, DmgsetToggle)
