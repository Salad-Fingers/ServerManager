damage_received_hud = GenerateHud()
damage_taken_hud = GenerateHud()

function DamageIndicate(id,source,wpn,hpdmg,apdmg,rawdmg)	
	if not HudExists(id, damage_received_hud) then
		Hudtxt2(id, damage_received_hud, hpdmg+apdmg, 320, 240, 0, 255, 0, 0)
		AddTimer(500, false, Freehud, id, damage_received_hud)
	end
	
	if player(source,"exists") then
		if not HudExists(id, damage_taken_hud) then
			Hudtxt2(source, damage_taken_hud, hpdmg+apdmg, 320, 210, 0, 0, 0, 255)
			AddTimer(500, false, Freehud, source, damage_taken_hud)
		end
	end
end
CreateHitAttachment(DamageIndicate)