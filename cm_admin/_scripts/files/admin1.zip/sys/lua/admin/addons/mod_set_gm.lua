gm_name = {}
gm_name[0] = "trans:281"
gm_name[1] = "trans:282"
gm_name[2] = "trans:283"
gm_name[3] = "trans:284"
gm_name[4] = "trans:285"

gm_max = 4

function GameMode()
	return tonumber(game("sv_gamemode"))
end

function GMButtonCustom(id)
	return Translate(id, 280).."|"..(gm_name[GameMode()] or "")
end

function GMButtonToggle()
	local gm = GameMode() + 1
	if gm > gm_max then
		gm = 0
	end
	parse("sv_gm "..gm)
end

CreateSetting(GMButtonCustom, GMButtonToggle)
