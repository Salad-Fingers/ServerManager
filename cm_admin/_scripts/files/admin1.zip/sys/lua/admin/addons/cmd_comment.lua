SERVER_DATA["comments"] = {}

CreateChat "!comment" "[text]" (0) [[
	local message = string.sub(txt, pos[2])
	if string.len(message) > 0 then
		if player(id,"usgn") > 0 then
			table.insert(SERVER_DATA["comments"], "#"..player(id,"usgn")..": "..message)
			msgc2(id, Translate(id, 102), 0, 255, 0)
		else
			ErrorMSG(id, Translate(id, 103))
		end
	end
]]

CreateChat "!comments" "" (30) [[
	if table.size(SERVER_DATA["comments"]) > 0 then
		for _, m in pairs(SERVER_DATA["comments"]) do
			msgc2(id, m, 255, 255, 0)
		end
		SERVER_DATA["comments"] ={}
		SaveServer()
	else
		ErrorMSG(id, Translate(id, 104))
	end
]]
