function FriendlyfireButton(id)
	if game("sv_friendlyfire") == "1" then
		return Translate(id, 279).."|"..Translate(id, 2)
	end
	return Translate(id, 279).."|"..Translate(id, 3)
end

function FriendlyfireToggle()
	if game("sv_friendlyfire") == "1" then
		parse("sv_friendlyfire 0")
	elseif game("sv_friendlyfire") == "0" then
		parse("sv_friendlyfire 1")
	end
end

CreateSetting(FriendlyfireButton, FriendlyfireToggle)
