function FixedName(n)
	if not n then return end
	local n = string.gsub(n, "|", "!")
	n = string.gsub(n, ",", "")
	return n
end

function WeaponID(pl)
	if player(pl,"exists") and player(pl,"health") > 0 then
		for _, w in pairs(item(0,"table")) do
			if not item(w, "dropped") then
				msg("Item "..item(w,"name").." is carried by player ID "..item(w,"player"))
				
				if item(w,"player") == pl then
					return w
				end
			end
		end
	end
end

function setmaxhealth(id,health)
	parse("setmaxhealth "..id.." "..health)
	parse("sethealth "..id.." "..health)
end

function speedmod(id,speed)
	parse("speedmod "..id.." "..speed)
end

function increasespeedmod(id,s)
	parse("speedmod "..id.." "..player(id,"speedmod")+s)
end

function increasehealth(id,h)
	parse("sethealth "..id.." "..player(id,"health")+h)
end

function increasemaxhealth(id,h)
	parse("setmaxhealth "..id.." "..player(id,"maxhealth")+h)
	parse("sethealth "..id.." "..player(id,"maxhealth"))
end

function NameColor(id)
	local r, g, b
	if game("sv_gamemode") == 1 then
		r, g, b = 0, 255, 0
	elseif player(id,"team") == 1 then
		r, g, b = 255, 25, 0
	elseif player(id,"team") == 2 then
		r, g, b = 50, 150, 255
	elseif player(id,"team") == 0 then
		r, g, b = 150, 150, 150
	end
	
	if USER[id]["tag"] then
		local rank = SERVER_RANK[PlayerRank(id)]
		r = USER[id]["colorr"] or rank.r
		g = USER[id]["colorg"] or rank.g
		b = USER[id]["colorb"] or rank.b
	end
	return r, g, b
end

function PlayerName(id)
	if not id or type(id) ~= "number" then return nil end
	if player(id,"exists") then
		local r, g, b
		local name = player(id,"name")
		if game("sv_gamemode") == 1 then
			r, g, b = 0, 255, 0
		elseif player(id,"team") == 1 then
			r, g, b = 255, 25, 0
		elseif player(id,"team") == 2 then
			r, g, b = 50, 150, 255
		elseif player(id,"team") == 0 then
			r, g, b = 150, 150, 150
		end

		if USER[id]["tag"] then
			local rank = SERVER_RANK[PlayerRank(id)]
			r = USER[id]["colorr"] or rank.r
			g = USER[id]["colorg"] or rank.g
			b = USER[id]["colorb"] or rank.b
			name = USER[id]["name"] or name
		end
		return Color(r, g, b)..name..Color(255,255,0)
	end
end

function USGNName(usgnid)
	if not usgnid or type(usgnid) ~= "number" then return nil end
	local p = USGNPlayer(usgnid)
	if p then return PlayerName(p) end
	
	if USGNDataExists(usgnid) then
		local r, g, b
		local name = USGN[usgnid]["game_name"]
		if game("sv_gamemode") == 1 then
			r, g, b = 0, 255, 0
		else
			r, g, b = 150, 150, 15
		end

		if USGN[usgnid]["tag"] then
			local rank = SERVER_RANK[USGNRank(usgnid)]
			r = USGN[usgnid]["colorr"] or rank.r
			g = USGN[usgnid]["colorg"] or rank.g
			b = USGN[usgnid]["colorb"] or rank.b
			name = USGN[usgnid]["name"] or name
		end
		return Color(r, g, b)..name..Color(255,255,0)
	end
end