USERTEMP_DEFAULTDATA["utsfx_kill"] = 0
USERTEMP_DEFAULTDATA["utsfx_timer"] = 0

addhook("startround","utsfx_reset")
function utsfx_reset()
	if SERVER_DATA["utsfx_enabled"] then
		for i = 1, tonumber(game("sv_maxplayers")) do
			USERTEMP[i]["utsfx_kill"] = 0
			USERTEMP[i]["utsfx_timer"] = 0
		end
	end
end

addhook("kill","utsfx_earnkill")
function utsfx_earnkill(k,v,w)
	if SERVER_DATA["utsfx_enabled"] then
		if Millisecs() - USERTEMP[k]["utsfx_timer"] > 3000 then
			USERTEMP[k]["utsfx_kill"] = 0
		end

		USERTEMP[k]["utsfx_kill"] = USERTEMP[k]["utsfx_kill"] + 1
		USERTEMP[k]["utsfx_timer"] = Millisecs()

		if w == 50 then
			parse("sv_sound starkkz/glados_utsfx/humiliation.wav")
			msgc(player(k,"name").." humiliated "..player(v,"name").."!@C", 255)
		else
			if USERTEMP[k]["utsfx_kill"] == 2 then
				parse("sv_sound starkkz/glados_utsfx/doublekill.wav")
				for _, id in pairs(player(0,"table")) do
					msgc2(id, Translate(id, 38, player(k,"name")).."@C", 255)
				end
			elseif USERTEMP[k]["utsfx_kill"] == 3 then
				parse("sv_sound starkkz/glados_utsfx/multikill.wav")
				for _, id in pairs(player(0,"table")) do
					msgc2(id, Translate(id, 39, player(k,"name")).."@C", 255)
				end
			elseif USERTEMP[k]["utsfx_kill"] == 4 then
				parse("sv_sound starkkz/glados_utsfx/ultrakill.wav")
				for _, id in pairs(player(0,"table")) do
					msgc2(id, Translate(id, 40, player(k,"name")).."@C", 255)
				end
			elseif USERTEMP[k]["utsfx_kill"] == 5 then
				parse("sv_sound starkkz/glados_utsfx/monsterkill.wav")
				for _, id in pairs(player(0,"table")) do
					msgc2(id, Translate(id, 41, player(k,"name")).."@C", 255)
				end
			elseif USERTEMP[k]["utsfx_kill"] > 5 then
				parse("sv_sound starkkz/glados_utsfx/unstoppable.wav")
				for _, id in pairs(player(0,"table")) do
					msgc2(id, Translate(id, 42, player(k,"name"), USERTEMP[k]["utsfx_kill"]).."@C", 255)
				end
			end
		end
	end
end

function UTSFXButtonCustom(id)
	if SERVER_DATA["utsfx_enabled"] then
		return Translate(id, 43).."|"..Translate(id, 2)
	end
	return Translate(id, 43).."|"..Translate(id, 3)
end

function UTSFXButtonToggle()
	if SERVER_DATA["utsfx_enabled"] then
		SERVER_DATA["utsfx_enabled"] = nil
	else
		SERVER_DATA["utsfx_enabled"] = true
	end
end
CreateSetting(UTSFXButtonCustom, UTSFXButtonToggle)

AddTransferFile("sfx/starkkz/glados_utsfx/doublekill.wav")
AddTransferFile("sfx/starkkz/glados_utsfx/humiliation.wav")
AddTransferFile("sfx/starkkz/glados_utsfx/monsterkill.wav")
AddTransferFile("sfx/starkkz/glados_utsfx/multikill.wav")
AddTransferFile("sfx/starkkz/glados_utsfx/ultrakill.wav")
AddTransferFile("sfx/starkkz/glados_utsfx/unstoppable.wav")
