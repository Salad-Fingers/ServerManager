CreateChat "!makect" "<id>" (25) [[
	if args >= 2 then
		local p = tonumber(s[2])
		if p and player(p,"exists") then
			parse("makect "..p)
			msg2(p, Translate(p, 129, PlayerName(id)))
		end
	end
]]
