addhook("buy","nobuyingFunc")
function nobuyingFunc(id)
	if SERVER_DATA["nobuying"] then
		ErrorMSG(id, Translate(id, 271))
		return 1
	end
end

function NobuyingButton(id)
	if SERVER_DATA["nobuying"] then
		return Translate(id, 270).."|"..Translate(id, 2)
	end
	return Translate(id, 270).."|"..Translate(id, 3)
end

function NobuyingToggle()
	if SERVER_DATA["nobuying"] then
		SERVER_DATA["nobuying"] = nil
		msg("trans:272@C")
	else
		SERVER_DATA["nobuying"] = true
		msg("trans:273@C")
	end
end

CreateSetting(NobuyingButton, NobuyingToggle)
