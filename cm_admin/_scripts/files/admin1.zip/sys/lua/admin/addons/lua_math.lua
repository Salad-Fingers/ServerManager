function math.sgn(x)
	return x/math.abs(x)
end

function math.dist(x1,y1,x2,y2)
	return math.sqrt((x1-x2)^2 + (y1-y2)^2)
end

function math.round(x,decimals)
	return math.floor((x * (10^(decimals or 0))) + 0.5)/(10^(decimals or 0))
end
