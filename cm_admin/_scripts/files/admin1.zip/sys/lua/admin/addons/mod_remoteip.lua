if stream_dll_loaded then
	print("Finding remote IP Address")
	local remoteip = "127.0.0.1"
	mod_remip_game = game

	function game(...)
		local arg = {...}
		if arg[1] == "remoteip" then
			return remoteip
		end
		return mod_remip_game(...)
	end

	if toboolean(ADDONSET["find_remote_ip"]) == true then
		local request = HTTPRequest("http://starkkz.zxq.net/ip.php")
		if request then
			while ReadAvail(request) > 0 do
				local line = ReadLine(request)
				if line:len() > 0 then
					local match = line:split(".")
					if #match == 4 then
						remoteip = line
						print("Found IP Address: "..line)
						break
					end
				end
			end
			CloseTCPStream(request)
		end
	end
end
