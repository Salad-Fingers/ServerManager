function ATBButton(id)
	if game("mp_autoteambalance") == "1" then
		return Translate(id, 269).."|"..Translate(id, 2)
	end
	return Translate(id, 269).."|"..Translate(id, 3)
end

function ATBToggle()
	if game("mp_autoteambalance") == "1" then
		parse("mp_autoteambalance 0")
	elseif game("mp_autoteambalance") == "0" then
		parse("mp_autoteambalance 1")
	end
end

CreateSetting(ATBButton, ATBToggle)
