CreateChat "@rcon" "[command]" (30) [[
	if args >= 2 then
		local _cmd = string.sub(txt, pos[2])
		printc("RCon ("..player(id,"name").."): ".._cmd, 0, 255, 0)
		parse(_cmd)
	end
]]