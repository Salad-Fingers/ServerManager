cmd_mute = CreateChat "!mute" "<id> <minutes> [reason]" (15)[[
	if args >= 3 then
		local p = tonumber(s[2])
		local mins = tonumber(s[3])
		local reason; if args >= 4 then reason = string.sub(txt, pos[4]) end

		if p and player(p,"exists") and mins then
			if not IPMuted(player(p,"ip")) then
				AddTempMute(p, mins, reason, id)
			else
				ErrorMSG(id, Translate(id, 136, USERIP[player(p,"ip")]["mute"]))
			end
		end
	end
]]

CreateChat "!unmute" "<id>" (15)[[
	local p = tonumber(s[2])
	if p and player(p,"exists") then
		RemoveTempMute(p, id)
	else
		ErrorMSG(id, Translate(id, 137))
	end
]]

function IPMuted(ip)
	return USERIP[ip]["mute"] ~= nil
end

function AddTempMute(id,mins,reason,source)
	if source and player(source,"exists") then
		if PlayerLevel(source) <= PlayerLevel(id) then
			return ErrorMSG(source, Translate(source, 138))
		end
	end

	if player(id,"exists") and not IPMuted(player(id,"ip")) then
		USERIP[player(id,"ip")]["mute"] = os.time() + mins*60
		if source and player(source,"exists") then
			if reason and string.len(reason) > 0 then
				for _, pid in pairs(player(0,"table")) do
					ServerMSG2(pid, Translate(pid, 139, PlayerName(source), PlayerName(id), reason, mins))
				end
			else
				for _, pid in pairs(player(0,"table")) do
					ServerMSG2(pid, Translate(id, 140, PlayerName(source), PlayerName(id), mins))
				end
			end
		else
			if reason and string.len(reason) > 0 then
				for _, pid in pairs(player(0,"table")) do
					ServerMSG2(pid, Translate(pid, 141, PlayerName(id), reason, mins))
				end
			else
				for _, pid in pairs(player(0,"table")) do
					ServerMSG2(pid, Translate(pid, 142, PlayerName(id), mins))
				end
			end
		end
	end
end

function RemoveTempMute(id)
	if player(id,"exists") and IPMuted(player(id,"ip")) then
		USERIP[player(id,"ip")]["mute"] = nil
		for _, pid in pairs(player(0,"table")) do
			ServerMSG2(pid, Translate(pid, 355, PlayerName(id)))
		end
	end
end

CreateChatAttachment(
	function (id,txt)
		if USERIP[player(id,"ip")]["mute"] and USERIP[player(id,"ip")]["mute"] > 0 then
			ErrorMSG(id, Translate(id, 143, os.timestring(USERIP[player(id,"ip")]["mute"]-os.time())))
			return 1
		end
	end
)

addhook("second","remove_temp_mute")
function remove_temp_mute()
	for _, id in pairs(player(0,"table")) do
		if USERIP[player(id,"ip")]["mute"] then
			if os.time() >= USERIP[player(id,"ip")]["mute"] then
				RemoveTempMute(id)
			end
		end
	end
end
