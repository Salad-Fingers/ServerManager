censored_list = {"fuck","bitch","asshole","idiot","smartass","shit"}

function censor_check(id, txt)
	if SERVER_DATA["censor_enabled"] then
		local txt = string.lower(txt)
		for _, word in pairs(censored_list) do
			if string.find(txt, word) then
				AddTempMute(id, 10, "trans:211()")
				return 1
			end
		end
	end
end
CreateChatAttachment(censor_check)

function CensorButtonCustom(id)
	if SERVER_DATA["censor_enabled"] then
		return Translate(id, 212).."|"..Translate(id, 2)
	end
	return Translate(id, 212).."|"..Translate(id, 3)
end

function CensorButtonToggle()
	if SERVER_DATA["censor_enabled"] then
		SERVER_DATA["censor_enabled"] = nil
	else
		SERVER_DATA["censor_enabled"] = true
	end
end

CreateSetting(CensorButtonCustom, CensorButtonToggle)
