game_menu = {}

function CreateMenu(title,txt)
	if title then
		local modifier = ""
		if string.find(title, "@") then
			modifier = title:match("@(.+)")
			title = title:sub(1, title:find("@")-1)
		end

		title = tonumber(title) or title
		game_menu[title] = {}
		game_menu[title].title = title
		game_menu[title].modifier = modifier
		setmetatable(game_menu[title], {__index = class_menu})

		game_menu[title]:SetText(txt)
		return game_menu[title]
	end
end

class_menu = {}

function InsertMenuTags(id,text)
	text = InsertTags(id, text)
	text = string.gsub(text, string.char(169)..".........", "")
	return text
end

function ButtonPage(b)
	if b < 9 then return 1 end
	if b >= 9 then
		local bt = b - 9
		return math.floor(bt/7) + 2
	end
end

function PageButtons(p)
	if p == 1 then return 8 end
	return 7
end

function GetButtons(page)
	local t = {}
	if page == 1 then
		for i = 1, 8 do table.insert(t, i) end
	elseif page > 1 then
		for i = 1, 7 do table.insert(t, 8 + i + (page-2)*7) end
	end
	return t
end

function class_menu:SetText(txt)
	if type(txt) == "string" then
		self.buttonText = txt:split(",")
	elseif type(txt) == "table" then
		self.buttonText = txt
	else
		self.buttonText = {}
	end
end

function class_menu:getcustombutton(button,id,default)
end

function class_menu:click(id,button,page)
end

function class_menu:getbutton(b,p,id)
	local button = GetButtons(p)[b]
	local defaultBtText = self.buttonText[button]
	local btText = self:getcustombutton(button, id, defaultBtText) or defaultBtText or ""
	return InsertMenuTags(id, btText)
end

function class_menu:PageText(p, id)
	local text = ""
	for i = 1, PageButtons(p) do
		text = text .. self:getbutton(i, p, id) ..","
	end
	if p == 1 then
		text = text..Translate(id, 311).."|"..Translate(id, 313).." "..p+1
	elseif p > 1 then
		text = text..Translate(id, 312).."|"..Translate(id, 313).." "..(p-1)..","..Translate(id, 311).."|"..Translate(id, 313).." "..(p+1)
	end
	return text
end

function class_menu:gettitle(id)
	if type(self.title) == "string" then
		return self.title
	elseif type(self.title) == "number" then
		if id then
			return Translate(id, self.title)
		else
			return "trans:"..self.title
		end
	end
end

function class_menu:OpenPlayer(id,page)
	local page = page or 1
	if string.len(self.modifier) > 0 then
		menu(id, self:gettitle(id).." | Page "..page.."@"..self.modifier..","..self:PageText(page, id))
	else
		menu(id, self:gettitle(id).." | Page "..page..","..self:PageText(page, id))
	end
end

addhook("menu","menu_click")
function menu_click(id,men,sel)
	local menu_name, menu_page = string.match(men, "(.+) | Page (%d+)")
	if menu_name and menu_page then
		menu_page = tonumber(menu_page)

		local menu_id, lan_id = TranslationID(menu_name, USER[id]["lan"])
		menu_id = menu_id or menu_name
		if menu_id then
			local menu_object = game_menu[menu_id]
			if menu_object then
				local button = GetButtons(menu_page)[sel] or 0
				if menu_page then
					if sel == 9 then
						menu_object:OpenPlayer(id, menu_page+1)
					elseif sel == 8 and menu_page > 1 then
						menu_object:OpenPlayer(id, menu_page-1)
					else
						menu_object:click(id, button, menu_page)
					end
				end
			end
		end
	end
end
