CreateChat "@modchat" "[text]" (15) [[
	if args >= 2 then
		local m = string.sub(txt, pos[2])
		RankMSG(15, PlayerName(id)..Color(200,200).." [Mod chat]: "..m)
	end
]]

CreateChat "@admchat" "[text]" (25) [[
	if args >= 2 then
		local m = string.sub(txt, pos[2])
		RankMSG(25, PlayerName(id).." [Admin chat]: "..m)
	end
]]