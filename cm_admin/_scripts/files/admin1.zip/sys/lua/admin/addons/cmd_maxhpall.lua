CreateChat "!maxhpall" "<health>" (25) [[
	if args >= 2 then
		local health = tonumber(s[2])
		if health then
			for _, pid in pairs(player(0,"table")) do
				ServerMSG2(pid, Translate(pid, 135, PlayerName(id), health))
			end
			for _, p in pairs(player(0,"table")) do
				if player(p,"team") > 0 then
					parse("setmaxhealth "..p.." "..health)
				end
			end
		end
	end
]]
