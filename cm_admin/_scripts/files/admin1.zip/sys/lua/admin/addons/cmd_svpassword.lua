CreateChat "@svpassword" "[password]" (30) [[
	if args >= 2 then
		local pass = string.sub(txt, pos[2])
		parse('sv_password "'..pass..'"')
	end
]]

CreateChat "@removepass" "" (30) [[
	parse('sv_password ""')
]]