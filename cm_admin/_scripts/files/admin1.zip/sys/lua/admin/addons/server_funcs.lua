_game = game
function game(...)
	local v = _game(unpack(arg))
	local intv = tonumber(v)
	if intv then return intv end
	return v
end

item_name = {}
item_name[253] = "Turret"
item_name[254] = "Gate Field"
item_name[255] = "Barbed Wire"
function ItemName(x)
	if item_name[x] then return item_name[x] end
	return itemtype(x, "name")
end