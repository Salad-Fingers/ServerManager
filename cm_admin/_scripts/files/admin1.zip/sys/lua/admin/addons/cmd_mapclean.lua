CreateChat "!mapclean" "<item id>" (16) [[
	if args >= 2 then
		local item_id = tonumber(s[2])
		if item_id then
			local item_table = item(0, "table")
			local i = 0
			for _, it in pairs(item_table) do
				if item(it, "type") == item_id then
					i = i + 100
					AddTimer(i, true, parse, "removeitem "..it)
				end
			end
		end
	elseif args == 1 then
		local item_table = item(0, "table")
		local i = 0
		for _, it in pairs(item_table) do
			i = i + 100
			AddTimer(i, true, parse, "removeitem "..it)
		end
	end
]]