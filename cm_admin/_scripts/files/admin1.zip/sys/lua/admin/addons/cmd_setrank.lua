CreateChat "@setrank" "<id> <rank>" (30)[[
	local p = tonumber(s[2])
	local rank = s[3]
	if p and player(p,"exists") and rank then
		if SERVER_RANK[rank] then
			PlayerSetRank(id, p, rank)
		end
	elseif not p then
		rank_menu:OpenPlayer(id, 1)
	end
]]