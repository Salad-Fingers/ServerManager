-- Spawn items menu
spawnitem_menu = CreateMenu("Spawn Item")
function spawnitem_menu:getcustombutton(b)
	return itemtype(b, "name")
end

function spawnitem_menu:click(id,button,page)
	if button > 0 then
		if itemtype(button, "name") then
			USERTEMP[id]["spawnitem"] = button
		end
		spawnitem_menu:OpenPlayer(id, page)
	end
end

function mouse_func_event_spawnitem(id,x,y)
	if USERTEMP[id]["spawnitem"] and USERTEMP[id]["spawnitem"] > 0 then
		parse("spawnitem "..USERTEMP[id]["spawnitem"].." "..math.floor(x/32).." "..math.floor(y/32))
	end
	USERTEMP[id]["mouseevent"] = nil
end
mouse_event_spawnitem = CreateMouseEvent(mouse_func_event_spawnitem); mouse_func_event_spawnitem = nil

CreateMouseFunc("trans:230", mouse_event_spawnitem,
function (id)
	spawnitem_menu:OpenPlayer(id, 1)
end, 16)
