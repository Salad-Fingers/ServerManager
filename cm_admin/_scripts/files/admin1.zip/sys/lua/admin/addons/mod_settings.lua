SETTINGS = {}

function CreateSetting(custombutton,click_f)
	if custombutton and click_f then
		table.insert(SETTINGS, {custombutton, click_f})
	end
end

setting_menu = CreateMenu(338)
function setting_menu:getcustombutton(b,id)
	if SETTINGS[b] then
		if type(SETTINGS[b][1]) == "function" then
			return SETTINGS[b][1](id)
		elseif type(SETTINGS[b][1]) == "string" then
			return SETTINGS[b][1]
		end
	end
end

function setting_menu:click(id,b,p)
	if SETTINGS[b] then
		SETTINGS[b][2](id)
	end
	if b > 0 then
		setting_menu:OpenPlayer(id, p)
	end
end

AddMenu(setting_menu, 26)
