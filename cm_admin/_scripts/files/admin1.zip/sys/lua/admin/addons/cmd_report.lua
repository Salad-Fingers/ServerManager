SERVER_DATA["player_report"] = SERVER_DATA["player_report"] or {}

function ReportPlayer(id,reason)
	table.insert(SERVER_DATA["player_report"], {player(id,"usgn"),player(id,"name"),player(id,"ip"),reason})
end

CreateChat "!report" "<id> [reason]" (0) [[
	if args >= 3 then
		local p = tonumber(s[2])
		local reason = string.sub(txt, pos[3])
		if p and reason then
			RankMSG(26, "trans:152("..PlayerName(id).."�"..PlayerName(p).."�"..reason..")", 255)
			ReportPlayer(p, reason)
			msgc2(id, Translate(id, 151), 0, 255)
		end
	end
]]

CreateChat "@checkreport" "" (26) [[
	if table.size(SERVER_DATA["player_report"]) > 0 then
		local i = 0
		for k, v in pairs(SERVER_DATA["player_report"]) do
			i = i + 100
			AddTimer(i, false, msgc2, id, "trans:153("..v[2].."�"..v[3].."�"..v[1].."�"..v[4]..")", 255, 255)
			SERVER_DATA["player_report"][k] = nil
		end
	else
		msgc2(id, Translate(id, 154), 255, 0, 0)
	end
]]

reports_menu = CreateMenu(351)
function reports_menu:getcustombutton(b,id,def)
	if b <= table.size(SERVER_DATA["player_report"]) then
		local i = 0
		for k, v in pairs(SERVER_DATA["player_report"]) do
			i = i + 1
			if i == b then
				local usgn = v[1]
				local name = v[2]
				local ip = v[3]
				if usgn > 0 then
					return USGN[usgn]["name"] or USGN[usgn]["game_name"] or "#"..usgn
				else
					return name.."("..ip..")"
				end
			end
		end
	end
end

function reports_menu:click(id,b,p)
	if b > 0 then
		if b <= table.size(SERVER_DATA["player_report"]) then
			local i = 0
			for k, v in pairs(SERVER_DATA["player_report"]) do
				i = i + 1
				if i == b then
					msgc2(id, Translate(id, 154, v[2], v[3], v[1], v[4]), 255, 255)
					SERVER_DATA["player_report"][k] = nil
					break
				end
			end
		end
		reports_menu:OpenPlayer(id, 1)
	end
end

AddMenu(reports_menu, 26)
