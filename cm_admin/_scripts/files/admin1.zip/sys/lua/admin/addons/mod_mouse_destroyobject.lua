kill_object_event = CreateMouseEvent(function (id,x,y)
	local closest
	for _, o in pairs(object(0,"table")) do
		local dist = math.sqrt((object(o,"x")-x)^2 + (object(o,"y")-y)^2)
		if dist < 32 then
			if not closest or dist < closest[2] then
				closest = {o, dist}
			end
		end
	end

	if closest then
		parse("killobject "..closest[1])
	end

	USERTEMP[id]["mouseevent"] = nil
end)
CreateMouseFunc("trans:224", kill_object_event, nil, 15)
