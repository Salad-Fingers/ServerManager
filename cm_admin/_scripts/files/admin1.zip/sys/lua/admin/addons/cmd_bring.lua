CreateChat "!bring" "<id>" (15)[[
	local p = tonumber(s[2])
	if p and player(p,"exists") and player(id,"health") > 0 then
		if player(p,"health") > 0 then
			parse("setpos "..p.." "..player(id,"x").." "..player(id,"y"))
		elseif player(p,"team") > 0 then
			parse("spawnplayer "..p.." "..player(id,"x").." "..player(id,"y"))
		end
	elseif not p then
		bring_menu:OpenPlayer(id, 1)
	end
]]

bring_menu = CreateMenu("Bring")
function bring_menu:getcustombutton(b)
	return player(b,"name")
end

function bring_menu:click(id,b,p)
	if player(b,"exists") and player(id,"health") > 0 then
		if player(b,"health") > 0 then
			parse("setpos "..b.." "..player(id,"x").." "..player(id,"y"))
		elseif player(b,"team") > 0 then
			parse("spawnplayer "..b.." "..player(id,"x").." "..player(id,"y"))
		end
	end
end