CreateChat "!rs" "" (0) [[
	parse("setscore "..id.." 0")
	parse("setdeaths "..id.." 0")
	msgc2(id, Translate(id, 157), 0, 255, 0)
]]
