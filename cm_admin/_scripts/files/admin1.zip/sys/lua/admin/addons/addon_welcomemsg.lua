AddTransferFile("sfx/starkkz/welcome.wav")

addhook("join","welcome_message")
function welcome_message(id)
	if SERVER_DATA["wmsg_active"] then
		msgc2(id, Translate(id, 52, PlayerName(id)), 255, 255, 0)
		parse("sv_sound2 "..id.." starkkz/welcome.wav")
	end
end

function WMSGButton(id)
	if SERVER_DATA["wmsg_active"] then
		return Translate(id, 53).."|"..Translate(id, 2)
	end
	return Translate(id, 53).."|"..Translate(id, 3)
end

function WMSGToggle()
	if SERVER_DATA["wmsg_active"] then
		SERVER_DATA["wmsg_active"] = nil
	else
		SERVER_DATA["wmsg_active"] = true
	end
end
CreateSetting(WMSGButton,WMSGToggle)
