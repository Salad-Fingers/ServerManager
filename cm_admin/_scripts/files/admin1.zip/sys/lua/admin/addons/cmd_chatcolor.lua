CreateChat "!chatcolor" "<r> <g> <b>" (10) [[
	if args >= 4 then
		local r = tonumber(s[2])
		local g = tonumber(s[3])
		local b = tonumber(s[4])
		if r and g and b then
			USER[id]["ccolorr"] = r
			USER[id]["ccolorg"] = g
			USER[id]["ccolorb"] = b
		end
	else
		USER[id]["ccolorr"] = nil
		USER[id]["ccolorg"] = nil
		USER[id]["ccolorb"] = nil
	end
]]