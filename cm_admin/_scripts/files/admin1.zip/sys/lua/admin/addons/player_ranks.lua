USGN_DEFAULTDATA["rank"] = "player"

SERVER_RANK = {}
SERVER_RANK["banned"] = {prefix = "trans:314",r=55,g=0,b=55,lvl=-1}				-- Banned
SERVER_RANK["player"] = {prefix = "trans:315",r=255,g=255,b=255,lvl = 0}		-- Player
SERVER_RANK["user"] = {prefix = "trans:316",r=255,g=255,b=255,lvl=1}			-- User
SERVER_RANK["newbie"] = {prefix = "trans:317",r=0,g=50,b=255,lvl=4}				-- Newbie
SERVER_RANK["vip"] = {prefix = "trans:318",r=150,g=0,b=100,lvl = 5}				-- Vip
SERVER_RANK["member"] = {prefix = "trans:319",r=0,g=50,b=255,lvl=10}			-- Member
SERVER_RANK["mod"] = {prefix = "trans:320",r=150,g=150,b=150,lvl = 15}			-- Mod
SERVER_RANK["smod"] = {prefix = "trans:321",r=100,g=100,b=100,lvl = 16}			-- Super-Mod
SERVER_RANK["supporter"] = {prefix = "trans:322",r=100,g=0,b=100,lvl = 20}		-- Supporter
SERVER_RANK["admin"] = {prefix = "trans:323",r=0,g=255,b=255,lvl = 25}			-- Admin
SERVER_RANK["sadmin"] = {prefix = "trans:324",r=0,g=200,b=200,lvl = 26}			-- Super-Admin
SERVER_RANK["head-admin"] = {prefix = "trans:325",r=255,g=0,b=0,lvl = 30}		-- Head-Admin
SERVER_RANK["owner"] = {prefix = "trans:326",r=255,g=255,b=0,lvl = 35}				-- Owner

function SetTempRank(data,rank,t)
	SetTempRankDate(data, rank, os.time() + t)
end

function SetTempRankDate(data,rank,d)
	data["trank"] = rank
	data["trdate"] = d
end

function SetPlayerTempRank(id,rank,t)
	local date = os.time() + t
	SetTempRank(USER[id], rank, t)
	ServerMSG("trans:327("..PlayerName(id).."�"..RankPrefix(rank).."�"..os.date("%d", date).." "..os.date("%B", date).." "..os.date("%Y", date)..")")
end

function TempRankExpired(data)
	if os.time() >= data["trdate"] then
		return true
	end
end

function TempRank(id)
	local rank_name = USER[id]["trank"]
	if rank_name then
		if not TempRankExpired(USER[id]) then
			return USER[id]["trank"]
		end
	end
end

function USGNTempRank(usgnid)
	local rank_name = USGN[usgnid]["trank"]
	if rank_name then
		if not TempRankExpired(USGN[usgnid]) then
			return USGN[usgnid]["trank"]
		end
	end
end

function PlayerLevel(id)
	return RankLevel(PlayerRank(id))
end

function USGNLevel(usgnid)
	if USGNDataExists(usgnid) then
		return RankLevel(USGNRank(usgnid)) or RankLevel(USGN_DEFAULTDATA["rank"])
	end
	return RankLevel(USGN_DEFAULTDATA["rank"])
end

function USGNRank(usgnid)
	if USGNDataExists(usgnid) then
		local tr = USGNTempRank(usgnid)
		if tr then
			return tr
		end
		return USGN[usgnid]["rank"] or USGN_DEFAULTDATA["rank"]
	end
	return USGN_DEFAULTDATA["rank"]
end

function PlayerRank(id)
	local tr = TempRank(id)
	if tr then
		return tr
	end
	return USER[id]["rank"]
end

function RankPrefix(r)
	if SERVER_RANK[r] then return SERVER_RANK[r].prefix end
	return r
end

function RankLevel(r)
	if SERVER_RANK[r] then return SERVER_RANK[r].lvl end
	return 0
end

function RankExists(r)
	return SERVER_RANK[r] and not SERVER_RANK[r].hidden
end

function RankLower(x,y)
	if not x or not y then return false end
	if not SERVER_RANK[x] or not SERVER_RANK[y] then return false end
	return SERVER_RANK[x].lvl < SERVER_RANK[y].lvl
end

function RankHigher(x,y)
	if not x or not y then return false end
	if not SERVER_RANK[x] or not SERVER_RANK[y] then return false end
	return SERVER_RANK[x].lvl > SERVER_RANK[y].lvl
end

function HighestLevel()
	local l = 0
	for k, v in pairs(SERVER_RANK) do
		if v.lvl > l then
			l = v.lvl
		end
	end
	return l
end

function LevelRanks(lvl)
	local r = {}
	local last
	for name, v in pairs(SERVER_RANK) do
		if v.lvl == lvl then
			if not last then
				last = name
			else
				r[last] = name
				last = name
			end
		end
	end
	return r
end

function FirstRank()
	local r
	for k, v in pairs(SERVER_RANK) do
		if RankExists(k) then
			if not r or v.lvl < SERVER_RANK[r].lvl then
				r = k
			end
		end
	end
	return r
end

function LastRank()
	local r = USGN_DEFAULTDATA["rank"]
	local n = NextRank(r)
	while n do
		r = n
		n = NextRank(r)
	end
	return r
end

function NextRank(name)
	local ranks = LevelRanks(SERVER_RANK[name].lvl)
	if ranks[name] then
		return ranks[name]
	else
		local lowestName
		for k, v in pairs(SERVER_RANK) do
			if RankExists(k) then
				if v.lvl > SERVER_RANK[name].lvl and k ~= name then
					if not lowestName and not v.hidden then
						lowestName = k
					elseif v.lvl < SERVER_RANK[lowestName].lvl and not v.hidden then
						lowestName = k
					end
				end
			end
		end
		return lowestName
	end
end

function RankList()
	local _list = {}
	local _last = FirstRank()
	while true do
		if _last then
			table.insert(_list, _last)
		else
			break
		end

		_last = NextRank(_last)
	end
	return _list
end

function SetUSGNRank(usgnid,rank)
	if USGNDataExists(usgnid) then
		USGN[usgnid]["rank"] = rank
		SaveUSGN(usgnid)
	end
end

function SetUSERRank(id,rank)
	if player(id,"exists") then
		USER[id]["rank"] = rank
	end
end

function DefaultRank()
	return USGN_DEFAULTDATA["rank"]
end

function SetExpireRank(id)
	USER[id]["trank"] = nil
	USER[id]["trdate"] = nil
	SaveUSER(id)

	Warning2(id, Translate(id, 328))
	ServerMSG("trans:329("..PlayerName(id)..")")
end

function TempRankRemaining(data)
	local rem_time = data["trdate"] - os.time()
	return os.timestring(rem_time)
end

addhook("second","RankExpire")
function RankExpire()
	for _, id in pairs(player(0,"table")) do
		if USER[id]["trank"] then
			if TempRankExpired(USER[id]) then
				SetExpireRank(id)
			end
		end
	end
end

function RankExpireWarn(id)
	if USER[id]["trank"] then
		if not USERTEMP[id]["expirewarn"] then
			if TempRankExpired(USER[id]) then
				SetExpireRank(id)
			else
				local end_time = USER[id]["trdate"]
				Warning2(id, Translate(id, 330, TempRankRemaining(USER[id])))
			end
			USERTEMP[id]["expirewarn"] = true
		end
	end
end
CreateTeamAttachment(RankExpireWarn)
