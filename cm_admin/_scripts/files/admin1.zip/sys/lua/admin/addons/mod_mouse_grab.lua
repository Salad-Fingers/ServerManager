function mouse_grab_func_event(id,x,y)
	if USERTEMP[id]["targetplayer"] then
		USERTEMP[id]["targetplayer"] = nil
		USERTEMP[id]["mouseevent"] = nil
	else
		USERTEMP[id]["mouseevent"] = nil

		for _, p in pairs(player(0,"table")) do
			if math.sqrt((x-player(p,"x"))^2 + (y-player(p,"y"))^2) < 32 and p ~= id then
				USERTEMP[id]["targetplayer"] = p
				USERTEMP[id]["mouseevent"] = mouse_grabmove_event
				break
			end
		end
	end
end

function mouse_grabmove_func_event(id,x,y)
	local p = USERTEMP[id]["targetplayer"]
	if p and player(p,"exists") and player(p,"team") > 0 then
		if player(p,"health") > 0 then
			parse("setpos "..p.." "..x.." "..y)
		else
			parse("spawnplayer "..p.." "..x.." "..y)
		end
	elseif USERTEMP[id]["targetplayer"] then
		USERTEMP[id]["mouseevent"] = nil
		USERTEMP[id]["targetplayer"] = nil
	else
		USERTEMP[id]["mouseevent"] = nil
	end
end

mouse_grab_event = CreateMouseEvent(mouse_grab_func_event); mouse_grab_func_event = nil
mouse_grabmove_event = CreateMouseEvent(mouse_grabmove_func_event); mouse_grabmove_func_event = nil

CreateMouseFunc("trans:226", mouse_grab_event, nil, 25)
