function Bannable(id,source)
	if source and player(source,"exists") then
		if RankLower(PlayerRank(id), PlayerRank(source)) then
			return false
		end
	end
	return true
end

function TempbanUSGN(usgn,minutes)
	parse('banusgn '..usgn..' '..minutes)
end

function TempbanIP(ip,minutes)
	parse('banip "'..ip..'" '..minutes)
end

function TempbanName(name,minutes)
	parse('banname "'..name..'" '..minutes)
end

function AddTempban(id,m,source,reason)
	if not id or not player(id,"exists") then return nil end

	if source and player(source,"exists") then
		if PlayerLevel(id) >= PlayerLevel(source) then
			return ErrorMSG(source, Translate(source, 274))
		end
	end

	local reason = reason or ""
	local usgn = player(id,"usgn")
	local ip = player(id,"ip")
	local name = player(id,"name")

	if string.len(reason) > 0 then
		if source and player(source,"exists") then
			ServerMSG("trans:296("..PlayerName(source).."�"..PlayerName(id).."�"..reason.."�"..m..")")
		else
			ServerMSG("trans:297("..PlayerName(id).."�"..reason.."�"..m..")")
		end
	else
		if source and player(source,"exists") then
			ServerMSG("trans:298("..PlayerName(source).."�"..PlayerName(id).."�"..m..")")
		else
			ServerMSG("trans:299("..PlayerName(id).."�"..m..")")
		end
	end

	if player(id,"usgn") and player(id,"usgn") > 0 then
		parse('banusgn '..usgn..' '..m..' "'..reason..'"')
	end
	parse('banip "'..ip..'" '..m..' "'..reason..'"')
	parse('banname "'..name..'" '..m..' "'..reason..'"')
end
