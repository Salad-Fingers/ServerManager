CreateChat "!strip" "<id> [wpn]" (10) [[
	local p = tonumber(s[2])
	local wpn = tonumber(s[3])
	if p and player(p,"exists") and wpn then
		parse("strip "..p.." "..wpn)
	elseif p and player(p,"exists") then
		local x, y = player(p,"x"), player(p,"y")
		parse("spawnplayer "..p.." "..x.." "..y)
		parse("setpos "..p.." "..x.." "..y)
	end
]]