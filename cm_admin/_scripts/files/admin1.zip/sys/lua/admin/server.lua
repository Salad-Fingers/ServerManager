AM = {}
mod_path = "sys/lua/admin/"
mod_name = "Starkkz's Admin Script"
mod_version = "0.1.5"

package.cpath = package.cpath..";./"..mod_path.."res/?.dll;/lib/?.dll"

dofile(mod_path.."os.lua")
if string.find(os.name(), "windows") then
	function LoadDLL(path,func,name)
		local f, e = package.loadlib(path, func)
		if f and not e then
			f()
			print("Loaded "..name.." DLL")
			return true
		else
			print("Failed to load "..name.." DLL: "..e)
		end
	end

	if LoadDLL(mod_path.."res/stream.dll", "init", "stream functions") then
		dofile(mod_path.."stream_functions_dll.lua")
	else
		dofile(mod_path.."stream_functions.lua")
	end
else
	dofile(mod_path.."stream_functions.lua")
end
dofile(mod_path.."data.lua")

-- Important addons
dofile(mod_path.."addons/lua_table.lua")
dofile(mod_path.."addons/lua_math.lua")
dofile(mod_path.."addons/lua_string.lua")
dofile(mod_path.."addons/lua_funcs.lua")
dofile(mod_path.."addons/lua_error.lua")

function SetTempAddonTable(t)
	local mt = {}
	function mt.__newindex(g,k,v)
		t[k] = CopyObject(v)
	end

	setmetatable(_G, mt)
end

function RequireTempAddon(name)
	local f = io.open(mod_path.."addons/"..name..".lua")
	if f then
		f:close()

		local t = {}
		SetTempAddonTable(t)
		ProtectedCall(dofile, mod_path.."addons/"..name..".lua")

		setmetatable(_G, nil)
		return t
	end
end

function SetAddonTable(t)
	local mt = {}
	function mt.__newindex(g,k,v)
		t[k] = v

		if k ~= "Init" then
			setmetatable(_G, nil)
			_G[k] = v

			setmetatable(_G, mt)
		end
	end

	setmetatable(_G, mt)
end

ADDON_INSTALLED = {}
function RequireAddon(name)
	local f = io.open(mod_path.."addons/"..name..".lua")
	if f then
		f:close()

		local t = {}
		SetAddonTable(t)
		ProtectedCall(dofile, mod_path.."addons/"..name..".lua")

		ADDON_INSTALLED[name] = true

		setmetatable(_G, nil)
		return t
	end
end

function ScanAddon(a,keyword)
	local f = io.open(mod_path.."addons/"..a..".lua")
	if f then
		local code = f:read("*a"); f:close()
		if code:find(keyword) then
			msg("Found "..keyword.." in addon: "..a)
		end
		return true
	end
end

function LoadAddons()
	print(string.char(169).."000255000Loading server addons")
	local f = io.open(mod_path.."addon_config.txt", "r")
	local temp_addon = {}
	if f then
		for lines in f:lines() do
			if string.byte(lines, string.len(lines)) == 13 then
				lines = string.sub(lines, 1, string.len(lines)-1)
			end

			if string.len(lines) > 0 and string.sub(lines, 1, 2) ~= "//" then
				temp_addon[lines] = RequireAddon(lines)
				if temp_addon[lines] then
					print(string.char(169).."000255000Loaded addon "..lines)
				else
					print(string.char(169).."255000000Failed to load addon "..lines)
				end
			end
		end
		f:close()
	end

	for k, t in pairs(temp_addon) do
		if t.Init then
			t.Init()
		end
	end
	LoadAddons = nil
end; LoadAddons()

function AM.ReloadLogin(id)
	DeleteUSER(id)
	DeleteUSGN(player(id,"usgn"))

	ReloadUSER(id)
	ReloadTEMP(id)
	LoadIPData(player(id,"ip"))
end

addhook("join","AM.PlayerJoin")
function AM.PlayerJoin(id)
	while string.sub(player(id,"name"), 1, 1) == "(" do
		parse('setname '..id..' "'..string.sub(player(id,"name"), 2)..'" 1')
	end
	AM.ReloadLogin(id)
end

addhook("leave","AM.PlayerLeave")
function AM.PlayerLeave(id)
	SaveUSER(id)
	SaveIPData(player(id,"ip"))

	DeleteUSER(id)
	DeleteUSGN(player(id,"usgn"))
end

function bot_list()
	local l = {}
	for _, id in pairs(player(0,"table")) do
		if player(id, "bot") then
			table.insert(l, id)
		end
	end
	return l
end

bot_init = {}
addhook("always","AM.BotCheck")
function AM.BotCheck()
	local bl = bot_list()
	if last_bots then
		for _, id in pairs(last_bots) do
			if player(id,"exists") then
				if not bot_init[id] then
					AM.PlayerJoin(id)
					bot_init[id] = true
				end
			else
				AM.PlayerLeave(id)
				last_bots[id] = nil
				bot_init[id] = nil
			end
		end
	end

	last_bots = bl
end

addhook("mapchange","AM.GeneralSave")
function AM.GeneralSave()
	for _, id in pairs(player(0,"table")) do
		SaveUSER(id)
	end
	SaveServer()
end
