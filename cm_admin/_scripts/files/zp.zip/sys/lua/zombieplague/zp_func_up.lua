------------------------------------
-- Zombie Plague Functions Update --
------------------------------------

function string.split(t,b)
	local cmd = {}
	local match = "[^%s]+"
	if type(b) == "string" then match = "[^"..b.."]+" end
	for word in string.gmatch(t, match) do table.insert(cmd, word) end
	return cmd
end 

function zp_print(c,t)
	print(color[c]..'[ZP] '..t)
end

function zp_hudtxt2(p,s,c,t,x,y,a)
	parse('hudtxt2 '..p..' '..s..' "'..color[c]..''..t..'" '..x..' '..y..' '..a)
end

function zp_hudtxt(s,c,t,x,y,a)
	parse('hudtxt '..s..' "'..color[c]..''..t..'" '..x..' '..y..' '..a)
end

function zp_msg2(p,c,t)
	msg2(p,color[c]..''..t)
end

function zp_msg(c,t)
	msg(color[c]..''..t)
end

function zp_snd2(p,s)
	if (zp_sound > 0) then
		parse('sv_sound2 '..p..'  '..snd_dir..''..zp_adv_snd[s]..'.wav')
	end
end

function zp_snd(s)
	if (zp_sound > 0) then
		parse('sv_sound '..snd_dir..''..zp_adv_snd[s]..'.ogg')
	end
end

function zp_snd_count(s)
	if (zp_sound > 0) then
		parse('sv_sound '..snd_dir..'cnt_'..s..'.wav')
	end
end