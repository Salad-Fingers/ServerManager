-----------------------------
-- Zombie Plague Functions --
-----------------------------

zp_classes_ld()
zp_weapons_ld()
zp_items_ld()
zp_create_flashlight()
zp_help_ld()

function zp_team(p,t)
	if (zp_p_join[p] < 1) then
		zp_hudtxt2(p,0,2,'Zombie Plague Mod (1.15b)',322,5,1)
		zp_hudtxt2(p,1,3,game('sv_name')..' Server',322,20,1)
		zp_player_ld(p)
		zp_help_show(p)
		zp_p_join[p] = 1
	end
	if (t == 0 and zp_p_class[p] == -1) then
		parse('restart')
		zp_msg(4,'[ZP] Nemesis Left Zombies - Round Restart')
	end
end

function zp_serveraction(p,a)
	local t = player(p,'team')
	if (a == 1) then
		zp_main_menu(p)
	elseif (a == 2 and t == 2) then
		local m = zp_light_state[p]
		if (m == -zp_hud_waste) then
			zp_light_state[p] = zp_hud_recovery
			imagealpha(p_light[p],0)
		else
			zp_light_state[p] = -zp_hud_waste
			imagealpha(p_light[p],(zp_hud_alpha / 10) * (0.2+zp_light_eng[p]/200))
		end
		zp_snd2(p,11)
	elseif (a == 3 and zp_help_close[p] < 1) then
		zp_help_close[p] = 1
		for i = 1, #zp_help_line do
			zp_hudtxt2(p,25 + i,2,'',0,0,0)
		end
	end
end


function zp_startround()
	p_light = arrays(p_cnt,nil)
	zp_create_flashlight()
	zp_wpndmg_set()
	if (zp_nemesis > 0) then
		local p_table = player(0,'table')
		for i = 1, #player(0,'table') do
			if (player(p_table[i],'team') ~= 0) then
				parse('makect '..p_table[i])
			end
		end
		zp_nemesis_sec = zp_nemesis_time
	end
	zp_on_tip = 1
end

function zp_minute()
	zp_minutes = zp_minutes + 1
	if (zp_minutes == 1) then
		zp_msg(8,'===== Zombie Plague =====')
		zp_msg(8,'Release: 2010/04/14')
		zp_msg(8,'Version: 1.15 (Beta)')
		zp_msg(8,'Author: Blazzingxx')
	elseif (zp_minutes == 2) then
		zp_msg(8,'[ZP] [F2] - Main Zombie Plague Menu')
	elseif (zp_minutes == 3) then
		if (zp_hud_flashlight > 0) then
			zp_msg(8,'[ZP] [F3] - Control Flashlight')
		end
	elseif (zp_minutes == 4) then
		zp_msg(8,'[ZP] [F4] - Close Help File')
	elseif (zp_minutes > 4) then
		zp_minutes = 0
	end
end

function zp_endround()
	zp_nemesis_id = 0
	zp_on_tip = 0
	local i
	for i = 1, p_cnt do
		if (zp_p_class[i] == -1) then
			zp_p_class[i] = zp_p_last_class[i]
		end
	end
	if (zp_ct_cnt() > 0) then
		local p = zp_ct_table()
		zp_msg(2,'=== Survivors ===')
		for i = 1, zp_ct_cnt() do
			zp_msg(2,i..'. '..player(p[i],'name'))
			zp_msg2(p[i],2,'You Get Extra '..zp_xp_survive..' XP For Surviving Round!@C')
			if (zp_pack_survive > 0) then
				zp_msg2(p[i],2,'You Get Extra '..zp_pack_survive..' Ammo Packs For Surviving Round!@C')
				set_player_statb(p[i],2,zp_pack_survive)
			end
			set_player_statb(p[i],1,zp_xp_survive)
			zp_player_hud(p[i])
			zp_level_up(p[i],1)
		end
	end
end

function zp_second()
	if (zp_hud_flashlight > 0) then	
		local i 
		for i = 1, 32 do
			zp_light_update(i)
		end
	end
	if (zp_nemesis > 0) then
		if (zp_nemesis_sec > 0) then
			zp_msg(8,zp_nemesis_sec..' Seconds Left@C')
			if (zp_nemesis_sec > 0 and zp_nemesis_sec < 11) then
				zp_snd_count(zp_nemesis_sec)
			end
			zp_nemesis_sec = zp_nemesis_sec - 1
		elseif (zp_nemesis_sec == 0) then
			zp_nemesis_sec = zp_nemesis_sec - 1
			zp_nemesis_form()
		end
	end
	local i
	for i = 1, #player(0,'table') do
		if (player(i,'exists') and player(i,'health') > 0) then
			if (zp_p_stun[i] > 1) then
				zp_p_stun[i] = zp_p_stun[i] - 1
			elseif (zp_p_stun[i] == 1) then
				zp_p_stun[i] = zp_p_stun[i] - 1
				parse('speedmod '..i..' '..set_zm_val(zp_p_class[i],3))
			end
		end
	end
end

function zp_say(p,t)
	t = string.lower(t)
	if (t == zp_say_cmd[1]) then
		zp_main_menu(p)
	elseif (t == zp_say_cmd[2]) then
		zp_class_menu_id[p] = 0
		zp_menu_class(p)
	elseif (t == zp_say_cmd[3]) then
		zp_wpn_menu_id[p] = 0
		zp_menu_weapon(p)
	elseif (t == zp_say_cmd[4]) then
		zp_item_menu_id[p] = 0
		zp_hm_items_menu(p)
	elseif (t == zp_say_cmd[5]) then
		zp_item_menu_id[p] = 0
		zp_zm_items_menu(p)
	elseif (t == zp_say_cmd[6]) then
		zp_respawn(p)
	elseif (t == zp_say_cmd[7]) then
		zp_buy_aps(p)
	elseif (t == zp_say_cmd[8]) then
		zp_say_menu(p)
	elseif (string.sub(t, 1, 7) == zp_say_cmd[9]) then
		zp_say_give(p,t)
	elseif (string.sub(t, 1, 10) == zp_say_cmd[10]) then
		zp_say_whatstats(p,t)
	end
end

function zp_kill(p,v,w)
	local p_t = player(p,'team')
	if (p_t ~= player(v,'team')) then
		if (p_t == 1) then
			set_player_statb(p,2,zp_pack_infection)
			set_player_statb(p,1,zp_xp_infection)
		end
		if (p_t == 2) then	
			set_player_statb(p,2,zp_pack_kill)
			set_player_statb(p,1,zp_xp_kill)
		end
		zp_level_up(p,1)
		zp_player_hud(p)
		zp_player_sv(p)
	end
end

function zp_hit(p,s,w,h)
	local s_t = player(s,'team')
	local p_t = player(p,'team')
	if (p_t == 1 and s_t == 2) then
		local p_h = player(p,'health') - h
		zp_player_hud(p)
		if (w == 51) then
			zp_msg2(p,4,'You get stunned!@C')
			parse('shake '..p..' 100')
			parse('speedmod '..p..' '..set_zm_val(zp_p_class[p],3) - 20)
			zp_p_stun[p] = 3
		end
		if (zp_p_health[p] - h > 0) then
			if (w < 50 or w > 69) then zp_knockback_func(s,p,w) end
			zp_p_health[p] = zp_p_health[p] - h
			if (zp_p_health[p] > p_h and zp_p_health[p] < 251) then
				parse('setmaxhealth '..p..' '..zp_p_health[p])
				parse('sethealth '..p..' '..zp_p_health[p])
				return 1
			elseif (p_h < 1 and zp_p_health[p] > 250) then
				parse('setmaxhealth '..p..' 250')
				parse('sethealth '..p..' 250')
				return 1
			end
		else
			zp_snd(math.random(4,7))
			parse('customkill '..s..' "'..itemtype(w,'name')..'" '..p)
			zp_hudtxt2(p,2,1,'',0,0,0)
			zp_hudtxt2(p,4,1,'',0,0,0)
			return 1
		end
	elseif (p_t == 2 and s_t == 1) then
		local p_h = player(p,'health') - set_zm_val(zp_p_class[s],5)
		local p_a = player(p,'armor') - set_zm_val(zp_p_class[s],5)
		local p_ap = player(p,'armor')
		if (w == 78 or w == 86) then
			local wpn = {}
			wpn[78] = 'Infected'
			wpn[86] = 'Infection Bomb'
			wpn[256] = 'Critical Hit'
			if (set_zm_val(zp_p_class[s],5) > 0 and p_h > 0 and w ~= 86) then
				if (p_ap > 0) then
					if (p_a > 0) then
						parse('setarmor '..p..' '..p_a)
					else
						parse('setarmor '..p..' 0')
					end
				else
					parse('sethealth '..p..' '..p_h)
				end
				return 1
			else
				if (set_zm_val(zp_p_class[s],5) == 0) then w = 256 end
				local p_x = player(p,'x')
				local p_y =  player(p,'y')
				parse('customkill '..s..' "'..wpn[w]..'" '..p)
				parse('spawnplayer '..p..' '..p_x..' '..p_y)
				zp_snd(math.random(1,3))
				if (zp_hud_flashlight > 0) then	imagealpha(p_light[p],0) end
				return 1
			end
		end
	end
	zp_player_hud(p)
end

function zp_join(p)
	zp_join_set(p)
end

function zp_spawn(p)
	local t = player(p,'team')
	if (t == 1) then
		zp_p_health[p] = set_zm_val(zp_p_class[p],2)
		zp_zombie_set(p)
		zp_class_check(p)
		if (zp_t_tips > 0 and zp_on_tip > 0) then zp_msg2(p,8,'TIP: '..zp_t_tip[math.random(1,#zp_t_tip)]..'@C') end
	elseif (t == 2) then
		zp_wpn_menu_id[p] = 0
		parse('setmaxhealth '..p..' 100')
		if (zp_p_class[p] == -1) then
			parse('maket '..p)
			zp_msg2(p,4,'Nemesis Cant Change Teams!@C')
		end
		if (zp_on_tip > 0) then
			zp_menu_weapon(p)
			if (zp_buy_standart > 0) then zp_msg2(p,8,'Standart Buying Allowed!@C') end
			if (zp_ct_tips > 0) then zp_msg2(p,8,'TIP: '..zp_ct_tip[math.random(1,#zp_ct_tip)]..'@C') end
		end
		zp_p_weapons[p] = 0
	end
	zp_player_hud(p)
	if (zp_hud_flashlight > 0) then zp_light_set(p) end
end

function zp_die(p)
	zp_hudtxt2(p,2,1,'',0,0,0)
	zp_hudtxt2(p,4,1,'',0,0,0)
	return 1
end

function zp_menu(p,t,s)
	local team = player(p,'team')
	if (string.sub(t, 1, 12) == 'Zombie Class') then
		local id = zp_class_menu_id[p]
		if (zp_nemesis_id == p) then
			zp_msg2(p,4,'[ZP] Nemesis Cant Choose Class!')
		elseif (id == 0) then
			if (s > 0 and s < 9) then
				local m = set_zm_val(s,6)
				if (m > 0) then
					m = itemtype(set_zm_val(s,6),'name')
				else
					m = 'n/a'
				end
				zp_p_class[p] = s
				zp_p_last_class[p] = s
				zp_msg2(p,2,'[ZP] Your Zombie Class After The Next Infection Will Be: '..set_zm_val(s,1))
				zp_msg2(p,2,'[ZP] Health: '..set_zm_val(s,2)..' - Speed: '..set_zm_val(s,3)..' - Knockback: '..20 * set_zm_val(s,4)..'% - Item: '..m)
			elseif (s == 9) then
				zp_class_menu_id[p] =  id + 1
				zp_menu_class(p)
			end
		elseif (id > 0) then
			local page = s + 8 + 7 * (id - 1)
			if (s > 0 and s < 8) then
				local m = set_zm_val(page,6)
				if (m > 0) then
					m = itemtype(set_zm_val(page,6),'name')
				else
					m = 'n/a'
				end
				zp_p_class[p] = page
				zp_msg2(p,2,'[ZP] Your Zombie Class After The Next Infection Will Be: '..set_zm_val(page,1))
				zp_msg2(p,2,'[ZP] Health: '..set_zm_val(page,2)..' - Speed: '..set_zm_val(page,3)..' - Knockback: '..20 * set_zm_val(page,4)..'% - Item: '..m)
			elseif (s == 8) then
				zp_class_menu_id[p] =  id - 1
				zp_menu_class(p)
			elseif (s == 9) then
				zp_class_menu_id[p] =  id + 1
				zp_menu_class(p)
			end
		end
	end
	if (string.sub(t, 1, 13) == 'Choose Weapon') then
		if (team == 2) then
			local id = zp_wpn_menu_id[p]
			if (id == 0) then
				if (s > 0 and s < 9) then
					if (set_player_val(p,3) >= set_wpn_val(s,3)) then
						if (zp_p_weapons[p] < zp_weapons_limit) then
							zp_msg2(p,3,'[ZP] Your Selected Weapon: '..set_wpn_val(s,1))
							parse('equip '..p..' '..set_wpn_val(s,2))
							parse('setweapon '..p..' '..set_wpn_val(s,2))
							zp_p_weapons[p] = zp_p_weapons[p] + 1
						else
							zp_msg2(p,4,'[ZP] You Cant Choose More Weapons')
						end
					else
						zp_wpn_menu_id[p] = 0
						zp_menu_weapon(p)
						zp_msg2(p,4,'[ZP] Need Higher Level! (required: '..set_wpn_val(s,3)..')')
					end
				elseif (s == 9) then
					zp_wpn_menu_id[p] =  id + 1
					zp_menu_weapon(p)
				end
			elseif (id > 0) then
				local page = s + 8 + 7 * ( id - 1)
				if (s > 0 and s < 8) then
					if (set_player_val(p,3) >= set_wpn_val(page,3)) then
						if (zp_p_weapons[p] < zp_weapons_limit) then
							zp_msg2(p,3,'[ZP] Your Selected Weapon: '..set_wpn_val(page,1))
							parse('equip '..p..' '..set_wpn_val(page,2))
							parse('setweapon '..p..' '..set_wpn_val(page,2))
							zp_p_weapons[p] = zp_p_weapons[p] + 1
						else
							zp_msg2(p,4,'[ZP] You Cant Choose More Weapons')
						end
					else
						zp_wpn_menu_id[p] = 0
						zp_menu_weapon(p)
						zp_msg2(p,4,'[ZP] Need Higher Level! (required: '..set_wpn_val(page,3)..')')
					end
				elseif (s == 8) then
					zp_wpn_menu_id[p] = id -1
					zp_menu_weapon(p)
				elseif (s == 9) then
					zp_wpn_menu_id[p] =  id + 1
					zp_menu_weapon(p)
				end
			end
		else
			zp_msg2(p,4,'[ZP] Only For Counter Terrorists!')
		end
	end
	if (string.sub(t, 1, 10) == 'Human Shop') then
		if (player(p,'health') > 0) then
			if (team == 2) then
				local id = zp_item_menu_id[p]
				if (id == 0) then
					if (s > 0 and s <= 8) then
						if (set_player_val(p,2) >= set_ct_item_val(s,2)) then
							set_player_stata(p,2,set_player_val(p,2) - set_ct_item_val(s,2))
							if (set_ct_item_val(s,5) ~= nil and set_ct_item_val(s,6) ~= nil) then
								zp_hm_items_set(p,s)
							else
								zp_msg2(p,3,'[ZP] You Have Bought: '..set_ct_item_val(s,1)..' (Building!)')
								for x = 0,zp_buildings[s.."_x"] - 1 do
									for y = 0,zp_buildings[s.."_y"] - 1  do
										if (zp_buildings[s.."_pos_"..x.."_"..y] ~= nil and zp_buildings[s.."_pos_"..x.."_"..y] > 0) then
										parse('spawnobject '..zp_buildings[s.."_pos_"..x.."_"..y]..' '..player(p,'tilex')-set_ct_item_val(s,3) + 1 + x..' '..player(p,'tiley')-set_ct_item_val(s,3) + 1 + y..' 0 1 '..player(p,'team')..' '..p)
										end
									end
								end
							end
						else
							zp_msg2(p,4,'[ZP] Not Enough Ammo Packs! Need '..set_ct_item_val(s,2) - set_player_val(p,2)..' More!')
						end
					elseif (s == 9) then
						zp_item_menu_id[p] =  id + 1
						zp_hm_items_menu(p)
					end
				elseif (id > 0) then
					local page = s + 8 + 7 * (id - 1)
					if (s > 0 and s < 8) then
						if (set_player_val(p,2) >= set_ct_item_val(page,2)) then
							set_player_stata(p,2,set_player_val(p,2) - set_ct_item_val(page,2))
							if (set_ct_item_val(page,5) ~= nil and set_ct_item_val(page,6) ~= nil) then
								zp_hm_items_set(p,page)
							else
								zp_msg2(p,3,'[ZP] You Have Bought: '..set_ct_item_val(page,1)..' (Building!)')
								for x = 0,zp_buildings[page.."_x"] - 1 do
									for y = 0,zp_buildings[page.."_y"] - 1  do
										if (zp_buildings[page.."_pos_"..x.."_"..y] ~= nil and zp_buildings[page.."_pos_"..x.."_"..y] > 0) then
											parse('spawnobject '..zp_buildings[page.."_pos_"..x.."_"..y]..' '..player(p,'tilex')-set_ct_item_val(page,3) + 1 + x..' '..player(p,'tiley')-set_ct_item_val(page,3) + 1 + y..' 0 1 '..player(p,'team')..' '..p)
										end
									end
								end
							end
						else
							zp_msg2(p,4,'[ZP] Not Enough Ammo Packs! Need '..set_ct_item_val(page,2) - set_player_val(p,2)..' More!')
						end
					elseif (s == 8) then
						zp_item_menu_id[p] = id -1
						zp_hm_items_menu(p)
					elseif (s == 9) then
						zp_item_menu_id[p] =  id + 1
						zp_hm_items_menu(p)
					end
				end
			else
				zp_msg2(p,4,'[ZP] These itemsOnly For Survivors!')
			end
			zp_player_hud(p)
		else
			zp_msg2(p,4,'[ZP] You Are Dead!')
		end
		zp_player_sv(p)
	end
	if (string.sub(t, 1, 11) == 'Zombie Shop') then
		if (player(p,'health') > 0) then
			if (team == 1) then
				local id = zp_item_menu_id[p]
				if (id == 0) then
					if (s > 0 and s <= 8) then
						if (set_player_val(p,2) >= set_zm_item_val(s,2)) then
							set_player_stata(p,2,set_player_val(p,2) - set_zm_item_val(s,2))
							zp_zm_items_set(p,s)
						else
							zp_msg2(p,4,'[ZP] Not Enough Ammo Packs! Need '..set_zm_item_val(s,2) - set_player_val(p,2)..' More!')
						end
					elseif (s == 9) then
						zp_item_menu_id[p] =  id + 1
						zp_hm_items_menu(p)
					end
				elseif (id > 0) then
					local page = s + 8 + 7 * (id - 1)
					if (s > 0 and s < 8) then
						if (set_player_val(p,2) >= set_zm_item_val(page,2)) then
							set_player_stata(p,2,set_player_val(p,2) - set_zm_item_val(page,2))
							zp_zm_items_set(p,page)
						else
							zp_msg2(p,4,'[ZP] Not Enough Ammo Packs! Need '..set_zm_item_val(page,2) - set_player_val(p,2)..' More!')
						end
					elseif (s == 8) then
						zp_item_menu_id[p] = id -1
						zp_hm_items_menu(p)
					elseif (s == 9) then
						zp_item_menu_id[p] =  id + 1
						zp_hm_items_menu(p)
					end
				end
			else
				zp_msg2(p,4,'[ZP] These Items Only For Zombies!')
			end
			zp_player_hud(p)
		else
			zp_msg2(p,4,'[ZP] You Are Dead!')
		end
		zp_player_sv(p)
	end
	if (t == 'Zombie Plague 1.15b Menu') then
		if (s == 1) then
			zp_wpn_menu_id[p] = 0
			zp_menu_weapon(p)
		elseif (s == 2) then
			zp_class_menu_id[p] = 0
			zp_menu_class(p)
		elseif (s == 3) then
			zp_item_menu_id[p] = 0
			zp_hm_items_menu(p)
		elseif (s == 4) then
			zp_item_menu_id[p] = 0
			zp_zm_items_menu(p)
		elseif (s == 5) then
			zp_respawn(p)
		elseif (s == 6) then
			zp_buy_aps(p)
		elseif (s == 7) then
			if (team == 2) then
				local zombies = 0
				for i = 1, p_cnt do
					if (player(i,'team') == 1) then	
						zombies = zombies + 1
					end
				end
				if (zombies < 2) then
					parse('maket '..p)
				else
					zp_msg2(p,4,'[ZP] There Are Already '..zombies..' Zombies!')
				end
			else
				zp_msg2(p,4,'[ZP] You Are Already Zombie!')
			end
		elseif (s == 8) then
			zp_say_menu(p)
		elseif (s == 9) then
			zp_console_menu(p)
		end
	end
	if (t == 'Money to Ammo Packs') then
		if (s > 0 and player(p,'money') >= zp_money_gd[s]) then
			parse('setmoney '..p..' '..player(p,'money') - zp_money_gd[s])
			set_player_stata(p,2,set_player_val(p,2) + zp_money_ap[s])
			zp_msg2(p,2,'You Changed '..zp_money_gd[s]..'$ For '..zp_money_ap[s]..' Ammo Pack(s)!@C')
			zp_player_hud(p)
			zp_player_sv(p)
		else
			zp_msg2(p,4,'You Dont Have Money Enough!@C')
		end
		zp_player_sv(p)
	end
	if (t == 'Console Commands (Admin)') then
		if (s > 0 and s <= 9) then
			zp_msg2(p,2,zp_adm_cmd[s]..''..zp_adm_inf[s]..'@C')
		end
	end
	if (t == 'Say Commands (Client)') then
		if (s == 1) then
			zp_main_menu(p)
		elseif (s == 2) then
			zp_class_menu_id[p] = 0
			zp_menu_class(p)
		elseif (s == 3) then
			zp_wpn_menu_id[p] = 0
			zp_menu_weapon(p)
		elseif (s == 4) then
			zp_hm_items_menu(p)
		elseif (s == 5) then
			zp_zm_items_menu(p)
		elseif (s == 6) then
			zp_respawn(p)
		elseif (s == 7) then
			zp_buy_aps(p)
		elseif (s == 8) then
			zp_say_menu(p)
		elseif (s == 9) then
			zp_msg2(p,2,'!giveap <id> <ap> - Give Own Aps@C')
		end
	end
end

function zp_projectile(p,w,x,y)
	local t = player(p,'team')
	if (w == 52 and t == 2) then
		local p_x = player(p,'x')
		local p_y = player(p,'y')
		local i
		for i = 1, #player(0,'table') do
			if (player(i,'exists') and player(i,"team") ~= player(p,"team")) then
				if (player(i,'health') > 0 and p_x - 320 < player(i,'x') and p_x + 320 > player(i,'x') and p_y - 240 < player(i,'y') and p_y + 240 > player(i,'y')) then
					parse('customkill '..p..' "Flashed" '..i)
				end
			end
		end
	end
end

function zp_drop()
	return 1
end

function zp_buy()
	if (zp_buy_standart > 0) then
		return 0
	else
		return 1
	end
end

function zp_leave(p)
	zp_player_reset(p)
	if (zp_nemesis_id == p) then
		parse('sv_restart')
	end
end