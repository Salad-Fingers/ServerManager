-----------------------------
-- Zombie Plague Valuables --
-----------------------------

function array(m)
	local array = {}
	for i = 1, m do
		array[i] = 0
	end
	return array
end

function arrays(m,n)
	local array = {}
	for i = 1, m do
		array[i] = n
	end
	return array
end

function set_zm_val(id,n)
	local set_val
	set_val = zp_class_stats[6 * (id - 1) + n]
	return set_val
end

function set_zm_stata(id,n,m)
	zp_class_stats[6 * (id - 1) + n] =  m
end

function set_wpn_val(id,n)
	local set_val
	set_val = zp_weapon_stats[5 * (id - 1) + n]
	return set_val
end

function set_wpn_stata(id,n,m)
	zp_weapon_stats[5 * (id - 1) + n] =  m
end

function set_ct_item_val(id,n)
	local set_val
	set_val = zp_ct_item_stats[6 * (id - 1) + n]
	return set_val
end

function set_ct_item_stata(id,n,m)
	zp_ct_item_stats[6 * (id - 1) + n] =  m
end

function set_zm_item_val(id,n)
	local set_val
	set_val = zp_zm_item_stats[6 * (id - 1) + n]
	return set_val
end

function set_zm_item_stata(id,n,m)
	zp_zm_item_stats[6 * (id - 1) + n] =  m
end


function set_player_val(p,n)
	local set_val
	set_val = zp_p_stats[4 * (p - 1) + n]
	return set_val
end

function set_player_stata(p,n,m)
	zp_p_stats[4 * (p - 1) + n] =  m
end

function set_player_statb(p,n,m)
	zp_p_stats[4 * (p - 1) + n] = zp_p_stats[4 * (p - 1) + n] + m
end
zp_minutes = 0
p_cnt = game('sv_maxplayers')
p_light = arrays(p_cnt,nil)
zp_class_stats = {}
zp_classes_cnt = 0
zp_weapon_stats = {}
zp_weapons_cnt = 0
zp_wpn_knock = {}
zp_wpn_dmg = {}
zp_ct_item_stats = {}
zp_ct_items_cnt = 0
zp_zm_item_stats = {}
zp_zm_items_cnt = 0
zp_on_tip = 1
zp_ct_tip = {'PRESS 3RD SERVERATION TO CONTROL FLASHLIGHT','AT START YOU HAVE TO RUN AWAY FROM OTHER TEAMATES'}
zp_t_tip = {'TURN ON NIGHT VISION','TRY TO STAY WITH ZOMBIE GROUP','BEIGN IN ZOMBIE GROUP IS MORE EFFECTIVE'}
zp_nemesis_id = 0
zp_nemesis_sec = zp_nemesis_time
zp_p_stats = {}
zp_p_join = array(p_cnt)
zp_p_class = array(p_cnt)
zp_p_last_class = array(p_cnt)
zp_p_health = array(p_cnt)
zp_p_stun = array(p_cnt)
zp_p_weapons = array(p_cnt)
zp_help_line = {}
zp_help_close = array(p_cnt)
zp_char_table = {[" "] = 0,["B"] = 1,["b"] = 1,["M"] = 20,["m"] = 20,["S"] = 9,["s"] = 9,["W"] = 2,["w"] = 2,["0"] = 8,["1"] = 11,["2"] = 12,["3"] = 03,["4"] = 4,["5"] = 5,["#"] = 6,["$"] = 7,["["] = 13,["]"] = 14}
zp_buildings = {}
zp_max_class = {25000,15,10,100,110}
zp_min_class = {1,-15,0,0,0}
zp_med_class = {1000,3,0,1,0}
zp_tile_x = array(p_cnt)
zp_tile_y = array(p_cnt)
zp_tile_hit = array(p_cnt)
zp_zm_state = {'- - - -','- - -','- -','-','+ -','+','++','+++','++++','+++++'}
zp_zm_state[0] = '- - - - -'
zp_light_eng = array(p_cnt)
zp_light_state = arrays(32,-zp_hud_waste)
zp_map_tile = {}
zp_money_ap = {1,5,8,15,25}
zp_money_gd = {1000,4000,6000,10000,15000}
zp_class_menu_id = array(p_cnt)
zp_wpn_menu_id = array(p_cnt)
zp_item_menu_id = array(p_cnt)
color = {'�255200000','�000255000','�160160255','�255000000','�240000240','�255128064','�255255255','�155255000','�100100255'}
zp_say_cmd = {'!help','!class','!weapons','!hm_shop','!zm_shop','!unstuck','!buy_ap','!commands','!giveap','!whatstats'}
zp_say_inf = {' - Main Menu',' - Select Weapon',' - Class Selection',' - Human Shop',' - Zombie Shop',' - Zombie Unstuck',' - Buy Ammo Packs',' - Say Commands','<id> <ap> - Give Own APs',' <id - Look Players Stats'}
zp_adm_cmd = {'zp_list_players','zp_list_cmd','zp_list_say','zp_give_xp','zp_give_lvl','zp_give_ap','zp_give_all_ap','zp_set_xp','zp_set_lvl','zp_set_ap'}
zp_adm_inf = {' - Players List',' - Console Commands List',' - Say Commands List',' <id> <exp> - Give Exp For Player',' <id> <lvl> - Give Level For Player',' <id> <ap> - Give Ammo Packs For Player',' <ap> - Give APs For All',' <id> <exp> - Set Exp For Player',' <id> <lvl> - Set Level For Player',' <id> <ap> - Set Ammo Packs For Player'}
set_zm_stata(0,1,'Default Zombie')
set_zm_stata(0,2,1000)
set_zm_stata(0,3,4)
set_zm_stata(0,4,5)
set_zm_stata(0,5,5)
set_zm_stata(0,6,0)
set_zm_stata(-1,1,'Nemesis')
set_zm_stata(-1,2,zp_nemesis_health)
set_zm_stata(-1,3,zp_nemesis_speed)
set_zm_stata(-1,4,zp_nemesis_knock)
set_zm_stata(-1,5,zp_nemesis_dmg)
set_zm_stata(-1,6,zp_nemesis_item)
zp_adv_snd = {'infect_1','infect_2','infect_3','die_1','die_2','die_3','die_4','die_5','nemesis_1','nemesis_2','flashlight'}