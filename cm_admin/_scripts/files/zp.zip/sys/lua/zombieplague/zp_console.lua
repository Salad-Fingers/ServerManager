---------------------------
-- Zombie Plague Console --
---------------------------

-- Console Function --
function zp_parse(cmd)

	if (cmd == zp_adm_cmd[1]) then
		zp_print(2,'====== Players List ======')
		for i = 1,p_cnt do
			if (player(i,'exists')) then
				if (player(i,'health') > 0) then
					zp_print(2,i..'. '..player(i,'name')..' - Level: '..set_player_val(i,3)..' - Experience: ('..set_player_val(i,1)..'/'..set_player_val(i,4)..') - AmmoPacks: '..set_player_val(i,2))
				else
					zp_print(4,i..'. '..player(i,'name')..' (dead) - Level: '..set_player_val(i,3)..' - Experience: ('..set_player_val(i,1)..'/'..set_player_val(i,4)..') - AmmoPacks: '..set_player_val(i,2))
				end
			end
		end
		return 2
	end

	if (cmd == zp_adm_cmd[2]) then
		zp_print(2,'====== Console Commands List ======')
		for i = 1,#zp_adm_cmd do
			zp_print(2,zp_adm_cmd[i]..''..zp_adm_inf[i])
		end
		return 2
	end

	if (cmd == zp_adm_cmd[3]) then
		zp_print(2,'====== Say Commands List ======')
		for i = 1,#zp_say_cmd do
			zp_print(2,zp_say_cmd[i]..''..zp_say_inf[i])
		end
		return 2
	end

	if (string.sub(cmd, 1, 13) == 'sv_maxplayers') then
		zp_print(4,'You Cant Change Max Players In The Game!')
		zp_print(4,'Change It Before Starting Server!')
		return 2
	end

	if (string.sub(cmd, 1, 10) == zp_adm_cmd[4]) then
		local parses = string.split(cmd)
		local p = tonumber(parses[2])
		local xp = tonumber(parses[3])
		if (p ~= nil and xp ~= nil) then
			if (player(p,'exists')) then
				if (player(p,'health') > 0) then
					set_player_statb(p,1,xp)
					zp_msg(2,'Admin Gave '..player(p,'name')..' '..xp..' Exp!')
					zp_print(2,'You Gave '..xp..' Exp For '..player(p,'name')..'!')
					zp_msg2(p,2,'Admin Gave You '..xp..' Exp!@C')
					zp_level_up(p,0)
					zp_player_sv(p)
					zp_player_hud(p)
				else
					zp_print(4,'You Cant Give Exp For Dead Player!')
				end
			else
				zp_print(4,'Player Does Not Exist!')
			end
		else
			zp_print(4,'Command Doesnt Have Right Parameters!')
		end
		return 2
	end

	if (string.sub(cmd, 1, 11) == zp_adm_cmd[5]) then
		local parses = string.split(cmd)
		local p = tonumber(parses[2])
		local lvl = tonumber(parses[3])
		if (p ~= nil and lvl ~= nil) then
			if (player(p,'exists')) then
				if (player(p,'health') > 0) then
					for i = 1, lvl do
						if (set_player_val(p,3) < zp_lvl_max) then
							set_player_statb(p,1,set_player_val(p,4) - set_player_val(p,1))
							zp_level_up(p,0)
						end
					end	
					zp_msg(2,'Admin Gave '..player(p,'name')..' '..lvl..' Level(s)!')
					zp_print(2,'You Gave '..lvl..' Level(s) For '..player(p,'name')..'!')
					zp_msg2(p,2,'Admin Gave You '..lvl..' Level(s)!@C')
					zp_level_up(p,0)
					zp_player_sv(p)
					zp_player_hud(p)
				else
					zp_print(4,'You Cant Give Level(s) For Dead Player!')
				end
			else
				zp_print(4,'Player Does Not Exist!')
			end
		else
			zp_print(4,'Command Doesnt Have Right Parameters!')
		end
		return 2
	end

	if (string.sub(cmd, 1, 10) == zp_adm_cmd[6]) then
		local parses = string.split(cmd)
		local p = tonumber(parses[2])
		local ap = tonumber(parses[3])
		if (p ~= nil and ap ~= nil) then
			if (player(p,'exists')) then
				if (player(p,'health') > 0) then
					set_player_statb(p,2,ap)
					zp_msg(2,'Admin Gave '..player(p,'name')..' '..ap..' Ammo Pack(s)!')
					zp_print(2,'You Gave '..ap..' Ammo Packs For '..player(p,'name')..'!')
					zp_msg2(p,2,'Admin Gave You '..ap..' Ammo Pack(s)!@C')
					zp_player_sv(p)
					zp_player_hud(p)
				else
					zp_print(4,'You Cant Give Ammo Pack(s) For Dead Player!')
				end
			else
				zp_print(4,'Player Does Not Exist!')
			end
		else
			zp_print(4,'Command Doesnt Have Right Parameters!')
		end
		return 2
	end
			
	if (string.sub(cmd, 1, 14) == zp_adm_cmd[7]) then
		local parses = string.split(cmd)
		local ap = tonumber(parses[2])
		if (ap ~= nil) then
			zp_msg(2,'Admin Gave '..ap..' Ammo Pack(s) To All!')
			for i = 1, p_cnt do
				if (player(i,'exists')) then
					if (player(i,'health') > 0) then
						set_player_statb(i,2,ap)
						zp_player_sv(i)
						zp_player_hud(i)
					end
				end
			end
		else
			zp_print(4,'Command Doesnt Have Right Parameters!')
		end
		return 2
	end

	if (string.sub(cmd, 1, 9) == zp_adm_cmd[8]) then
		local parses = string.split(cmd)
		local p = tonumber(parses[2])
		local xp = tonumber(parses[3])
		if (p ~= nil and xp ~= nil) then
			if (player(p,'exists')) then
				if (player(p,'health') > 0) then
					set_player_stata(p,3,zp_lvl_start)
					set_player_stata(p,4,zp_lvl_ratio)
					set_player_stata(p,1,xp)
					zp_msg(2,'Admin Set '..player(p,'name')..' Exp To '..xp..'!')
					zp_print(2,'You Set '..player(p,'name')..' Exp to '..xp..'!')
					zp_msg2(p,2,'Admin Set Your Exp To '..xp..'!@C')
					zp_level_up(p,0)
					zp_player_sv(p)
					zp_player_hud(p)
				else
					zp_print(4,'You Cant Give Exp For Dead Player!')
				end
			else
				zp_print(4,'Player Does Not Exist!')
			end
		else
			zp_print(4,'Command Doesnt Have Right Parameters!')
		end
		return 2
	end

	if (string.sub(cmd, 1, 10) == zp_adm_cmd[9]) then
		local parses = string.split(cmd)
		local p = tonumber(parses[2])
		local lvl = tonumber(parses[3])
		if (p ~= nil and lvl ~= nil) then
			if (player(p,'exists')) then
				if (player(p,'health') > 0) then
					set_player_stata(p,3,zp_lvl_start)
					set_player_stata(p,4,zp_lvl_ratio)
					set_player_stata(p,1,0)
					for i = 1, lvl - 1 do
						if (set_player_val(p,3) < zp_lvl_max) then
							set_player_statb(p,1,set_player_val(p,4) - set_player_val(p,1))
							zp_level_up(p,0)
						end
					end
					zp_level_up(p,0)
					zp_msg(2,'Admin Set '..player(p,'name')..' Level To '..lvl..'!')
					zp_print(2,'You Set '..player(p,'name')..' Level To '..lvl..'!')
					zp_msg2(p,2,'Admin Set Your Level To '..lvl..'!@C')
					zp_player_sv(p)
					zp_player_hud(p)
				else
					zp_print(4,'You Cant Give Level(s) For Dead Player!')
				end
			else
				zp_print(4,'Player Does Not Exist!')
			end
		else
			zp_print(4,'Command Doesnt Have Right Parameters!')
		end
		return 2
	end

	if (string.sub(cmd, 1, 9) == zp_adm_cmd[10]) then
		local parses = string.split(cmd)
		local p = tonumber(parses[2])
		local ap = tonumber(parses[3])
		if (p ~= nil and ap ~= nil) then
			if (player(p,'exists')) then
				if (player(p,'health') > 0) then
					set_player_stata(p,2,ap)
					zp_msg(2,'Admin Set '..player(p,'name')..' Ammo Packs To '..ap..'!')
					zp_print(2,'You Set '..player(p,'name')..' Ammo Packs To '..ap..'!')
					zp_msg2(p,2,'Admin Set Your Ammo Packs To '..ap..'!@C')
					zp_player_sv(p)
					zp_player_hud(p)
				else
					zp_print(4,'You Cant Give Ammo Pack(s) For Dead Player!')
				end
			else
				zp_print(4,'Player Does Not Exist!')
			end
		else
			zp_print(4,'Command Doesnt Have Right Parameters!')
		end
		return 2
	end
end