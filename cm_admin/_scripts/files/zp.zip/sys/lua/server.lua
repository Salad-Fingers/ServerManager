--------------------------------------------------------
-- Zombie Plague (1.15b) By Blazzingxx
--------------------------------------------------------
-- Version: 1.15(Beta)
-- Release: 2010/04/14
-- Author: Blazzingxx
--------------------------------------------------------
-- Dofiles --
zp_dir = 'sys/lua/zombieplague/zp_'
snd_dir = 'zombieplague/zp_'
dofile(zp_dir..'config.cfg')
dofile(zp_dir..'values.lua')
dofile(zp_dir..'func_up.lua')
dofile(zp_dir..'console.lua')
dofile(zp_dir..'filter.lua')
dofile(zp_dir..'func_m.lua')
dofile(zp_dir..'func.lua')
dofile(zp_dir..'settings.cfg')

-- Hooks --
addhook("team","zp_team")
addhook("join","zp_join")
addhook("spawn","zp_spawn")
addhook("kill","zp_kill")
addhook("hit","zp_hit")
addhook("menu","zp_menu")
addhook("serveraction","zp_serveraction")
addhook("minute","zp_minute")
addhook("projectile","zp_projectile")
addhook("second","zp_second")
addhook("startround","zp_startround")
addhook("endround","zp_endround")
addhook("drop","zp_drop")
addhook("die","zp_die")
addhook("parse","zp_parse")
addhook("buy","zp_buy")
addhook("leave","zp_leave")
addhook("say","zp_say")