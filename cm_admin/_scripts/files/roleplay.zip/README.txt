   ____  _      _____                   _ _    _____                 _             
  / __ \| |    / ____|                 | | |  / ____|               (_)            
 | |  | | |__ | |  __  __ ___      ____| | | | |  __  __ _ _ __ ___  _ _ __   __ _ 
 | |  | | '_ \| | |_ |/ _` \ \ /\ / / _` | | | | |_ |/ _` | '_ ` _ \| | '_ \ / _` |
 | |__| | | | | |__| | (_| |\ V  V / (_| |_| | |__| | (_| | | | | | | | | | | (_| |
  \____/|_| |_|\_____|\__,_| \_/\_/ \__,_(_)  \_____|\__,_|_| |_| |_|_|_| |_|\__, |
                                                                              __/ |
                                                                             |___/ 
This file is created by http://OhGawd-Gaming.info
Please do not reupload to any another site without permission.

Please contact Trauma Tizer if you have any problem.
________________________________________________

Installation:
- Extract the file on your cs2D folder.
- Overwrite everything
- Configure admins. Use your Unreal Software Gaming Network id to work it

Credits:
- Original Script: Starkkz
- Editors: Trauma Tizer / Beckerchen / Yasday
- Beta Testing: Trauma Tizer / Yasday
- Helpers: Peter_Toman
- Ideas: Trauma Tizer / Beckerchen
- Map Making (Not avaliable): Trauma Tizer 
- Watcher of the credits: You

The file you downloaded is:
- RolePlay Script (Edited From Original) Revision 2.2 040512-2341

Permissions:
- Use it on your server
- Edit the script (But not the credits)
- Have fun with your friends

Restrictions:
- Editing the credits
- Upload it on any site
- Say it's yours
- Abusing the script
	
If this is a paying script, please do not upload it.
Trauma Tizer - Main Admin of OhGawd!
______________________________________________										  