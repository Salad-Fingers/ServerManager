doctorwho={}

function initArray2(f,v)
	local cmd={}
	for c=1,f do
		cmd[c]=v
	end
	return cmd
end

function doublearray(m,n,k)
    local a, x, y = {}
    for x = 0, m do a[x] = {}
        for y = 0, n do
            a[x][y] = k
        end
    end
    return a
end

function sound3(tilex,tiley,rangex,rangey,sound)
    -- Ranges are tiles!
    for pl=1,32 do
        if (player(pl,"exists")) then
            if (player(pl,"tilex")>=tilex-rangex and player(pl,"tiley")>=tiley-rangey and player(pl,"tilex")<=tilex+rangex and player(pl,"tiley")<=tiley+rangey) then
                parse("sv_sound2 "..pl.." \""..sound.."\"")
            end
        end
    end
end

doctorwho.tardis={}

doctorwho.tardis.current=0
doctorwho.tardis.next=1
doctorwho.tardis.limit=game("sv_maxplayers") --only one TARDIS per player
doctorwho.tardis.owner=initArray2(doctorwho.tardis.limit,0)

doctorwho.tardis.pos=doublearray(doctorwho.tardis.limit,4,0) --1 is px x, 2 is px y, 3 is tile x, 4 is tile y
doctorwho.tardis.image=initArray2(doctorwho.tardis.limit,0) -- the box itself
doctorwho.tardis.gimage=initArray2(doctorwho.tardis.limit,0) -- the ghost box image (appearing when materializing)
doctorwho.tardis.light=initArray2(doctorwho.tardis.limit,0) -- the light that will be blinking while the TARDIS is dematerializing/rematerializing
doctorwho.tardis.glight=initArray2(doctorwho.tardis.limit,0) -- the light that will be blinking while the ghost TARDIS is materializing
doctorwho.tardis.destination=doublearray(doctorwho.tardis.limit,2,0) --1 is tile x, 2 is tile y

doctorwho.tardis.defaultimg="gfx/doctorwho/tardis.png"
doctorwho.tardis.recolor=false -- does the image need recoloring?
doctorwho.tardis.color=initArray2(3,0) -- use if image needs recoloring

doctorwho.tardis.color[1]=0 -- R
doctorwho.tardis.color[2]=0 -- G
doctorwho.tardis.color[3]=255 -- B

playerSittingIn=doublearray(doctorwho.tardis.limit,doctorwho.tardis.limit,false)
playerSitting=initArray2(doctorwho.tardis.limit,initArray2(doctorwho.tardis.limit,0))
tardisIn=initArray2(doctorwho.tardis.limit,0)
tardisOf=initArray2(doctorwho.tardis.limit,0)
canBeInteracted=initArray2(doctorwho.tardis.limit,true)

playerSpeedmod=initArray2(doctorwho.tardis.limit,0)
playerArmor=initArray2(doctorwho.tardis.limit,0)
playerMomentum=initArray2(doctorwho.tardis.limit,0)
angularMomentum=initArray2(doctorwho.tardis.limit,0)
acceleration=0.8
angAcceleration=0.4
angle=initArray2(doctorwho.tardis.limit,0)

doctorwho.dalekimg=initArray2(doctorwho.tardis.limit,0)
dalekSoundReady=initArray2(doctorwho.tardis.limit,true)
sonicSoundReady=initArray2(doctorwho.tardis.limit,true)
cloisterReady=initArray2(doctorwho.tardis.limit,true)
hasSonic=initArray2(doctorwho.tardis.limit,false)

doctorwho.regenerating=initArray2(doctorwho.tardis.limit,false)
doctorwho.regenglow=initArray2(doctorwho.tardis.limit,0)
recoveringhp=initArray2(doctorwho.tardis.limit,false)
srecoveringhp=initArray2(doctorwho.tardis.limit,false)
doctorwho.regencycles=initArray2(doctorwho.tardis.limit,13)

flyMode=initArray2(doctorwho.tardis.limit,false)
piloting=initArray2(doctorwho.tardis.limit,0)
flying=initArray2(doctorwho.tardis.limit,false)
pilot=initArray2(doctorwho.tardis.limit,0)
enteringCoordinates=initArray2(doctorwho.tardis.limit,false)
matloop=initArray2(doctorwho.tardis.limit,false)

doctorwho.admins={1,7749}

function contains(table, element)
    for _, value in pairs(table) do
        if value == element then
            return true
        end
    end
    return false
end

function showkey(table, element)
    for key, value in pairs(table) do
        if value == element then
            return key
        end
    end
    return false
end

function createTARDIS(ply,x,y)
	if (doctorwho.tardis.next<tonumber(doctorwho.tardis.limit)) then
		doctorwho.tardis.image[doctorwho.tardis.next]=image(doctorwho.tardis.defaultimg,x*32+16,y*32+16,1)
		if (doctorwho.tardis.recolor) then
			imagecolor(doctorwho.tardis.image[doctorwho.tardis.next],doctorwho.tardis.color[1],doctorwho.tardis.color[2],doctorwho.tardis.color[3])
		end
		doctorwho.tardis.gimage[doctorwho.tardis.next]=image(doctorwho.tardis.defaultimg,x*32+16,y*32+16,1)
		if (doctorwho.tardis.recolor) then
			imagecolor(doctorwho.tardis.gimage[doctorwho.tardis.next],doctorwho.tardis.color[1],doctorwho.tardis.color[2],doctorwho.tardis.color[3])
		end
		
		doctorwho.tardis.light[doctorwho.tardis.next]=image("gfx/sprites/flare3.bmp",x*32+16,y*32+16,1)
		doctorwho.tardis.glight[doctorwho.tardis.next]=image("gfx/sprites/flare3.bmp",x*32+16,y*32+16,1)
		imagealpha(doctorwho.tardis.light[doctorwho.tardis.next],0)
		imagealpha(doctorwho.tardis.glight[doctorwho.tardis.next],0)
		imageblend(doctorwho.tardis.light[doctorwho.tardis.next],1)
		imageblend(doctorwho.tardis.glight[doctorwho.tardis.next],1)
		imagescale(doctorwho.tardis.light[doctorwho.tardis.next],0.3,0.3)
		imagescale(doctorwho.tardis.glight[doctorwho.tardis.next],0.3,0.3)
		
		
		imagealpha(doctorwho.tardis.gimage[doctorwho.tardis.next],0)
		doctorwho.tardis.owner[doctorwho.tardis.next]=ply
		doctorwho.tardis.pos[doctorwho.tardis.next][1]=x*32+16
		doctorwho.tardis.pos[doctorwho.tardis.next][2]=y*32+16
		doctorwho.tardis.pos[doctorwho.tardis.next][3]=x
		doctorwho.tardis.pos[doctorwho.tardis.next][4]=y
		doctorwho.tardis.current=doctorwho.tardis.current+1
		doctorwho.tardis.next=doctorwho.tardis.next+1
	end
end

function blinkTARDIS(id,deg)
	if (deg==1) then
		tween_alpha(doctorwho.tardis.image[id],1000,0.5)
		tween_alpha(doctorwho.tardis.light[id],1000,1)
		timer(1000,"parse","lua tween_alpha("..doctorwho.tardis.image[id]..",1000,1)")
		timer(1000,"parse","lua tween_alpha("..doctorwho.tardis.light[id]..",1000,0)")
	end
	if (deg==2) then
		tween_alpha(doctorwho.tardis.image[id],1000,0.25)
		tween_alpha(doctorwho.tardis.light[id],1000,1)
		timer(1000,"parse","lua tween_alpha("..doctorwho.tardis.image[id]..",1000,0.5)")
		timer(1000,"parse","lua tween_alpha("..doctorwho.tardis.light[id]..",1000,0)")
	end
	if (deg==3) then
		tween_alpha(doctorwho.tardis.image[id],1000,0)
		tween_alpha(doctorwho.tardis.light[id],1000,1)
		timer(1000,"parse","lua tween_alpha("..doctorwho.tardis.image[id]..",1000,0.25)")
		timer(1000,"parse","lua tween_alpha("..doctorwho.tardis.light[id]..",1000,0)")
	end
	if (deg==1.2) then
		tween_alpha(doctorwho.tardis.image[id],1000,0)
		tween_alpha(doctorwho.tardis.light[id],1000,0)
		timer(1000,"parse","lua tween_alpha("..doctorwho.tardis.image[id]..",1000,1)")
		timer(1000,"parse","lua tween_alpha("..doctorwho.tardis.light[id]..",1000,1)")
	end
	if (deg==2.2) then
		tween_alpha(doctorwho.tardis.image[id],1000,0)
		tween_alpha(doctorwho.tardis.light[id],1000,0)
		timer(1000,"parse","lua tween_alpha("..doctorwho.tardis.image[id]..",1000,0.5)")
		timer(1000,"parse","lua tween_alpha("..doctorwho.tardis.light[id]..",1000,1)")
	end
	if (deg==3.2) then
		tween_alpha(doctorwho.tardis.image[id],1000,0)
		tween_alpha(doctorwho.tardis.light[id],1000,0)
		timer(1000,"parse","lua tween_alpha("..doctorwho.tardis.image[id]..",1000,0.25)")
		timer(1000,"parse","lua tween_alpha("..doctorwho.tardis.light[id]..",1000,1)")
	end
end

function blinkGhostTARDIS(id,deg)
	if (deg==1) then
		tween_alpha(doctorwho.tardis.gimage[id],1000,1)
		tween_alpha(doctorwho.tardis.glight[id],1000,1)
		timer(1000,"parse","lua tween_alpha("..doctorwho.tardis.gimage[id]..",1000,0.5)")
		timer(1000,"parse","lua tween_alpha("..doctorwho.tardis.glight[id]..",1000,0)")
	end
	if (deg==2) then
		tween_alpha(doctorwho.tardis.gimage[id],1000,0.5)
		tween_alpha(doctorwho.tardis.glight[id],1000,1)
		timer(1000,"parse","lua tween_alpha("..doctorwho.tardis.gimage[id]..",1000,0.25)")
		timer(1000,"parse","lua tween_alpha("..doctorwho.tardis.glight[id]..",1000,0)")
	end
	if (deg==3) then
		tween_alpha(doctorwho.tardis.gimage[id],1000,0.25)
		tween_alpha(doctorwho.tardis.glight[id],1000,1)
		timer(1000,"parse","lua tween_alpha("..doctorwho.tardis.gimage[id]..",1000,0)")
		timer(1000,"parse","lua tween_alpha("..doctorwho.tardis.glight[id]..",1000,0)")
	end
end

function transportPlayer(id,dx,dy)
	for ply=1,doctorwho.tardis.limit do
		if (playerSittingIn[id][ply]) then 
			parse("setpos "..ply.." "..((dx*32)+16).." "..((dy*32)+16)) 
		end
	end
end

function updatePosition(id,x,y)
	doctorwho.tardis.pos[id][1]=x*32+16
	doctorwho.tardis.pos[id][2]=y*32+16
	doctorwho.tardis.pos[id][3]=x
	doctorwho.tardis.pos[id][4]=y
end

function changePosition(id,dx,dy)
	if (flying[id]) then
		freeimage(doctorwho.tardis.image[id])
		doctorwho.tardis.image[id]=image("gfx/doctorwho/tardis.png",0,0,200+doctorwho.tardis.owner[id])
		tween_rotateconstantly(doctorwho.tardis.image[id],5)
	else
		imagepos(doctorwho.tardis.image[id],dx*32+16,dy*32+16,0)
		imagepos(doctorwho.tardis.light[id],dx*32+16,dy*32+16,0)
	end
end

function transportTARDIS(id,dx,dy)
	flyMode[playerSitting[id][doctorwho.tardis.owner[id]]]=false
	piloting[playerSitting[id][doctorwho.tardis.owner[id]]]=0
	flying[id]=false
	pilot[id]=0
	freeimage(doctorwho.tardis.image[id])
	doctorwho.tardis.image[id]=image(doctorwho.tardis.defaultimg,(player(id,"tilex")*32+16),(player(id,"tiley")*32+16),1)
	tween_rotate(doctorwho.tardis.image[id],1500,0)
	parse("speedmod "..id.." -100")
	parse("setpos "..id.." "..(player(id,"tilex")*32+16).." "..(player(id,"tiley")*32+16))
	canBeInteracted[id]=false
	sound3(doctorwho.tardis.pos[id][3],doctorwho.tardis.pos[id][4],8,8,"doctorwho/tardis_takeoff.ogg")
	sound3(dx,dy,8,8,"doctorwho/tardis_land.ogg")
	doctorwho.tardis.gimage[id]=image(doctorwho.tardis.defaultimg,dx*32+16,dy*32+16,1)
	
	doctorwho.tardis.glight[id]=image("gfx/sprites/flare3.bmp",(player(id,"tilex")*32+16),(player(id,"tiley")*32+16),1)
	imagealpha(doctorwho.tardis.glight[id],0)
	imageblend(doctorwho.tardis.glight[id],1)
	imagescale(doctorwho.tardis.glight[id],0.3,0.3)
	
	if (doctorwho.tardis.recolor) then
		imagecolor(doctorwho.tardis.gimage[id],doctorwho.tardis.color[1],doctorwho.tardis.color[2],doctorwho.tardis.color[3])
	end
	imagealpha(doctorwho.tardis.gimage[id],0)
	imagepos(doctorwho.tardis.gimage[id],dx*32+16,dy*32+16,0)
	
	imagepos(doctorwho.tardis.glight[id],dx*32+16,dy*32+16,0)
	
	timer(6500,"parse","lua blinkTARDIS("..id..",1)")
	timer(8500,"parse","lua blinkTARDIS("..id..",1)")
	timer(10500,"parse","lua blinkTARDIS("..id..",2)")
	timer(10500,"parse","lua blinkGhostTARDIS("..id..",3)")
	timer(12500,"parse","lua blinkTARDIS("..id..",3)")
	timer(12500,"parse","lua blinkGhostTARDIS("..id..",3)")
	timer(14500,"parse","lua changePosition("..id..","..dx..","..dy..")")
	timer(14500,"parse","lua freeimage(doctorwho.tardis.gimage["..id.."])")
	timer(14500,"parse","lua freeimage(doctorwho.tardis.glight["..id.."])")
	timer(14500,"parse","lua transportPlayer("..id..","..dx..","..dy..")")
	timer(14500,"parse","lua blinkTARDIS("..id..",3.2)")
	timer(16500,"parse","lua blinkTARDIS("..id..",2.2)")
	timer(18500,"parse","lua blinkTARDIS("..id..",1.2)")
	timer(20500,"parse","lua updatePosition("..id..","..dx..","..dy..")")
	timer(20500,"parse","lua tween_alpha(doctorwho.tardis.light["..id.."],1000,0)")
	timer(21000,"parse","lua canBeInteracted["..id.."]=true")
end

addhook("use","doctorwho.tardis.plyenter")
function doctorwho.tardis.plyenter(id)
	for t=1,doctorwho.tardis.current do
		if (canBeInteracted[t] and player(id,"team")==2) then
			if (player(id,"tilex")==doctorwho.tardis.pos[t][3] and player(id,"tiley")==doctorwho.tardis.pos[t][4]) then
				if (not contains(playerSitting[t],id)) then
					parse("setpos "..id.." "..(doctorwho.tardis.pos[t][3]*32+16).." "..(doctorwho.tardis.pos[t][4]*32+16))
					playerSpeedmod[id]=player(id,"speedmod")
					parse("speedmod "..id.." -100")
					playerSittingIn[t][id]=true
					table.insert(playerSitting[t],id)
					tardisIn[id]=t
				elseif (contains(playerSitting[t],id)) then
					if (flyMode[id]) then
						flyMode[id]=false
						piloting[id]=0
						flying[tardisIn[id]]=false
						pilot[tardisIn[id]]=0
						freeimage(doctorwho.tardis.image[tardisIn[id]])
						doctorwho.tardis.image[tardisIn[id]]=image(doctorwho.tardis.defaultimg,(player(id,"tilex")*32+16),(player(id,"tiley")*32+16),1)
						tween_rotate(doctorwho.tardis.image[tardisIn[id]],1500,0)
						parse("setpos "..id.." "..(player(id,"tilex")*32+16).." "..(player(id,"tiley")*32+16))
					end
					parse("speedmod "..id.." "..playerSpeedmod[id])
					tardisIn[id]=0
					local key=showkey(playerSitting[t],id)
					table.remove(playerSitting[t],key)
				end
			end
		end
	end
end

addhook("spawn","doctorwho.godalek")
function doctorwho.godalek(id)
	if (player(id,"team")==1) then
		doctorwho.dalekimg[id]=image("gfx/doctorwho/dalek.png",1,0,200+id)
		parse("speedmod "..id.." -7")
		parse("equip "..id.." 83")
		parse("equip "..id.." 45")
		parse("strip "..id.." 2")
		parse("strip "..id.." 50")
	else
		if (doctorwho.dalekimg[id]~=0) then
			freeimage(doctorwho.dalekimg[id])
			doctorwho.dalekimg[id]=0
		end
	end
end

addhook("die","doctorwho.dalekdie")
function doctorwho.dalekdie(id)
	if (player(id,"team")==1) then
		return 1
	end
end

addhook("drop","doctorwho.dalekdrop")
function doctorwho.dalekdrop(id)
	if (player(id,"team")==1) then
		return 1
	end
end

addhook("walkover","doctorwho.dalekwalkover")
function doctorwho.dalekdrop(id)
	if (player(id,"team")==1) then
		return 1
	end
end

addhook("serveraction","doctorwho.daleksfx")
function doctorwho.daleksfx(id,a)
	if (a==3) then
		if (dalekSoundReady[id] and player(id,"team")==1) then
			sound3(player(id,"tilex"),player(id,"tiley"),5,5,"doctorwho/dalek_exterminate.ogg")
			dalekSoundReady[id]=false
			timer(2000,"parse","lua dalekSoundReady["..id.."]=true")
		end
	end
end

function activateNearbyTriggers(id)
	if (entity(player(id,"tilex"),player(id,"tiley"),"exists")) then
		--parse("trigger "..entity(player(id,"tilex"),player(id,"tiley"),"name"))
		parse("trigger "..entity(player(id,"tilex"),player(id,"tiley"),"trigger"))
	end
	if (entity(player(id,"tilex")+1,player(id,"tiley"),"exists")) then
		--parse("trigger "..entity(player(id,"tilex")+1,player(id,"tiley"),"name"))
		parse("trigger "..entity(player(id,"tilex")+1,player(id,"tiley"),"trigger"))
	end
	if (entity(player(id,"tilex")-1,player(id,"tiley"),"exists")) then
		--parse("trigger "..entity(player(id,"tilex")-1,player(id,"tiley"),"name"))
		parse("trigger "..entity(player(id,"tilex")-1,player(id,"tiley"),"trigger"))
	end
	if (entity(player(id,"tilex"),player(id,"tiley")-1,"exists")) then
		--parse("trigger "..entity(player(id,"tilex"),player(id,"tiley")-1,"name"))
		parse("trigger "..entity(player(id,"tilex"),player(id,"tiley")-1,"trigger"))
	end
	if (entity(player(id,"tilex"),player(id,"tiley")+1,"exists")) then
		--parse("trigger "..entity(player(id,"tilex"),player(id,"tiley")+1,"name"))
		parse("trigger "..entity(player(id,"tilex"),player(id,"tiley")+1,"trigger"))
	end
	if (entity(player(id,"tilex")-1,player(id,"tiley")-1,"exists")) then
		--parse("trigger "..entity(player(id,"tilex")-1,player(id,"tiley")-1,"name"))
		parse("trigger "..entity(player(id,"tilex")-1,player(id,"tiley")-1,"trigger"))
	end
	if (entity(player(id,"tilex")-1,player(id,"tiley")+1,"exists")) then
		--parse("trigger "..entity(player(id,"tilex")-1,player(id,"tiley")+1,"name"))
		parse("trigger "..entity(player(id,"tilex")-1,player(id,"tiley")+1,"trigger"))
	end
	if (entity(player(id,"tilex")+1,player(id,"tiley")+1,"exists")) then
		--parse("trigger "..entity(player(id,"tilex")+1,player(id,"tiley")+1,"name"))
		parse("trigger "..entity(player(id,"tilex")+1,player(id,"tiley")+1,"trigger"))
	end
	if (entity(player(id,"tilex")+1,player(id,"tiley")-1,"exists")) then
		--parse("trigger "..entity(player(id,"tilex")+1,player(id,"tiley")-1,"name"))
		parse("trigger "..entity(player(id,"tilex")+1,player(id,"tiley")-1,"trigger"))
	end
end

function csconvert(rot,x,y,factor)
	if rot<-90 then rot=rot+360 end
	local angle=math.rad(math.abs(rot+90))-math.pi
	local cx=x+(math.cos(angle)*factor)
	local cy=y+(math.sin(angle)*factor)
	return cx,cy
end

function toggleTrigger(id,mode)
	local xx,yy=csconvert(player(id,"rot"),player(id,"x"),player(id,"y"),32)
	local cx=math.floor(xx/32)
	local cy=math.floor(yy/32)
	local xx2,yy2=csconvert(player(id,"rot"),player(id,"x"),player(id,"y"),64)
	local cx2=math.floor(xx2/32)
	local cy2=math.floor(yy2/32)
	local tx=player(id,"tilex")
	local ty=player(id,"tiley")
	if (mode==1) then
		if (entity(cx,cy,"trigger") and entity(cx,cy,"trigger")~=nil) then
			parse("trigger "..entity(cx,cy,"trigger"))
		end
		if (entity(cx2,cy2,"trigger") and entity(cx2,cy2,"trigger")~=nil) then
			parse("trigger "..entity(cx2,cy2,"trigger"))
		end
		if (entity(tx,ty,"trigger") and entity(tx,ty,"trigger")~=nil) then
			parse("trigger "..entity(tx,ty,"trigger"))
		end
	elseif (mode==2) then
		if (entity(cx,cy,"name") and entity(cx,cy,"name")~=nil) then
			parse("trigger "..entity(cx,cy,"name"))
		end
		if (entity(cx2,cy2,"name") and entity(cx2,cy2,"name")~=nil) then
			parse("trigger "..entity(cx2,cy2,"name"))
		end
		if (entity(tx,ty,"name") and entity(tx,ty,"name")~=nil) then
			parse("trigger "..entity(tx,ty,"name"))
		end
	end
end

plyposition=doublearray(32,3,0)

function isGoodPos(pos,ppos)
	if (pos==ppos) then
		return 0
	elseif (pos==nil) then
		return 0
	end
	return pos
end

--[[function findNearestPlayer(id)
	for fid=1,doctorwho.tardis.limit do
		if (player(fid,"exists") and fid~=id) then
			plyposition[fid][1]=player(fid,"tilex")
			plyposition[fid][2]=player(fid,"tiley")
			plyposition[fid][3]=plyposition[fid][1]+plyposition[fid][2]
		end
	end
	plyposition[id][3]=player(id,"tilex")+player(id,"tiley")
	plypositionmin=math.min(math.abs(plyposition[id][3]-isGoodPos(plyposition[1][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[2][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[3][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[4][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[5][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[6][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[7][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[8][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[9][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[10][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[11][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[12][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[13][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[14][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[15][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[16][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[17][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[18][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[19][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[20][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[21][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[22][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[23][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[24][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[25][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[26][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[27][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[28][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[29][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[30][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[31][3],plyposition[id][3])),math.abs(plyposition[id][3]-isGoodPos(plyposition[32][3],plyposition[id][3])))
	for fid=1,doctorwho.tardis.limit do
		if (player(fid,"exists") and fid~=id) then
			if (plypositionmin==math.abs(plyposition[id][3]-plyposition[fid][3])) then
				msg("The nearest player is "..player(fid,"name").." ("..math.abs(plyposition[id][3]-plyposition[fid][3]).." tiles away)")
				break
			else
				msg("An error occured; could not find the nearest player!")
				break
			end
		end
	end
end]]

function printPosition(id)
	msg("Sonic Screwdriver: your current position is TILES ("..player(id,"tilex").."|"..player(id,"tiley").."); PIXELS ("..math.floor(player(id,"x")).."|"..math.floor(player(id,"y"))..")")
end

function sonicMenu(id)
	menu(id,"Sonic Screwdriver,Toggle trigger,Toggle entity,Toggle nearby triggers,Print own position,Summon TARDIS")
end

addhook("menu","doctorwho.ssmenu")
function doctorwho.ssmenu(id,menu,sel)
	if (menu=="Sonic Screwdriver") then
		if (sel==1) then
			sound3(player(id,"tilex"),player(id,"tiley"),5,5,"weapons/sonic.ogg")
			timer(1000,"parse","lua toggleTrigger("..id..",1)")
		end
		if (sel==2) then
			sound3(player(id,"tilex"),player(id,"tiley"),5,5,"weapons/sonic.ogg")
			timer(1000,"parse","lua toggleTrigger("..id..",2)")
		end
		if (sel==3) then
			sound3(player(id,"tilex"),player(id,"tiley"),5,5,"weapons/sonic.ogg")
			timer(1000,"parse","lua activateNearbyTriggers("..id..")")
		end
		if (sel==4) then
			sound3(player(id,"tilex"),player(id,"tiley"),5,5,"weapons/sonic.ogg")
			timer(1000,"parse","lua printPosition("..id..")")
		end
		if (sel==5) then
			sound3(player(id,"tilex"),player(id,"tiley"),5,5,"weapons/sonic.ogg")
			for t=1,doctorwho.tardis.current do
				if (doctorwho.tardis.owner[t]==id) then
					transportTARDIS(t,player(id,"tilex"),player(id,"tiley"))
					break
				end
			end
		end
	end
	if (menu=="TARDIS Controls") then
		if (sel==1) then
			enteringCoordinates[id]=true
			msg2(id,"Enter destination coordinates (TILEX;TILEY)")
		end
		if (sel==2) then
			if (not flyMode[id]) then
				flyMode[id]=true
				piloting[id]=tardisIn[id]
				flying[tardisIn[id]]=true
				pilot[tardisIn[id]]=id
				freeimage(doctorwho.tardis.image[tardisIn[id]])
				doctorwho.tardis.image[tardisIn[id]]=image(doctorwho.tardis.defaultimg,0,0,200+id)
				tween_rotateconstantly(doctorwho.tardis.image[tardisIn[id]],5)
				freeimage(doctorwho.tardis.light[tardisIn[id]])
				doctorwho.tardis.light[tardisIn[id]]=image("gfx/sprites/flare3.bmp",0,0,200+id)
				imagealpha(doctorwho.tardis.light[tardisIn[id]],0)
				imageblend(doctorwho.tardis.light[tardisIn[id]],1)
				imagescale(doctorwho.tardis.light[tardisIn[id]],0.3,0.3)
				parse("speedmod "..id.." "..playerSpeedmod[id])
			else
				flyMode[id]=false
				piloting[id]=0
				flying[tardisIn[id]]=false
				pilot[tardisIn[id]]=0
				freeimage(doctorwho.tardis.image[tardisIn[id]])
				doctorwho.tardis.image[tardisIn[id]]=image(doctorwho.tardis.defaultimg,(player(id,"tilex")*32+16),(player(id,"tiley")*32+16),1)
				tween_rotate(doctorwho.tardis.image[tardisIn[id]],1500,0)
				freeimage(doctorwho.tardis.light[tardisIn[id]])
				doctorwho.tardis.light[tardisIn[id]]=image("gfx/sprites/flare3.bmp",(player(id,"tilex")*32+16),(player(id,"tiley")*32+16),1)
				imagealpha(doctorwho.tardis.light[tardisIn[id]],0)
				imageblend(doctorwho.tardis.light[tardisIn[id]],1)
				imagescale(doctorwho.tardis.light[tardisIn[id]],0.3,0.3)
				parse("speedmod "..id.." -100")
				parse("setpos "..id.." "..(player(id,"tilex")*32+16).." "..(player(id,"tiley")*32+16))
			end
		end
		if (sel==3) then
			if (cloisterReady[tardisIn[id]]) then
				cloisterReady[tardisIn[id]]=false
				sound3(player(id,"tilex"),player(id,"tiley"),5,5,"doctorwho/cloisterbell.ogg")
				timer(3000,"parse","lua cloisterReady["..tardisIn[id].."]=true")
			end
		end
	end
end

addhook("hit","doctorwho.hitrender")
function doctorwho.hitrender(id,src,wpn,dmg)
	if (tardisIn[id]~=0) then
		return 1
	end
	if (player(id,"team")==2 and doctorwho.regencycles[id]>0 and dmg>=player(id,"maxhealth")) then
		parse("sethealth "..id.." 1")
		return 1
	end
end

function quickPlural(count)
	if (count>1) then
		return "s"
	elseif (count<-1) then
		return "s"
	end
	return ""
end

addhook("say","doctorwho.sayprocess")
function doctorwho.sayprocess(id,t)
	if (contains(doctorwho.admins,player(id,"usgn"))) then
		if (t:sub(1,5)=="!give") then
			if (t:sub(7,11)=="sonic") then
				local _=t:sub(13)
				local tid=tonumber(_)
				hasSonic[tid]=true
				msg2(id,"You have given a sonic screwdriver to "..player(tid,"name"))
				msg2(tid,player(id,"name").." has given you a sonic screwdriver")
			end
			if (t:sub(7,11)=="regen") then
				local _=t:sub(13,14)
				local __=t:sub(15)
				local tid=tonumber(__)
				local rc=tonumber(_)
				doctorwho.regencycles[tid]=doctorwho.regencycles[tid]+rc
				if (rc>0) then
					msg2(id,"You have given "..rc.." regeneration"..quickPlural(rc).." to "..player(tid,"name"))
					msg2(tid,player(id,"name").." has given you "..rc.." regeneration"..quickPlural(rc))
				end
			end
			if (t:lower():sub(7,12)=="tardis") then
				local _=t:sub(14)
				local tid=tonumber(_)
				createTARDIS(tid,player(tid,"tilex"),player(tid,"tiley"))
				msg2(id,"You have given a TARDIS to "..player(tid,"name"))
				msg2(tid,player(id,"name").." has given you a TARDIS")
			end
			return 1
		end
	end
	if (enteringCoordinates[id]) then
		if (tardisIn[id]~=0) then
			local divider=t:find(";")
			local c1=t:sub(1,divider-1)
			local c2=t:sub(divider+1)
			local x=tonumber(c1)
			local y=tonumber(c2)
			if (x>=0 and x<=map("xsize") and y>=0 and y<=map("ysize")) then
				transportTARDIS(tardisIn[id],x,y)
				enteringCoordinates[id]=false
			else
				msg2(id,"�255000000ERROR: Invalid coordinates")
				enteringCoordinates[id]=false
			end
		end
		return 1
	end
end

function doctorwho.regenerate(id)
	doctorwho.regenerating[id]=true
	doctorwho.regenglow[id]=image("gfx/sprites/flare2.bmp",1,0,200+id)
	imageblend(doctorwho.regenglow[id],1)
	imagecolor(doctorwho.regenglow[id],255,200,0)
	imagealpha(doctorwho.regenglow[id],0)
	tween_alpha(doctorwho.regenglow[id],10000,0.4)
	playerSpeedmod[id]=player(id,"speedmod")
	parse("speedmod "..id.." -25")
	timer(10000,"parse","lua tween_alpha(doctorwho.regenglow["..id.."],1000,0)")
	timer(10000,"parse","speedmod "..id.." -100")
	timer(11000,"parse","lua tween_alpha(doctorwho.regenglow["..id.."],1000,1)")
	timer(11000,"parse","lua sound3("..player(id,"tilex")..","..player(id,"tiley")..",8,8,\"doctorwho/regeneration.ogg\")")
	timer(12500,"parse","lua recoveringhp["..id.."]=true")
	timer(19250,"parse","lua tween_alpha(doctorwho.regenglow["..id.."],500,0)")
	timer(19750,"parse","speedmod "..id.." "..playerSpeedmod[id])
end

addhook("die","doctorwho.abortregen")
function doctorwho.abortregen(id)
	if (doctorwho.regenerating[id]) then
		doctorwho.regenerating[id]=false
		freetimer("parse","lua tween_alpha(doctorwho.regenglow["..id.."],1000,0)")
		freetimer("parse","lua playerSpeedmod["..id.."]=player("..id..",\"speedmod\")")
		freetimer("parse","speedmod "..id.." -100")
		freetimer("parse","lua tween_alpha(doctorwho.regenglow["..id.."],1000,1)")
		freetimer("parse","lua sound3("..player(id,"tilex")..","..player(id,"tiley")..",8,8,\"doctorwho/regeneration.ogg\")")
		freetimer("parse","lua recoveringhp["..id.."]=true")
		freetimer("parse","lua tween_alpha(doctorwho.regenglow["..id.."],500,0)")
		freetimer("parse","speedmod "..id.." "..playerSpeedmod[id])
		freeimage(doctorwho.regenglow[id])
	end
end

function matloopTransport(t)
	local x=math.random(0,map("xsize"))
	local y=math.random(0,map("ysize"))
	if (tile(x,y,"frame")~=0 and tile(x,y,"property")>=5 and tile(x,y,"property")<=15) then
		imagepos(doctorwho.tardis.image[t],x*32+16,y*32+16,0)
		if (playerSittingIn[t]) then
			transportPlayer(playerSitting[t],x,y)
		end
		updatePosition(t,x,y)
	else
		matloopTransport(t)
	end
end

tick=0
stick=0

addhook("ms100","doctorwho.ms100")
function doctorwho.ms100()
	for id=1,doctorwho.tardis.limit do
		if (player(id,"exists") and player(id,"health")<=10 and player(id,"health")>0) then
			if (doctorwho.regencycles[id]>0) then
				srecoveringhp[id]=false
				doctorwho.regenerate(id)
				parse("sethealth "..id.." 11")
				doctorwho.regencycles[id]=doctorwho.regencycles[id]-1
			end
		end
		if (player(id,"exists") and recoveringhp[id]) then
			if (player(id,"health")<player(id,"maxhealth")) then
				if (tick<65) then
					parse("sethealth "..id.." "..player(id,"health")+1)
					tick=tick+1
				else
					tick=0
					recoveringhp[id]=false
					srecoveringhp[id]=true
				end
			end
			local rnd=math.random(75,100)/100
			imagealpha(doctorwho.regenglow[id],rnd)
		end
		if (player(id,"exists") and srecoveringhp[id]) then
			if (player(id,"health")<player(id,"maxhealth")) then
				tick=tick+0.5
				if (tick==7.5) then
					parse("sethealth "..id.." "..player(id,"health")+1)
					tick=0
				end
			else
				srecoveringhp[id]=false
			end
		end
		for t=1,doctorwho.tardis.current do
			if (matloop[t]) then
				matloopTransport(t)
			end
		end
	end
	stick=stick+0.1
end

addhook("serveraction","doctorwho.sonicscrewdriver")
function doctorwho.sonicscrewdriver(id,a)
	if (a==3) then
		if (hasSonic[id]) then
			if (sonicSoundReady[id] and player(id,"team")==2) then
				sound3(player(id,"tilex"),player(id,"tiley"),5,5,"doctorwho/sonicextend.ogg")
				sonicSoundReady[id]=false
				sonicMenu(id)
				timer(1000,"parse","lua sonicSoundReady["..id.."]=true")
			end
		end
	end
end

function tardismenu(id)
	menu(id,"TARDIS Controls,Teleport,Toggle Flying,Ring Cloister Bell")
end

addhook("serveraction","doctorwho.tardiscontrols")
function doctorwho.tardiscontrols(id,a)
	if (a==1) then
		if (tardisIn[id]~=0 and doctorwho.tardis.owner[tardisIn[id]]==id) then
			tardismenu(id)
		end
	end
end

mtick=0

addhook("second","doctorwho.second")
function doctorwho.second()
	mtick=mtick+1
	for id=1,32 do
		if (player(id,"exists") and flying[tardisIn[id]]) then
			if (stick>=1) then
				sound3(player(id,"tilex"),player(id,"tiley"),5,5,"doctorwho/inflight.ogg")
				imagescale(doctorwho.tardis.light[tardisIn[id]],0.3,0.3)
				tween_alpha(doctorwho.tardis.light[tardisIn[id]],1000,1)
				timer(1000,"parse","lua tween_alpha(doctorwho.tardis.light["..tardisIn[id].."],1000,0)")
				stick=0
			end
		end
	end
	for t=1,doctorwho.tardis.current do
		if (matloop[t]) then
			if (mtick>=2) then
				mtick=0
				parse("sv_sound2 "..playerSitting[t].." \"doctorwho/matloop.ogg\"")
			end
		end
	end
end

addhook("movetile","doctorwho.movetile")
function doctorwho.movetile(id,x,y)
	if (flyMode[id]) then
		doctorwho.tardis.pos[tardisIn[id]][1]=player(id,"x")
		doctorwho.tardis.pos[tardisIn[id]][2]=player(id,"y")
		doctorwho.tardis.pos[tardisIn[id]][3]=x
		doctorwho.tardis.pos[tardisIn[id]][4]=y
	end
end
