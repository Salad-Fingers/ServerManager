-- Super Hero Mod By Blazzingxx
-- author: Blazzingxx
-- version: 1.2
-- release date: 2009/08/17

-- Dofiles
sh_dir = 'sys/lua/superhero/'
dofile(sh_dir..'sh_config.cfg')
dofile(sh_dir..'sh_settings.cfg')
dofile(sh_dir..'sh_values.lua')
dofile(sh_dir..'sh_buildings.lua')
dofile(sh_dir..'sh_func_up.lua')
dofile(sh_dir..'sh_func_m.lua')
dofile(sh_dir..'sh_console.lua')
dofile(sh_dir..'sh_func.lua')

-- Hooks
addhook("parse","sh_parse")
addhook("team","sh_team")
addhook("join","sh_join")
addhook("spawn","sh_spawn")
addhook("minute","sh_interupt")
addhook("second","sh_second")
addhook("buildattempt","sh_buildattempt")
addhook("reload","sh_reload")
addhook("startround","sh_startround")
addhook("kill","sh_kill")
addhook("hit","sh_hit")
addhook("menu","sh_menu")
addhook("serveraction","sh_serveraction")
addhook("walkover","sh_walkover")
if sh_wpn_rounds == 1 then
	addhook("die","sh_die")
	addhook("drop","sh_drop")
	addhook("buy","sh_buy")
end
if sh_pl_say == 1 then
	addhook("say","sh_say")
end