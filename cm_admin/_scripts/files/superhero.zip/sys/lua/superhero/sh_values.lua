-- Super Hero Valuables

-- Array
function array(m)
	local array = {}
	for i = 1, m do
		array[i] = 0
	end
	return array
end

-- Values
pl_count = game('sv_maxplayers')
pl_lvl = array(pl_count)
pl_load = array(pl_count)
pl_xp = array(pl_count)
pl_credits = array(pl_count)
pl_nxp = array(pl_count)
pl_pt = array(pl_count)
pl_stunt = array(pl_count)
pl_psn = array(pl_count)
pl_menu_id = array(pl_count)
pl_gren = array(pl_count)
pl_life = array(pl_count)
sh_id = array(pl_count*35)
sh_time = 0
sh_name = {'Sportsman','Policeman','Thief','Snowman','Nightcrawler','Night Hawk','Businessman','Bomberman','Superman','Punisher','The Torch','The Flash','Cyclop','Engineer','The Beast','The Chainsaw','Dracula','Minesweeper','Cobra','Wolverine','Kamikadze','Batman','Magician','Demoman','The Hammer','Iron Man','Robin','Tarzan','Spiderman','Pyro','Hulk','Major','Bin Laden','Shadow Cat','Diablo'}
sh_limit = {4,4,3,1,1,1,5,5,4,1,1,2,1,3,2,1,3,1,3,5,3,2,1,1,3,1,2,1,1,1,2,1,1,1,1}
sh_req_pt = {1,1,1,1,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,6,6,6,6,7,7,7,7,15,15,20}
sh_item_names = {'Walls I','Walls II','Walls III','Mines I','Mines II','Mines III','Base I','Base II','Base III','25hp Heal Potion','50hp Heal Potion','75hp Heal Potion','100hp Heal Potion','Super-Bomb I','Super-Bomb II','Super-Bomb III','Diablo Power|Evil Wrath'}
sh_item_inv = array(pl_count*17)
sh_item_prices = {75,100,125,55,65,75,150,250,400,10,15,20,25,100,125,150,0}
sh_power = {'Health','Armor','Speed','Snowballs','Telekinesis','See Dark','Money Income','Respawn Grenades','Health/Armor','No Reload','Molotov','Speed','Laser Mines','Turrets','Health','Chainsaw','Hp Per Kill','Mines','Poision','Heal/Claws','Explosion','Armor/Speed','Critical Heal','Gren. Launcher','Damage','Rockets','Speed','Machete','Stun','Flamethrower','Health','Airstrike','RPG Launcher','Invisibility','Explosions'}
sh_class_name = {'Usual Heroes','Classical Heroes','Reliable Heroes','Super Heroes','Glorious Heroes','Ultra Heroes','Modern Heroes','Legend Heroes','God'}
sh_btn = {'Next|More','Back|Previous'}
sh_heroes = ''
wpn_lvl = {32,20,39,22,10,30,38,40,35,11}
wpn_rnd = 1
minutes = 5
color = {'�255200000','�000255000','�160160255','�255000000','�240000240','�255128064'}
say_cmd = {'!help','!heroes','!reheroes','!myheroes','!clearheroes','!shop','!inventory','!reset','!commands','!whatstats'}
say_cmd_inf = {'Super Hero Menu','Select Heroes','Remove Heroes','Your Heroes','Clear All','Shop Menu','Inventory Menu','Reset Lvl','Say Commands','Shows Player Info'}
adm_cmd = {'sh_cmd_list','sh_say_list','sh_pl_list','sh_give_xp','sh_give_lvl','sh_give_credits','sh_give_all_credits'}
adm_cmd_inf = {' - Console Commands List',' - Say Commands List',' - Players List',' <id> <xp> - Gives xp for player',' <id> <lvl> - Gives lvl for player',' <id> <credits> - Gives credits for player',' <credits> - Gives credits for all players'}