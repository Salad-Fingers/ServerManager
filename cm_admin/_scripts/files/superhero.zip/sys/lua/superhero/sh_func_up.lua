-- Super Hero Functions Update

function sh_print(clr,txt)
	print(color[clr]..''..txt)
end

function sh_txt2(id,slot,clr,txt,x,y,a)
	parse('hudtxt2 '..id..' '..slot..' "'..color[clr]..''..txt..'" '..x..' '..y..' '..a..'')
end

function sh_msg2(id,clr,txt)
	msg2(id,color[clr]..''..txt)
end

function sh_msg(clr,txt)
	msg(color[clr]..''..txt)
end

function sh_build(id,b,x,y,t)
	if not entity(x,y,"exists") then
		parse('spawnobject '..b..' '..x..' '..y..' 0 0 '..t..' '..id)
	else
		sh_msg2(id,4,'Do not build on entities!@C')
	end
end

function sh_explosion(id,dmg,x,y)
	parse('explosion '..x..' '..y..' '..dmg..' '..dmg..' '..id)
end

function sh_health(id,hp)
	parse("setmaxhealth "..id.." "..100 + hp)
end

function sh_heal(id,hp)
	parse('sethealth '..id..' '..player(id,"health") + hp)
end

function sh_armor(id,armor)
	parse('setarmor '..id..' '..(100 + armor))
end

function sh_speed(id,speed)
	parse('speedmod '..id..' '..speed)
end

function sh_money(id,m)
	parse('setmoney '..id..' '..player(id,"money") + m)
end

function sh_equip(id,item)
	parse('equip '..id..' '..item)
end

function sh_snd(snd)
	if sh_sound == 1 then
		parse('sv_sound '..snd)
	end
end

function sh_snd2(id,snd)
	if sh_sound == 1 then
		parse('sv_sound2 '..id..' '..snd)
	end
end