-- Super Hero Functions

function sh_join(p)
	pl_load[p] = 0
	pl_menu_id[p] = 0
	pl_credits[p] = sh_credits_start
	sh_hero_reset(p)
	sh_item_reset(p)
end

function sh_hit(id,s,wpn,h,a)
	if player(s,"exists") then
	if sh_id[35 * (s - 1) + 29] > 0 and pl_stunt[id] < 1 and wpn < 50 and player(id,"team") ~= player(s,"team") then
		sh_msg2(id,4,'You Get Stunned by '..player(s,"name")..'@C')
		pl_stunt[id] = 1
		sh_speed(id,-15)
	end
	if sh_id[35 * (s - 1) + 19] > 0 and pl_psn[id] < 1 and wpn < 50 and player(id,"team") ~= player(s,"team") then
		pl_psn[id] = sh_id[35 * (s - 1) + 19]
		sh_msg2(id,4,'You Get Poisened by '..player(s,"name")..'!@C')
	end
	if sh_id[35 * (s - 1) + 25] > 0 and wpn < 51 then
		local hp_dmg = h + (h / 9) * sh_id[35 * (s - 1) + 25]
		local ap_dmg = a + (a / 9) * sh_id[35 * (s - 1) + 25]
		if player(id,"health") - hp_dmg > 0 then
			parse('sethealth '..id..' ' ..player(id,"health") - hp_dmg)
			parse('setarmor '..id..' ' ..player(id,"armor") - ap_dmg)
			return 1
		end
	end
	end
	if sh_id[35 * (id - 1) + 23] > 0 and pl_life[id] < 1 then
		if player(id,"health") - h  <= 0 then
			pl_life[id] = pl_life[id] + 1
			sh_msg2(id,3,'Reborn!@C')
			parse('sethealth '..id..' 50')
			return 1
		end
	end
end

function sh_team(id)
	sh_pl_load(id)
	sh_txt2(id,0,2,'Super Hero Mod (v 1.2)',322,13,1)
	sh_txt2(id,1,3,''..game("sv_name")..' Server',322,26,1)
	sh_txt2(id,2,1,'Level: '..pl_lvl[id]..'/'..sh_lvl_max..'',3,430,0)
	sh_txt2(id,3,1,'Points: '..pl_pt[id]..'',110,430,0)
	sh_txt2(id,4,1,'Exp: ('..pl_xp[id]..'/'..pl_nxp[id]..')',210,430,0)
	sh_txt2(id,6,3,'Credits: ('..pl_credits[id]..'/'..sh_credits_max..')',210,415,0)
end

function sh_kill(killer,victim,wpn)
	sh_xp_gain(killer,victim,wpn)
	sh_lvl_up(killer)
	sh_pl_save(killer)
	if sh_id[35 * (victim - 1) + 21] > 0 then sh_explosion(victim,sh_id[35 * (victim - 1) + 21] * 75,player(victim,"x"),player(victim,"y")); end
end

function sh_serveraction(id,btn)
	if (btn == 1) then sh_hero_menu(id); end
	if (btn == 2) then sh_say_menu(id); end
	if (btn == 3) then sh_items_menu(id); end
end

function sh_spawn(id)
	pl_psn[id] = 0
	pl_life[id] = 0
	pl_gren[id] = 30
	sh_wpn_rnd(id)
	sh_heroes_action(id)
	if pl_pt[id] > 0 then sh_class_menu(id); end
	if sh_id[35 * (id - 1) + 14] > 0 then sh_msg2(id,3,'You Have Enginier - You Can build '..sh_id[35 * (id - 1) + 14]..' Turret(s)!'); end
	if sh_id[35 * (id - 1) + 35] > 0 then
		sh_msg2(id,3,'Diablo Power Charged! Check Inventory For Power!@C')
		sh_item_inv[17 * (id - 1) + 17] = 1
	end
end

function sh_interupt()
	if minutes > 3 then
		sh_msg(6,'===== Super Hero Script =====')
		sh_msg(2,'Author: '..aut..''..autt)
		sh_msg(2,'Version: 1.2')
		sh_msg(2,'Release: 2009/08/17')
		minutes = 0
	end
	minutes = minutes + 1
	if minutes == 2 then
		sh_msg(6,'[SH] Press F2 to show the game menu')
		sh_msg(6,'[SH] Press F3 to show the say commands')
		sh_msg(6,'[SH] Press F4 to show items menu')
		minutes = 0
	end
end

function sh_reload(id,mode)
	if sh_id[35 * (id - 1) + 10] > 0 then
		if (mode == 1) then sh_equip(id,player(id,"weapontype")); end
	end
end

function sh_second()
	sh_time = sh_time + 1
	if sh_time > 3 then
		for i = 1, pl_count do
			if (player(i,"exists")) then
				if sh_id[35 * (i - 1) + 8] > 0 then pl_gren[i] = pl_gren[i] + 4 if pl_gren[i] > 30 - sh_id[35 * (i - 1) + 8] * 4 then sh_equip(i,51); pl_gren[i] = 0; end; end
				if sh_id[35 * (i - 1) + 7] > 0 then sh_money(i,sh_id[35 * (i - 1) + 7] * 45); end
				if sh_id[35 * (i - 1) + 20] > 0 then sh_heal(i,sh_id[35 * (i - 1) + 20] * 10); end
				if pl_stunt[i] > 0 then pl_stunt[i] = 0; sh_speed(i,sh_id[35 * (i - 1) + 3] + sh_id[35 * (i - 1) + 12] + sh_id[35 * (i - 1) + 22] + sh_id[35 * (i - 1) + 27]); end
				if pl_psn[i] > 0 then pl_psn[i] = pl_psn[i] - 1; parse('sethealth '..i..' ' ..player(i,"health") - 5); end
			end
		end
		sh_time = 0
	end
end

function sh_say(id,txt)
	if (txt == say_cmd[1]) then sh_hero_menu(id); return 1; end
	if (txt == say_cmd[2]) then sh_class_menu(id); return 1; end
	if (txt == say_cmd[3]) then sh_reheroes(id); return 1; end
	if (txt == say_cmd[4]) then sh_myheroes(id); return 1; end
	if (txt == say_cmd[5]) then sh_hero_reset(id); sh_msg2(id,4,'Your All Heroes Removed!@C'); pl_pt[id] = sh_pt_start + pl_lvl[id] -1; sh_txt2(id,3,1,'Points: '..pl_pt[id]..'',110,430,0); return 1; end
	if (txt == say_cmd[6]) then sh_items_shop(id); return 1; end
	if (txt == say_cmd[7]) then sh_items_inventory(id); return 1; end
	if (txt == say_cmd[8]) then sh_menu_reset(id); return 1; end
	if (txt == say_cmd[9]) then sh_say_menu(id); return 1; end
	if (string.sub(txt, 1, 10) == say_cmd[10]) then sh_whatstats(id,txt); return 1; end
end

function sh_menu(id,menu,sel)
	if (menu == 'Reset Your Lvl? Sure?') then
		if sel == 1 then
			pl_lvl[id] = sh_lvl_start
			pl_pt[id] = sh_pt_start
			pl_nxp[id] = sh_lvl_ratio
			pl_xp[id] = 0
			sh_txt2(id,2,1,'Level: '..pl_lvl[id]..'/'..sh_lvl_max..'',3,430,0)
			sh_txt2(id,3,1,'Points: '..pl_pt[id]..'',110,430,0)
			sh_txt2(id,4,1,'Exp: ('..pl_xp[id]..'/'..pl_nxp[id]..')',210,430,0)
			sh_msg2(id,3,'Your Lvl Reseted!@C')
			sh_pl_save(id)
		end
		if sel == 2 then
			sh_msg2(id,4,'Refused!@C')
		end
	end
	if (menu == 'Remove Heroes (Page '..(pl_menu_id[id] + 1)..')') then
		if (sel >= 1 and sel <= 7) then
			local s = 8 + 7 * (pl_menu_id[id] - 1)
			local f
			for i = 9 + 7 * (pl_menu_id[id] - 1), 35 do
				if sh_id[35 * (id - 1) + i] > 0 then
					s = s + 1
					f = 35 * (id - 1) + i
					if (sel + 8 + 7 * (pl_menu_id[id] -1) == s) then
						sh_id[f] = sh_id[f] - 1
						pl_pt[id] = pl_pt[id] + sh_req_pt[i]
						sh_msg2(id,6,sh_name[i]..' Hero Removed! +'..sh_req_pt[i]..' Point(s)')
					end
				end
			end
			sh_reheroes_2(id)
		end
		if (sel== 8) then
			if pl_menu_id[id] == 1 then
				sh_reheroes(id)
			else
			pl_menu_id[id] = pl_menu_id[id] - 1
			sh_reheroes_2(id)
			end
		end
		if (sel== 9) then pl_menu_id[id] = pl_menu_id[id] + 1; sh_reheroes_2(id); end
	end
	if (menu == 'Remove Heroes (Page 1)') then
		if (sel >= 1 and sel <= 8) then
			local s = 0
			local f
			for i = 1, 35 do
				if sh_id[35 * (id - 1) + i] > 0 then
					s = s + 1
					f = 35 * (id - 1) + i
					if (sel == s) then
						sh_id[f] = sh_id[f] - 1
						pl_pt[id] = pl_pt[id] + sh_req_pt[i]
						sh_msg2(id,6,sh_name[i]..' Hero Removed! +'..sh_req_pt[i]..' Point(s)')
					end
				end
			end
			sh_reheroes(id); pl_menu_id[id] = 1
		end
		if (sel== 9) then sh_reheroes_2(id); pl_menu_id[id] = 1; end
	end
	if (menu == 'Say Commands') then
		if (sel== 1) then sh_hero_menu(id); end
		if (sel== 2) then sh_class_menu(id); end
		if (sel== 3) then sh_reheroes(id); end
		if (sel== 4) then sh_myheroes(id); end
		if (sel== 5) then sh_hero_reset(id); sh_msg2(id,4,'Your All Heroes Removed!@C'); pl_pt[id] = sh_pt_start + pl_lvl[id] -1; sh_txt2(id,3,1,'Points: '..pl_pt[id]..'',110,430,0); end
		if (sel== 6) then sh_items_shop(id); end
		if (sel== 7) then sh_items_inventory(id); end
		if (sel== 8) then sh_menu_reset(id); end
		if (sel== 9) then sh_say_menu(id); end
	end
	if (menu == 'Inventory') then
		if (sel >= 1 and sel <= 9) then
			if (player(id,"health") > 0) then
			local s = 0
			local f
			for i = 1, 17 do
				if sh_item_inv[17 * (id - 1) + i] > 0 then
					s = s + 1
					f = 17 * (id - 1) + i
					if (sel == s) then
						sh_items_action(id,f)
						sh_item_inv[f] = sh_item_inv[f] - 1
					end
				end
			end
			else
				sh_msg2(id,4,'Dead Cant Use Items!@C')
			end
		end
	end
	if (menu == 'Market - Sell Items') then
		if (sel >= 1 and sel <= 9) then
			local s = 0
			for i = 1, 17 do
				if sh_item_inv[17 * (id - 1) + i] > 0 then
				s = s + 1
				if (sel == s) then
					sh_item_inv[17 * (id - 1) + i] = sh_item_inv[17 * (id - 1) + i] - 1
					pl_credits[id] = pl_credits[id] + sh_item_prices[i]
					sh_msg2(id,2,'('..sh_item_names[i]..') Sold For '..sh_item_prices[i]..' Credits!@C')
				end
				end
			end
		end
	end
	if (menu == 'Power Items') then
		if (sel >= 1 and sel <= 3) then
			if sh_item_inv[17 * (id - 1) + sel + 13] < 1 then
				if pl_credits[id] >= sh_item_prices[sel + 13] then
					pl_credits[id] = pl_credits[id] - sh_item_prices[sel + 13]
					sh_item_inv[17 * (id - 1) + sel + 13] = sh_item_inv[17 * (id - 1) + sel + 13] + 1
					sh_msg2(id,2,'You Bought '..sh_item_names[sel + 13]..'!@C')
					sh_msg2(id,3,'Check Your Inventory!@C')
				else
					sh_msg2(id,4,'You Need More Credits!@C')
				end
			else
				sh_msg2(id,4,'You Already Have This Item!@C')
			end
		end
	end
	if (menu == 'Potion Items') then
		if (sel >= 1 and sel <= 4) then
			if sh_item_inv[17 * (id - 1) + sel + 9] < 1 then
				if pl_credits[id] >= sh_item_prices[sel + 9] then
					pl_credits[id] = pl_credits[id] - sh_item_prices[sel + 9]
					sh_item_inv[17 * (id - 1) + sel + 9] = sh_item_inv[17 * (id - 1) + sel + 9] + 1
					sh_msg2(id,2,'You Bought '..sh_item_names[sel + 9]..'!@C')
					sh_msg2(id,3,'Check Your Inventory!@C')
				else
					sh_msg2(id,4,'You Need More Credits!@C')
				end
			else
				sh_msg2(id,4,'You Already Have This Item!@C')
			end
		end
	end
	if (menu == 'Building Items') then
		if (sel >= 1 and sel <= 9) then
			if sh_item_inv[17 * (id - 1) + sel] < 1 then
				if pl_credits[id] >= sh_item_prices[sel] then
					pl_credits[id] = pl_credits[id] - sh_item_prices[sel]
					sh_item_inv[17 * (id - 1) + sel] = sh_item_inv[17 * (id - 1) + sel] + 1
					sh_msg2(id,2,'You Bought '..sh_item_names[sel]..'!@C')
					sh_msg2(id,3,'Check Your Inventory!@C')
				else
					sh_msg2(id,4,'You Need More Credits!@C')
				end
			else
				sh_msg2(id,4,'You Already Have This Item!@C')
			end
		end
	end
	if (menu == 'Shop - Buy Items (Credits: '..pl_credits[id]..')') then
		if (sel== 1) then sh_items_build(id); end
		if (sel== 2) then sh_items_potion(id); end
		if (sel== 3) then sh_items_powers(id); end
	end
	if (menu == 'Items Menu (Credits: '..pl_credits[id]..')') then
		if (sel== 1) then sh_items_inventory(id); end
		if (sel== 2) then sh_items_shop(id); end
		if (sel== 3) then sh_items_market(id); end
	end
	if (menu == 'Console Commands') then
		if (sel >= 1 and sel <= 9) then
			sh_msg2(id,2,adm_cmd[sel]..''..adm_cmd_inf[sel]..'@C')
		end
	end
	if (menu == 'Super Hero 1.2 Menu') then
		if (sel == 1) then sh_say_menu(id); end
		if (sel == 2) then sh_adm_menu(id); end
		if (sel == 3) then sh_class_menu(id); end
		if (sel == 4) then sh_reheroes(id); pl_menu_id[id] = 1; end
		if (sel == 5) then sh_items_menu(id); end
	end
	if (menu == 'Select Hero Class (Level: '..pl_lvl[id]..')') then
		if (sel >= 1 and sel <= 9) then
			if pl_lvl[id] >= 5 * (sel - 1) then
				pl_menu_id[id] = sel
				sh_menu_render(id,sel)
			else
				sh_msg2(id,4,'You Need To Have '..(5 * (sel - 1))..' Lvl!@C')
			end
		end
	end
	if (menu == sh_class_name[1]..' ('..pl_pt[id]..'/1 Pts)') then
		if (sel >= 1 and sel <= 8) then
			if pl_pt[id] > 0 then
				if sh_limit[sel] > sh_id[35 * (id - 1) + sel] then
					sh_id[35 * (id - 1) + sel] = sh_id[35 * (id - 1) + sel] + 1
					pl_pt[id] = pl_pt[id] - 1
				end
				sh_menu_render(id,sel)
			else
				sh_msg2(id,2,'Most Heroes Will Work After Next Spawn!@C')
				sh_msg2(id,4,'You Need More Points!@C')
			end
		end
		if (sel == 9) then
			sh_class_menu(id)
		end
	end
	if (menu == sh_class_name[2]..' ('..pl_pt[id]..'/'..pl_menu_id[id]..' Pts)' or menu == sh_class_name[3]..' ('..pl_pt[id]..'/'..pl_menu_id[id]..' Pts)' or menu == sh_class_name[4]..' ('..pl_pt[id]..'/'..pl_menu_id[id]..' Pts)' or menu == sh_class_name[5]..' ('..pl_pt[id]..'/'..pl_menu_id[id]..' Pts)' or menu == sh_class_name[6]..' ('..pl_pt[id]..'/'..pl_menu_id[id]..' Pts)' or menu == sh_class_name[7]..' ('..pl_pt[id]..'/'..pl_menu_id[id]..' Pts)') then
		if (sel >= 1 and sel <= 4) then
			if pl_pt[id] >= pl_menu_id[id] then
				if sh_limit[sel + 8 + (pl_menu_id[id] - 2) * 4] > sh_id[35 * (id - 1) + sel + 8 + (pl_menu_id[id] - 2) * 4] then
					sh_id[35 * (id - 1) + sel + 8 + (pl_menu_id[id] - 2) * 4] = sh_id[35 * (id - 1) + sel + 8 + (pl_menu_id[id] - 2) * 4] + 1
					pl_pt[id] = pl_pt[id] - pl_menu_id[id]
				end
				sh_menu_render(id,sel)
			else
				sh_msg2(id,2,'Most Heroes Will Work After Next Spawn!@C')
				sh_msg2(id,4,pl_menu_id[id]..' Points Required!@C')
			end
		end
		if (sel == 5) then
			sh_class_menu(id)
		end
	end
	if (menu == sh_class_name[8]..' ('..pl_pt[id]..'/15 Pts)') then
		if (sel >= 1 and sel <= 2) then
			if pl_pt[id] >= 15 then
				if sh_limit[sel + 32] > sh_id[35 * (id - 1) + sel + 32] then
					sh_id[35 * (id - 1) + sel + 32] = sh_id[35 * (id - 1) + sel + 32] + 1
					pl_pt[id] = pl_pt[id] - 15
				end
				sh_menu_render(id,sel)
			else
				sh_msg2(id,2,'Most Heroes Will Work After Next Spawn!@C')
				sh_msg2(id,4,'15 Points Required!@C')
			end
		end
		if (sel == 3) then
			sh_class_menu(id)
		end
	end
	if (menu == sh_class_name[9]..' ('..pl_pt[id]..'/20 Pts)') then
		if (sel == 1) then
			if pl_pt[id] >= 20 then
				if sh_limit[35] > sh_id[35 * (id - 1) + 35] then
					sh_id[35 * (id - 1) + 35] = sh_id[35 * (id - 1) + 35] + 1
					pl_pt[id] = pl_pt[id] - 20
				end
				sh_menu_render(id,sel)
			else
				sh_msg2(id,2,'Most Heroes Will Work After Next Spawn!@C')
				sh_msg2(id,4,'20 Points Required!@C')
			end
		end
		if (sel == 2) then
			sh_class_menu(id)
		end
	end
	sh_txt2(id,6,3,'Credits: ('..pl_credits[id]..'/'..sh_credits_max..')',210,415,0)
	sh_txt2(id,3,1,'Points: '..pl_pt[id]..'',110,430,0)
end

function sh_startround()
	if sh_wpn_rounds == 1 then sh_wpn_set(); end
	local win
	local lose
	if game("winrow_ct") > 0 then win = 2; lose = 1; end
	if game("winrow_t") > 0 then win = 1; lose = 2; end
	for i = 1, pl_count do
		if player(i,"team") == win then
			sh_msg2(i,2,'You get extra '..(3 * sh_xp_ratio)..' Exp For Wining Round!@C'); pl_xp[i] = pl_xp[i] + 3 * sh_xp_ratio
			sh_snd2(i,'superhero/sh_rnd_win.ogg')
			sh_lvl_up(i)
		end
		if player(i,"team") == lose then
			sh_snd2(i,'superhero/sh_rnd_lose.ogg')
		end
	end
end

function sh_die(id,iid,type)
	if (type<51 or type > 71) then
		return 1
	end
end

function sh_drop(id,iid,type)
	if (type<51 or  type > 71) then
		return 1
	end
end

function sh_walkover(id,iid,type)
	if (type<51 or type > 71) then
		return 1
	end
end

function sh_buy(id)
	sh_msg2(id,4,'Buying Disabled!@C')
	return 1
end

function sh_buildattempt(id,type,x,y)
	if type == 8 then parse('mp_building_limit "turret" '..sh_id[35 * (id - 1) + 14]); end
end