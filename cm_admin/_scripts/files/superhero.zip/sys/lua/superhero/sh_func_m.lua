-- Super Hero Mini Functions

function sh_xp_gain(id,victim,wpn)
	if player(id,"team") ~= player(victim,"team") then
	if sh_id[35 * (id - 1) + 17] > 0 then
		parse('sethealth '..id..' ' ..player(id,"health") + 15 * sh_id[35 * (id - 1) + 17])
		sh_msg2(id,2,'Vampiric Drain! + '..(15 * sh_id[35 * (id - 1) + 17])..' Hp')
	end
	if pl_credits[id] < sh_credits_max then
		pl_credits[id] = pl_credits[id] + sh_credits_kill
	else
		pl_credits[id] = sh_credits_max
	end
	if (wpn == 50) then
		sh_msg(5,player(id,"name")..' Humiliated '..player(victim,"name")..'!@C')
		sh_msg2(id,3,'You Get Extra '..(2 * sh_xp_ratio)..' Exp For Humiliation!@C')
		sh_snd('fun/humiliation.wav')
		pl_xp[id] = pl_xp[id] + 2 * sh_xp_ratio
	end
	pl_xp[id] = pl_xp[id] + 2 * sh_xp_ratio
	if pl_lvl[victim] > pl_lvl[id] then
		pl_xp[id] = pl_xp[id] + sh_xp_ratio* (pl_lvl[victim] - pl_lvl[id])
		sh_msg2(id,2,'You Killed Stronger Player!@C')
		sh_msg2(id,3,'You Get Extra '..(sh_xp_ratio * (pl_lvl[victim] - pl_lvl[id]))..' Exp!@C')
	end
	end
	sh_txt2(id,4,1,'Exp: ('..pl_xp[id]..'/'..pl_nxp[id]..')',210,430,0)
	sh_txt2(id,6,3,'Credits: ('..pl_credits[id]..'/'..sh_credits_max..')',210,415,0)
end

function sh_lvl_up(id)
	if pl_lvl[id] < sh_lvl_max then
		while pl_nxp[id] <= pl_xp[id] do
			sh_msg2(id,2,'Level Up!@C')
			pl_lvl[id] = pl_lvl[id] + 1
			pl_pt[id] = pl_pt[id] + sh_pt_lvl
			pl_nxp[id] = pl_nxp[id] + pl_lvl[id] * sh_lvl_ratio
			sh_snd2(id,'superhero/sh_levelup.wav')
			sh_msg(5,player(id,"name")..' Reached Lvl '..pl_lvl[id]..'!')
			sh_txt2(id,2,1,'Level: '..pl_lvl[id]..'/'..sh_lvl_max..'',3,430,0)
			sh_txt2(id,4,1,'Exp: ('..pl_xp[id]..'/'..pl_nxp[id]..')',210,430,0)
			sh_txt2(id,3,1,'Points: '..pl_pt[id]..'',110,430,0)
			for i = 2, 9 do
				if pl_lvl[id] == 5 * (i - 1) then		
					sh_msg2(id,6,sh_class_name[i]..' Unlocked!@C')
					sh_snd2(id,'superhero/sh_unlock.ogg')
				end
			end
		end
	end
end

function sh_wpn_rnd(id)
	if sh_wpn_rounds == 1 then
		parse('equip '..id..' '..wpn_lvl[wpn_rnd])
		parse('setweapon  '..id..' '..wpn_lvl[wpn_rnd])
	end
end

function sh_wpn_set()
	local i
	for i = 1,pl_count do
		if (player(i,"exists")) then
			parse('strip '..i..' '..wpn_lvl[wpn_rnd])
		end
	end
	wpn_rnd = wpn_rnd + 1
	if (wpn_rnd ># wpn_lvl) then wpn_rnd = 1; end
	for i = 1,pl_count do
		if (player(i,"exists")) then
			parse('equip '..i..' '..wpn_lvl[wpn_rnd])
			parse('setweapon  '..i..' '..wpn_lvl[wpn_rnd])
		end
	end
	sh_msg(3,itemtype(wpn_lvl[wpn_rnd],"name")..' Round!@C')
end

function totable(t,match)
	local cmd = {}
	if not match then match = "[^%s]+" end
	for word in string.gmatch(t, match) do
		table.insert(cmd, word)
	end 
	return cmd 
end

function sh_pl_load(id)
	if pl_load[id] == 0 then
		if (player(id,"usgn") > 0) then
			sh_txt2(id,5,2,'Login as: '..player(id,"usgn"),3,415,0)
			sh_msg2(id,3,'Your U.S.G.N ID: '..player(id,"usgn")..'@C')
			local usgn = player(id, "usgn")
			ld_data = io.open(sh_dir..'sh_data/'..player(id,"usgn")..'.txt','r')
			if (ld_data ~= nil) then
				sh_msg2(id,2,'Your Save File Found!@C')
				for line in io.lines(sh_dir..'sh_data/'..player(id,"usgn")..'.txt','r') do
					local parses = totable(line)
					if (tonumber(parses[1]) > 0) then
						pl_xp[id] = tonumber(parses[1])
						local i = 0; local f = 0
						while pl_xp[id] >= f and i < sh_lvl_max do
							i = i + 1
							f = f + sh_lvl_ratio * i
						end
						if (i > sh_lvl_max) then i = sh_lvl_max end
						pl_lvl[id] = i
						pl_pt[id] = sh_pt_start + sh_pt_lvl * (pl_lvl[id] - 1)
						pl_nxp[id] = f
						ld_data:close()
					end
				end
			else
				sh_msg2(id,4,'Failed To Load Save!@C')
				pl_xp[id] = 0
			end
		else
			sh_txt2(id,5,4,'Failed to login!',3,415,0) ;sh_msg2(id,4,'Please check your U.S.G.N account settings!@C')
		end
		if pl_xp[id] == 0 or (player(id,"usgn") < 1) then
			pl_xp[id] = 0
			pl_lvl[id] = sh_lvl_start
			pl_nxp[id] = sh_lvl_ratio
			pl_pt[id] = sh_pt_start
		end
		pl_load[id] = 1
	end
end

function sh_pl_save(id)
	if (player(id,"usgn") > 0) then
		file = assert(io.open(sh_dir..'sh_data/'..player(id,"usgn")..'.txt','w'))
		file:write(pl_xp[id])
		file:close()
	end
end

function sh_hero_reset(id)
	local i
	for i = (id - 1) * 35 + 1,(id - 1) * 35 + 35 do
		sh_id[i] = 0
	end
end

function sh_item_reset(id)
	local i
	for i = (id - 1) * 17 + 1,(id - 1) * 17 + 17 do
		sh_item_inv[i] = 0
	end
end
aut = 'Bla'
function sh_hero_menu(id)
	menu(id,'Super Hero 1.2 Menu,Say Commands|(Client),Console Commands|(Admin),Select Heroes|(Client),Remove Heroes|(Client),Items Menu|(Client)')
end

function sh_menu_reset(id)
	if pl_lvl[id] >= sh_lvl_max then
		menu(id,'Reset Your Lvl? Sure?,Yes|Reset Lvl,No|Refuse')
	else
		sh_msg2(id,4,'You Arent Max Level ('..sh_lvl_max ..')!@C')
	end
end

function sh_items_menu(id)
	menu(id,'Items Menu (Credits: '..pl_credits[id]..'),Inventory Menu|Use Items,Shop|Buy Items,Market|Sell Items')
end

function sh_items_shop(id)
	if sh_shop == 1 then
		menu(id,'Shop - Buy Items (Credits: '..pl_credits[id]..'),Buildings|,Potions|,Temp. Powers|')
	else
		sh_msg2(id,4,'Items Feature Disabled By Hoster!@C')
	end
end

function sh_items_build(id)
	for i = 1, 9 do
		sh_heroes = sh_heroes..''..sh_item_names[i]..'|'..sh_item_prices[i]..' Credits,'
	end
	menu(id,'Building Items,'..sh_heroes)
	sh_heroes = ''
end

function sh_items_potion(id)
	for i = 10, 13 do
		sh_heroes = sh_heroes..''..sh_item_names[i]..'|'..sh_item_prices[i]..' Credits,'
	end
	menu(id,'Potion Items,'..sh_heroes)
	sh_heroes = ''
end

function sh_items_powers(id)
	for i = 14, 16 do
		sh_heroes = sh_heroes..''..sh_item_names[i]..'|'..sh_item_prices[i]..' Credits,'
	end
	menu(id,'Power Items,'..sh_heroes)
	sh_heroes = ''
end
autt = 'zzingxx'
function sh_class_menu(id)
	for i = 1, 9 do
		if pl_lvl[id] >= 5 * (i - 1) then
			sh_heroes= sh_heroes..''..sh_class_name[i]..'|Require '..(5 * (i - 1))..' lvl,'
		else
			sh_heroes= sh_heroes..'(Locked Class)|Require '..(5 * (i - 1))..' lvl,'
		end
	end
	menu(id,'Select Hero Class (Level: '..pl_lvl[id]..'),'..sh_heroes)	
	sh_heroes = ''
end

function sh_menu_render(id,sel)
	if pl_menu_id[id] == 1 then
		for i = 1, 8 do
			sh_heroes = sh_heroes..''..sh_name[i]..' ('..sh_id[35 * (id - 1) + i]..'/'..sh_limit[i]..')|'..sh_power[i]..','
		end
		menu(id,sh_class_name[1]..' ('..pl_pt[id]..'/1 Pts),'..sh_heroes..''..sh_btn[2])
	end
	if (pl_menu_id[id] > 1 and pl_menu_id[id] <= 7)  then
		for i = 1, 4 do
			sh_heroes = sh_heroes..''..sh_name[i + 8 + (pl_menu_id[id] - 2) * 4]..' ('..sh_id[35 * (id - 1) + i + 8 + (pl_menu_id[id] - 2) * 4]..'/'..sh_limit[i + 8 + (pl_menu_id[id] - 2) * 4]..')|'..sh_power[i + 8 + (pl_menu_id[id] - 2) * 4]..','
		end
		menu(id,sh_class_name[pl_menu_id[id]]..' ('..pl_pt[id]..'/'..pl_menu_id[id]..' Pts),'..sh_heroes..''..sh_btn[2])
	end
	if pl_menu_id[id] == 8 then
		for i = 1, 2 do
			sh_heroes = sh_heroes..''..sh_name[i + 32]..' ('..sh_id[35 * (id - 1) + i + 32]..'/'..sh_limit[i + 32]..')|'..sh_power[i + 32]..','
		end
		menu(id,sh_class_name[8]..' ('..pl_pt[id]..'/15 Pts),'..sh_heroes..''..sh_btn[2])
	end
	if pl_menu_id[id] == 9 then
		menu(id,sh_class_name[9]..' ('..pl_pt[id]..'/20 Pts),'..sh_name[35]..' ('..sh_id[35 * (id - 1) + 35]..'/'..sh_limit[35]..')|'..sh_power[35]..','..sh_btn[2])
	end
	sh_heroes = ''
end

function sh_say_menu(id)
	for i = 1, 9 do
		sh_heroes = sh_heroes..''..say_cmd[i]..'|'..say_cmd_inf[i]..','
	end
	menu(id,'Say Commands,'..sh_heroes)
	sh_heroes = ''
end

function sh_adm_menu(id)
	for i = 1, 6 do
		sh_heroes = sh_heroes..''..adm_cmd[i]..'|(Admin),'
	end
	menu(id,'Console Commands,'..sh_heroes)
	sh_heroes = ''
end

function sh_items_inventory(id)
	for i = 1, 17 do
		if sh_item_inv[17 * (id - 1) + i] > 0 then
			sh_heroes = sh_heroes..''..sh_item_names[i]..' ('..sh_item_inv[17 * (id - 1) + i]..'/1)|,'
		end
	end
	menu(id,'Inventory,'..sh_heroes)
	sh_heroes = ''
end

function sh_items_market(id)
	if sh_shop == 1 then
		for i = 1, 16 do
			if sh_item_inv[17 * (id - 1) + i] > 0 then
				sh_heroes = sh_heroes..''..sh_item_names[i]..' ('..sh_item_inv[17 * (id - 1) + i]..'/1)|,'
			end
		end
		menu(id,'Market - Sell Items,'..sh_heroes)
		sh_heroes = ''
	else
		sh_msg2(id,4,'Items Feature Disabled By Hoster!@C')
	end
end

function sh_diablo(id,x,y)
	sh_msg(3,player(id,"name")..' Used Evil Wrath!')
	sh_explosion(id,135,x,y)
	sh_explosion(id,195,x + 120,y + 120)
	sh_explosion(id,195,x + 120,y - 120)
	sh_explosion(id,195,x - 120,y - 120)
	sh_explosion(id,195,x - 120,y + 120)
	sh_explosion(id,195,x,y + 120)
	sh_explosion(id,195,x,y - 120)
	sh_explosion(id,195,x - 120,y)
	sh_explosion(id,195,x + 120,y)
end

function sh_items_action(id,action)
	if action == 17 * (id - 1) + 1 then sh_build_wall_1(id,player(id,"team"),player(id,"tilex"),player(id,"tiley"));	end
	if action == 17 * (id - 1) + 2 then sh_build_wall_2(id,player(id,"team"),player(id,"tilex"),player(id,"tiley")); end
	if action == 17 * (id - 1) + 3 then sh_build_wall_3(id,player(id,"team"),player(id,"tilex"),player(id,"tiley")); end
	if action == 17 * (id - 1) + 4 then sh_build_mine_1(id,player(id,"team"),player(id,"tilex"),player(id,"tiley"));	end
	if action == 17 * (id - 1) + 5 then sh_build_mine_2(id,player(id,"team"),player(id,"tilex"),player(id,"tiley")); end
	if action == 17 * (id - 1) + 6 then sh_build_mine_3(id,player(id,"team"),player(id,"tilex"),player(id,"tiley")); end
	if action == 17 * (id - 1) + 7 then sh_build_base_1(id,player(id,"team"),player(id,"tilex"),player(id,"tiley")); end
	if action == 17 * (id - 1) + 8 then sh_build_base_2(id,player(id,"team"),player(id,"tilex"),player(id,"tiley"));	end
	if action == 17 * (id - 1) + 9 then sh_build_base_3(id,player(id,"team"),player(id,"tilex"),player(id,"tiley")); end
	if action == 17 * (id - 1) + 10 then parse("sethealth "..id.." "..player(id,"health") + 25); end
	if action == 17 * (id - 1) + 11 then parse("sethealth "..id.." "..player(id,"health") + 50); end
	if action == 17 * (id - 1) + 12 then parse("sethealth "..id.." "..player(id,"health") + 75); end
	if action == 17 * (id - 1) + 13 then parse("sethealth "..id.." "..player(id,"health") + 100); end
	if action == 17 * (id - 1) + 14 then sh_explosion(id,250,player(id,"x"),player(id,"y")); end
	if action == 17 * (id - 1) + 15 then sh_explosion(id,400,player(id,"x"),player(id,"y")); end
	if action == 17 * (id - 1) + 16 then sh_explosion(id,650,player(id,"x"),player(id,"y")); end
	if action == 17 * (id - 1) + 17 then sh_diablo(id,player(id,"x"),player(id,"y")); end
end

function sh_heroes_action(id)
	sh_health(id,5 * sh_id[35 * (id - 1) + 1] + 5 * sh_id[35 * (id - 1) + 9] + 20 * sh_id[35 * (id - 1) + 15] + 35 * sh_id[35 * (id - 1) + 31])
	sh_armor(id,5 * sh_id[35 * (id - 1) + 2] + 5 * sh_id[35 * (id - 1) + 9] + 30 * sh_id[35 * (id - 1) + 22])
	sh_speed(id,sh_id[35 * (id - 1) + 3] + 2 * sh_id[35 * (id - 1) + 12] + sh_id[35 * (id - 1) + 22] + 2* sh_id[35 * (id - 1) + 27])
	if sh_id[35 * (id - 1) + 4] > 0 then sh_equip(id,75); end
	if sh_id[35 * (id - 1) + 5] > 0 then sh_equip(id,88); end
	if sh_id[35 * (id - 1) + 6] > 0 then sh_equip(id,59); end
	if sh_id[35 * (id - 1) + 11] > 0 then sh_equip(id,73); end
	if sh_id[35 * (id - 1) + 13] > 0 then sh_equip(id,87); end
	if sh_id[35 * (id - 1) + 14] > 0 then sh_equip(id,74); end
	if sh_id[35 * (id - 1) + 16] > 0 then sh_equip(id,85); end
	if sh_id[35 * (id - 1) + 18] > 0 then sh_equip(id,77); end
	if sh_id[35 * (id - 1) + 20] > 0 then sh_equip(id,78); end
	if sh_id[35 * (id - 1) + 24] > 0 then sh_equip(id,49); end
	if sh_id[35 * (id - 1) + 26] > 0 then sh_equip(id,48); end
	if sh_id[35 * (id - 1) + 28] > 0 then sh_equip(id,69); end
	if sh_id[35 * (id - 1) + 30] > 0 then sh_equip(id,46); end
	if sh_id[35 * (id - 1) + 32] > 0 then sh_equip(id,76); end
	if sh_id[35 * (id - 1) + 33] > 0 then sh_equip(id,47); end
	if sh_id[35 * (id - 1) + 34] > 0 then sh_equip(id,84); end
end

function sh_myheroes(id)
	sh_msg2(id,3,'Your Heroes:')
	local i
	for i = 1,35 do
		if sh_id[(id - 1) * 35 + i] > 0 then sh_msg2(id,1,sh_name[i]..' ('..sh_id[(id - 1) * 35 + i]..'/'..sh_limit[i]..') - '..sh_power[i]); end
	end
end

function sh_reheroes(id)
	pl_menu_id[id] = 1
	local i ; local f = 0
	for i = 1, 35 do
		if sh_id[(id - 1) * 35 + i] > 0 then
			f = f + 1
			if f < 9 then sh_heroes = sh_heroes..''..sh_name[i]..' ('..sh_id[35 * (id - 1) + i]..'/'..sh_limit[i]..')|'..sh_power[i]..',' ; end
		end
	end
	if f > 8 then
		sh_heroes = sh_heroes..''..sh_btn[1]
	end
	menu(id,'Remove Heroes (Page 1),'..sh_heroes)
	sh_heroes = ''
end

function sh_reheroes_2(id)
	local i ; local f = 0
	for i = 9 + 7 * (pl_menu_id[id] - 1), 35 do
		if sh_id[(id - 1) * 35 + i] > 0 then
			f = f + 1
			if f < 8 then sh_heroes = sh_heroes..''..sh_name[i]..' ('..sh_id[35 * (id - 1) + i]..'/'..sh_limit[i]..')|'..sh_power[i]..',' ; end
		end
	end
	if f < 7 then
		for i = 1, 7 - f do
			sh_heroes = sh_heroes..','
		end
	end
	sh_heroes = sh_heroes..''..sh_btn[2]..','
	if f > 7 then
		sh_heroes = sh_heroes..''..sh_btn[1]
	end
	menu(id,'Remove Heroes (Page '..(pl_menu_id[id] + 1)..'),'..sh_heroes)
	sh_heroes = ''
end

function sh_whatstats(id,txt)
	local parses = totable(txt)
	local target = tonumber(parses[2])
	local i
	if (target ~= nil) and player(target,"exists") then
		sh_msg(6,player(id,"name")..' Watching '..player(target,"name")..' Stats!')
		sh_msg2(id,3,'=== '..player(target,"name")..' Stats ===')
		sh_msg2(id,2,'Level: '..pl_lvl[target])
		sh_msg2(id,2,'Experience: '..pl_xp[target]..'/'..pl_nxp[target])
		sh_msg2(id,2,'Credits: '..pl_credits[target])
		sh_msg2(id,3,'== '..player(target,"name")..' Heroes ===')
		for i = 1,35 do
			if sh_id[(target - 1) * 35 + i] > 0 then sh_msg2(id,2,sh_name[i]..' ('..sh_id[(target - 1) * 35 + i]..'/'..sh_limit[i]..') - '..sh_power[i]); end
		end
		
	else
		sh_msg2(id,4,'Wrong Command Parameters!')
	end
end